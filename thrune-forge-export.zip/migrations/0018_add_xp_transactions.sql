-- XP Transactions table for tracking XP history
CREATE TABLE xp_transactions (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    character_id UUID NOT NULL,
    amount INTEGER NOT NULL,
    transaction_type VARCHAR(50) NOT NULL,
    reason TEXT NOT NULL,
    skill_id UUID,
    body_points INTEGER,
    stamina_points INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_xp_transactions_character_id FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    CONSTRAINT fk_xp_transactions_skill_id FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE SET NULL,
    CONSTRAINT xp_transactions_type_check CHECK (transaction_type IN ('initial', 'skill_purchase', 'skill_refund', 'body_purchase', 'stamina_purchase', 'event_reward', 'admin_adjustment'))
);