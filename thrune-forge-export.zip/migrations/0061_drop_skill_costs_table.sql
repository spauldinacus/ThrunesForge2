-- Drop the skill_costs table as we're using archetype_primary_skills and archetype_secondary_skills instead
DROP TABLE IF EXISTS skill_costs CASCADE;