-- Create system_milestones table for automatic milestone definitions
CREATE TABLE IF NOT EXISTS system_milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    category VARCHAR(100) NOT NULL, -- e.g., 'events', 'xp', 'skills', 'social', 'mechanical'
    milestone_type VARCHAR(50) NOT NULL, -- e.g., 'event_count', 'xp_total', 'skill_count', 'candle_transactions', 'character_age'
    threshold_value INTEGER NOT NULL, -- e.g., 5 for "attend 5 events", 50 for "reach 50 XP"
    enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE system_milestones IS 'Definitions for automatic milestones tracked by the system';
COMMENT ON COLUMN system_milestones.milestone_type IS 'Type of milestone for automatic calculation (event_count, xp_total, skill_count, etc.)';
COMMENT ON COLUMN system_milestones.threshold_value IS 'Value required to complete this milestone';
COMMENT ON COLUMN system_milestones.enabled IS 'Whether this milestone is active and should be tracked';

-- Create player_milestones table for tracking milestone progress
CREATE TABLE IF NOT EXISTS player_milestones (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
    system_milestone_id UUID REFERENCES system_milestones(id) ON DELETE CASCADE,
    is_custom BOOLEAN NOT NULL DEFAULT false,
    custom_name VARCHAR(255),
    custom_description TEXT,
    custom_category VARCHAR(100),
    current_progress INTEGER DEFAULT 0,
    target_progress INTEGER,
    completed_at TIMESTAMPTZ,
    notes TEXT,
    shared_with_staff BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT valid_milestone_type CHECK (
        (is_custom = true AND custom_name IS NOT NULL AND custom_description IS NOT NULL) OR
        (is_custom = false AND system_milestone_id IS NOT NULL)
    )
);

COMMENT ON TABLE player_milestones IS 'Player milestone tracking for both system and custom milestones';
COMMENT ON COLUMN player_milestones.is_custom IS 'True for player-created milestones, false for system milestones';
COMMENT ON COLUMN player_milestones.current_progress IS 'Current progress towards milestone (for trackable milestones)';
COMMENT ON COLUMN player_milestones.target_progress IS 'Target progress for custom milestones';
COMMENT ON COLUMN player_milestones.shared_with_staff IS 'Whether this milestone is visible to staff/admins';

CREATE INDEX idx_player_milestones_character ON player_milestones(character_id);
CREATE INDEX idx_player_milestones_system ON player_milestones(system_milestone_id);
CREATE INDEX idx_player_milestones_shared ON player_milestones(shared_with_staff) WHERE shared_with_staff = true;

-- Create journal_entries table for character journals
CREATE TABLE IF NOT EXISTS journal_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    tags TEXT[], -- Array of tags for categorization
    event_id UUID REFERENCES events(id) ON DELETE SET NULL,
    shared_with_staff BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

COMMENT ON TABLE journal_entries IS 'Character journal entries for roleplay and session notes';
COMMENT ON COLUMN journal_entries.tags IS 'Array of tags for filtering and categorization';
COMMENT ON COLUMN journal_entries.event_id IS 'Optional link to a specific event';
COMMENT ON COLUMN journal_entries.shared_with_staff IS 'Whether this journal entry is visible to staff/admins';

CREATE INDEX idx_journal_entries_character ON journal_entries(character_id);
CREATE INDEX idx_journal_entries_event ON journal_entries(event_id);
CREATE INDEX idx_journal_entries_shared ON journal_entries(shared_with_staff) WHERE shared_with_staff = true;
CREATE INDEX idx_journal_entries_created ON journal_entries(created_at DESC);

-- Add VIEW_SHARED_MILESTONES permission
INSERT INTO permissions (name, description)
VALUES ('view_shared_milestones', 'View player milestones and journals shared with staff')
ON CONFLICT (name) DO NOTHING;