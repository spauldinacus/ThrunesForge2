-- Backfill email addresses for existing player profiles from Stack Auth
UPDATE public.player_profiles 
SET email = users_sync.email
FROM neon_auth.users_sync 
WHERE player_profiles.user_id = users_sync.id 
  AND player_profiles.email IS NULL
  AND users_sync.email IS NOT NULL;