-- Add is_admin field to player_profiles table
ALTER TABLE public.player_profiles 
ADD COLUMN is_admin BOOLEAN DEFAULT FALSE;

-- Set James Spaulding as admin (using the UUID we know works)
UPDATE public.player_profiles 
SET is_admin = TRUE 
WHERE user_id = '2dffe81f-4441-4149-acb2-c54f6768cc1c';

-- Also update any existing test users to be admin for testing
UPDATE public.player_profiles 
SET is_admin = TRUE 
WHERE user_id IN ('test-admin-user', 'admin-user-123', 'admin-test-user');

-- Add index for performance
CREATE INDEX idx_player_profiles_is_admin ON public.player_profiles(is_admin) WHERE is_admin = TRUE;