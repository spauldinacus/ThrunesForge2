
-- Add character_reassignment permission to Super Admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    r.id as role_id,
    p.id as permission_id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'Super Admin'
AND p.name = 'character_reassignment'
AND NOT EXISTS (
    SELECT 1 FROM role_permissions rp2
    WHERE rp2.role_id = r.id
    AND rp2.permission_id = p.id
);
