-- Add benefit_name and weakness_name fields to heritages table
ALTER TABLE heritages 
ADD COLUMN benefit_name VARCHAR(255),
ADD COLUMN weakness_name VARCHAR(255);