-- Backfill from character_reassignment_history
INSERT INTO audit_logs (id, created_at, performed_by_user_id, action_type, action, entity_id, entity_type, details)
SELECT 
    gen_random_uuid(),
    reassigned_at,
    reassigned_by,
    'character',
    'reassign',
    character_id,
    'character',
    jsonb_build_object(
        'from_player_id', from_player_id,
        'to_player_id', to_player_id,
        'notes', notes
    )
FROM character_reassignment_history;

-- Backfill from lore_submissions (creation)
INSERT INTO audit_logs (id, created_at, performed_by_user_id, action_type, action, entity_id, entity_type, details)
SELECT 
    gen_random_uuid(),
    created_at,
    created_by,
    'lore',
    'create',
    id,
    'lore_submission',
    jsonb_build_object(
        'event_id', event_id,
        'chapter_id', chapter_id,
        'character_id', character_id,
        'outcome', outcome
    )
FROM lore_submissions
WHERE created_by IS NOT NULL;

-- Backfill from candle_transactions (admin grants/deductions)
-- Note: We need to join with player_profiles to get the user_id if granted_by_user_id is missing, 
-- but candle_transactions has granted_by_user_id which is what we want.
INSERT INTO audit_logs (id, created_at, performed_by_user_id, action_type, action, entity_id, entity_type, details)
SELECT 
    gen_random_uuid(),
    created_at,
    granted_by_user_id,
    'candle',
    'transaction',
    player_profile_id, -- Using player profile as entity
    'player_profile',
    jsonb_build_object(
        'amount', amount,
        'reason', reason,
        'used_for', used_for
    )
FROM candle_transactions
WHERE granted_by_user_id IS NOT NULL;

-- Backfill from xp_transactions (admin adjustments)
-- Note: xp_transactions doesn't store who performed it directly in a separate column usually, 
-- but let's check if we can infer it or if it's missing.
-- The current schema for xp_transactions doesn't seem to have 'performed_by'.
-- However, we can try to extract from reason if it was logged there, or just skip if we can't attribute it.
-- For now, we will skip XP transactions backfill if we cannot identify the admin.
