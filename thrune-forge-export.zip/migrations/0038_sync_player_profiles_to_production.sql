-- Insert player profiles from development to production
INSERT INTO player_profiles (user_id, first_name, last_name, phone_number, player_number, chapter_id, candles_available, is_admin)
VALUES 
  ('2dffe81f-4441-4149-acb2-c54f6768cc1c', 'James', 'Spaulding', '5088181795', 'FL2501019', '3ab8194f-03a4-412d-be45-2cccf1f0cb3b', 200, true),
  ('test-user-id', 'James', 'Spaulding', null, 'ADMIN001', '3ab8194f-03a4-412d-be45-2cccf1f0cb3b', 0, true),
  ('0d809af0-5fdc-45db-baee-eb7775bbf606', 'James', 'Spaulding', '5088181795', 'FL2508002', '3ab8194f-03a4-412d-be45-2cccf1f0cb3b', 0, false)
ON CONFLICT (user_id) DO UPDATE SET
  first_name = EXCLUDED.first_name,
  last_name = EXCLUDED.last_name,
  phone_number = EXCLUDED.phone_number,
  player_number = EXCLUDED.player_number,
  chapter_id = EXCLUDED.chapter_id,
  candles_available = EXCLUDED.candles_available,
  is_admin = EXCLUDED.is_admin;