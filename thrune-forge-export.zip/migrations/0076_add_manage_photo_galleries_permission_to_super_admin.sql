-- Insert the manage_photo_galleries permission
INSERT INTO permissions (id, name, description)
VALUES (
    gen_random_uuid(),
    'manage_photo_galleries',
    'Can create, update, and delete photo galleries'
)
ON CONFLICT (name) DO NOTHING;

-- Add the permission to Super Admin role (dynamically look up role ID)
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    r.id,
    p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'Super Admin'
AND p.name = 'manage_photo_galleries'
AND NOT EXISTS (
    SELECT 1 FROM role_permissions rp
    WHERE rp.role_id = r.id
    AND rp.permission_id = p.id
);