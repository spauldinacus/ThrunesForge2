CREATE TABLE public.test_characters (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    user_id text NOT NULL,
    name character varying(255) NOT NULL,
    heritage_id uuid NOT NULL REFERENCES heritages(id),
    culture_id uuid NOT NULL REFERENCES cultures(id),
    archetype_id uuid NOT NULL REFERENCES archetypes(id),
    secondary_archetype_id uuid REFERENCES archetypes(id),
    tertiary_archetype_id uuid REFERENCES archetypes(id),
    body integer DEFAULT 10 NOT NULL,
    stamina integer DEFAULT 10 NOT NULL,
    corruption integer DEFAULT 0,
    deaths integer DEFAULT 0,
    selected_skills jsonb DEFAULT '[]'::jsonb,
    xp_cost integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT test_characters_body_check CHECK ((body >= 1) AND (body <= 200)),
    CONSTRAINT test_characters_stamina_check CHECK ((stamina >= 1) AND (stamina <= 200)),
    CONSTRAINT test_characters_corruption_check CHECK ((corruption >= 0) AND (corruption <= 10)),
    CONSTRAINT test_characters_deaths_check CHECK ((deaths >= 0) AND (deaths <= 10))
);

COMMENT ON TABLE public.test_characters IS 'Experimental test characters for player build testing - not usable in events';
COMMENT ON COLUMN public.test_characters.user_id IS 'Stack Auth user ID - limit 3 per user';
COMMENT ON COLUMN public.test_characters.xp_cost IS 'Calculated XP cost - no limit enforced for experimentation';

CREATE INDEX idx_test_characters_user_id ON public.test_characters(user_id);