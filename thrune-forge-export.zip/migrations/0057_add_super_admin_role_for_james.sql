-- Add Super Admin role for James Spaulding (user_id: 0d809af0-5fdc-45db-baee-eb7775bbf606)
-- This works for both dev and prod by finding the profile via user_id
INSERT INTO public.player_roles (id, player_profile_id, role_id, assigned_at, assigned_by_user_id)
SELECT 
    gen_random_uuid(),
    pp.id,
    r.id,
    NOW(),
    pp.user_id
FROM public.player_profiles pp
CROSS JOIN public.roles r
WHERE pp.user_id = '0d809af0-5fdc-45db-baee-eb7775bbf606'
  AND r.name = 'Super Admin'
  AND NOT EXISTS (
    SELECT 1 FROM public.player_roles pr 
    WHERE pr.player_profile_id = pp.id 
    AND pr.role_id = r.id
  );