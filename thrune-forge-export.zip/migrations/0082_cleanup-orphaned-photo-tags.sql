
-- Remove photo tags where the referenced photo no longer exists in gallery_photos
DELETE FROM public.photo_tags
WHERE photo_id NOT IN (
    SELECT id::text FROM public.gallery_photos
);
