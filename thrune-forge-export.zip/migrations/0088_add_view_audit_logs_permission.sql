-- Add view_audit_logs permission
INSERT INTO permissions (id, name, description)
VALUES (gen_random_uuid(), 'view_audit_logs', 'Can view system audit logs')
ON CONFLICT (name) DO NOTHING;

-- Assign to Super Admin
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r, permissions p
WHERE r.name = 'Super Admin' AND p.name = 'view_audit_logs'
ON CONFLICT DO NOTHING;