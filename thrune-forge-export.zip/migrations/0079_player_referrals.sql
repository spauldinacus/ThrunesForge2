-- Add referral tracking columns to player_profiles table
ALTER TABLE player_profiles 
ADD COLUMN referred_by_player_id UUID REFERENCES player_profiles(id) ON DELETE SET NULL,
ADD COLUMN referral_acknowledged BOOLEAN DEFAULT FALSE NOT NULL,
ADD COLUMN referral_acknowledged_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN referral_acknowledged_by_user_id TEXT;

-- Add indexes for faster referral lookups
CREATE INDEX idx_player_profiles_referred_by ON player_profiles(referred_by_player_id);
CREATE INDEX idx_player_profiles_referral_acknowledged ON player_profiles(referral_acknowledged);

-- Add comments
COMMENT ON COLUMN player_profiles.referred_by_player_id IS 'Player who referred this player';
COMMENT ON COLUMN player_profiles.referral_acknowledged IS 'Whether admin has acknowledged this referral (locks it)';
COMMENT ON COLUMN player_profiles.referral_acknowledged_at IS 'When the referral was acknowledged by admin';
COMMENT ON COLUMN player_profiles.referral_acknowledged_by_user_id IS 'User ID of admin who acknowledged the referral';