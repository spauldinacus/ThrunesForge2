-- Add retired column
ALTER TABLE characters ADD COLUMN retired BOOLEAN NOT NULL DEFAULT false;

-- Convert death_2 from integer to boolean properly
ALTER TABLE characters ALTER COLUMN death_2 DROP DEFAULT;
ALTER TABLE characters ALTER COLUMN death_2 TYPE BOOLEAN USING (death_2 > 0);
ALTER TABLE characters ALTER COLUMN death_2 SET DEFAULT false;