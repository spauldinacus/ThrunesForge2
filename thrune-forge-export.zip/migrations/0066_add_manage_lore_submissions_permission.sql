
-- Add manage_lore_submissions permission to the permissions table
INSERT INTO permissions (id, name, description)
VALUES (
    '5ccecf59-c00b-4105-86b7-d31c9cfe37a8',
    'manage_lore_submissions',
    'Can create, edit, and delete lore research submissions'
)
ON CONFLICT (id) DO NOTHING;

-- Add the permission to Super Admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT 
    r.id,
    '5ccecf59-c00b-4105-86b7-d31c9cfe37a8'
FROM roles r
WHERE r.name = 'Super Admin'
ON CONFLICT DO NOTHING;
