-- Remove the automatic trigger - we'll handle this better in the application layer
DROP TRIGGER IF EXISTS character_xp_recalculation_trigger ON characters;
DROP FUNCTION IF EXISTS recalculate_character_xp_trigger();