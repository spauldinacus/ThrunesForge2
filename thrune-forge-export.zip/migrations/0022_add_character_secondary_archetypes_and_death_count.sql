-- Add secondary and tertiary archetype support and death tracking
ALTER TABLE characters 
ADD COLUMN secondary_archetype_id UUID REFERENCES archetypes(id),
ADD COLUMN tertiary_archetype_id UUID REFERENCES archetypes(id),
ADD COLUMN death_count INTEGER NOT NULL DEFAULT 0;