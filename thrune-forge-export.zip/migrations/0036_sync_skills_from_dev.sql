-- Migrate all skills from dev to production
INSERT INTO skills (id, name, description, hidden, created_at, prerequisite_count, max_purchases)
SELECT 
    s.id,
    s.name,
    s.description,
    s.hidden,
    s.created_at,
    s.prerequisite_count,
    s.max_purchases
FROM (
    VALUES
    ('341d71ed-1f24-43ea-9980-aba33ba24926'::uuid, 'Alchemy', 'By expending the resources and Stamina listed upon an Alchemical recipe, you are
capable of creating Alchemical concoctions.', false, '2025-08-25T02:00:50.609604+00:00'::timestamptz, 1, 1),
    ('9429a9ba-fbba-4b4f-b216-ac30d5c5ce24'::uuid, 'Alchemy Master', 'You are capable of using items and crafting recipes that require Alchemy Mastery.', false, '2025-08-25T02:02:06.587496+00:00'::timestamptz, 1, 1),
    ('ca3aefa4-00fe-45b7-885e-e871f199944c'::uuid, 'Alertness', 'Spend 5 Stamina and loudly declare "Alertness" while pointing at or indicating a
target that is attempting to conceal themselves. This removes the Hidden condition.', false, '2025-08-25T02:02:21.755925+00:00'::timestamptz, 1, 1)
    -- I need to get the full skills data to complete this migration
) AS s(id, name, description, hidden, created_at, prerequisite_count, max_purchases)
WHERE NOT EXISTS (
    SELECT 1 FROM skills WHERE skills.id = s.id
);