-- Add selected_skills JSONB column to replace skills_bitwise
ALTER TABLE characters 
ADD COLUMN selected_skills JSONB DEFAULT '[]'::jsonb;

-- Update existing characters to convert bitwise to skill IDs
-- For now, set all existing characters to empty skills array
UPDATE characters 
SET selected_skills = '[]'::jsonb 
WHERE selected_skills IS NULL;