-- Fix event status constraint to include 'upcoming' status
-- This aligns the database constraint with backend validation and frontend options

ALTER TABLE public.events 
DROP CONSTRAINT events_status_check;

ALTER TABLE public.events 
ADD CONSTRAINT events_status_check 
CHECK (status::text = ANY (ARRAY['scheduled'::character varying, 'completed'::character varying, 'cancelled'::character varying, 'upcoming'::character varying]::text[]));