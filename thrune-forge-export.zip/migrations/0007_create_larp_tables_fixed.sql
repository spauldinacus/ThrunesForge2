-- Drop existing tables if they exist (in case of conflicts)
DROP TABLE IF EXISTS rsvps CASCADE;
DROP TABLE IF EXISTS events CASCADE;
DROP TABLE IF EXISTS chapters CASCADE;

-- Create chapters table
CREATE TABLE chapters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create larp_events table (to avoid conflict with databutton.events)
CREATE TABLE larp_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    chapter_id UUID NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    location VARCHAR(255),
    starts_at TIMESTAMP WITH TIME ZONE NOT NULL,
    ends_at TIMESTAMP WITH TIME ZONE NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_larp_events_chapter_id FOREIGN KEY (chapter_id) REFERENCES chapters(id) ON DELETE CASCADE
);

-- Create event_rsvps table
CREATE TABLE event_rsvps (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL,
    user_id TEXT NOT NULL, -- from auth token sub
    status VARCHAR(50) NOT NULL DEFAULT 'going' CHECK (status IN ('going', 'maybe', 'not_going')),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT fk_event_rsvps_event_id FOREIGN KEY (event_id) REFERENCES larp_events(id) ON DELETE CASCADE,
    CONSTRAINT unique_user_event_rsvp UNIQUE (event_id, user_id)
);

-- Create helpful indexes
CREATE INDEX idx_larp_events_starts_at ON larp_events(starts_at);
CREATE INDEX idx_larp_events_chapter_id ON larp_events(chapter_id);
CREATE INDEX idx_event_rsvps_user_id ON event_rsvps(user_id);
CREATE INDEX idx_event_rsvps_event_id ON event_rsvps(event_id);

-- Comments for clarity
COMMENT ON TABLE chapters IS 'LARP chapters/organizations';
COMMENT ON TABLE larp_events IS 'LARP events organized by chapters';
COMMENT ON TABLE event_rsvps IS 'User RSVPs to LARP events, linked by user_id from auth token';
COMMENT ON COLUMN event_rsvps.user_id IS 'User ID from Stack Auth token sub field';