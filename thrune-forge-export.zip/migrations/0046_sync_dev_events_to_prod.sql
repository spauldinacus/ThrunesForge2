-- Copy events from dev to prod (if they don't already exist)
INSERT INTO events (id, chapter_id, title, description, location, starts_at, ends_at, status, created_at) 
VALUES ('c942148e-ee4c-4030-8d3e-ad86fdf9ece8', '3ab8194f-03a4-412d-be45-2cccf1f0cb3b', 'Season 2 Opener', 'testing', 'Test', '2025-08-22T20:53:00+00:00', '2025-08-24T15:53:00+00:00', 'scheduled', '2025-08-22T19:54:03.494026+00:00')
ON CONFLICT (id) DO NOTHING;