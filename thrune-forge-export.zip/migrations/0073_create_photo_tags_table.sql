-- Create table for photo tags
CREATE TABLE public.photo_tags (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    photo_url TEXT NOT NULL,
    photo_id TEXT NOT NULL,
    character_id UUID NOT NULL REFERENCES public.characters(id) ON DELETE CASCADE,
    tagged_by_user_id TEXT NOT NULL,
    x_position DECIMAL(5,2) NOT NULL CHECK (x_position >= 0 AND x_position <= 100),
    y_position DECIMAL(5,2) NOT NULL CHECK (y_position >= 0 AND y_position <= 100),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT unique_character_per_photo UNIQUE (photo_url, character_id)
);

COMMENT ON TABLE public.photo_tags IS 'Character tags on photos from Google Photos';
COMMENT ON COLUMN public.photo_tags.photo_url IS 'Full URL of the photo from Google Photos';
COMMENT ON COLUMN public.photo_tags.photo_id IS 'Google Photos ID or identifier';
COMMENT ON COLUMN public.photo_tags.x_position IS 'X position percentage (0-100) for tag placement';
COMMENT ON COLUMN public.photo_tags.y_position IS 'Y position percentage (0-100) for tag placement';

-- Create index for faster lookups
CREATE INDEX idx_photo_tags_photo_url ON public.photo_tags(photo_url);
CREATE INDEX idx_photo_tags_character_id ON public.photo_tags(character_id);