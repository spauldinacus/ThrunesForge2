-- Add missing fields to chapters table for comprehensive chapter management
ALTER TABLE public.chapters 
ADD COLUMN chapter_code VARCHAR(2) UNIQUE,
ADD COLUMN location VARCHAR(255),
ADD COLUMN contact_email VARCHAR(255),
ADD COLUMN website VARCHAR(255);

-- Add constraint to ensure chapter_code is exactly 2 uppercase letters
ALTER TABLE public.chapters 
ADD CONSTRAINT chapter_code_format CHECK (chapter_code ~ '^[A-Z]{2}$');

-- Add comments for documentation
COMMENT ON COLUMN public.chapters.chapter_code IS 'Two-letter chapter code (e.g., NY, LA) used in player number generation';
COMMENT ON COLUMN public.chapters.location IS 'Physical location of the chapter';
COMMENT ON COLUMN public.chapters.contact_email IS 'Primary contact email for the chapter';
COMMENT ON COLUMN public.chapters.website IS 'Chapter website URL';