-- Update any existing 'not_going' values to 'not_attending'
UPDATE public.rsvps SET status = 'not_attending' WHERE status = 'not_going';

-- Drop the old constraint
ALTER TABLE public.rsvps DROP CONSTRAINT IF EXISTS rsvps_status_check;

-- Add the new constraint with 'not_attending' instead of 'not_going'
ALTER TABLE public.rsvps ADD CONSTRAINT rsvps_status_check 
  CHECK (status IN ('going', 'maybe', 'not_attending'));