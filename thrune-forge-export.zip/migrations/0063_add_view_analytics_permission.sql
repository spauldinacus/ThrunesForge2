-- Add view_analytics permission
INSERT INTO permissions (id, name, description)
VALUES (gen_random_uuid(), 'view_analytics', 'Access analytics hub and system metrics')
ON CONFLICT (name) DO NOTHING;