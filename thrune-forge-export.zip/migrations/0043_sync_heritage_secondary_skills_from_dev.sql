-- Sync heritage secondary skills data from development to production
-- This matches heritages and skills by name since UUIDs differ between environments

INSERT INTO heritage_secondary_skills (heritage_id, skill_id)
SELECT DISTINCT
    h_prod.id as heritage_id,
    s_prod.id as skill_id
FROM (
    -- The heritage-skill combinations that exist in dev
    VALUES 
        ('Ar-Nura', 'Bard'),
        ('Ar-Nura', 'First Aid'),
        ('Ar-Nura', 'Herbalism'),
        ('Ar-Nura', 'Meditation '),
        ('Human', 'Farming'),
        ('Human', 'First Aid'),
        ('Human', 'Lumberjack'),
        ('Human', 'Mining'),
        ('Rystarri', 'Herbalism'),
        ('Rystarri', 'Intercept'),
        ('Rystarri', 'Mercantile'),
        ('Rystarri', 'Scavenging'),
        ('Stoneborn', 'Blacksmithing'),
        ('Stoneborn', 'Cooking'),
        ('Stoneborn', 'Lumberjack'),
        ('Stoneborn', 'Mining'),
        ('Ughol', 'Quick Search'),
        ('Ughol', 'Scavenging'),
        ('Ughol', 'Taunt'),
        ('Ughol', 'Trapper')
) AS dev_data(heritage_name, skill_name)
JOIN heritages h_prod ON h_prod.name = dev_data.heritage_name
JOIN skills s_prod ON s_prod.name = dev_data.skill_name
WHERE NOT EXISTS (
    -- Only insert if this combination doesn't already exist
    SELECT 1 FROM heritage_secondary_skills existing 
    WHERE existing.heritage_id = h_prod.id 
    AND existing.skill_id = s_prod.id
);