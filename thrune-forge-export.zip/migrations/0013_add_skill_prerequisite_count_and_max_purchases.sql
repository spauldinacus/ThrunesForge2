-- Add prerequisite_count and max_purchases fields to skills table
ALTER TABLE skills 
ADD COLUMN prerequisite_count INTEGER DEFAULT 1 NOT NULL,
ADD COLUMN max_purchases INTEGER DEFAULT 1 NOT NULL;

-- Add constraints to ensure valid values
ALTER TABLE skills 
ADD CONSTRAINT skills_prerequisite_count_check CHECK (prerequisite_count >= 1),
ADD CONSTRAINT skills_max_purchases_check CHECK (max_purchases >= 1 AND max_purchases <= 10);

-- Update existing skills to have default values
UPDATE skills SET prerequisite_count = 1, max_purchases = 1 WHERE prerequisite_count IS NULL OR max_purchases IS NULL;