-- Add items_used column to lore_submissions table
ALTER TABLE lore_submissions
ADD COLUMN items_used TEXT;

-- Add comment
COMMENT ON COLUMN lore_submissions.items_used IS 'Items used during lore research (optional)';