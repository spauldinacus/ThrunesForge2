-- Migration: Convert character skills from old format to new format
-- Old format: [{"quantity": 1, "skill_id": "uuid"}]
-- New format: [{"id": "uuid", "name": "skill_name", "purchase_count": 1, "xp_cost": 5}]

-- Create backup table for safety
CREATE TABLE IF NOT EXISTS character_skills_migration_backup (
    id UUID PRIMARY KEY,
    character_id UUID,
    old_skills JSONB,
    new_skills JSONB,
    migrated_at TIMESTAMP DEFAULT NOW(),
    archetype_id UUID,
    character_name VARCHAR(255)
);

-- Create function to calculate XP cost based on archetype and skill
CREATE OR REPLACE FUNCTION calculate_skill_xp_cost(
    skill_base_cost INTEGER,
    archetype_primary_cost INTEGER,
    archetype_secondary_cost INTEGER,
    archetype_tertiary_cost INTEGER
) RETURNS INTEGER AS $$
BEGIN
    -- Return the appropriate cost based on skill's base cost and archetype multipliers
    CASE skill_base_cost
        WHEN 5 THEN RETURN archetype_primary_cost;
        WHEN 10 THEN RETURN archetype_secondary_cost;
        WHEN 20 THEN RETURN archetype_tertiary_cost;
        ELSE RETURN skill_base_cost; -- fallback to base cost
    END CASE;
END;
$$ LANGUAGE plpgsql;

-- Create function to migrate a single character's skills
CREATE OR REPLACE FUNCTION migrate_character_skills(character_uuid UUID, dry_run BOOLEAN DEFAULT TRUE) 
RETURNS TABLE(
    character_id UUID,
    character_name VARCHAR,
    old_format JSONB,
    new_format JSONB,
    status TEXT
) AS $$
DECLARE
    char_record RECORD;
    skill_record RECORD;
    archetype_record RECORD;
    old_skills JSONB;
    new_skills JSONB := '[]'::JSONB;
    skill_item JSONB;
    new_skill_item JSONB;
    calculated_xp_cost INTEGER;
BEGIN
    -- Get character data
    SELECT c.id, c.name, c.selected_skills, c.archetype_id
    INTO char_record
    FROM characters c
    WHERE c.id = character_uuid;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT character_uuid, 'NOT_FOUND'::VARCHAR, NULL::JSONB, NULL::JSONB, 'Character not found'::TEXT;
        RETURN;
    END IF;
    
    old_skills := char_record.selected_skills;
    
    -- Check if already in new format or no skills
    IF old_skills IS NULL OR old_skills = '[]'::JSONB OR old_skills::TEXT LIKE '%"id":%' THEN
        RETURN QUERY SELECT char_record.id, char_record.name, old_skills, old_skills, 'Already migrated or no skills'::TEXT;
        RETURN;
    END IF;
    
    -- Get archetype for XP cost calculation
    SELECT primary_skill_cost, secondary_skill_cost, tertiary_skill_cost
    INTO archetype_record
    FROM archetypes
    WHERE id = char_record.archetype_id;
    
    IF NOT FOUND THEN
        RETURN QUERY SELECT char_record.id, char_record.name, old_skills, NULL::JSONB, 'Archetype not found'::TEXT;
        RETURN;
    END IF;
    
    -- Process each skill in old format
    FOR skill_item IN SELECT * FROM jsonb_array_elements(old_skills)
    LOOP
        -- Get skill details
        SELECT s.id, s.name, s.xp_cost
        INTO skill_record
        FROM skills s
        WHERE s.id = (skill_item->>'skill_id')::UUID;
        
        IF FOUND THEN
            -- Calculate XP cost based on archetype
            calculated_xp_cost := calculate_skill_xp_cost(
                skill_record.xp_cost,
                archetype_record.primary_skill_cost,
                archetype_record.secondary_skill_cost,
                archetype_record.tertiary_skill_cost
            );
            
            -- Create new format skill item
            new_skill_item := jsonb_build_object(
                'id', skill_record.id,
                'name', skill_record.name,
                'purchase_count', (skill_item->>'quantity')::INTEGER,
                'xp_cost', calculated_xp_cost
            );
            
            -- Add to new skills array
            new_skills := new_skills || new_skill_item;
        END IF;
    END LOOP;
    
    -- Store backup
    INSERT INTO character_skills_migration_backup (
        id, character_id, old_skills, new_skills, archetype_id, character_name
    ) VALUES (
        gen_random_uuid(), char_record.id, old_skills, new_skills, char_record.archetype_id, char_record.name
    );
    
    -- Update character if not dry run
    IF NOT dry_run THEN
        UPDATE characters 
        SET selected_skills = new_skills 
        WHERE id = char_record.id;
    END IF;
    
    RETURN QUERY SELECT char_record.id, char_record.name, old_skills, new_skills, 
        CASE WHEN dry_run THEN 'DRY_RUN_SUCCESS' ELSE 'MIGRATED' END::TEXT;
END;
$$ LANGUAGE plpgsql;

-- Create function to migrate all characters
CREATE OR REPLACE FUNCTION migrate_all_character_skills(dry_run BOOLEAN DEFAULT TRUE)
RETURNS TABLE(
    character_id UUID,
    character_name VARCHAR,
    old_format JSONB,
    new_format JSONB,
    status TEXT
) AS $$
DECLARE
    char_id UUID;
BEGIN
    -- Get all characters with old format skills
    FOR char_id IN 
        SELECT c.id 
        FROM characters c 
        WHERE c.selected_skills IS NOT NULL 
        AND c.selected_skills != '[]'::JSONB
        AND c.selected_skills::TEXT LIKE '%skill_id%'
    LOOP
        RETURN QUERY SELECT * FROM migrate_character_skills(char_id, dry_run);
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- Create rollback function
CREATE OR REPLACE FUNCTION rollback_character_skills_migration()
RETURNS TABLE(
    character_id UUID,
    character_name VARCHAR,
    status TEXT
) AS $$
DECLARE
    backup_record RECORD;
BEGIN
    FOR backup_record IN 
        SELECT * FROM character_skills_migration_backup ORDER BY migrated_at DESC
    LOOP
        UPDATE characters 
        SET selected_skills = backup_record.old_skills 
        WHERE id = backup_record.character_id;
        
        RETURN QUERY SELECT backup_record.character_id, backup_record.character_name, 'ROLLED_BACK'::TEXT;
    END LOOP;
END;
$$ LANGUAGE plpgsql;