-- Fix missing XP transactions for stamina and body purchases during character creation
-- This migration creates XP transactions for characters who have stamina/body above their heritage base values
-- but don't have corresponding XP transactions

-- Insert missing stamina purchase transactions
INSERT INTO xp_transactions (
    character_id,
    amount,
    transaction_type,
    reason,
    skill_id,
    body_points,
    stamina_points,
    created_at
)
SELECT 
    c.id,
    -(c.stamina - h.base_stamina) as amount,
    'stamina_purchase',
    'Stamina increased to ' || c.stamina,
    null,
    null,
    c.stamina,
    c.created_at + INTERVAL '5 seconds'
FROM characters c
JOIN heritages h ON c.heritage_id = h.id
WHERE c.stamina > h.base_stamina
  AND NOT EXISTS (
    SELECT 1 FROM xp_transactions xt 
    WHERE xt.character_id = c.id 
    AND xt.transaction_type = 'stamina_purchase'
  );

-- Insert missing body purchase transactions  
INSERT INTO xp_transactions (
    character_id,
    amount,
    transaction_type,
    reason,
    skill_id,
    body_points,
    stamina_points,
    created_at
)
SELECT 
    c.id,
    -(c.body - h.base_body) as amount,
    'body_purchase',
    'Body increased to ' || c.body,
    null,
    c.body,
    null,
    c.created_at + INTERVAL '10 seconds'
FROM characters c
JOIN heritages h ON c.heritage_id = h.id
WHERE c.body > h.base_body
  AND NOT EXISTS (
    SELECT 1 FROM xp_transactions xt 
    WHERE xt.character_id = c.id 
    AND xt.transaction_type = 'body_purchase'
  );