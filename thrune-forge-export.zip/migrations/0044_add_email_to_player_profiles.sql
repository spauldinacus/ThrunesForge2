-- Add email column to player_profiles table
ALTER TABLE public.player_profiles 
ADD COLUMN email VARCHAR(255);

-- Add comment to document the field
COMMENT ON COLUMN public.player_profiles.email IS 'Player email address, populated from Stack Auth user data';

-- Create index for performance
CREATE INDEX idx_player_profiles_email ON public.player_profiles(email);