-- Create function to handle automatic XP recalculation
CREATE OR REPLACE FUNCTION recalculate_character_xp_trigger()
RETURNS TRIGGER AS $$
DECLARE
    archetype_changed BOOLEAN := FALSE;
    old_primary_cost INTEGER;
    old_secondary_cost INTEGER; 
    old_tertiary_cost INTEGER;
    new_primary_cost INTEGER;
    new_secondary_cost INTEGER;
    new_tertiary_cost INTEGER;
    skill_record RECORD;
    skill_cost_diff INTEGER;
    skill_data JSONB;
    updated_skills JSONB := '[]'::jsonb;
BEGIN
    -- Check if any XP-relevant fields changed
    IF OLD.archetype_id IS DISTINCT FROM NEW.archetype_id OR
       OLD.secondary_archetype_id IS DISTINCT FROM NEW.secondary_archetype_id OR
       OLD.tertiary_archetype_id IS DISTINCT FROM NEW.tertiary_archetype_id OR
       OLD.body IS DISTINCT FROM NEW.body OR
       OLD.stamina IS DISTINCT FROM NEW.stamina THEN
        
        -- Handle archetype changes and skill cost recalculation
        IF OLD.archetype_id IS DISTINCT FROM NEW.archetype_id OR
           OLD.secondary_archetype_id IS DISTINCT FROM NEW.secondary_archetype_id OR
           OLD.tertiary_archetype_id IS DISTINCT FROM NEW.tertiary_archetype_id THEN
            
            archetype_changed := TRUE;
            
            -- Process archetype XP costs (secondary/tertiary only, primary is free)
            
            -- Secondary archetype changes
            IF OLD.secondary_archetype_id IS DISTINCT FROM NEW.secondary_archetype_id THEN
                -- Refund old secondary if it existed
                IF OLD.secondary_archetype_id IS NOT NULL THEN
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES (NEW.id, 50, 'archetype_refund', 'Refund for removed secondary archetype');
                END IF;
                
                -- Charge for new secondary if it exists  
                IF NEW.secondary_archetype_id IS NOT NULL THEN
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES (NEW.id, -50, 'archetype_purchase', 'Purchase of secondary archetype');
                END IF;
            END IF;
            
            -- Tertiary archetype changes
            IF OLD.tertiary_archetype_id IS DISTINCT FROM NEW.tertiary_archetype_id THEN
                -- Refund old tertiary if it existed
                IF OLD.tertiary_archetype_id IS NOT NULL THEN
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES (NEW.id, 50, 'archetype_refund', 'Refund for removed tertiary archetype');
                END IF;
                
                -- Charge for new tertiary if it exists
                IF NEW.tertiary_archetype_id IS NOT NULL THEN
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES (NEW.id, -50, 'archetype_purchase', 'Purchase of tertiary archetype');
                END IF;
            END IF;
            
            -- Recalculate skill costs if skills exist
            IF NEW.selected_skills IS NOT NULL AND jsonb_array_length(NEW.selected_skills) > 0 THEN
                
                -- Process each skill to update costs based on new archetypes
                FOR skill_record IN SELECT * FROM jsonb_array_elements(NEW.selected_skills)
                LOOP
                    skill_data := skill_record.value;
                    
                    -- Calculate old skill cost based on old archetypes
                    old_primary_cost := CASE WHEN skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills) 
                        FROM archetypes s WHERE s.id = OLD.archetype_id
                    ) THEN 5 ELSE 999 END;
                    
                    old_secondary_cost := CASE WHEN OLD.secondary_archetype_id IS NOT NULL AND skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills)
                        FROM archetypes s WHERE s.id = OLD.secondary_archetype_id  
                    ) THEN 10 ELSE 999 END;
                    
                    old_tertiary_cost := CASE WHEN OLD.tertiary_archetype_id IS NOT NULL AND skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills)
                        FROM archetypes s WHERE s.id = OLD.tertiary_archetype_id
                    ) THEN 20 ELSE 999 END;
                    
                    -- Calculate new skill cost based on new archetypes  
                    new_primary_cost := CASE WHEN skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills)
                        FROM archetypes s WHERE s.id = NEW.archetype_id
                    ) THEN 5 ELSE 999 END;
                    
                    new_secondary_cost := CASE WHEN NEW.secondary_archetype_id IS NOT NULL AND skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills)
                        FROM archetypes s WHERE s.id = NEW.secondary_archetype_id
                    ) THEN 10 ELSE 999 END;
                    
                    new_tertiary_cost := CASE WHEN NEW.tertiary_archetype_id IS NOT NULL AND skill_data->>'id' IN (
                        SELECT jsonb_array_elements_text(s.skills)
                        FROM archetypes s WHERE s.id = NEW.tertiary_archetype_id
                    ) THEN 20 ELSE 999 END;
                    
                    -- Get the minimum cost for each scenario
                    old_primary_cost := LEAST(old_primary_cost, old_secondary_cost, old_tertiary_cost);
                    new_primary_cost := LEAST(new_primary_cost, new_secondary_cost, new_tertiary_cost);
                    
                    -- If costs are different, create adjustment transaction
                    skill_cost_diff := (new_primary_cost - old_primary_cost) * COALESCE((skill_data->>'purchase_count')::INTEGER, 1);
                    
                    IF skill_cost_diff != 0 THEN
                        INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, skill_id)
                        VALUES (NEW.id, -skill_cost_diff, 'skill_cost_adjustment', 
                               format('Skill cost adjustment for %s: %s -> %s XP', 
                                      skill_data->>'name', old_primary_cost, new_primary_cost),
                               (skill_data->>'id')::UUID);
                    END IF;
                    
                    -- Update skill cost in the JSON
                    skill_data := jsonb_set(skill_data, '{xp_cost}', to_jsonb(new_primary_cost));
                    updated_skills := updated_skills || skill_data;
                END LOOP;
                
                -- Update the character's skills with new costs
                NEW.selected_skills := updated_skills;
            END IF;
        END IF;
        
        -- Handle body/stamina XP costs
        IF OLD.body IS DISTINCT FROM NEW.body OR OLD.stamina IS DISTINCT FROM NEW.stamina THEN
            -- Get heritage base values
            DECLARE
                heritage_base_body INTEGER;
                heritage_base_stamina INTEGER;
                body_diff INTEGER;
                stamina_diff INTEGER;
            BEGIN
                SELECT base_body, base_stamina INTO heritage_base_body, heritage_base_stamina
                FROM heritages WHERE id = NEW.heritage_id;
                
                -- Handle body changes
                IF OLD.body IS DISTINCT FROM NEW.body THEN
                    body_diff := NEW.body - OLD.body;
                    IF body_diff > 0 THEN
                        -- Purchased body
                        INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                        VALUES (NEW.id, -body_diff, 'body_purchase', format('Body increased: %s -> %s', OLD.body, NEW.body));
                    ELSIF body_diff < 0 AND NEW.body >= heritage_base_body THEN
                        -- Refund body (only down to heritage base)
                        INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                        VALUES (NEW.id, -body_diff, 'admin_adjustment', format('Body refund: %s -> %s (%s points)', OLD.body, NEW.body, -body_diff));
                    END IF;
                END IF;
                
                -- Handle stamina changes  
                IF OLD.stamina IS DISTINCT FROM NEW.stamina THEN
                    stamina_diff := NEW.stamina - OLD.stamina;
                    IF stamina_diff > 0 THEN
                        -- Purchased stamina
                        INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                        VALUES (NEW.id, -stamina_diff, 'stamina_purchase', format('Stamina increased: %s -> %s', OLD.stamina, NEW.stamina));
                    ELSIF stamina_diff < 0 AND NEW.stamina >= heritage_base_stamina THEN
                        -- Refund stamina (only down to heritage base)
                        INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                        VALUES (NEW.id, -stamina_diff, 'admin_adjustment', format('Stamina refund: %s -> %s (%s points)', OLD.stamina, NEW.stamina, -stamina_diff));
                    END IF;
                END IF;
            END;
        END IF;
        
        -- Recalculate character XP totals
        DECLARE
            total_earned INTEGER;
            total_purchased INTEGER;
            total_refunded INTEGER;
            xp_total INTEGER;
            xp_spent INTEGER;
            xp_available INTEGER;
        BEGIN
            -- Calculate XP totals using the same logic as the Python function
            SELECT 
                COALESCE(SUM(CASE 
                    WHEN transaction_type IN ('initial', 'event_reward') THEN amount
                    WHEN transaction_type = 'admin_adjustment' AND amount > 0 AND reason NOT LIKE '%refund%' AND reason NOT LIKE '%Refund%' THEN amount
                    ELSE 0 
                END), 0),
                COALESCE(SUM(CASE 
                    WHEN transaction_type IN ('skill_purchase', 'archetype_purchase', 'body_purchase', 'stamina_purchase') THEN ABS(amount)
                    WHEN transaction_type = 'admin_adjustment' AND amount < 0 THEN ABS(amount)
                    ELSE 0 
                END), 0),
                COALESCE(SUM(CASE 
                    WHEN transaction_type IN ('skill_refund', 'archetype_refund', 'skill_cost_adjustment') THEN amount
                    WHEN transaction_type = 'admin_adjustment' AND (reason LIKE '%refund%' OR reason LIKE '%Refund%') THEN amount
                    ELSE 0 
                END), 0)
            INTO total_earned, total_purchased, total_refunded
            FROM xp_transactions 
            WHERE character_id = NEW.id;
            
            -- Calculate final values
            xp_total := total_earned;
            xp_spent := GREATEST(0, total_purchased - total_refunded);
            xp_available := GREATEST(0, xp_total - xp_spent);
            
            -- Update character XP totals
            NEW.xp_total := xp_total;
            NEW.xp_spent := xp_spent;
            NEW.xp_available := xp_available;
        END;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create the trigger
CREATE TRIGGER character_xp_recalculation_trigger
    BEFORE UPDATE ON characters
    FOR EACH ROW
    EXECUTE FUNCTION recalculate_character_xp_trigger();