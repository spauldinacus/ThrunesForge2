-- Add new columns to rsvps table for enhanced functionality
ALTER TABLE public.rsvps 
ADD COLUMN character_id UUID,
ADD COLUMN notes TEXT,
ADD COLUMN ticket_xp INTEGER DEFAULT 0 NOT NULL,
ADD COLUMN candle_xp INTEGER DEFAULT 0 NOT NULL,
ADD CONSTRAINT rsvps_ticket_xp_check CHECK (ticket_xp >= 0 AND ticket_xp <= 2),
ADD CONSTRAINT rsvps_candle_xp_check CHECK (candle_xp >= 0 AND candle_xp <= 2);

-- Add foreign key constraint for character_id
ALTER TABLE public.rsvps 
ADD CONSTRAINT rsvps_character_id_fkey 
FOREIGN KEY (character_id) REFERENCES public.characters(id) ON DELETE CASCADE;

-- Add index for character_id for better query performance
CREATE INDEX idx_rsvps_character_id ON public.rsvps USING btree (character_id);

-- Update table comment
COMMENT ON TABLE public.rsvps IS 'Enhanced user RSVPs to events with character selection and XP purchasing options';
COMMENT ON COLUMN public.rsvps.character_id IS 'Character attending the event (null for user-only RSVP)';
COMMENT ON COLUMN public.rsvps.notes IS 'Player notes/comments for this RSVP';
COMMENT ON COLUMN public.rsvps.ticket_xp IS 'XP purchased with event ticket (0-2)';
COMMENT ON COLUMN public.rsvps.candle_xp IS 'XP purchased with candles (0-2, costs 10 candles per XP)';

-- Remove the unique constraint on user_id + event_id to allow multiple character RSVPs
ALTER TABLE public.rsvps DROP CONSTRAINT unique_user_event_rsvp;

-- Add new unique constraint to allow one RSVP per character per event, but still allow user-only RSVPs
CREATE UNIQUE INDEX unique_character_event_rsvp 
ON public.rsvps (event_id, character_id) 
WHERE character_id IS NOT NULL;

-- Allow only one user-only RSVP per event (where character_id is null)
CREATE UNIQUE INDEX unique_user_event_rsvp_no_character 
ON public.rsvps (event_id, user_id) 
WHERE character_id IS NULL;