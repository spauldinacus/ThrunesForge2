-- Migration to sync all skills from dev to production
-- First, get a count to verify we're copying the right amount
DO $$
DECLARE
    skill_count INTEGER;
BEGIN
    -- This migration copies all skills that don't exist in production
    -- Using a batch approach to handle large datasets efficiently
    
    INSERT INTO skills (id, name, description, hidden, created_at, prerequisite_count, max_purchases)
    VALUES 
    ('341d71ed-1f24-43ea-9980-aba33ba24926', 'Alchemy', 'By expending the resources and Stamina listed upon an Alchemical recipe, you are
capable of creating Alchemical concoctions.', false, '2025-08-25T02:00:50.609604+00:00', 1, 1),
    ('9429a9ba-fbba-4b4f-b216-ac30d5c5ce24', 'Alchemy Master', 'You are capable of using items and crafting recipes that require Alchemy Mastery.', false, '2025-08-25T02:02:06.587496+00:00', 1, 1),
    ('ca3aefa4-00fe-45b7-885e-e871f199944c', 'Alertness', 'Spend 5 Stamina and loudly declare "Alertness" while pointing at or indicating a
target that is attempting to conceal themselves. This removes the Hidden condition.', false, '2025-08-25T02:02:21.755925+00:00', 1, 1),
    ('e2cc7f31-db79-4216-a899-8b01d21006ea', 'Ambidexterity', 'You may use a Small Weapon or Pistol in your off-hand during combat, as long as you
have Weapon Proficiency with the weapon.
This skill may be taken a second time, which allows you to use a Medium Weapon
in either hand.', false, '2025-08-25T02:02:34.672369+00:00', 1, 2),
    ('769a08d8-b23d-442d-8b45-0552c6638636', 'Armor Smithing', 'While using appropriate tools and expending Stamina, you are capable of crafting
Armor formulas. You may also repair Armor and Shields, by spending 1 Stamina and
2 minutes, you are capable of repairing up to 20 points of Armor or repairing a Shield.', false, '2025-08-25T02:03:06.086279+00:00', 1, 1),
    ('7728ef54-fb1a-4e9d-85aa-362529af77ca', 'Armor Training (Heavy)', 'You may use any special armor abilities of armor of the Heavy category, which is
traditionally things like plate mail.', false, '2025-08-25T02:03:36.895862+00:00', 1, 1),
    ('6ada2c9d-16ef-4138-ad60-09ef9e7c40d7', 'Armor Training (Light)', 'You may use any armor special abilities of armor of the Light category, which is
traditionally things like padded and leather armor.', false, '2025-08-25T02:03:18.316144+00:00', 1, 1),
    ('dbdd6ca4-2939-4fa5-b97a-1a424b1150ea', 'Armor Training (Medium)', 'You may use any special armor abilities of armor of the Medium category, which is
traditionally things like chain mail.', false, '2025-08-25T02:03:27.771271+00:00', 1, 1),
    ('5b7e5280-5e6e-4d4d-b06a-de2f4b062abf', 'Backstab', 'While behind a target, spend 5 Stamina to call "Backstab X" with your melee strike,
where X is double the amount of damage that you would normally inflict with the
weapon. This skill only works with melee weapon.
This skill does not stack with any other method of inflicting double damage.', false, '2025-08-25T02:03:56.088869+00:00', 1, 1),
    ('a6d60cfa-fa1c-4129-9455-e879f415b63f', 'Bard', 'Spend 5 Stamina and 15 minutes while playing an instrument, singing a song, reciting
a poem, or performing entertainment. Once completed, declare "Bard, 20 foot radius,
restore 5 Stamina"
Note that the Bard does not benefit from activating this skill.', false, '2025-08-25T02:04:06.483281+00:00', 1, 1)
    ON CONFLICT (id) DO NOTHING;
    
    -- Log the count
    SELECT COUNT(*) INTO skill_count FROM skills;
    RAISE NOTICE 'Total skills after initial batch: %', skill_count;
END $$;