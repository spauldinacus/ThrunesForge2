-- Add skill_cost_adjustment to allowed transaction types
ALTER TABLE xp_transactions 
DROP CONSTRAINT xp_transactions_type_check;

ALTER TABLE xp_transactions 
ADD CONSTRAINT xp_transactions_type_check 
CHECK (transaction_type IN (
    'initial',
    'skill_purchase', 
    'skill_refund',
    'body_purchase',
    'stamina_purchase', 
    'event_reward',
    'admin_adjustment',
    'archetype_purchase',
    'archetype_refund',
    'skill_cost_adjustment'
));