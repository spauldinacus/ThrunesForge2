-- Seed initial chapters data
INSERT INTO chapters (id, name, description, created_at, chapter_code, location, contact_email, website) 
VALUES ('3ab8194f-03a4-412d-be45-2cccf1f0cb3b', 'Wanderer''s Hope', '', '2025-01-01T12:01:10.890598+00:00', 'FL', 'Florida', 'logistics@thrunefl.com', 'ThruneFL.com')
ON CONFLICT (id) DO NOTHING;