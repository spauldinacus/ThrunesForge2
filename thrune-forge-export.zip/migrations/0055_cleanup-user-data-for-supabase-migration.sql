-- Database Cleanup Migration for Supabase Auth Transition
-- This migration wipes all user-related data while preserving game data
-- Created: 2024-09-14

BEGIN;

-- Create a backup log table for this migration
CREATE TABLE IF NOT EXISTS migration_cleanup_log (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    table_name TEXT NOT NULL,
    records_deleted INTEGER NOT NULL,
    deleted_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Function to safely delete with logging
CREATE OR REPLACE FUNCTION safe_delete_with_log(table_name_param TEXT) 
RETURNS INTEGER AS $$
DECLARE
    deleted_count INTEGER;
BEGIN
    EXECUTE format('DELETE FROM %I', table_name_param);
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    INSERT INTO migration_cleanup_log (table_name, records_deleted)
    VALUES (table_name_param, deleted_count);
    
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- WIPE USER DATA TABLES (delete all data, preserve structure)
-- Order matters due to foreign key constraints

-- 1. Delete attendance records first (references characters and events)
SELECT safe_delete_with_log('character_event_attendance');

-- 2. Delete XP transactions (references characters)
SELECT safe_delete_with_log('xp_transactions');

-- 3. Delete candle transactions (references player_profiles)
SELECT safe_delete_with_log('candle_transactions');

-- 4. Delete RSVPs (references events and characters)
SELECT safe_delete_with_log('rsvps');

-- 5. Delete characters (references player_profiles)
SELECT safe_delete_with_log('characters');

-- 6. Delete player roles (references player_profiles and roles)
SELECT safe_delete_with_log('player_roles');

-- 7. Delete player profiles (main user data)
SELECT safe_delete_with_log('player_profiles');

-- 8. Delete player number sequences (user-related sequences)
SELECT safe_delete_with_log('player_number_sequences');

-- 9. Delete old migration backup data
SELECT safe_delete_with_log('character_skills_migration_backup');
SELECT safe_delete_with_log('character_skills_backup_simple');

-- 10. Delete Stack Auth sync data
DELETE FROM neon_auth.users_sync;
INSERT INTO migration_cleanup_log (table_name, records_deleted)
SELECT 'neon_auth.users_sync', 0; -- We don't get ROW_COUNT from different schema

-- Reset any sequences that might need resetting
-- (Most of our IDs are UUIDs, but player_number_sequences has auto-increment)
-- Reset player number sequences for clean start
ALTER SEQUENCE IF EXISTS player_number_sequences_next_sequence_seq RESTART WITH 1;

-- Show cleanup summary
SELECT 
    table_name,
    records_deleted,
    deleted_at
FROM migration_cleanup_log 
ORDER BY deleted_at;

-- Cleanup the helper function
DROP FUNCTION safe_delete_with_log(TEXT);

-- Verification: Show remaining record counts for key tables
SELECT 
    'Post-cleanup verification' as status,
    (SELECT COUNT(*) FROM player_profiles) as player_profiles_count,
    (SELECT COUNT(*) FROM characters) as characters_count,
    (SELECT COUNT(*) FROM rsvps) as rsvps_count,
    (SELECT COUNT(*) FROM skills) as skills_preserved,
    (SELECT COUNT(*) FROM heritages) as heritages_preserved,
    (SELECT COUNT(*) FROM roles) as roles_preserved,
    (SELECT COUNT(*) FROM events) as events_preserved;

COMMIT;

-- Note: The following game data tables are PRESERVED (no changes):
-- - skills (skill definitions)
-- - heritages (heritage definitions)  
-- - cultures (culture definitions)
-- - archetypes (archetype definitions)
-- - chapters (chapter information)
-- - events (event information)
-- - roles (role definitions)
-- - permissions (permission definitions)
-- - role_permissions (role-permission mappings)
-- - skill_prerequisites (skill relationships)
-- - heritage_secondary_skills (heritage skill relationships)
-- - archetype_primary_skills (archetype skill relationships)
-- - archetype_secondary_skills (archetype skill relationships)