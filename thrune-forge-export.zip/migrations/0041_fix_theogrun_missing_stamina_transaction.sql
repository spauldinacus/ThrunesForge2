-- Fix missing stamina purchase transaction for character Theogrun
-- Character has stamina=10 but heritage base_stamina=5, missing 5 stamina purchase transaction

INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points, stamina_points, created_at)
SELECT 
  c.id,
  -(c.stamina - h.base_stamina),
  'stamina_purchase',
  'Stamina increased to ' || c.stamina,
  null,
  c.stamina,
  c.created_at + INTERVAL '5 seconds'
FROM characters c
JOIN heritages h ON c.heritage_id = h.id
WHERE c.stamina > h.base_stamina
  AND NOT EXISTS (
    SELECT 1 FROM xp_transactions xt 
    WHERE xt.character_id = c.id 
    AND xt.transaction_type = 'stamina_purchase'
  );

-- Also handle any missing body purchases
INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points, stamina_points, created_at)
SELECT 
  c.id,
  -(c.body - h.base_body),
  'body_purchase',
  'Body increased to ' || c.body,
  c.body,
  null,
  c.created_at + INTERVAL '6 seconds'
FROM characters c
JOIN heritages h ON c.heritage_id = h.id
WHERE c.body > h.base_body
  AND NOT EXISTS (
    SELECT 1 FROM xp_transactions xt 
    WHERE xt.character_id = c.id 
    AND xt.transaction_type = 'body_purchase'
  );