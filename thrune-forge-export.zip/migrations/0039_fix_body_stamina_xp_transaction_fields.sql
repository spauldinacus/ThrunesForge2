-- Fix existing body and stamina purchase transactions by populating NULL body_points and stamina_points
-- from the reason text field

UPDATE xp_transactions 
SET body_points = CASE 
  WHEN reason LIKE 'Body increased to %' THEN CAST(SUBSTRING(reason FROM 'Body increased to (\d+)') AS INTEGER)
  WHEN reason LIKE 'Body increased from % to %' THEN CAST(SUBSTRING(reason FROM 'Body increased from \d+ to (\d+)') AS INTEGER)
END
WHERE transaction_type = 'body_purchase' AND body_points IS NULL;

UPDATE xp_transactions 
SET stamina_points = CASE 
  WHEN reason LIKE 'Stamina increased to %' THEN CAST(SUBSTRING(reason FROM 'Stamina increased to (\d+)') AS INTEGER)
  WHEN reason LIKE 'Stamina increased from % to %' THEN CAST(SUBSTRING(reason FROM 'Stamina increased from \d+ to (\d+)') AS INTEGER)
END
WHERE transaction_type = 'stamina_purchase' AND stamina_points IS NULL;