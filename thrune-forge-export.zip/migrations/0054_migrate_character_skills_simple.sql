-- Simple Migration: Convert character skills from old format to new format
-- This uses the existing cost calculation logic from the admin API

-- Create backup table
CREATE TABLE IF NOT EXISTS character_skills_backup_simple (
    character_id UUID PRIMARY KEY,
    old_skills JSONB,
    new_skills JSONB,
    migrated_at TIMESTAMP DEFAULT NOW()
);

-- First, backup all characters with old format skills
INSERT INTO character_skills_backup_simple (character_id, old_skills)
SELECT 
    c.id,
    c.selected_skills
FROM characters c
WHERE c.selected_skills IS NOT NULL 
  AND c.selected_skills != '[]'::JSONB
  AND c.selected_skills::TEXT LIKE '%skill_id%'
ON CONFLICT (character_id) DO NOTHING;

-- Now perform the migration using the same logic as admin API
WITH character_skills_migration AS (
    SELECT 
        c.id as character_id,
        c.name as character_name,
        c.archetype_id,
        c.heritage_id,
        c.selected_skills as old_skills,
        skill_item->>'skill_id' as skill_id,
        (skill_item->>'quantity')::INTEGER as quantity
    FROM characters c,
         jsonb_array_elements(c.selected_skills) as skill_item
    WHERE c.selected_skills IS NOT NULL 
      AND c.selected_skills != '[]'::JSONB
      AND c.selected_skills::TEXT LIKE '%skill_id%'
),
skill_costs AS (
    SELECT 
        csm.*,
        s.name as skill_name,
        CASE 
            WHEN aps.skill_id IS NOT NULL THEN 5
            WHEN ass.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
            ELSE 20
        END as xp_cost
    FROM character_skills_migration csm
    JOIN skills s ON s.id = csm.skill_id::UUID
    LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = csm.archetype_id
    LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = csm.archetype_id
    LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = csm.heritage_id
),
new_skills_array AS (
    SELECT 
        character_id,
        jsonb_agg(
            jsonb_build_object(
                'id', skill_id,
                'name', skill_name,
                'purchase_count', quantity,
                'xp_cost', xp_cost
            )
        ) as new_skills
    FROM skill_costs
    GROUP BY character_id
)
-- Update the backup table with new skills format
UPDATE character_skills_backup_simple csb
SET new_skills = nsa.new_skills
FROM new_skills_array nsa
WHERE csb.character_id = nsa.character_id;

-- Show the migration preview (what will be changed)
SELECT 
    c.name as character_name,
    jsonb_array_length(csb.old_skills) as old_count,
    jsonb_array_length(csb.new_skills) as new_count,
    csb.old_skills,
    csb.new_skills
FROM character_skills_backup_simple csb
JOIN characters c ON c.id = csb.character_id
WHERE csb.new_skills IS NOT NULL
ORDER BY c.name;