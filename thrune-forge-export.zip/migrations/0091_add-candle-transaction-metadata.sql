-- Add new columns to candle_transactions table for enhanced tracking
ALTER TABLE public.candle_transactions 
ADD COLUMN transaction_type TEXT,
ADD COLUMN character_id UUID REFERENCES characters(id) ON DELETE SET NULL,
ADD COLUMN event_id UUID REFERENCES events(id) ON DELETE SET NULL;

-- Add check constraint for transaction_type to ensure valid values
ALTER TABLE public.candle_transactions
ADD CONSTRAINT valid_transaction_type CHECK (
  transaction_type IS NULL OR 
  transaction_type IN ('general', 'print/scroll', 'attendance', 'candle purchase', 'donation', 'transfer')
);