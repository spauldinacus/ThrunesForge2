-- Assign Super Admin role to James Spaulding (jamescspaulding@gmail.com) using role name lookup
INSERT INTO player_roles (player_profile_id, role_id, assigned_by_user_id, assigned_at)
SELECT 
    pp.id,
    r.id,  -- Super Admin role ID looked up by name
    pp.user_id,  -- Self-assigned
    NOW()
FROM player_profiles pp 
CROSS JOIN roles r
WHERE pp.email = 'jamescspaulding@gmail.com'
  AND r.name = 'Super Admin'
ON CONFLICT (player_profile_id, role_id) DO NOTHING;