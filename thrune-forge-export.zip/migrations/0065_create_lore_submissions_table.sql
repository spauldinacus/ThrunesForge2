CREATE TABLE lore_submissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    event_id UUID NOT NULL REFERENCES events(id) ON DELETE CASCADE,
    chapter_id UUID NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
    character_id UUID NOT NULL REFERENCES characters(id) ON DELETE CASCADE,
    lores_used TEXT NOT NULL,
    outcome TEXT NOT NULL,
    link TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    created_by TEXT NOT NULL
);

CREATE INDEX idx_lore_submissions_character ON lore_submissions(character_id);
CREATE INDEX idx_lore_submissions_event ON lore_submissions(event_id);
CREATE INDEX idx_lore_submissions_chapter ON lore_submissions(chapter_id);
CREATE INDEX idx_lore_submissions_created_at ON lore_submissions(created_at DESC);