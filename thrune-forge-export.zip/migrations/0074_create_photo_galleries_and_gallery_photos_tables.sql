-- Create photo_galleries table
CREATE TABLE IF NOT EXISTS public.photo_galleries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    description TEXT,
    event_date TIMESTAMP WITH TIME ZONE,
    created_by_user_id TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.photo_galleries IS 'Photo galleries for organizing LARP event photos';

-- Create gallery_photos table
CREATE TABLE IF NOT EXISTS public.gallery_photos (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    gallery_id UUID NOT NULL REFERENCES public.photo_galleries(id) ON DELETE CASCADE,
    photo_url TEXT NOT NULL,
    thumbnail_url TEXT,
    photo_id TEXT NOT NULL UNIQUE,
    description TEXT,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.gallery_photos IS 'Individual photos within galleries';

-- Create indexes
CREATE INDEX idx_gallery_photos_gallery_id ON public.gallery_photos(gallery_id);
CREATE INDEX idx_gallery_photos_display_order ON public.gallery_photos(gallery_id, display_order);
CREATE INDEX idx_gallery_photos_photo_id ON public.gallery_photos(photo_id);

-- Add updated_at trigger for photo_galleries
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_photo_galleries_updated_at
    BEFORE UPDATE ON public.photo_galleries
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_gallery_photos_updated_at
    BEFORE UPDATE ON public.gallery_photos
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();