-- Character Event Attendance tracking
CREATE TABLE character_event_attendance (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    character_id UUID NOT NULL,
    event_id UUID NOT NULL,
    attended BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_character_event_attendance_character_id FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE,
    CONSTRAINT fk_character_event_attendance_event_id FOREIGN KEY (event_id) REFERENCES events(id) ON DELETE CASCADE,
    CONSTRAINT unique_character_event_attendance UNIQUE (character_id, event_id)
);