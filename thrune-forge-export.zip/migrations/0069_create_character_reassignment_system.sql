-- Create character_reassignment_history table
CREATE TABLE IF NOT EXISTS public.character_reassignment_history (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    character_id UUID NOT NULL REFERENCES public.characters(id) ON DELETE CASCADE,
    from_player_id UUID REFERENCES public.player_profiles(id) ON DELETE SET NULL,
    to_player_id UUID NOT NULL REFERENCES public.player_profiles(id) ON DELETE CASCADE,
    reassigned_by TEXT NOT NULL,
    notes TEXT,
    reassigned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.character_reassignment_history IS 'Tracks all character reassignments between players';
COMMENT ON COLUMN public.character_reassignment_history.from_player_id IS 'Previous player (nullable for initial assignments)';
COMMENT ON COLUMN public.character_reassignment_history.to_player_id IS 'New player who receives the character';
COMMENT ON COLUMN public.character_reassignment_history.reassigned_by IS 'Admin user ID who performed the reassignment';
COMMENT ON COLUMN public.character_reassignment_history.notes IS 'Optional reason or notes for the reassignment';

-- Create indexes for better query performance
CREATE INDEX idx_reassignment_history_character ON public.character_reassignment_history(character_id);
CREATE INDEX idx_reassignment_history_from_player ON public.character_reassignment_history(from_player_id);
CREATE INDEX idx_reassignment_history_to_player ON public.character_reassignment_history(to_player_id);

-- Add character_reassignment permission
INSERT INTO public.permissions (id, name, description)
VALUES (
    gen_random_uuid(),
    'character_reassignment',
    'Allows reassigning characters from one player to another'
) ON CONFLICT (name) DO NOTHING;

-- Assign character_reassignment permission to super_admin role
INSERT INTO public.role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM public.roles r
CROSS JOIN public.permissions p
WHERE r.name = 'super_admin' 
  AND p.name = 'character_reassignment'
  AND NOT EXISTS (
    SELECT 1 FROM public.role_permissions rp
    WHERE rp.role_id = r.id AND rp.permission_id = p.id
  );