-- Rename death-related columns to match frontend field names
ALTER TABLE characters RENAME COLUMN is_dead TO death_1;
ALTER TABLE characters RENAME COLUMN death_count TO death_2;