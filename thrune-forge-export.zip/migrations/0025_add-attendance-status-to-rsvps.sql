-- Add attendance status field to RSVPs table
ALTER TABLE rsvps ADD COLUMN attendance_status VARCHAR(20) DEFAULT 'rsvp' NOT NULL;

-- Add constraint for valid attendance statuses
ALTER TABLE rsvps ADD CONSTRAINT rsvps_attendance_status_check 
    CHECK (attendance_status IN ('rsvp', 'attended', 'no_show'));

-- Add index for attendance status queries
CREATE INDEX idx_rsvps_attendance_status ON rsvps(attendance_status);

-- Add admin user who processed attendance
ALTER TABLE rsvps ADD COLUMN processed_by_user_id TEXT;

-- Add timestamp for when attendance was processed
ALTER TABLE rsvps ADD COLUMN attendance_processed_at TIMESTAMP WITH TIME ZONE;