-- Migration: Convert death_1/death_2 boolean fields to deaths integer counter

-- Step 1: Add new deaths column
ALTER TABLE characters ADD COLUMN deaths INTEGER DEFAULT 0 NOT NULL;

-- Step 2: Migrate existing data based on death_1 and death_2 values
UPDATE characters 
SET deaths = CASE 
    WHEN death_1 = true AND death_2 = true THEN 2
    WHEN death_1 = true AND death_2 = false THEN 1
    WHEN death_1 = false THEN 0
    ELSE 0
END;

-- Step 3: Add constraint to ensure deaths is within reasonable range (0-10)
ALTER TABLE characters ADD CONSTRAINT characters_deaths_check CHECK ((deaths >= 0) AND (deaths <= 10));

-- Step 4: Drop the old death_1 and death_2 columns
ALTER TABLE characters DROP COLUMN death_1;
ALTER TABLE characters DROP COLUMN death_2;

-- Step 5: Add comment for the new column
COMMENT ON COLUMN characters.deaths IS 'Number of character deaths (integer counter replacing death_1/death_2 booleans)';