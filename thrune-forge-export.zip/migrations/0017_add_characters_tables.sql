-- Characters table with bitwise skill storage
CREATE TABLE characters (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    player_profile_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    heritage_id UUID NOT NULL,
    culture_id UUID NOT NULL,
    archetype_id UUID NOT NULL,
    body INTEGER NOT NULL DEFAULT 4,
    stamina INTEGER NOT NULL DEFAULT 4,
    skills_bitwise BIGINT NOT NULL DEFAULT 0,
    xp_total INTEGER NOT NULL DEFAULT 25,
    xp_spent INTEGER NOT NULL DEFAULT 0,
    xp_available INTEGER NOT NULL DEFAULT 25,
    player_notes TEXT,
    addictions_diseases TEXT,
    is_dead BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_characters_player_profile_id FOREIGN KEY (player_profile_id) REFERENCES player_profiles(id) ON DELETE CASCADE,
    CONSTRAINT fk_characters_heritage_id FOREIGN KEY (heritage_id) REFERENCES heritages(id) ON DELETE RESTRICT,
    CONSTRAINT fk_characters_culture_id FOREIGN KEY (culture_id) REFERENCES cultures(id) ON DELETE RESTRICT,
    CONSTRAINT fk_characters_archetype_id FOREIGN KEY (archetype_id) REFERENCES archetypes(id) ON DELETE RESTRICT,
    CONSTRAINT characters_body_check CHECK (body >= 1 AND body <= 200),
    CONSTRAINT characters_stamina_check CHECK (stamina >= 1 AND stamina <= 200),
    CONSTRAINT characters_xp_check CHECK (xp_spent <= xp_total AND xp_available >= 0)
);