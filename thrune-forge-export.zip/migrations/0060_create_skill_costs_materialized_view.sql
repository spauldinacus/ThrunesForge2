-- Create skill_costs table/view for build optimization
-- This precomputes XP costs for every skill under every archetype
CREATE TABLE skill_costs AS
SELECT 
    s.id AS skill_id,
    s.name AS skill_name,
    a.id AS archetype_id,
    a.name AS archetype_name,
    -- Primary cost: if skill is in archetype_primary_skills
    CASE 
        WHEN aps.archetype_id IS NOT NULL THEN 5
        ELSE NULL
    END AS cost_primary,
    -- Secondary cost: if skill is in archetype_secondary_skills  
    CASE 
        WHEN ass.archetype_id IS NOT NULL THEN 10
        ELSE NULL
    END AS cost_secondary,
    -- Tertiary cost: all other skills
    CASE 
        WHEN aps.archetype_id IS NULL AND ass.archetype_id IS NULL THEN 20
        ELSE NULL
    END AS cost_tertiary
FROM 
    skills s
CROSS JOIN 
    archetypes a
LEFT JOIN 
    archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = a.id
LEFT JOIN 
    archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = a.id;

-- Add indexes for fast lookups
CREATE INDEX idx_skill_costs_skill_id ON skill_costs(skill_id);
CREATE INDEX idx_skill_costs_archetype_id ON skill_costs(archetype_id);
CREATE INDEX idx_skill_costs_lookup ON skill_costs(skill_id, archetype_id);

COMMENT ON TABLE skill_costs IS 'Materialized view of skill XP costs under each archetype for build optimization';