-- Add candle_cost column to tables
ALTER TABLE heritages ADD COLUMN IF NOT EXISTS candle_cost INTEGER DEFAULT 0 NOT NULL;
ALTER TABLE cultures ADD COLUMN IF NOT EXISTS candle_cost INTEGER DEFAULT 0 NOT NULL;
ALTER TABLE archetypes ADD COLUMN IF NOT EXISTS candle_cost INTEGER DEFAULT 0 NOT NULL;

-- Data Migration: Update names containing "(500 candles)"
-- We use ILIKE for case-insensitive matching
-- We set candle_cost to 500
-- We clean the name using regex to handle variations in casing and spacing

UPDATE heritages 
SET candle_cost = 500, 
    name = TRIM(REGEXP_REPLACE(name, '\s*\(500\s*candles\)', '', 'i'))
WHERE name ILIKE '%(500 candles)%';

UPDATE cultures 
SET candle_cost = 500, 
    name = TRIM(REGEXP_REPLACE(name, '\s*\(500\s*candles\)', '', 'i'))
WHERE name ILIKE '%(500 candles)%';

UPDATE archetypes 
SET candle_cost = 500, 
    name = TRIM(REGEXP_REPLACE(name, '\s*\(500\s*candles\)', '', 'i'))
WHERE name ILIKE '%(500 candles)%';