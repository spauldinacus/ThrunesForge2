UPDATE characters 
SET 
    xp_spent = LEAST(xp_total, ABS(xp_spent)),
    xp_available = GREATEST(0, xp_total - ABS(xp_spent))
WHERE xp_spent < 0;