-- Create player profiles table
CREATE TABLE public.player_profiles (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE, -- Links to Stack Auth user ID
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone_number VARCHAR(20),
    emergency_contact_name VARCHAR(200),
    emergency_contact_phone VARCHAR(20),
    chapter_id UUID NOT NULL,
    player_number VARCHAR(20) UNIQUE NOT NULL, -- Format: CCYYMMNNN
    candles_available INTEGER DEFAULT 0 NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_player_profiles_chapter_id 
        FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE RESTRICT
);

-- Create candle transactions table for history tracking
CREATE TABLE public.candle_transactions (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    player_profile_id UUID NOT NULL,
    amount INTEGER NOT NULL, -- Positive for earned, negative for spent
    reason TEXT NOT NULL,
    granted_by_user_id TEXT, -- Stack Auth user ID of admin who granted (if applicable)
    used_for TEXT, -- What candles were used for (if spent)
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_candle_transactions_player_profile_id 
        FOREIGN KEY (player_profile_id) REFERENCES public.player_profiles(id) ON DELETE CASCADE
);

-- Create indexes for performance
CREATE INDEX idx_player_profiles_user_id ON public.player_profiles(user_id);
CREATE INDEX idx_player_profiles_chapter_id ON public.player_profiles(chapter_id);
CREATE INDEX idx_player_profiles_player_number ON public.player_profiles(player_number);
CREATE INDEX idx_candle_transactions_player_profile_id ON public.candle_transactions(player_profile_id);
CREATE INDEX idx_candle_transactions_created_at ON public.candle_transactions(created_at);

-- Create sequence for player number generation per chapter per month
CREATE TABLE public.player_number_sequences (
    id UUID DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    chapter_id UUID NOT NULL,
    year INTEGER NOT NULL,
    month INTEGER NOT NULL,
    next_sequence INTEGER DEFAULT 1 NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_player_number_sequences_chapter_id 
        FOREIGN KEY (chapter_id) REFERENCES public.chapters(id) ON DELETE CASCADE,
    CONSTRAINT unique_chapter_year_month 
        UNIQUE (chapter_id, year, month)
);

CREATE INDEX idx_player_number_sequences_chapter_year_month ON public.player_number_sequences(chapter_id, year, month);

-- Add comments for documentation
COMMENT ON TABLE public.player_profiles IS 'Extended player profiles linked to Stack Auth users';
COMMENT ON COLUMN public.player_profiles.user_id IS 'Stack Auth user ID from token.sub';
COMMENT ON COLUMN public.player_profiles.player_number IS 'Auto-generated player number format: CCYYMMNNN';
COMMENT ON COLUMN public.player_profiles.candles_available IS 'Current candle balance for this player';

COMMENT ON TABLE public.candle_transactions IS 'History of all candle transactions (earned/spent)';
COMMENT ON COLUMN public.candle_transactions.amount IS 'Positive for earned candles, negative for spent candles';
COMMENT ON COLUMN public.candle_transactions.granted_by_user_id IS 'Admin user who granted candles (if applicable)';

COMMENT ON TABLE public.player_number_sequences IS 'Tracks next sequence number for player number generation per chapter/month';