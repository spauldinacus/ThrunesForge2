-- Add indexes for performance
CREATE INDEX idx_characters_player_profile_id ON characters(player_profile_id);
CREATE INDEX idx_characters_heritage_id ON characters(heritage_id);
CREATE INDEX idx_characters_culture_id ON characters(culture_id);
CREATE INDEX idx_characters_archetype_id ON characters(archetype_id);
CREATE INDEX idx_characters_name ON characters(name);
CREATE INDEX idx_characters_is_dead ON characters(is_dead);

CREATE INDEX idx_xp_transactions_character_id ON xp_transactions(character_id);
CREATE INDEX idx_xp_transactions_created_at ON xp_transactions(created_at);
CREATE INDEX idx_xp_transactions_type ON xp_transactions(transaction_type);

CREATE INDEX idx_character_event_attendance_character_id ON character_event_attendance(character_id);
CREATE INDEX idx_character_event_attendance_event_id ON character_event_attendance(event_id);

-- Add comments for documentation
COMMENT ON TABLE characters IS 'Player characters with bitwise skill storage and XP tracking';
COMMENT ON COLUMN characters.skills_bitwise IS 'Bitwise storage of character skills for efficient querying';
COMMENT ON COLUMN characters.xp_total IS 'Total XP ever earned by this character';
COMMENT ON COLUMN characters.xp_spent IS 'Total XP spent on skills, body, stamina';
COMMENT ON COLUMN characters.xp_available IS 'Current available XP (total - spent)';

COMMENT ON TABLE xp_transactions IS 'Complete history of all XP transactions for auditing and display';
COMMENT ON COLUMN xp_transactions.amount IS 'XP amount (positive for gains, negative for expenditures)';
COMMENT ON COLUMN xp_transactions.transaction_type IS 'Type of transaction for categorization';

COMMENT ON TABLE character_event_attendance IS 'Tracks which events each character has attended';