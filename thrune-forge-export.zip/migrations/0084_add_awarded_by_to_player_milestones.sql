ALTER TABLE public.player_milestones ADD COLUMN awarded_by text;
COMMENT ON COLUMN public.player_milestones.awarded_by IS 'User ID of the admin who awarded this milestone (if applicable)';