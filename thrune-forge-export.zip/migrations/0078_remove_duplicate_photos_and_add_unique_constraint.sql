-- Delete duplicate photos, keeping only the oldest one for each (gallery_id, photo_url) pair
DELETE FROM gallery_photos
WHERE id IN (
    SELECT id
    FROM (
        SELECT id,
               ROW_NUMBER() OVER (
                   PARTITION BY gallery_id, photo_url 
                   ORDER BY created_at ASC
               ) AS rn
        FROM gallery_photos
    ) t
    WHERE t.rn > 1
);

-- Add unique constraint to prevent duplicate photo URLs within the same gallery
ALTER TABLE gallery_photos 
ADD CONSTRAINT gallery_photos_gallery_id_photo_url_key 
UNIQUE (gallery_id, photo_url);