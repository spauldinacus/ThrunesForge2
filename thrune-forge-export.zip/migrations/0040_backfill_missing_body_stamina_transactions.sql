-- Backfill missing body and stamina purchase XP transactions for existing characters
-- This migration identifies characters with body/stamina above heritage base values
-- and creates the missing XP transaction records

WITH character_analysis AS (
  SELECT 
    c.id as character_id,
    c.name,
    c.body,
    c.stamina,
    c.created_at,
    h.base_body,
    h.base_stamina,
    (c.body - h.base_body) as body_purchases,
    (c.stamina - h.base_stamina) as stamina_purchases,
    (c.body - h.base_body) as body_xp_spent,
    (c.stamina - h.base_stamina) as stamina_xp_spent
  FROM characters c
  JOIN heritages h ON c.heritage_id = h.id
  WHERE c.body > h.base_body OR c.stamina > h.base_stamina
),
missing_body_transactions AS (
  SELECT 
    character_id,
    name,
    body_purchases,
    body_xp_spent,
    body,
    created_at
  FROM character_analysis 
  WHERE body_purchases > 0
),
missing_stamina_transactions AS (
  SELECT 
    character_id,
    name,
    stamina_purchases,
    stamina_xp_spent,
    stamina,
    created_at
  FROM character_analysis 
  WHERE stamina_purchases > 0
)

-- Insert missing body purchase transactions
INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points, stamina_points, created_at)
SELECT 
  character_id,
  -body_xp_spent,
  'body_purchase',
  'Body increased to ' || body,
  body,
  null,
  created_at + INTERVAL '1 second'  -- Slightly after character creation
FROM missing_body_transactions

UNION ALL

-- Insert missing stamina purchase transactions  
SELECT 
  character_id,
  -stamina_xp_spent,
  'stamina_purchase', 
  'Stamina increased to ' || stamina,
  null,
  stamina,
  created_at + INTERVAL '2 seconds'  -- Slightly after character creation
FROM missing_stamina_transactions;

-- Verify the results
SELECT 'Migration completed - missing transactions added' as status;