-- Create roles table
CREATE TABLE public.roles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    is_system_role BOOLEAN DEFAULT false NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create permissions table  
CREATE TABLE public.permissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Create role_permissions junction table
CREATE TABLE public.role_permissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES public.permissions(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(role_id, permission_id)
);

-- Create player_roles junction table (players can have multiple roles)
CREATE TABLE public.player_roles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    player_profile_id UUID NOT NULL REFERENCES public.player_profiles(id) ON DELETE CASCADE,
    role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    assigned_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    assigned_by_user_id TEXT,
    UNIQUE(player_profile_id, role_id)
);

-- Create indexes for performance
CREATE INDEX idx_role_permissions_role_id ON public.role_permissions(role_id);
CREATE INDEX idx_role_permissions_permission_id ON public.role_permissions(permission_id);
CREATE INDEX idx_player_roles_player_profile_id ON public.player_roles(player_profile_id);
CREATE INDEX idx_player_roles_role_id ON public.player_roles(role_id);

-- Insert default permissions based on requirements
INSERT INTO public.permissions (name, description) VALUES
    ('manage_players', 'Can view and edit player profiles, roles, and basic information'),
    ('manage_characters', 'Can view, edit, and manage character sheets and progression'),
    ('manage_events', 'Can create, edit, and manage events and attendance'),
    ('manage_heritages', 'Can create, edit, and delete heritage options'),
    ('manage_cultures', 'Can create, edit, and delete culture options'),
    ('manage_skills', 'Can create, edit, and delete skills and skill trees'),
    ('manage_roles', 'Can create, edit, and assign roles and permissions to other users'),
    ('manage_chapters', 'Can create, edit, and manage chapter information'),
    ('manage_archetypes', 'Can create, edit, and delete archetype/class options'),
    ('view_admin_panel', 'Can access the admin dashboard and administrative tools');

-- Insert default roles
INSERT INTO public.roles (name, description, is_system_role) VALUES
    ('Super Admin', 'Full administrative access to all system functions', true),
    ('Chapter Admin', 'Administrative access limited to chapter-specific functions', true),
    ('Event Coordinator', 'Can manage events and attendance for their chapter', true),
    ('Character Sheet Admin', 'Can review and manage character sheets and progression', true),
    ('Player', 'Standard player role with no administrative privileges', true);

-- Get role IDs for permission assignments
DO $$
DECLARE
    super_admin_id UUID;
    chapter_admin_id UUID;
    event_coord_id UUID;
    char_admin_id UUID;
    player_id UUID;
BEGIN
    -- Get role IDs
    SELECT id INTO super_admin_id FROM public.roles WHERE name = 'Super Admin';
    SELECT id INTO chapter_admin_id FROM public.roles WHERE name = 'Chapter Admin';
    SELECT id INTO event_coord_id FROM public.roles WHERE name = 'Event Coordinator';
    SELECT id INTO char_admin_id FROM public.roles WHERE name = 'Character Sheet Admin';
    SELECT id INTO player_id FROM public.roles WHERE name = 'Player';

    -- Super Admin gets all permissions
    INSERT INTO public.role_permissions (role_id, permission_id)
    SELECT super_admin_id, id FROM public.permissions;

    -- Chapter Admin gets most permissions except manage_roles
    INSERT INTO public.role_permissions (role_id, permission_id)
    SELECT chapter_admin_id, id FROM public.permissions 
    WHERE name IN ('manage_players', 'manage_characters', 'manage_events', 'manage_heritages', 
                   'manage_cultures', 'manage_skills', 'manage_chapters', 'manage_archetypes', 'view_admin_panel');

    -- Event Coordinator gets event and player management
    INSERT INTO public.role_permissions (role_id, permission_id)
    SELECT event_coord_id, id FROM public.permissions 
    WHERE name IN ('manage_events', 'manage_players', 'view_admin_panel');

    -- Character Sheet Admin gets character and player management
    INSERT INTO public.role_permissions (role_id, permission_id)
    SELECT char_admin_id, id FROM public.permissions 
    WHERE name IN ('manage_characters', 'manage_players', 'view_admin_panel');

    -- Player role gets no administrative permissions (just basic access)
END $$;

-- Migrate existing admin users to Super Admin role
INSERT INTO public.player_roles (player_profile_id, role_id, assigned_by_user_id)
SELECT 
    pp.id,
    r.id,
    'system_migration'
FROM public.player_profiles pp
CROSS JOIN public.roles r
WHERE pp.is_admin = true 
AND r.name = 'Super Admin';