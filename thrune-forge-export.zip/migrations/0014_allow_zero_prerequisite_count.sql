-- Allow prerequisite_count to be 0 for skills with no prerequisites
ALTER TABLE skills DROP CONSTRAINT IF EXISTS skills_prerequisite_count_check;
ALTER TABLE skills ADD CONSTRAINT skills_prerequisite_count_check CHECK (prerequisite_count >= 0);