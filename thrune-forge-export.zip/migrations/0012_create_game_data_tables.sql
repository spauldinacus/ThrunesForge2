-- Skills table with prerequisite system
CREATE TABLE public.skills (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    hidden BOOLEAN DEFAULT false NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.skills IS 'LARP skills/abilities that characters can learn';
COMMENT ON COLUMN public.skills.hidden IS 'Hidden skills only visible when prerequisites are met';

-- Skills prerequisites junction table (self-referencing)
CREATE TABLE public.skill_prerequisites (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    prerequisite_skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(skill_id, prerequisite_skill_id)
);

COMMENT ON TABLE public.skill_prerequisites IS 'Skills prerequisite chains - what skills are required to learn other skills';

-- Heritages table (races/lineages)
CREATE TABLE public.heritages (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    costuming_requirements TEXT,
    base_body INTEGER NOT NULL DEFAULT 4,
    base_stamina INTEGER NOT NULL DEFAULT 4,
    benefit TEXT NOT NULL,
    weakness TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.heritages IS 'Character heritage/race options with stats and traits';
COMMENT ON COLUMN public.heritages.base_body IS 'Starting body points for this heritage';
COMMENT ON COLUMN public.heritages.base_stamina IS 'Starting stamina points for this heritage';

-- Heritage secondary skills junction table
CREATE TABLE public.heritage_secondary_skills (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    heritage_id UUID NOT NULL REFERENCES public.heritages(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(heritage_id, skill_id)
);

COMMENT ON TABLE public.heritage_secondary_skills IS 'Secondary skills available to each heritage';

-- Cultures table (linked to heritages)
CREATE TABLE public.cultures (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    heritage_id UUID NOT NULL REFERENCES public.heritages(id) ON DELETE RESTRICT,
    description TEXT NOT NULL,
    costuming_requirements TEXT,
    benefit TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.cultures IS 'Cultural backgrounds tied to specific heritages';

-- Archetypes table (character classes)
CREATE TABLE public.archetypes (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    description TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

COMMENT ON TABLE public.archetypes IS 'Character archetype/class options';

-- Archetype primary skills junction table
CREATE TABLE public.archetype_primary_skills (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    archetype_id UUID NOT NULL REFERENCES public.archetypes(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(archetype_id, skill_id)
);

COMMENT ON TABLE public.archetype_primary_skills IS 'Primary skills for each archetype';

-- Archetype secondary skills junction table
CREATE TABLE public.archetype_secondary_skills (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    archetype_id UUID NOT NULL REFERENCES public.archetypes(id) ON DELETE CASCADE,
    skill_id UUID NOT NULL REFERENCES public.skills(id) ON DELETE CASCADE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    UNIQUE(archetype_id, skill_id)
);

COMMENT ON TABLE public.archetype_secondary_skills IS 'Secondary skills for each archetype';

-- Indexes for performance
CREATE INDEX idx_skills_name ON public.skills(name);
CREATE INDEX idx_skills_hidden ON public.skills(hidden);
CREATE INDEX idx_skill_prerequisites_skill_id ON public.skill_prerequisites(skill_id);
CREATE INDEX idx_skill_prerequisites_prerequisite_skill_id ON public.skill_prerequisites(prerequisite_skill_id);
CREATE INDEX idx_heritages_name ON public.heritages(name);
CREATE INDEX idx_heritage_secondary_skills_heritage_id ON public.heritage_secondary_skills(heritage_id);
CREATE INDEX idx_heritage_secondary_skills_skill_id ON public.heritage_secondary_skills(skill_id);
CREATE INDEX idx_cultures_name ON public.cultures(name);
CREATE INDEX idx_cultures_heritage_id ON public.cultures(heritage_id);
CREATE INDEX idx_archetypes_name ON public.archetypes(name);
CREATE INDEX idx_archetype_primary_skills_archetype_id ON public.archetype_primary_skills(archetype_id);
CREATE INDEX idx_archetype_secondary_skills_archetype_id ON public.archetype_secondary_skills(archetype_id);