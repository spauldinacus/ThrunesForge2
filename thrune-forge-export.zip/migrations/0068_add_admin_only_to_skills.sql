-- Add admin_only column to skills table
ALTER TABLE skills 
ADD COLUMN admin_only BOOLEAN DEFAULT false NOT NULL;

COMMENT ON COLUMN skills.admin_only IS 'If true, skill can only be selected in admin character editor, not in player character creator';