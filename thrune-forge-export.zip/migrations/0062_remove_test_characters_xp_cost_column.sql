-- Remove the xp_cost column from test_characters table
-- XP cost should be calculated dynamically based on heritage, archetypes, body/stamina, and skills
ALTER TABLE test_characters DROP COLUMN IF EXISTS xp_cost;