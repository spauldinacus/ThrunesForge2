-- Allow negative XP available to support force deletions of XP transactions
-- The xp_available field can now go negative when admins force-delete transactions
ALTER TABLE characters DROP CONSTRAINT IF EXISTS characters_xp_check;

-- Re-add the constraint but only check that xp_spent <= xp_total
-- Remove the xp_available >= 0 check to allow negative XP
ALTER TABLE characters ADD CONSTRAINT characters_xp_check 
    CHECK (xp_spent <= xp_total);