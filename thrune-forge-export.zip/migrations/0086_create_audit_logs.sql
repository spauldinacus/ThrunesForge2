-- Create the audit_logs table
CREATE TABLE IF NOT EXISTS public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL PRIMARY KEY,
    action_type text NOT NULL, -- 'candle', 'xp', 'character', 'milestone', 'lore', 'reassignment', 'event', 'other'
    action text NOT NULL, -- 'create', 'update', 'delete', 'grant', 'spend', 'reassign'
    entity_id uuid, -- ID of the entity (character_id, etc)
    entity_type text, -- 'character', 'event', 'player_profile', 'rsvp', 'lore_submission', 'milestone'
    performed_by_user_id text, -- Stack Auth User ID
    details jsonb DEFAULT '{}'::jsonb, -- Store details like "Reason", "Amount", "Old Value/New Value"
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_audit_logs_performed_by ON public.audit_logs(performed_by_user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_action_type ON public.audit_logs(action_type);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON public.audit_logs(created_at);

-- BACKFILL: Candle Transactions
INSERT INTO public.audit_logs (action_type, action, entity_id, entity_type, performed_by_user_id, details, created_at)
SELECT 
    'candle', 
    CASE WHEN amount > 0 THEN 'grant' ELSE 'spend' END,
    player_profile_id,
    'player_profile',
    COALESCE(granted_by_user_id, 'system'),
    jsonb_build_object('amount', amount, 'reason', reason, 'used_for', used_for),
    created_at
FROM public.candle_transactions;

-- BACKFILL: Character Reassignments
INSERT INTO public.audit_logs (action_type, action, entity_id, entity_type, performed_by_user_id, details, created_at)
SELECT 
    'reassignment', 
    'reassign',
    character_id,
    'character',
    reassigned_by,
    jsonb_build_object('from_player_id', from_player_id, 'to_player_id', to_player_id, 'notes', notes),
    reassigned_at
FROM public.character_reassignment_history;

-- BACKFILL: Milestones (Only ones awarded by admin)
INSERT INTO public.audit_logs (action_type, action, entity_id, entity_type, performed_by_user_id, details, created_at)
SELECT 
    'milestone', 
    'grant',
    character_id,
    'character',
    awarded_by,
    jsonb_build_object('milestone_id', id, 'system_milestone_id', system_milestone_id, 'custom_name', custom_name),
    created_at
FROM public.player_milestones
WHERE awarded_by IS NOT NULL;

-- BACKFILL: Lore Submissions (Approvals/Creations)
INSERT INTO public.audit_logs (action_type, action, entity_id, entity_type, performed_by_user_id, details, created_at)
SELECT 
    'lore', 
    'create',
    id,
    'lore_submission',
    created_by,
    jsonb_build_object('outcome', outcome, 'lores_used', lores_used),
    created_at
FROM public.lore_submissions;

-- BACKFILL: XP Transactions
INSERT INTO public.audit_logs (action_type, action, entity_id, entity_type, performed_by_user_id, details, created_at)
SELECT 
    'xp', 
    CASE WHEN amount > 0 THEN 'grant' ELSE 'deduct' END,
    character_id,
    'character',
    'system', 
    jsonb_build_object('amount', amount, 'reason', reason, 'type', transaction_type),
    created_at
FROM public.xp_transactions;
