from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
import asyncpg
import os
import io
import zipfile
from typing import List, Dict
from pydantic import BaseModel

router = APIRouter(prefix="/export")

class ExportStatus(BaseModel):
    total_files: int
    total_migrations: int
    total_size_bytes: int
    ready: bool

class MigrationFile(BaseModel):
    name: str
    order: int
    sql: str
    executed_at: str

@router.get("/status")
async def get_export_status() -> ExportStatus:
    """Get export readiness status"""
    
    # Count code files
    code_files = []
    for root, dirs, files in os.walk("/disk/frontend/src"):
        for file in files:
            if file.endswith(('.tsx', '.ts', '.css', '.json')):
                code_files.append(os.path.join(root, file))
    
    for root, dirs, files in os.walk("/disk/backend/app"):
        for file in files:
            if file.endswith('.py'):
                code_files.append(os.path.join(root, file))
    
    # Count migrations
    conn = await asyncpg.connect(os.environ.get("DATABASE_URL_DEV"))
    try:
        migrations = await conn.fetch(
            "SELECT COUNT(*) as count FROM databutton.migrations WHERE execution_order >= 6"
        )
        migration_count = migrations[0]['count']
    finally:
        await conn.close()
    
    total_size = sum(os.path.getsize(f) for f in code_files if os.path.exists(f))
    
    return ExportStatus(
        total_files=len(code_files),
        total_migrations=migration_count,
        total_size_bytes=total_size,
        ready=True
    )

@router.get("/migrations")
async def get_all_migrations() -> List[MigrationFile]:
    """Extract all migrations from database"""
    
    conn = await asyncpg.connect(os.environ.get("DATABASE_URL_DEV"))
    try:
        migrations = await conn.fetch("""
            SELECT 
                name,
                execution_order,
                executed_at,
                sql
            FROM databutton.migrations 
            WHERE execution_order >= 6
            ORDER BY execution_order
        """)
        
        return [
            MigrationFile(
                name=m['name'],
                order=m['execution_order'],
                sql=m['sql'] or '',
                executed_at=m['executed_at'].isoformat()
            )
            for m in migrations
        ]
    finally:
        await conn.close()

@router.get("/download-package")
async def download_complete_package():
    """Download complete app package as ZIP"""
    
    zip_buffer = io.BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        
        # Add frontend files
        for root, dirs, files in os.walk("/disk/frontend/src"):
            for file in files:
                if file.endswith(('.tsx', '.ts', '.css', '.json', '.html')):
                    file_path = os.path.join(root, file)
                    arcname = file_path.replace("/disk/", "")
                    zip_file.write(file_path, arcname)
        
        # Add backend files
        for root, dirs, files in os.walk("/disk/backend/app"):
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    arcname = file_path.replace("/disk/", "")
                    zip_file.write(file_path, arcname)
        
        # Add config files
        config_files = [
            "/disk/frontend/package.json",
            "/disk/frontend/tsconfig.json",
            "/disk/frontend/vite.config.ts",
            "/disk/frontend/tailwind.config.ts",
            "/disk/backend/pyproject.toml",
        ]
        
        for config_file in config_files:
            if os.path.exists(config_file):
                arcname = config_file.replace("/disk/", "")
                zip_file.write(config_file, arcname)
        
        # Extract and add migrations
        conn = await asyncpg.connect(os.environ.get("DATABASE_URL_DEV"))
        try:
            migrations = await conn.fetch("""
                SELECT 
                    execution_order,
                    name,
                    sql
                FROM databutton.migrations 
                WHERE execution_order >= 6
                ORDER BY execution_order
            """)
            
            # Create migrations directory in ZIP
            for m in migrations:
                if m['sql']:
                    filename = f"migrations/{m['execution_order']:04d}_{m['name']}.sql"
                    zip_file.writestr(filename, m['sql'])
        finally:
            await conn.close()
        
        # Add README
        readme_content = """# Thrune's Forge - Exported Application

This package contains the complete application code and database migrations.

## Contents

- `frontend/` - React/TypeScript frontend code
- `backend/` - FastAPI backend code
- `migrations/` - Database migration files (in execution order)

## Next Steps

See DEPLOY_STANDALONE.md for deployment instructions.

Exported from Riff workspace on: """ + str(os.environ.get('MODE', 'development'))
        
        zip_file.writestr("README.md", readme_content)
    
    zip_buffer.seek(0)
    
    return StreamingResponse(
        zip_buffer,
        media_type="application/zip",
        headers={
            "Content-Disposition": "attachment; filename=thrune-forge-export.zip"
        }
    )