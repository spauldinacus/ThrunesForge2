

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
from app.auth import AuthorizedUser
import os
from app.env import mode, Mode
from datetime import datetime

router = APIRouter(prefix="/dev")

# Helper function to check admin permissions
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    from app.libs.database import get_database_connection
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 AND p.name LIKE '%admin%'
            )
            """,
            user.sub
        )
        
        if not admin_check:
            raise HTTPException(
                status_code=403,
                detail="Admin permissions required for this operation"
            )
    finally:
        await conn.close()

class PlayerProfileSync(BaseModel):
    """Player profile data for sync from production to development"""
    user_id: str
    first_name: str
    last_name: str
    phone_number: Optional[str] = None
    emergency_contact_name: Optional[str] = None
    emergency_contact_phone: Optional[str] = None
    player_number: Optional[str] = None
    chapter_id: Optional[str] = None
    candles_available: Optional[int] = 0
    is_admin: Optional[bool] = False
    email: Optional[str] = None
    created_at: str
    updated_at: str

class SyncPlayerProfilesRequest(BaseModel):
    """Request body for syncing player profiles from production"""
    player_profiles: List[PlayerProfileSync]

class SyncResponse(BaseModel):
    """Response for sync operations"""
    success: bool
    message: str
    synced_count: int

@router.post("/sync-player-profiles")
async def sync_player_profiles_from_production(
    request: SyncPlayerProfilesRequest,
    user: AuthorizedUser
) -> SyncResponse:
    """
    Sync player_profiles data from production to development.
    
    This endpoint receives complete player_profiles table data from production
    and updates the development database to maintain OAuth consistency.
    
    Only available in development environment and requires admin permissions.
    """
    
    # Check admin permission
    await check_admin_permission(user)
    
    # Only allow in development environment
    if mode != Mode.DEV:
        raise HTTPException(
            status_code=403, 
            detail="Sync endpoint only available in development environment"
        )
    
    # Get database connection
    database_url = os.environ.get("DATABASE_URL_DEV")
    if not database_url:
        raise HTTPException(
            status_code=500,
            detail="Development database connection not configured"
        )
    
    try:
        # Connect to development database
        conn = await asyncpg.connect(database_url)
        
        try:
            # Start transaction
            async with conn.transaction():
                # Clear existing player_profiles data
                await conn.execute("DELETE FROM player_profiles")
                print(f"Cleared existing player_profiles data")
                
                # Insert new player_profiles data
                synced_count = 0
                for profile in request.player_profiles:
                    # Parse ISO datetime strings
                    created_at = datetime.fromisoformat(profile.created_at.replace('Z', '+00:00'))
                    updated_at = datetime.fromisoformat(profile.updated_at.replace('Z', '+00:00'))
                    
                    await conn.execute(
                        """
                        INSERT INTO player_profiles (
                            user_id, first_name, last_name, phone_number, 
                            emergency_contact_name, emergency_contact_phone, 
                            player_number, chapter_id, candles_available, is_admin, email, 
                            created_at, updated_at
                        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
                        """,
                        profile.user_id,
                        profile.first_name,
                        profile.last_name,
                        profile.phone_number,
                        profile.emergency_contact_name,
                        profile.emergency_contact_phone,
                        profile.player_number,
                        profile.chapter_id,
                        profile.candles_available,
                        profile.is_admin,
                        profile.email,
                        created_at,
                        updated_at
                    )
                    synced_count += 1
                
                print(f"Successfully synced {synced_count} player profiles from production")
                
                return SyncResponse(
                    success=True,
                    message=f"Successfully synced {synced_count} player profiles from production",
                    synced_count=synced_count
                )
                
        finally:
            await conn.close()
            
    except asyncpg.PostgresError as e:
        print(f"Database error during sync: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Database error during sync: {str(e)}"
        )
    
    except Exception as e:
        print(f"Unexpected error during sync: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Unexpected error during sync: {str(e)}"
        )
