from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID
import asyncpg
import json
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection

router = APIRouter(prefix="/test-characters")

# ============================================================================
# PYDANTIC MODELS
# ============================================================================

class SelectedSkillRequest(BaseModel):
    """Skill purchase for test character."""
    skill_id: str
    quantity: int

class TestCharacterCreate(BaseModel):
    """Request model for creating a test character."""
    name: str
    heritage_id: str
    culture_id: str
    archetype_id: str
    secondary_archetype_id: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    body: int
    stamina: int
    corruption: int = 0
    deaths: int = 0
    selected_skills: List[SelectedSkillRequest]

class TestCharacterUpdate(BaseModel):
    """Request model for updating a test character."""
    name: Optional[str] = None
    heritage_id: Optional[str] = None
    culture_id: Optional[str] = None
    archetype_id: Optional[str] = None
    secondary_archetype_id: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    body: Optional[int] = None
    stamina: Optional[int] = None
    corruption: Optional[int] = None
    deaths: Optional[int] = None
    selected_skills: Optional[List[SelectedSkillRequest]] = None

class TestCharacterResponse(BaseModel):
    """Response model for a test character."""
    id: str
    user_id: str
    name: str
    heritage_id: str
    culture_id: str
    archetype_id: str
    secondary_archetype_id: Optional[str]
    tertiary_archetype_id: Optional[str]
    body: int
    stamina: int
    corruption: int
    deaths: int
    selected_skills: List[dict]
    xp_cost: int
    created_at: str
    updated_at: str

class TestCharacterListResponse(BaseModel):
    """Response model for listing test characters."""
    test_characters: List[TestCharacterResponse]
    count: int
    max_allowed: int = 3

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def calculate_body_stamina_xp_cost(current_value: int, target_value: int) -> int:
    """Calculate XP cost for body/stamina increases using the scaling system.
    
    XP Cost Logic:
    - 1-20: 1 XP per point
    - 21-40: 2 XP per point
    - 41-60: 3 XP per point
    - 61-80: 4 XP per point
    - 81-100: 5 XP per point
    - 101-120: 6 XP per point
    - 121-140: 7 XP per point
    - 141-160: 8 XP per point
    - 161-180: 9 XP per point
    - 181-200: 10 XP per point
    - 201+: 10 XP per point (capped)
    """
    if target_value <= current_value:
        return 0
    
    total_cost = 0
    
    for value in range(current_value + 1, target_value + 1):
        if value <= 20:
            total_cost += 1
        elif value <= 40:
            total_cost += 2
        elif value <= 60:
            total_cost += 3
        elif value <= 80:
            total_cost += 4
        elif value <= 100:
            total_cost += 5
        elif value <= 120:
            total_cost += 6
        elif value <= 140:
            total_cost += 7
        elif value <= 160:
            total_cost += 8
        elif value <= 180:
            total_cost += 9
        else:  # 181+
            total_cost += 10
    
    return total_cost

async def calculate_test_character_xp_cost(
    conn: asyncpg.Connection,
    heritage_id: str,
    archetype_id: str,
    secondary_archetype_id: Optional[str],
    tertiary_archetype_id: Optional[str],
    body: int,
    stamina: int,
    selected_skills: List[SelectedSkillRequest]
) -> int:
    """
    Calculate total XP cost for a test character (informational only).
    This mimics the real character creation XP calculation.
    """
    print(f"DEBUG: Calculating XP cost for test character")
    print(f"  Heritage: {heritage_id}, Archetype: {archetype_id}")
    print(f"  Secondary: {secondary_archetype_id}, Tertiary: {tertiary_archetype_id}")
    print(f"  Body: {body}, Stamina: {stamina}")
    print(f"  Skills: {len(selected_skills)} purchases")
    
    # Get heritage base stats
    heritage_row = await conn.fetchrow(
        "SELECT base_body, base_stamina FROM heritages WHERE id = $1",
        UUID(heritage_id)
    )
    
    if not heritage_row:
        print(f"ERROR: Heritage {heritage_id} not found")
        raise HTTPException(status_code=400, detail="Invalid heritage")
    
    # Calculate body/stamina costs using tiered system
    body_cost = calculate_body_stamina_xp_cost(heritage_row['base_body'], body)
    stamina_cost = calculate_body_stamina_xp_cost(heritage_row['base_stamina'], stamina)
    
    print(f"  Body cost: {body_cost} (base: {heritage_row['base_body']})")
    print(f"  Stamina cost: {stamina_cost} (base: {heritage_row['base_stamina']})")
    
    # Calculate archetype costs (50 XP each for secondary and tertiary)
    archetype_cost = 0
    if secondary_archetype_id:
        archetype_cost += 50
    if tertiary_archetype_id:
        archetype_cost += 50
    
    print(f"  Archetype cost: {archetype_cost}")
    
    # Calculate skill costs based on archetype affinities
    skill_cost = 0
    if selected_skills:
        skill_ids = [s.skill_id for s in selected_skills]
        
        # Query skill costs considering all archetypes and heritage
        skill_cost_query = """
        SELECT s.id,
               CASE 
                   -- Check if primary skill in ANY archetype (primary, secondary, or tertiary)
                   WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN 5
                   -- Check if secondary skill in ANY archetype or heritage
                   WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
                   -- Default cost for tertiary skills
                   ELSE 20
               END as xp_cost
        FROM skills s
        -- Primary archetype
        LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = $1
        LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = $1
        -- Secondary archetype
        LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = $2
        LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = $2
        -- Tertiary archetype
        LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = $3
        LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = $3
        -- Heritage
        LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = $4
        WHERE s.id = ANY($5)
        """
        
        skill_rows = await conn.fetch(
            skill_cost_query,
            UUID(archetype_id),
            UUID(secondary_archetype_id) if secondary_archetype_id else UUID(archetype_id),
            UUID(tertiary_archetype_id) if tertiary_archetype_id else UUID(archetype_id),
            UUID(heritage_id),
            [UUID(s) for s in skill_ids]
        )
        
        # Calculate total skill cost considering quantities
        for skill_row in skill_rows:
            skill_id = str(skill_row['id'])
            cost_per_purchase = skill_row['xp_cost']
            total_quantity = sum(s.quantity for s in selected_skills if s.skill_id == skill_id)
            skill_cost += cost_per_purchase * total_quantity
            print(f"  Skill {skill_id}: {cost_per_purchase} XP x {total_quantity} = {cost_per_purchase * total_quantity}")
    
    total_cost = body_cost + stamina_cost + archetype_cost + skill_cost
    print(f"  TOTAL XP COST: {total_cost}")
    
    return total_cost

# ============================================================================
# ENDPOINTS
# ============================================================================

@router.get("/my-test-characters")
async def list_my_test_characters(user: AuthorizedUser) -> TestCharacterListResponse:
    """Get all test characters for the authenticated user (max 3)."""
    print(f"DEBUG: Listing test characters for user {user.sub}")
    
    conn = await get_database_connection()
    try:
        query = """
        SELECT * FROM test_characters 
        WHERE user_id = $1 
        ORDER BY created_at DESC
        """
        rows = await conn.fetch(query, user.sub)
        
        print(f"DEBUG: Found {len(rows)} test characters")
        
        test_characters = [
            TestCharacterResponse(
                id=str(row['id']),
                user_id=row['user_id'],
                name=row['name'],
                heritage_id=str(row['heritage_id']),
                culture_id=str(row['culture_id']),
                archetype_id=str(row['archetype_id']),
                secondary_archetype_id=str(row['secondary_archetype_id']) if row['secondary_archetype_id'] else None,
                tertiary_archetype_id=str(row['tertiary_archetype_id']) if row['tertiary_archetype_id'] else None,
                body=row['body'],
                stamina=row['stamina'],
                corruption=row['corruption'],
                deaths=row['deaths'],
                selected_skills=json.loads(row['selected_skills']) if row['selected_skills'] else [],
                xp_cost=await calculate_test_character_xp_cost(
                    conn,
                    str(row['heritage_id']),
                    str(row['archetype_id']),
                    str(row['secondary_archetype_id']) if row['secondary_archetype_id'] else None,
                    str(row['tertiary_archetype_id']) if row['tertiary_archetype_id'] else None,
                    row['body'],
                    row['stamina'],
                    [SelectedSkillRequest(**s) for s in (json.loads(row['selected_skills']) if row['selected_skills'] else [])]
                ),
                created_at=row['created_at'].isoformat(),
                updated_at=row['updated_at'].isoformat()
            )
            for row in rows
        ]
        
        return TestCharacterListResponse(
            test_characters=test_characters,
            count=len(test_characters),
            max_allowed=3
        )
    finally:
        await conn.close()

@router.post("/create")
async def create_test_character(character_data: TestCharacterCreate, user: AuthorizedUser) -> TestCharacterResponse:
    """Create a new test character. Limited to 3 per user."""
    print(f"DEBUG: Creating test character for user {user.sub}")
    print(f"DEBUG: Character data: {character_data.dict()}")
    
    conn = await get_database_connection()
    try:
        # Check count limit (3 max)
        count_query = "SELECT COUNT(*) FROM test_characters WHERE user_id = $1"
        count = await conn.fetchval(count_query, user.sub)
        
        print(f"DEBUG: User has {count} test characters")
        
        if count >= 3:
            print("ERROR: User has reached max test character limit")
            raise HTTPException(
                status_code=400, 
                detail="Maximum 3 test characters allowed. Please delete one to create a new one."
            )
        
        # Validate heritage exists
        heritage_check = await conn.fetchrow(
            "SELECT id FROM heritages WHERE id = $1",
            UUID(character_data.heritage_id)
        )
        if not heritage_check:
            raise HTTPException(status_code=400, detail="Invalid heritage")
        
        # Validate culture exists and belongs to heritage
        culture_check = await conn.fetchrow(
            "SELECT id FROM cultures WHERE id = $1 AND heritage_id = $2",
            UUID(character_data.culture_id),
            UUID(character_data.heritage_id)
        )
        if not culture_check:
            raise HTTPException(status_code=400, detail="Invalid culture for selected heritage")
        
        # Validate archetype exists
        archetype_check = await conn.fetchrow(
            "SELECT id FROM archetypes WHERE id = $1",
            UUID(character_data.archetype_id)
        )
        if not archetype_check:
            raise HTTPException(status_code=400, detail="Invalid archetype")
        
        # Calculate XP cost (no limit, just tracking)
        xp_cost = await calculate_test_character_xp_cost(
            conn,
            character_data.heritage_id,
            character_data.archetype_id,
            character_data.secondary_archetype_id,
            character_data.tertiary_archetype_id,
            character_data.body,
            character_data.stamina,
            character_data.selected_skills
        )
        
        print(f"DEBUG: Calculated XP cost: {xp_cost}")
        
        # Insert test character
        insert_query = """
        INSERT INTO test_characters 
        (user_id, name, heritage_id, culture_id, archetype_id, 
         secondary_archetype_id, tertiary_archetype_id, body, stamina, 
         corruption, deaths, selected_skills)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12::jsonb)
        RETURNING *
        """
        
        row = await conn.fetchrow(
            insert_query,
            user.sub,
            character_data.name,
            UUID(character_data.heritage_id),
            UUID(character_data.culture_id),
            UUID(character_data.archetype_id),
            UUID(character_data.secondary_archetype_id) if character_data.secondary_archetype_id else None,
            UUID(character_data.tertiary_archetype_id) if character_data.tertiary_archetype_id else None,
            character_data.body,
            character_data.stamina,
            character_data.corruption,
            character_data.deaths,
            json.dumps([{"skill_id": s.skill_id, "quantity": s.quantity} for s in character_data.selected_skills]),
        )
        
        print(f"SUCCESS: Created test character {row['id']}")
        
        return TestCharacterResponse(
            id=str(row['id']),
            user_id=row['user_id'],
            name=row['name'],
            heritage_id=str(row['heritage_id']),
            culture_id=str(row['culture_id']),
            archetype_id=str(row['archetype_id']),
            secondary_archetype_id=str(row['secondary_archetype_id']) if row['secondary_archetype_id'] else None,
            tertiary_archetype_id=str(row['tertiary_archetype_id']) if row['tertiary_archetype_id'] else None,
            body=row['body'],
            stamina=row['stamina'],
            corruption=row['corruption'],
            deaths=row['deaths'],
            selected_skills=json.loads(row['selected_skills']) if row['selected_skills'] else [],
            xp_cost=xp_cost,  # Already calculated above
            created_at=row['created_at'].isoformat(),
            updated_at=row['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.put("/{test_character_id}")
async def update_test_character(
    test_character_id: str, 
    character_data: TestCharacterUpdate, 
    user: AuthorizedUser
) -> TestCharacterResponse:
    """Update a test character. Recalculates XP cost."""
    print(f"DEBUG: Updating test character {test_character_id} for user {user.sub}")
    
    conn = await get_database_connection()
    try:
        # Verify ownership
        existing = await conn.fetchrow(
            "SELECT * FROM test_characters WHERE id = $1 AND user_id = $2",
            UUID(test_character_id), user.sub
        )
        
        if not existing:
            print(f"ERROR: Test character {test_character_id} not found or not owned by user")
            raise HTTPException(status_code=404, detail="Test character not found")
        
        print(f"DEBUG: Found existing test character: {existing['name']}")
        
        # Build update data with current values as defaults
        update_dict = character_data.dict(exclude_unset=True)
        
        final_heritage_id = update_dict.get('heritage_id', str(existing['heritage_id']))
        final_culture_id = update_dict.get('culture_id', str(existing['culture_id']))
        final_archetype_id = update_dict.get('archetype_id', str(existing['archetype_id']))
        final_secondary_archetype_id = update_dict.get('secondary_archetype_id', str(existing['secondary_archetype_id']) if existing['secondary_archetype_id'] else None)
        final_tertiary_archetype_id = update_dict.get('tertiary_archetype_id', str(existing['tertiary_archetype_id']) if existing['tertiary_archetype_id'] else None)
        final_body = update_dict.get('body', existing['body'])
        final_stamina = update_dict.get('stamina', existing['stamina'])
        final_corruption = update_dict.get('corruption', existing['corruption'])
        final_deaths = update_dict.get('deaths', existing['deaths'])
        final_name = update_dict.get('name', existing['name'])
        
        # Handle selected_skills (convert from dict to list of SelectedSkillRequest)
        if 'selected_skills' in update_dict:
            final_selected_skills = [
                SelectedSkillRequest(skill_id=s['skill_id'], quantity=s['quantity']) 
                for s in update_dict['selected_skills']
            ]
        else:
            final_selected_skills = [
                SelectedSkillRequest(skill_id=s['skill_id'], quantity=s['quantity']) 
                for s in (json.loads(existing['selected_skills']) if existing['selected_skills'] else [])
            ]
        
        # Recalculate XP cost
        xp_cost = await calculate_test_character_xp_cost(
            conn,
            final_heritage_id,
            final_archetype_id,
            final_secondary_archetype_id,
            final_tertiary_archetype_id,
            final_body,
            final_stamina,
            final_selected_skills
        )
        
        print(f"DEBUG: Recalculated XP cost: {xp_cost}")
        
        # Update test character
        update_query = """
        UPDATE test_characters 
        SET name = $2,
            heritage_id = $3,
            culture_id = $4,
            archetype_id = $5,
            secondary_archetype_id = $6,
            tertiary_archetype_id = $7,
            body = $8,
            stamina = $9,
            corruption = $10,
            deaths = $11,
            selected_skills = $12::jsonb,
            updated_at = NOW()
        WHERE id = $1
        RETURNING *
        """
        
        row = await conn.fetchrow(
            update_query,
            UUID(test_character_id),
            final_name,
            UUID(final_heritage_id),
            UUID(final_culture_id),
            UUID(final_archetype_id),
            UUID(final_secondary_archetype_id) if final_secondary_archetype_id else None,
            UUID(final_tertiary_archetype_id) if final_tertiary_archetype_id else None,
            final_body,
            final_stamina,
            final_corruption,
            final_deaths,
            json.dumps([{"skill_id": s.skill_id, "quantity": s.quantity} for s in final_selected_skills]),
        )
        
        print(f"SUCCESS: Updated test character {test_character_id}")
        
        return TestCharacterResponse(
            id=str(row['id']),
            user_id=row['user_id'],
            name=row['name'],
            heritage_id=str(row['heritage_id']),
            culture_id=str(row['culture_id']),
            archetype_id=str(row['archetype_id']),
            secondary_archetype_id=str(row['secondary_archetype_id']) if row['secondary_archetype_id'] else None,
            tertiary_archetype_id=str(row['tertiary_archetype_id']) if row['tertiary_archetype_id'] else None,
            body=row['body'],
            stamina=row['stamina'],
            corruption=row['corruption'],
            deaths=row['deaths'],
            selected_skills=json.loads(row['selected_skills']) if row['selected_skills'] else [],
            xp_cost=xp_cost,  # Already calculated above
            created_at=row['created_at'].isoformat(),
            updated_at=row['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.delete("/{test_character_id}")
async def delete_test_character(test_character_id: str, user: AuthorizedUser):
    """Delete a test character."""
    print(f"DEBUG: Deleting test character {test_character_id} for user {user.sub}")
    
    conn = await get_database_connection()
    try:
        result = await conn.execute(
            "DELETE FROM test_characters WHERE id = $1 AND user_id = $2",
            UUID(test_character_id), user.sub
        )
        
        if result == "DELETE 0":
            print(f"ERROR: Test character {test_character_id} not found or not owned by user")
            raise HTTPException(status_code=404, detail="Test character not found")
        
        print(f"SUCCESS: Deleted test character {test_character_id}")
        
        return {"message": "Test character deleted successfully"}
    finally:
        await conn.close()
