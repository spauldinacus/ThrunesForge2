from fastapi import APIRouter, HTTPException, Depends, Request, Query
from fastapi.exceptions import RequestValidationError
from pydantic import BaseModel, Field, ValidationError, field_validator
from typing import List, Optional, Dict, Any
from uuid import UUID, uuid4
from datetime import datetime
import asyncpg
import os
import json
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from app.libs.sync_utils import sync_player_profiles_to_dev, log_sync_attempt
from app.libs.permissions import get_user_chapters_with_permission, check_permission

router = APIRouter(prefix="/admin/players")

# Pydantic Models
class Permission(BaseModel):
    """Permission model"""
    id: str
    name: str
    description: Optional[str]

class Role(BaseModel):
    """Role model with permissions"""
    id: str
    name: str
    description: str | None = None
    permissions: List[Permission] = Field(default_factory=list)
    is_system_role: bool = False
    user_count: int = 0

class RoleCreate(BaseModel):
    """Role creation model"""
    name: str
    description: Optional[str] = None
    permission_ids: List[str] = []

class PlayerAssignedRole(BaseModel):
    """Role assigned to a player, optionally scoped to a chapter"""
    id: str
    name: str
    description: Optional[str]
    permissions: List[Permission] = []
    chapter_id: Optional[str] = None
    chapter_name: Optional[str] = None

class RoleAssignment(BaseModel):
    """Input model for assigning a role"""
    role_id: str
    chapter_id: Optional[str] = None

class RoleUpdate(BaseModel):
    """Role update model"""
    name: str
    description: Optional[str] = None
    permission_ids: List[str] = []

class PlayerSummary(BaseModel):
    """Player summary for management table"""
    id: str
    user_id: str
    first_name: str
    last_name: str
    player_number: str
    email: str | None = None
    chapter_name: str
    character_count: int
    roles: List[str] = []  # Role names
    is_admin: bool = False  # Legacy field
    created_at: str

class PlayerDetailResponse(BaseModel):
    """Detailed player information for editing"""
    id: str
    user_id: str
    first_name: str
    last_name: str
    phone_number: Optional[str]
    emergency_contact_name: Optional[str]
    emergency_contact_phone: Optional[str]
    chapter_id: str
    chapter_name: str
    player_number: str
    candles_available: int
    roles: List[PlayerAssignedRole] = []
    is_admin: bool = False
    email: Optional[str] = None
    referred_by_player_id: Optional[str] = None
    referred_by_player_name: Optional[str] = None
    referred_by_player_number: Optional[str] = None
    referral_acknowledged: bool = False
    referral_acknowledged_at: Optional[str] = None
    referral_acknowledged_by_user_id: Optional[str] = None
    referral_acknowledged_by_name: Optional[str] = None    
    created_at: str
    updated_at: str


class UpdatePlayerRolesRequest(BaseModel):
    """Request to update player roles"""
    assignments: List[RoleAssignment] = Field(..., description="List of roles to assign to player")
    reason: str = Field(..., min_length=1, max_length=500, description="Reason for role change")

class UpdatePlayerProfileRequest(BaseModel):
    """Request to update player profile (admin)"""
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    phone_number: Optional[str] = Field(None, max_length=20)
    emergency_contact_name: Optional[str] = Field(None, max_length=200)
    emergency_contact_phone: Optional[str] = Field(None, max_length=20)
    chapter_id: Optional[str] = None
    player_number: Optional[str] = Field(None, pattern=r"^[A-Z]{2}\d{7}$")
    referred_by_player_id: Optional[str] = None
    reason: str = Field(..., min_length=1, max_length=500, description="Reason for changes")
    
    @field_validator('player_number', 'phone_number', 'emergency_contact_name', 'emergency_contact_phone', 'referred_by_player_id', mode='before')
    @classmethod
    def empty_str_to_none(cls, v):
        """Convert empty strings to None for optional fields"""
        if v == "":
            return None
        return v

class CandleTransaction(BaseModel):
    """Candle transaction history entry"""
    id: str
    player_profile_id: str
    amount: int
    reason: str
    transaction_type: Optional[str] = None  # manual_adjustment, event_attendance, character_creation, referral_bonus
    character_id: Optional[str] = None
    character_name: Optional[str] = None  # Resolved character name if character_id exists
    event_id: Optional[str] = None
    event_name: Optional[str] = None  # Resolved event name if event_id exists
    granted_by_user_id: Optional[str]
    granted_by_name: Optional[str]  # Name of admin who created transaction
    created_at: str

class CandleHistoryResponse(BaseModel):
    """Response with player candle info and transaction history"""
    player_id: str
    player_name: str
    current_balance: int
    transactions: List[CandleTransaction]

class CreateCandleTransactionRequest(BaseModel):
    """Request to create a new candle transaction"""
    amount: int = Field(..., description="Amount of candles (positive or negative)")
    reason: str = Field(..., min_length=1, max_length=500, description="Reason for candle transaction")
    transaction_type: str = Field(default="manual_adjustment", description="Type of transaction: manual_adjustment, event_attendance, character_creation, referral_bonus")
    character_id: Optional[str] = Field(None, description="Character ID for character_creation transactions")
    event_id: Optional[str] = Field(None, description="Event ID for event_attendance transactions")

class UpdateCandleTransactionRequest(BaseModel):
    """Request to update an existing candle transaction"""
    amount: int = Field(..., description="New amount")
    reason: str = Field(..., min_length=1, max_length=500, description="Updated reason")
    transaction_type: str = Field(default="manual_adjustment", description="Type of transaction")
    character_id: Optional[str] = Field(None, description="Character ID for character_creation transactions")
    event_id: Optional[str] = Field(None, description="Event ID for event_attendance transactions")

class NegativeBalanceError(BaseModel):
    """Error response for transactions causing negative balance"""
    would_cause_negative: bool
    current_balance: int
    requested_amount: int

class CharacterSummary(BaseModel):
    """Summary of character info for player list"""
    id: str
    name: str
    heritage_name: str
    culture_name: str
    archetype_name: str
    status: str = "Active" # Default status

# Database connection
async def get_db_connection():
    """Get database connection"""
    return await get_database_connection()

# Simple admin permission check
async def check_admin_permission(user: AuthorizedUser):
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        # First get the player profile for this Stack Auth user
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_players', 'view_admin_panel', 'manage_roles')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

# API Endpoints
@router.get("/roles", response_model=List[Role])
async def list_all_roles(user: AuthorizedUser):
    """List all available roles with permissions (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        roles_data = await conn.fetch(
            """
            SELECT 
                r.id,
                r.name,
                r.description,
                r.is_system_role,
                (
                    SELECT COUNT(DISTINCT pr.player_profile_id) 
                    FROM public.player_roles pr 
                    WHERE pr.role_id = r.id
                ) as user_count,
                COALESCE(
                    jsonb_agg(
                        jsonb_build_object(
                            'id', p.id,
                            'name', p.name,
                            'description', p.description
                        )
                    ) FILTER (WHERE p.id IS NOT NULL),
                    '[]'::jsonb
                ) as permissions
            FROM public.roles r
            LEFT JOIN public.role_permissions rp ON r.id = rp.role_id
            LEFT JOIN public.permissions p ON rp.permission_id = p.id
            GROUP BY r.id, r.name, r.description, r.is_system_role
            ORDER BY r.name
            """
        )
        
        roles = []
        for role_data in roles_data:
            # Parse permissions - handle both JSON string and parsed data
            permissions_data = role_data['permissions']
            
            # If permissions_data is a string, parse it as JSON
            if isinstance(permissions_data, str):
                import json
                try:
                    permissions_data = json.loads(permissions_data)
                except json.JSONDecodeError:
                    permissions_data = []
            
            permissions = []
            if permissions_data and permissions_data != []:
                permissions = [
                    Permission(
                        id=str(perm['id']),
                        name=perm['name'],
                        description=perm['description']
                    )
                    for perm in permissions_data
                ]
            
            role = Role(
                id=str(role_data['id']),
                name=role_data['name'],
                description=role_data['description'],
                permissions=permissions,
                is_system_role=role_data['is_system_role'],
                user_count=role_data['user_count']
            )
            roles.append(role)
        
        return roles
    finally:
        await conn.close()

@router.get("/permissions", response_model=List[Permission])
async def list_permissions(user: AuthorizedUser):
    """List all available permissions"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        permissions_data = await conn.fetch(
            "SELECT id, name, description FROM public.permissions ORDER BY name"
        )
        
        return [
            Permission(
                id=str(perm['id']),
                name=perm['name'],
                description=perm['description']
            )
            for perm in permissions_data
        ]
    finally:
        await conn.close()

@router.post("/roles", response_model=Role)
async def create_role(role_data: RoleCreate, user: AuthorizedUser):
    """Create a new role"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if role name already exists
        existing_role = await conn.fetchval(
            "SELECT id FROM public.roles WHERE name = $1",
            role_data.name
        )
        if existing_role:
            raise HTTPException(status_code=400, detail="Role name already exists")
        
        # Create the role
        role_id = uuid4()
        await conn.execute(
            """
            INSERT INTO public.roles (id, name, description, is_system_role, created_at)
            VALUES ($1, $2, $3, $4, $5)
            """,
            role_id, role_data.name, role_data.description, False, datetime.utcnow()
        )
        
        # Add permissions to the role
        if role_data.permission_ids:
            for permission_id in role_data.permission_ids:
                try:
                    permission_uuid = UUID(permission_id)
                except ValueError:
                    raise HTTPException(
                        status_code=400, 
                        detail=f"Invalid permission ID format: {permission_id}"
                    )
                
                await conn.execute(
                    "INSERT INTO public.role_permissions (role_id, permission_id) VALUES ($1, $2)",
                    role_id, permission_uuid
                )
        
        # Fetch the created role with permissions
        role_with_permissions = await conn.fetchrow(
            """
            SELECT 
                r.id,
                r.name,
                r.description,
                r.is_system_role,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', p.id,
                            'name', p.name,
                            'description', p.description
                        )
                    ) FILTER (WHERE p.id IS NOT NULL),
                    '[]'::json
                ) as permissions
            FROM public.roles r
            LEFT JOIN public.role_permissions rp ON r.id = rp.role_id
            LEFT JOIN public.permissions p ON rp.permission_id = p.id
            WHERE r.id = $1
            GROUP BY r.id, r.name, r.description, r.is_system_role
            """,
            role_id
        )

        permissions_data = role_with_permissions['permissions']
        permissions = []
        
        # Handle the permissions data properly
        if permissions_data:
            if isinstance(permissions_data, str):
                import json
                permissions_list = json.loads(permissions_data)
            else:
                permissions_list = permissions_data
            
            # Only create Permission objects if we have actual permission data
            if permissions_list and permissions_list != []:
                permissions = [
                    Permission(
                        id=str(perm['id']),
                        name=perm['name'],
                        description=perm['description']
                    )
                    for perm in permissions_list
                    if perm and 'id' in perm  # Additional safety check
                ]
        
        # Return the created role with its permissions
        # Log action
        await log_admin_action(
            user.sub, "role", "create", str(role_id), "role",
            {"name": role_data.name}
        )        
        return Role(
            id=str(role_id),
            name=role_data.name,
            description=role_data.description,
            permissions=permissions,
            is_system_role=False,
            user_count=0  # New roles start with 0 users
        )
    finally:
        await conn.close()

@router.put("/roles/{role_id}", response_model=Role)
async def update_role(role_id: str, role_data: RoleUpdate, user: AuthorizedUser):
    """Update an existing role"""
    await check_admin_permission(user)
    
    # Validate role_id is a proper UUID
    try:
        UUID(role_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid role ID format")
    
    conn = await get_database_connection()
    try:
        # Check if role exists and is not a system role
        role_info = await conn.fetchrow(
            "SELECT id, is_system_role FROM public.roles WHERE id = $1",
            UUID(role_id)
        )
        if not role_info:
            raise HTTPException(status_code=404, detail="Role not found")
        if role_info['is_system_role']:
            raise HTTPException(status_code=400, detail="Cannot modify system roles")
        
        # Check if new name conflicts with existing role (excluding current role)
        name_conflict = await conn.fetchval(
            "SELECT id FROM public.roles WHERE name = $1 AND id != $2",
            role_data.name, UUID(role_id)
        )
        if name_conflict:
            raise HTTPException(status_code=400, detail="Role name already exists")
        
        # Validate permission IDs are valid UUIDs and exist
        if role_data.permission_ids:
            for perm_id in role_data.permission_ids:
                try:
                    UUID(perm_id)  # Validate UUID format
                except ValueError:
                    raise HTTPException(status_code=400, detail=f"Invalid permission ID format: {perm_id}")
                
                # Check if permission exists
                perm_exists = await conn.fetchval(
                    "SELECT EXISTS(SELECT 1 FROM public.permissions WHERE id = $1)",
                    UUID(perm_id)
                )
                if not perm_exists:
                    raise HTTPException(status_code=400, detail=f"Permission {perm_id} does not exist")
        
        # Update the role
        await conn.execute(
            """
            UPDATE public.roles 
            SET name = $2, description = $3
            WHERE id = $1
            """,
            UUID(role_id), role_data.name, role_data.description
        )
        
        # Remove existing permissions
        await conn.execute(
            "DELETE FROM public.role_permissions WHERE role_id = $1",
            UUID(role_id)
        )
        
        # Add new permissions
        if role_data.permission_ids:
            for permission_id in role_data.permission_ids:
                await conn.execute(
                    "INSERT INTO public.role_permissions (role_id, permission_id) VALUES ($1, $2)",
                    UUID(role_id), UUID(permission_id)
                )
        
        # Fetch the updated role with permissions
        role_with_permissions = await conn.fetchrow(
            """
            SELECT 
                r.id,
                r.name,
                r.description,
                r.is_system_role,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', p.id,
                            'name', p.name,
                            'description', p.description
                        )
                    ) FILTER (WHERE p.id IS NOT NULL),
                    '[]'::json
                ) as permissions
            FROM public.roles r
            LEFT JOIN public.role_permissions rp ON r.id = rp.role_id
            LEFT JOIN public.permissions p ON rp.permission_id = p.id
            WHERE r.id = $1
            GROUP BY r.id, r.name, r.description, r.is_system_role
            """,
            UUID(role_id)
        )
        
        if not role_with_permissions:
            raise HTTPException(status_code=404, detail="Role not found after update")
        
        # Convert permissions JSON to list of Permission objects
        permissions_data = role_with_permissions['permissions']
        if isinstance(permissions_data, str):
            import json
            permissions_data = json.loads(permissions_data)
        
        permissions = [
            Permission(
                id=str(perm['id']),
                name=perm['name'],
                description=perm['description']
            )
            for perm in permissions_data
            if perm and 'id' in perm
        ]
        
        # Get user count for this role
        user_count = await conn.fetchval(
            "SELECT COUNT(*) FROM public.player_roles WHERE role_id = $1",
            UUID(role_id)
        ) or 0

        await log_admin_action(
            user.sub, "role", "update", role_id, "role",
            {"name": role_data.name}
        )
        
        return Role(
            id=str(role_with_permissions['id']),
            name=role_with_permissions['name'],
            description=role_with_permissions['description'],
            permissions=permissions,
            is_system_role=role_with_permissions['is_system_role'],
            user_count=user_count
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Unexpected error in update_role: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")
    finally:
        await conn.close()

@router.delete("/roles/{role_id}")
async def delete_role(role_id: str, user: AuthorizedUser):
    """Delete a role (only if not assigned to any users and not a system role)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if role exists and is not a system role
        role_info = await conn.fetchrow(
            "SELECT id, name, is_system_role FROM public.roles WHERE id = $1",
            UUID(role_id)
        )
        if not role_info:
            raise HTTPException(status_code=404, detail="Role not found")
        if role_info['is_system_role']:
            raise HTTPException(status_code=400, detail="Cannot delete system roles")
        
        # Check if role is assigned to any users
        user_count = await conn.fetchval(
            "SELECT COUNT(*) FROM public.player_roles WHERE role_id = $1",
            UUID(role_id)
        )
        if user_count > 0:
            raise HTTPException(
                status_code=400, 
                detail=f"Cannot delete role '{role_info['name']}' - it is assigned to {user_count} user(s)"
            )
        
        # Delete role permissions first (foreign key constraint)
        await conn.execute(
            "DELETE FROM public.role_permissions WHERE role_id = $1",
            UUID(role_id)
        )
        
        # Delete the role
        await conn.execute(
            "DELETE FROM public.roles WHERE id = $1",
            UUID(role_id)
        )

        await log_admin_action(
            user.sub, "role", "delete", role_id, "role", {}
        )
        
        return {"message": "Role deleted successfully"}
    finally:
        await conn.close()

@router.get("/{player_id}", response_model=PlayerDetailResponse)
async def get_player_detail(player_id: str, user: AuthorizedUser):
    """Get detailed player information for editing (admin only)"""
    # Validate UUID format
    try:
        player_uuid = UUID(player_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player ID format")
    
    conn = await get_db_connection()
    try:
        # Get player info with referral data
        player = await conn.fetchrow(
            """
            SELECT 
                pp.*,
                c.name as chapter_name,
                referrer.first_name || ' ' || referrer.last_name as referrer_name,
                referrer.player_number as referrer_number,
                acknowledger.first_name || ' ' || acknowledger.last_name as acknowledger_name
            FROM public.player_profiles pp
            JOIN public.chapters c ON pp.chapter_id = c.id
            LEFT JOIN public.player_profiles referrer ON pp.referred_by_player_id = referrer.id
            LEFT JOIN public.player_profiles acknowledger ON pp.referral_acknowledged_by_user_id = acknowledger.user_id
            WHERE pp.id = $1
            """,
            player_uuid
        )
        
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
            
        # Check if user has permission to view this player
        await check_permission(user.sub, "manage_players", str(player['chapter_id']))
        
        # Get player roles with permissions and chapter scope
        roles_data = await conn.fetch(
            """
            SELECT 
                r.id,
                r.name,
                r.description,
                r.is_system_role,
                pr.chapter_id,
                c.name as chapter_name,
                COALESCE(
                    json_agg(
                        json_build_object(
                            'id', p.id,
                            'name', p.name,
                            'description', p.description
                        )
                    ) FILTER (WHERE p.id IS NOT NULL),
                    '[]'::json
                ) as permissions
            FROM public.player_roles pr
            JOIN public.roles r ON pr.role_id = r.id
            LEFT JOIN public.chapters c ON pr.chapter_id = c.id
            LEFT JOIN public.role_permissions rp ON r.id = rp.role_id
            LEFT JOIN public.permissions p ON rp.permission_id = p.id
            WHERE pr.player_profile_id = $1
            GROUP BY r.id, r.name, r.description, r.is_system_role, pr.chapter_id, c.name
            ORDER BY r.name
            """,
            UUID(player_id)
        )
        
        roles = []
        for role_data in roles_data:
            permissions_data = role_data['permissions']
            permissions = []
            
            # Handle the case where permissions might be JSON string or actual list
            if permissions_data and permissions_data != '[]':
                import json
                permissions_list = json.loads(permissions_data)
                
                permissions = [
                    Permission(
                        id=str(perm['id']),
                        name=perm['name'],
                        description=perm['description']
                    )
                    for perm in permissions_list
                ]
            
            roles.append(PlayerAssignedRole(
                id=str(role_data['id']),
                name=role_data['name'],
                description=role_data['description'],
                permissions=permissions,
                is_system_role=role_data['is_system_role'],
                chapter_id=str(role_data['chapter_id']) if role_data['chapter_id'] else None,
                chapter_name=role_data['chapter_name']
            ))
        
        return PlayerDetailResponse(
            id=str(player['id']),
            user_id=player['user_id'],
            first_name=player['first_name'],
            last_name=player['last_name'],
            phone_number=player['phone_number'],
            emergency_contact_name=player['emergency_contact_name'],
            emergency_contact_phone=player['emergency_contact_phone'],
            chapter_id=str(player['chapter_id']),
            chapter_name=player['chapter_name'],
            player_number=player['player_number'],
            candles_available=player['candles_available'],
            roles=roles,
            is_admin=player['is_admin'],
            email=player['email'] or getattr(user, 'email', None),  # Add email fallback logic
            created_at=player['created_at'].isoformat(),
            updated_at=player['updated_at'].isoformat(),
                        referred_by_player_id=str(player['referred_by_player_id']) if player['referred_by_player_id'] else None,
            referred_by_player_name=player['referrer_name'],
            referred_by_player_number=player['referrer_number'],
            referral_acknowledged=player['referral_acknowledged'],
            referral_acknowledged_at=player['referral_acknowledged_at'].isoformat() if player['referral_acknowledged_at'] else None,
            referral_acknowledged_by_user_id=player['referral_acknowledged_by_user_id'],
            referral_acknowledged_by_name=player.get('acknowledger_name')
        )
    finally:
        await conn.close()

@router.get("/{player_id}/characters", response_model=List[CharacterSummary])
async def list_player_characters(player_id: str, user: AuthorizedUser):
    """List all characters for a specific player (admin only)"""
    conn = await get_db_connection()
    try:
        player_uuid = UUID(player_id)
        
        # Verify player exists and check chapter permission
        player = await conn.fetchrow(
            "SELECT chapter_id FROM public.player_profiles WHERE id = $1",
            player_uuid
        )
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
            
        await check_permission(user.sub, "manage_players", str(player['chapter_id']))
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player ID format")
    except Exception as e:
        if "Permission denied" in str(e):
            raise
        # Re-raise other exceptions or handle them
        raise

    try:
        characters = await conn.fetch(
            """
            SELECT 
                c.id,
                c.name,
                h.name as heritage_name,
                cl.name as culture_name,
                a.name as archetype_name,
                CASE 
                    WHEN c.retired THEN 'Retired'
                    WHEN c.deaths >= 3 THEN 'Dead'
                    ELSE 'Active'
                END as status
            FROM public.characters c
            JOIN public.heritages h ON c.heritage_id = h.id
            JOIN public.cultures cl ON c.culture_id = cl.id
            JOIN public.archetypes a ON c.archetype_id = a.id
            WHERE c.player_profile_id = $1
            ORDER BY c.created_at DESC
            """,
            player_uuid
        )
        
        return [
            CharacterSummary(
                id=str(char['id']),
                name=char['name'],
                heritage_name=char['heritage_name'],
                culture_name=char['culture_name'],
                archetype_name=char['archetype_name'],
                status=char['status']
            )
            for char in characters
        ]
    finally:
        await conn.close()

@router.get("/", response_model=List[PlayerSummary])
async def list_all_players(user: AuthorizedUser):
    """List all players with management information (admin only)"""
    # Get chapters the user has permission to manage
    allowed_chapters = await get_user_chapters_with_permission(user.sub, "manage_players")
    
    # If list is empty, user has no permission
    if not allowed_chapters:
        raise HTTPException(status_code=403, detail="Permission denied: manage_players")
    
    # Check if user has global permission (indicated by None in the list)
    is_global = None in allowed_chapters
    
    conn = await get_db_connection()
    try:
        query = """
            SELECT 
                pp.id,
                pp.user_id,
                pp.first_name,
                pp.last_name,
                pp.player_number,
                pp.email,
                c.name as chapter_name,
                pp.is_admin,
                pp.created_at,
                COALESCE(char_count.count, 0) as character_count,
                COALESCE(
                    array_agg(r.name) FILTER (WHERE r.name IS NOT NULL),
                    ARRAY[]::text[]
                ) as role_names
            FROM public.player_profiles pp
            JOIN public.chapters c ON pp.chapter_id = c.id
            LEFT JOIN (
                SELECT player_profile_id, COUNT(*) as count
                FROM public.characters
                GROUP BY player_profile_id
            ) char_count ON pp.id = char_count.player_profile_id
            LEFT JOIN public.player_roles pr ON pp.id = pr.player_profile_id
            LEFT JOIN public.roles r ON pr.role_id = r.id
        """
        
        args = []
        # If not global, filter by allowed chapters
        if not is_global:
            # Filter out None values just in case, though logic above handles it
            chapter_ids = [c for c in allowed_chapters if c is not None]
            query += " WHERE pp.chapter_id = ANY($1::uuid[])"
            args.append(chapter_ids)
            
        query += """
            GROUP BY pp.id, pp.user_id, pp.first_name, pp.last_name, 
                     pp.player_number, pp.email, c.name, pp.is_admin, pp.created_at, char_count.count
            ORDER BY pp.created_at DESC
        """
        
        players = await conn.fetch(query, *args)
        
        return [
            PlayerSummary(
                id=str(player['id']),
                user_id=player['user_id'],
                first_name=player['first_name'],
                last_name=player['last_name'],
                player_number=player['player_number'],
                email=player['email'],
                chapter_name=player['chapter_name'],
                character_count=player['character_count'],
                roles=player['role_names'] or [],
                is_admin=player['is_admin'],
                created_at=player['created_at'].isoformat()
            )
            for player in players
        ]
    finally:
        await conn.close()

@router.put("/{player_id}/roles", response_model=Dict[str, Any])
async def update_player_roles(
    player_id: str,
    request: UpdatePlayerRolesRequest,
    user: AuthorizedUser
):
    """Update player roles (admin only)"""
    conn = await get_db_connection()
    try:
        # Verify player exists and check permissions
        player_data = await conn.fetchrow(
            "SELECT id, chapter_id FROM public.player_profiles WHERE id = $1",
            UUID(player_id)
        )
        if not player_data:
            raise HTTPException(status_code=404, detail="Player not found")
            
        # Check permission to manage roles for this player's chapter
        await check_permission(user.sub, "manage_roles", str(player_data['chapter_id']))
        
        # Check permissions for any specific chapters being assigned
        for assignment in request.assignments:
            if assignment.chapter_id:
                await check_permission(user.sub, "manage_roles", assignment.chapter_id)
        
        # Verify all role IDs exist
        role_ids = list(set([assignment.role_id for assignment in request.assignments]))
        if role_ids:
            role_count = await conn.fetchval(
                "SELECT COUNT(*) FROM public.roles WHERE id = ANY($1::uuid[])",
                [UUID(rid) for rid in role_ids]
            )
            if role_count != len(role_ids):
                raise HTTPException(status_code=400, detail="One or more invalid role IDs")

        # Verify all chapter IDs exist (if provided)
        chapter_ids = list(set([assignment.chapter_id for assignment in request.assignments if assignment.chapter_id]))
        if chapter_ids:
            chapter_count = await conn.fetchval(
                "SELECT COUNT(*) FROM public.chapters WHERE id = ANY($1::uuid[])",
                [UUID(cid) for cid in chapter_ids]
            )
            if chapter_count != len(chapter_ids):
                raise HTTPException(status_code=400, detail="One or more invalid chapter IDs")
        
        # Remove existing roles
        await conn.execute(
            "DELETE FROM public.player_roles WHERE player_profile_id = $1",
            UUID(player_id)
        )
        
        # Add new roles
        for assignment in request.assignments:
            await conn.execute(
                """
                INSERT INTO public.player_roles (player_profile_id, role_id, chapter_id, assigned_by_user_id)
                VALUES ($1, $2, $3, $4)
                """,
                UUID(player_id), 
                UUID(assignment.role_id), 
                UUID(assignment.chapter_id) if assignment.chapter_id else None,
                user.sub
            )
        
        # Log the change
        print(f"Admin {user.sub} updated roles for player {player_id}. Reason: {request.reason}")

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="player_roles",
            action="update",
            entity_id=player_id,
            entity_type="player_profile",
            details={"assignments": [a.dict() for a in request.assignments], "reason": request.reason}
        )        
        
        # Trigger sync to development (non-blocking)
        try:
            sync_success = await sync_player_profiles_to_dev()
            log_sync_attempt("update_player_roles", player_id, sync_success)
        except Exception as sync_error:
            log_sync_attempt("update_player_roles", player_id, False, str(sync_error))
        
        return {
            "success": True,
            "message": "Player roles updated successfully",
            "assigned_roles": len(request.assignments)
        }
    finally:
        await conn.close()

@router.put("/{player_id}/profile", response_model=PlayerDetailResponse)
async def update_player_profile(
    player_id: str,
    request: UpdatePlayerProfileRequest,
    user: AuthorizedUser
):
    """Update player profile information (admin only)"""
    conn = await get_db_connection()
    try:
        # Fetch current player data for validation
        player = await conn.fetchrow(
            "SELECT id, chapter_id, referral_acknowledged FROM public.player_profiles WHERE id = $1",
            UUID(player_id)
        )
        
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")

        # Check permission for current chapter
        await check_permission(user.sub, "manage_players", str(player['chapter_id']))
        
        # If changing chapter, check permission for new chapter
        if request.chapter_id and str(request.chapter_id) != str(player['chapter_id']):
             await check_permission(user.sub, "manage_players", str(request.chapter_id))
                
        # Build update query dynamically
        update_fields = []
        update_values = []
        param_count = 1
        
        if request.first_name is not None:
            update_fields.append(f"first_name = ${param_count}")
            update_values.append(request.first_name)
            param_count += 1
            
        if request.last_name is not None:
            update_fields.append(f"last_name = ${param_count}")
            update_values.append(request.last_name)
            param_count += 1
            
        if request.phone_number is not None:
            update_fields.append(f"phone_number = ${param_count}")
            update_values.append(request.phone_number)
            param_count += 1
            
        if request.emergency_contact_name is not None:
            update_fields.append(f"emergency_contact_name = ${param_count}")
            update_values.append(request.emergency_contact_name)
            param_count += 1
            
        if request.emergency_contact_phone is not None:
            update_fields.append(f"emergency_contact_phone = ${param_count}")
            update_values.append(request.emergency_contact_phone)
            param_count += 1
            
        if request.chapter_id is not None:
            # Verify chapter exists
            chapter_exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM public.chapters WHERE id = $1)",
                UUID(request.chapter_id)
            )
            if not chapter_exists:
                raise HTTPException(status_code=400, detail="Invalid chapter ID")
                
            update_fields.append(f"chapter_id = ${param_count}")
            update_values.append(UUID(request.chapter_id))
            param_count += 1

        # Validate referral changes
        if request.referred_by_player_id is not None and request.referred_by_player_id != "":
            # Check if referral is already acknowledged (locked)
            if player['referral_acknowledged']:
                raise HTTPException(
                    status_code=400,
                    detail="Referral has been acknowledged and cannot be changed"
                )
            
            # Prevent self-referral
            if request.referred_by_player_id == str(player['id']):
                raise HTTPException(status_code=400, detail="Player cannot refer themselves")
            
            # Validate UUID format
            try:
                referrer_uuid = UUID(request.referred_by_player_id)
            except ValueError:
                raise HTTPException(status_code=400, detail=f"Invalid referrer player ID format: {request.referred_by_player_id}")
            
            # Validate referrer exists
            referrer = await conn.fetchrow(
                "SELECT id FROM public.player_profiles WHERE id = $1",
                referrer_uuid
            )
            if not referrer:
                raise HTTPException(status_code=400, detail="Invalid referrer player ID")

            # Add to update fields
            update_fields.append(f"referred_by_player_id = ${param_count}")
            update_values.append(UUID(request.referred_by_player_id))
            param_count += 1      
        if request.player_number is not None:
            # Check if player number is already taken
            existing_player = await conn.fetchval(
                "SELECT id FROM public.player_profiles WHERE player_number = $1 AND id != $2",
                request.player_number, UUID(player_id)
            )
            if existing_player:
                raise HTTPException(status_code=400, detail="Player number already in use")
                
            update_fields.append(f"player_number = ${param_count}")
            update_values.append(request.player_number)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append(f"updated_at = NOW()")
        
        # Add player_id for WHERE clause
        update_values.append(UUID(player_id))
        
        # Execute update
        query = """
            UPDATE public.player_profiles 
            SET {} 
            WHERE id = ${}
        """.format(', '.join(update_fields), param_count)
        
        await conn.execute(query, *update_values)
        
        # Log the change
        print(f"Admin {user.sub} updated profile for player {player_id}. Reason: {request.reason}")

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="player_profile",
            action="update",
            entity_id=player_id,
            entity_type="player_profile",
            details=request.dict(exclude_unset=True)
        )
        
        # Trigger sync to development (non-blocking)
        try:
            sync_success = await sync_player_profiles_to_dev()
            log_sync_attempt("update_player_profile", player_id, sync_success)
        except Exception as sync_error:
            log_sync_attempt("update_player_profile", player_id, False, str(sync_error))


        
        # Return updated player data
        return await get_player_detail(player_id, user)
        
    finally:
        await conn.close()



@router.delete("/{player_id}")
async def delete_player(player_id: str, user: AuthorizedUser):
    """Delete a player and all associated data (admin only)"""
    await check_admin_permission(user)
    
    try:
        player_uuid = UUID(player_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player ID format")
    
    conn = await get_db_connection()
    try:
        # Verify player exists
        player = await conn.fetchrow(
            "SELECT id, first_name, last_name FROM public.player_profiles WHERE id = $1",
            player_uuid
        )
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
        
        # Delete in order to respect foreign key constraints:
        # 1. Delete player roles
        await conn.execute(
            "DELETE FROM public.player_roles WHERE player_profile_id = $1",
            player_uuid
        )
        
        # 2. Delete character-related data (XP transactions)
        await conn.execute(
            """
            DELETE FROM public.xp_transactions 
            WHERE character_id IN (
                SELECT id FROM public.characters WHERE player_profile_id = $1
            )
            """,
            player_uuid
        )
        
        # 3. Delete characters
        await conn.execute(
            "DELETE FROM public.characters WHERE player_profile_id = $1",
            player_uuid
        )
        
        # 4. Delete candle history
        await conn.execute(
            "DELETE FROM public.candle_transactions WHERE player_profile_id = $1",
            player_uuid
        )
                
        # 5. Delete event RSVPs
        await conn.execute(
            "DELETE FROM public.rsvps WHERE user_id = (SELECT user_id FROM public.player_profiles WHERE id = $1)",
            player_uuid
        )
        
        # 6. Finally, delete the player profile
        await conn.execute(
            "DELETE FROM public.player_profiles WHERE id = $1",
            player_uuid
        )
        
        # Log the deletion
        print(f"Admin {user.sub} deleted player {player_id} ({player['first_name']} {player['last_name']})")

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="player_profile",
            action="delete",
            entity_id=player_id,
            entity_type="player_profile",
            details={"name": f"{player['first_name']} {player['last_name']}"}
        )
        
        # Trigger sync to development
        try:
            sync_success = await sync_player_profiles_to_dev()
            log_sync_attempt("delete_player", player_id, sync_success)
        except Exception as sync_error:
            log_sync_attempt("delete_player", player_id, False, str(sync_error))
        
        return {"success": True, "message": "Player deleted successfully"}
        
    finally:
        await conn.close()



@router.get("/{player_id}/candle-history", response_model=CandleHistoryResponse)
async def get_player_candle_history(player_id: str, user: AuthorizedUser):
    """Get candle transaction history for a specific player (admin only)"""
    await check_admin_permission(user)
    
    try:
        player_uuid = UUID(player_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player ID format")
    
    conn = await get_db_connection()
    try:
        # Get player info
        player = await conn.fetchrow(
            "SELECT id, first_name, last_name, candles_available FROM public.player_profiles WHERE id = $1",
            player_uuid
        )
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
        
        # Get transaction history with admin names
        transactions_rows = await conn.fetch(
            """
            SELECT 
                ct.id,
                ct.player_profile_id,
                ct.amount,
                ct.reason,
                ct.transaction_type,
                ct.character_id,
                ct.event_id,
                ct.granted_by_user_id,
                ct.created_at,
                pp.first_name || ' ' || pp.last_name as granted_by_name,
                c.name as character_name,
                e.title as event_name
            FROM public.candle_transactions ct
            LEFT JOIN public.player_profiles pp ON ct.granted_by_user_id = pp.user_id
            LEFT JOIN public.characters c ON ct.character_id = c.id
            LEFT JOIN public.events e ON ct.event_id = e.id
            WHERE ct.player_profile_id = $1
            ORDER BY ct.created_at DESC
            """,
            player_uuid
        )
        
        transactions = [
            CandleTransaction(
                id=str(row['id']),
                player_profile_id=str(row['player_profile_id']),
                amount=row['amount'],
                reason=row['reason'],
                transaction_type=row['transaction_type'],
                character_id=str(row['character_id']) if row['character_id'] else None,
                character_name=row['character_name'],
                event_id=str(row['event_id']) if row['event_id'] else None,
                event_name=row['event_name'],
                granted_by_user_id=row['granted_by_user_id'],
                granted_by_name=row['granted_by_name'],
                created_at=row['created_at'].isoformat()
            )
            for row in transactions_rows
        ]
        
        return CandleHistoryResponse(
            player_id=str(player['id']),
            player_name=f"{player['first_name']} {player['last_name']}",
            current_balance=player['candles_available'],
            transactions=transactions
        )
        
    finally:
        await conn.close()



@router.post(
    "/{player_id}/candles",
    responses={409: {"model": NegativeBalanceError}}
)
async def create_candle_transaction(
    player_id: str, 
    request: CreateCandleTransactionRequest,
    user: AuthorizedUser,
    force: bool = Query(False, description="Force the transaction even if it results in a negative balance")
):
    """Create a new candle transaction for a player (admin only)"""
    await check_admin_permission(user)
    
    try:
        player_uuid = UUID(player_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player ID format")
    
    conn = await get_db_connection()
    try:
        # Start transaction
        async with conn.transaction():
            # Verify player exists and get current balance
            player = await conn.fetchrow(
                "SELECT id, first_name, last_name, candles_available FROM public.player_profiles WHERE id = $1",
                player_uuid
            )
            if not player:
                raise HTTPException(status_code=404, detail="Player not found")
            
            # Check if transaction would result in negative balance
            new_balance = player['candles_available'] + request.amount
            if new_balance < 0 and not force:
                # Return structured response instead of throwing exception
                return {
                    "success": False,
                    "would_cause_negative": True,
                    "current_balance": player['candles_available'],
                    "requested_amount": request.amount,
                    "projected_balance": new_balance,
                    "message": f"This transaction would result in negative candles ({new_balance}). Confirm to proceed anyway."
                }
            
            # Create transaction record
            transaction_id = await conn.fetchval(
                """
                INSERT INTO public.candle_transactions (
                    player_profile_id, amount, reason, granted_by_user_id,
                    transaction_type, character_id, event_id
                )
                VALUES ($1, $2, $3, $4, $5, $6, $7)
                RETURNING id
                """,
                player_uuid,
                request.amount,
                request.reason,
                user.sub,
                request.transaction_type,
                UUID(request.character_id) if request.character_id else None,
                UUID(request.event_id) if request.event_id else None
            )
            
            # Update player's candle balance
            await conn.execute(
                "UPDATE public.player_profiles SET candles_available = candles_available + $1 WHERE id = $2",
                request.amount,
                player_uuid
            )
            
            print(f"Admin {user.sub} {'added' if request.amount > 0 else 'removed'} {abs(request.amount)} candles for player {player_id}. Reason: {request.reason}")

            await log_admin_action(
                performed_by_user_id=user.sub,
                action_type="candle",
                action="create",
                entity_id=player_id,
                entity_type="player_profile",
                details={"amount": request.amount, "reason": request.reason, "transaction_id": str(transaction_id)}
            )
            
            return {
                "success": True,
                "transaction_id": str(transaction_id),
                "new_balance": new_balance,
                "message": f"Successfully {'added' if request.amount > 0 else 'removed'} {abs(request.amount)} candles"
            }
        
    finally:
        await conn.close()

@router.put("/{player_id}/candles/{transaction_id}")
async def update_candle_transaction(
    player_id: str,
    transaction_id: str,
    request: UpdateCandleTransactionRequest,
    user: AuthorizedUser
):
    """Update an existing candle transaction (admin only)"""
    await check_admin_permission(user)
    
    # Validate UUIDs
    try:
        player_uuid = UUID(player_id)
        transaction_uuid = UUID(transaction_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid ID format")
    
    # Ensure at least one field is being updated
    if request.amount is None and request.reason is None:
        raise HTTPException(status_code=400, detail="Must provide at least one field to update")
    
    conn = await get_db_connection()
    try:
        # Verify transaction exists and belongs to this player
        existing = await conn.fetchrow(
            """
            SELECT id, player_profile_id, amount
            FROM public.candle_transactions
            WHERE id = $1
            """,
            transaction_uuid
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Transaction not found")
        
        if str(existing['player_profile_id']) != player_id:
            raise HTTPException(status_code=400, detail="Transaction does not belong to this player")
        
        # Calculate the difference in candles if amount is changing
        old_amount = existing['amount']
        new_amount = request.amount if request.amount is not None else old_amount
        new_reason = request.reason if request.reason is not None else existing['reason']
        amount_diff = new_amount - old_amount
        
        # Update the transaction
        await conn.execute(
            """
            UPDATE public.candle_transactions
            SET amount = $2, reason = $3, transaction_type = $4, character_id = $5, event_id = $6
            WHERE id = $1
            """,
            transaction_uuid, 
            new_amount, 
            new_reason,
            request.transaction_type,
            UUID(request.character_id) if request.character_id else None,
            UUID(request.event_id) if request.event_id else None
        )
        
        # Update player's candle balance if amount changed
        if amount_diff != 0:
            await conn.execute(
                """
                UPDATE player_profiles
                SET candles_available = candles_available + $2
                WHERE id = $1
                """,
                player_uuid, amount_diff
            )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="candle",
            action="update",
            entity_id=player_id,
            entity_type="player_profile",
            details={"transaction_id": transaction_id, "amount": new_amount, "reason": new_reason}
        )
        
        # Fetch updated transaction
        updated = await conn.fetchrow(
            """
            SELECT 
                ct.id,
                ct.player_profile_id,
                ct.amount,
                ct.reason,
                ct.transaction_type,
                ct.character_id,
                ct.event_id,
                ct.granted_by_user_id,
                COALESCE(pp_granter.first_name || ' ' || pp_granter.last_name, 'System') as granted_by_name,
                ct.created_at,
                c.name as character_name,
                e.title as event_name
            FROM public.candle_transactions ct
            LEFT JOIN player_profiles pp_granter ON ct.granted_by_user_id = pp_granter.user_id
            LEFT JOIN public.characters c ON ct.character_id = c.id
            LEFT JOIN public.events e ON ct.event_id = e.id
            WHERE ct.id = $1
            """,
            transaction_uuid
        )
        
        return {
            "id": str(updated['id']),
            "player_profile_id": str(updated['player_profile_id']),
            "amount": updated['amount'],
            "reason": updated['reason'],
            "transaction_type": updated['transaction_type'],
            "character_id": str(updated['character_id']) if updated['character_id'] else None,
            "character_name": updated['character_name'],
            "event_id": str(updated['event_id']) if updated['event_id'] else None,
            "event_name": updated['event_name'],
            "granted_by_user_id": updated['granted_by_user_id'],
            "granted_by_name": updated['granted_by_name'],
            "created_at": updated['created_at'].isoformat()
        }
    finally:
        await conn.close()



@router.delete("/{player_id}/candles/{transaction_id}")
async def delete_candle_transaction(
    player_id: str,
    transaction_id: str,
    user: AuthorizedUser
):
    """Delete a candle transaction (admin only)"""
    await check_admin_permission(user)
    
    # Validate UUIDs
    try:
        player_uuid = UUID(player_id)
        transaction_uuid = UUID(transaction_id)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid ID format")
    
    conn = await get_db_connection()
    try:
        # Fetch transaction to verify it exists and get amount for balance adjustment
        transaction = await conn.fetchrow(
            """
            SELECT id, player_profile_id, amount
            FROM public.candle_transactions
            WHERE id = $1
            """,
            transaction_uuid
        )
        
        if not transaction:
            raise HTTPException(status_code=404, detail="Transaction not found")
        
        if str(transaction['player_profile_id']) != player_id:
            raise HTTPException(status_code=400, detail="Transaction does not belong to this player")
        
        # Delete the transaction
        await conn.execute(
            "DELETE FROM public.candle_transactions WHERE id = $1",
            transaction_uuid
        )
        
        # Adjust player's candle balance (reverse the transaction)
        await conn.execute(
            """
            UPDATE player_profiles
            SET candles_available = candles_available - $2
            WHERE id = $1
            """,
            player_uuid, transaction['amount']
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="candle",
            action="delete",
            entity_id=player_id,
            entity_type="player_profile",
            details={"transaction_id": transaction_id, "original_amount": transaction['amount']}
        )
        
        return {"message": "Transaction deleted successfully"}
    finally:
        await conn.close()


@router.get("/{player_id}/characters/{character_id}/events", response_model=List[Dict[str, Any]])
async def get_player_character_events(player_id: str, character_id: str, user: AuthorizedUser):
    """Get all events a character has RSVP'd to or attended (admin only)"""
    conn = await get_db_connection()
    try:
        player_uuid = UUID(player_id)
        character_uuid = UUID(character_id)
        
        # Verify player exists and check permissions
        player = await conn.fetchrow(
            "SELECT chapter_id FROM public.player_profiles WHERE id = $1",
            player_uuid
        )
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
            
        await check_permission(user.sub, "manage_players", str(player['chapter_id']))
        
        # Verify character belongs to player
        char_check = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM public.characters WHERE id = $1 AND player_profile_id = $2)",
            character_uuid, player_uuid
        )
        if not char_check:
            raise HTTPException(status_code=404, detail="Character not found for this player")
        
        # Get all events this character has RSVP'd to or attended
        events = await conn.fetch(
            """
            SELECT 
                e.id,
                e.title,
                e.starts_at,
                er.status,
                er.attendance_status,
                er.character_id
            FROM public.rsvps er
            JOIN public.events e ON er.event_id = e.id
            WHERE er.character_id = $1
            ORDER BY e.starts_at DESC
            """,
            character_uuid
        )
        
        return [
            {
                "id": str(event['id']),
                "name": event['title'],
                "event_date": event['starts_at'].isoformat() if event['starts_at'] else None,
                "rsvp_status": event['status'],
                "attended": event['attendance_status'] == 'attended',
                "character_id": str(event['character_id'])
            }
            for event in events
        ]
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid player or character ID format")
    finally:
        await conn.close()