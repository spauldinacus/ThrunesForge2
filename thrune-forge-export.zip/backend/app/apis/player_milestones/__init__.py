from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime, timezone
from uuid import UUID
from datetime import datetime
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/player-milestones")

# Pydantic Models

class SystemMilestoneProgress(BaseModel):
    """System milestone with calculated progress"""
    id: str
    name: str
    description: str
    category: str
    milestone_type: str
    threshold_value: int
    current_progress: int
    completed: bool
    player_milestone_id: Optional[str] = None
    notes: Optional[str] = None
    shared_with_staff: bool = False
    completed_at: Optional[str] = None
    awarded_by: Optional[str] = None
    awarded_by_user_name: Optional[str] = None

class CustomMilestoneCreate(BaseModel):
    """Create a custom player milestone"""
    character_id: str
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1)
    category: str = Field(..., max_length=100)
    target_progress: Optional[int] = None
    notes: Optional[str] = None
    shared_with_staff: bool = False

class CustomMilestoneUpdate(BaseModel):
    """Update a custom milestone"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, min_length=1)
    category: Optional[str] = None
    current_progress: Optional[int] = None
    target_progress: Optional[int] = None
    notes: Optional[str] = None
    shared_with_staff: Optional[bool] = None
    completed_at: Optional[str] = None

class CustomMilestoneResponse(BaseModel):
    """Custom milestone response"""
    id: str
    character_id: str
    character_name: str
    name: str
    description: str
    category: str
    current_progress: int
    target_progress: Optional[int]
    completed: bool
    notes: Optional[str]
    shared_with_staff: bool
    completed_at: Optional[str]
    created_at: str
    updated_at: str

class JournalEntryCreate(BaseModel):
    """Create a journal entry"""
    character_id: str
    title: str = Field(..., min_length=1, max_length=255)
    content: str = Field(..., min_length=1)
    tags: List[str] = Field(default=[])
    event_id: Optional[str] = None
    shared_with_staff: bool = False

class JournalEntryUpdate(BaseModel):
    """Update a journal entry"""
    title: Optional[str] = Field(None, min_length=1, max_length=255)
    content: Optional[str] = Field(None, min_length=1)
    tags: Optional[List[str]] = None
    event_id: Optional[str] = None
    shared_with_staff: Optional[bool] = None

class JournalEntryResponse(BaseModel):
    """Journal entry response"""
    id: str
    character_id: str
    character_name: str
    title: str
    content: str
    tags: List[str]
    event_id: Optional[str]
    event_title: Optional[str]
    shared_with_staff: bool
    created_at: str
    updated_at: str

# Helper Functions

async def verify_character_ownership(character_id: str, user_id: str) -> bool:
    """Verify that the user owns the specified character"""
    conn = await get_database_connection()
    try:
        result = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM characters c
                JOIN player_profiles pp ON c.player_profile_id = pp.id
                WHERE c.id = $1 AND pp.user_id = $2
            )
            """,
            UUID(character_id),
            user_id
        )
        return result
    finally:
        await conn.close()

async def calculate_system_milestone_progress(
    character_id: str,
    milestone_type: str,
    threshold: int
) -> int:
    """
    Calculate current progress for a system milestone.
    Supports: event_count, xp_total, skill_count, candle_total, character_age_days
    """
    conn = await get_database_connection()
    try:
        if milestone_type == "event_count":
            # Count events attended by this specific character
            progress = await conn.fetchval(
                """
                SELECT COUNT(DISTINCT r.event_id)
                FROM rsvps r
                WHERE r.character_id = $1 AND r.attendance_status = 'attended'
                """,
                UUID(character_id)
            )
        elif milestone_type == "xp_total":
            # Get total XP for character
            progress = await conn.fetchval(
                "SELECT xp_total FROM characters WHERE id = $1",
                UUID(character_id)
            )
        elif milestone_type == "skill_count":
            # Count purchased skills
            result = await conn.fetchval(
                "SELECT selected_skills FROM characters WHERE id = $1",
                UUID(character_id)
            )
            if result:
                import json
                skills = json.loads(result) if isinstance(result, str) else result
                progress = len(skills) if isinstance(skills, list) else 0
            else:
                progress = 0
        elif milestone_type == "candle_total":
            # Get total candles earned (sum of positive transactions)
            char_row = await conn.fetchrow(
                "SELECT player_profile_id FROM characters WHERE id = $1",
                UUID(character_id)
            )
            if char_row:
                progress = await conn.fetchval(
                    "SELECT COALESCE(SUM(amount), 0) FROM candle_transactions WHERE player_profile_id = $1 AND amount > 0",
                    char_row['player_profile_id']
                )
            else:
                progress = 0
        elif milestone_type == "character_age_days":
            # Calculate days since character creation
            result = await conn.fetchval(
                "SELECT EXTRACT(DAY FROM NOW() - created_at)::int FROM characters WHERE id = $1",
                UUID(character_id)
            )
            progress = result or 0
        elif milestone_type == "other":
            # For 'other' type, return 1 if marked complete, 0 otherwise
            # This will be checked via player_milestones.completed_at
            progress = 0
        else:
            progress = 0
        
        return int(progress) if progress else 0
    finally:
        await conn.close()

# Endpoints

@router.get("/character/{character_id}/system-milestones", response_model=List[SystemMilestoneProgress])
async def get_character_system_milestones(character_id: str, user: AuthorizedUser):
    """Get all system milestones with progress for a character"""
    # Verify ownership
    if not await verify_character_ownership(character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to view this character's milestones")
    
    conn = await get_database_connection()
    try:
        # Get all enabled system milestones
        system_milestones = await conn.fetch(
            "SELECT * FROM system_milestones WHERE enabled = true ORDER BY category, name"
        )
        
        result = []
        for sm in system_milestones:
            # Check if player has a milestone record for this
            player_milestone = await conn.fetchrow(
                """
                SELECT 
                    pm.id, 
                    pm.notes, 
                    pm.shared_with_staff, 
                    pm.completed_at,
                    pm.awarded_by,
                    TRIM(CONCAT(pp.first_name, ' ', pp.last_name)) as awarded_by_user_name
                FROM player_milestones pm
                LEFT JOIN player_profiles pp ON pm.awarded_by = pp.user_id
                WHERE pm.character_id = $1 AND pm.system_milestone_id = $2
                """,
                UUID(character_id),
                sm['id']
            )
            
            # Determine completion status - Manual assignment takes precedence
            manual_completion = bool(player_milestone and player_milestone['completed_at'] is not None)
            
            if manual_completion:
                completed = True
                current_progress = sm['threshold_value'] # Force full progress if awarded
            elif sm['milestone_type'] == 'other':
                completed = False
                current_progress = 0
            else:
                # Calculate current progress for trackable milestones
                current_progress = await calculate_system_milestone_progress(
                    character_id,
                    sm['milestone_type'],
                    sm['threshold_value']
                )
                completed = current_progress >= sm['threshold_value']
            
            # Handle awarded_by name with fallback
            awarded_by_name = None
            if player_milestone and player_milestone['awarded_by']:
                awarded_by_name = player_milestone['awarded_by_user_name'] or "Admin"

            result.append(SystemMilestoneProgress(
                id=str(sm['id']),
                name=sm['name'],
                description=sm['description'],
                category=sm['category'],
                milestone_type=sm['milestone_type'],
                threshold_value=sm['threshold_value'],
                current_progress=current_progress,
                completed=completed,
                player_milestone_id=str(player_milestone['id']) if player_milestone else None,
                notes=player_milestone['notes'] if player_milestone else None,
                shared_with_staff=player_milestone['shared_with_staff'] if player_milestone else False,
                completed_at=player_milestone['completed_at'].isoformat() if player_milestone and player_milestone['completed_at'] else None,
                awarded_by=player_milestone['awarded_by'] if player_milestone else None,
                awarded_by_user_name=awarded_by_name
            ))
        
        return result
    finally:
        await conn.close()

@router.post("/character/{character_id}/system-milestones/{system_milestone_id}/notes")
async def update_system_milestone_notes(
    character_id: str,
    system_milestone_id: str,
    notes: Optional[str] = None,
    shared_with_staff: bool = False,
    user: AuthorizedUser = None
):
    """Update notes and sharing settings for a system milestone"""
    # Verify ownership
    if not await verify_character_ownership(character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to modify this character's milestones")
    
    conn = await get_database_connection()
    try:
        # Check if milestone record exists
        existing = await conn.fetchrow(
            "SELECT id FROM player_milestones WHERE character_id = $1 AND system_milestone_id = $2",
            UUID(character_id),
            UUID(system_milestone_id)
        )
        
        if existing:
            # Update existing
            await conn.execute(
                """
                UPDATE player_milestones
                SET notes = $1, shared_with_staff = $2, updated_at = CURRENT_TIMESTAMP
                WHERE id = $3
                """,
                notes,
                shared_with_staff,
                existing['id']
            )
        else:
            # Create new
            await conn.execute(
                """
                INSERT INTO player_milestones (
                    character_id, system_milestone_id, is_custom, notes, shared_with_staff
                )
                VALUES ($1, $2, false, $3, $4)
                """,
                UUID(character_id),
                UUID(system_milestone_id),
                notes,
                shared_with_staff
            )
        
        return {"success": True, "message": "Milestone notes updated"}
    finally:
        await conn.close()

@router.post("/character/{character_id}/system-milestones/{system_milestone_id}/mark-complete")
async def mark_system_milestone_complete(
    character_id: str,
    system_milestone_id: str,
    user: AuthorizedUser = None
):
    """Mark an 'other' type system milestone as completed"""
    # Verify ownership
    if not await verify_character_ownership(character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to modify this character's milestones")
    
    conn = await get_database_connection()
    try:
        # Verify this is an 'other' type milestone
        milestone = await conn.fetchrow(
            "SELECT milestone_type FROM system_milestones WHERE id = $1",
            UUID(system_milestone_id)
        )
        
        if not milestone:
            raise HTTPException(status_code=404, detail="System milestone not found")
        
        if milestone['milestone_type'] != 'other':
            raise HTTPException(status_code=400, detail="Only 'other' type milestones can be manually marked complete")
        
        # Check if milestone record exists
        existing = await conn.fetchrow(
            "SELECT id, completed_at FROM player_milestones WHERE character_id = $1 AND system_milestone_id = $2",
            UUID(character_id),
            UUID(system_milestone_id)
        )
        
        if existing:
            # Update to mark complete (or toggle)
            new_completed_at = None if existing['completed_at'] else datetime.now()
            await conn.execute(
                """
                UPDATE player_milestones
                SET completed_at = $1, updated_at = CURRENT_TIMESTAMP
                WHERE id = $2
                """,
                new_completed_at,
                existing['id']
            )
        else:
            # Create new and mark complete
            await conn.execute(
                """
                INSERT INTO player_milestones (
                    character_id, system_milestone_id, is_custom, completed_at
                )
                VALUES ($1, $2, false, $3)
                """,
                UUID(character_id),
                UUID(system_milestone_id),
                datetime.now()
            )
        
        return {"success": True, "message": "Milestone completion toggled"}
    finally:
        await conn.close()

@router.get("/character/{character_id}/custom-milestones", response_model=List[CustomMilestoneResponse])
async def get_character_custom_milestones(character_id: str, user: AuthorizedUser):
    """Get all custom milestones for a character"""
    # Verify ownership
    if not await verify_character_ownership(character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to view this character's milestones")
    
    conn = await get_database_connection()
    try:
        milestones = await conn.fetch(
            """
            SELECT 
                pm.*,
                c.name as character_name
            FROM player_milestones pm
            JOIN characters c ON pm.character_id = c.id
            WHERE pm.character_id = $1 AND pm.is_custom = true
            ORDER BY pm.created_at DESC
            """,
            UUID(character_id)
        )
        
        return [
            CustomMilestoneResponse(
                id=str(m['id']),
                character_id=str(m['character_id']),
                character_name=m['character_name'],
                name=m['custom_name'],
                description=m['custom_description'],
                category=m['custom_category'] or "general",
                current_progress=m['current_progress'] or 0,
                target_progress=m['target_progress'],
                completed=m['completed_at'] is not None,
                notes=m['notes'],
                shared_with_staff=m['shared_with_staff'],
                completed_at=m['completed_at'].isoformat() if m['completed_at'] else None,
                created_at=m['created_at'].isoformat(),
                updated_at=m['updated_at'].isoformat()
            )
            for m in milestones
        ]
    finally:
        await conn.close()

@router.post("/custom-milestones", response_model=CustomMilestoneResponse)
async def create_custom_milestone(milestone: CustomMilestoneCreate, user: AuthorizedUser):
    """Create a new custom milestone"""
    # Verify ownership
    if not await verify_character_ownership(milestone.character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to create milestones for this character")
    
    conn = await get_database_connection()
    try:
        # Get character name for response
        char_name = await conn.fetchval(
            "SELECT name FROM characters WHERE id = $1",
            UUID(milestone.character_id)
        )
        
        # Create milestone
        new_milestone = await conn.fetchrow(
            """
            INSERT INTO player_milestones (
                character_id, is_custom, custom_name, custom_description,
                custom_category, target_progress, notes, shared_with_staff
            )
            VALUES ($1, true, $2, $3, $4, $5, $6, $7)
            RETURNING *
            """,
            UUID(milestone.character_id),
            milestone.name,
            milestone.description,
            milestone.category,
            milestone.target_progress,
            milestone.notes,
            milestone.shared_with_staff
        )
        
        return CustomMilestoneResponse(
            id=str(new_milestone['id']),
            character_id=str(new_milestone['character_id']),
            character_name=char_name,
            name=new_milestone['custom_name'],
            description=new_milestone['custom_description'],
            category=new_milestone['custom_category'] or "general",
            current_progress=new_milestone['current_progress'] or 0,
            target_progress=new_milestone['target_progress'],
            completed=new_milestone['completed_at'] is not None,
            notes=new_milestone['notes'],
            shared_with_staff=new_milestone['shared_with_staff'],
            completed_at=new_milestone['completed_at'].isoformat() if new_milestone['completed_at'] else None,
            created_at=new_milestone['created_at'].isoformat(),
            updated_at=new_milestone['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.put("/custom-milestones/{milestone_id}", response_model=CustomMilestoneResponse)
async def update_custom_milestone(
    milestone_id: str,
    update_data: CustomMilestoneUpdate,
    user: AuthorizedUser
):
    """Update a custom milestone"""
    conn = await get_database_connection()
    try:
        # Get milestone and verify ownership
        milestone = await conn.fetchrow(
            """
            SELECT pm.*, c.name as character_name
            FROM player_milestones pm
            JOIN characters c ON pm.character_id = c.id
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            WHERE pm.id = $1 AND pm.is_custom = true
            """,
            UUID(milestone_id)
        )
        
        if not milestone:
            raise HTTPException(status_code=404, detail="Custom milestone not found")
        
        # Verify ownership
        if not await verify_character_ownership(str(milestone['character_id']), user.sub):
            raise HTTPException(status_code=403, detail="Not authorized to modify this milestone")
        
        # Build update query dynamically
        update_fields = []
        params = []
        param_count = 1
        
        if update_data.name is not None:
            update_fields.append(f"custom_name = ${param_count}")
            params.append(update_data.name)
            param_count += 1
        
        if update_data.description is not None:
            update_fields.append(f"custom_description = ${param_count}")
            params.append(update_data.description)
            param_count += 1
        
        if update_data.category is not None:
            update_fields.append(f"custom_category = ${param_count}")
            params.append(update_data.category)
            param_count += 1
        
        if update_data.current_progress is not None:
            update_fields.append(f"current_progress = ${param_count}")
            params.append(update_data.current_progress)
            param_count += 1
        
        if update_data.target_progress is not None:
            update_fields.append(f"target_progress = ${param_count}")
            params.append(update_data.target_progress)
            param_count += 1
        
        # Auto-complete milestone if current_progress >= target_progress
        # Get the current or updated values
        current_progress = update_data.current_progress if update_data.current_progress is not None else milestone['current_progress']
        target_progress = update_data.target_progress if update_data.target_progress is not None else milestone['target_progress']
        
        if current_progress is not None and target_progress is not None:
            if current_progress >= target_progress and milestone['completed_at'] is None:
                # Mark as completed with current timestamp
                update_fields.append(f"completed_at = ${param_count}")
                params.append(datetime.now(timezone.utc))
                param_count += 1
            elif current_progress < target_progress and milestone['completed_at'] is not None:
                # Unmark as completed if progress reduced
                update_fields.append(f"completed_at = ${param_count}")
                params.append(None)
                param_count += 1
        
        if update_data.notes is not None:
            update_fields.append(f"notes = ${param_count}")
            params.append(update_data.notes)
            param_count += 1
        
        if update_data.shared_with_staff is not None:
            update_fields.append(f"shared_with_staff = ${param_count}")
            params.append(update_data.shared_with_staff)
            param_count += 1
        
        if update_data.completed_at is not None:
            update_fields.append(f"completed_at = ${param_count}")
            params.append(update_data.completed_at)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        params.append(UUID(milestone_id))
        
        query = f"UPDATE player_milestones SET {', '.join(update_fields)} WHERE id = ${param_count} RETURNING *"
        
        updated = await conn.fetchrow(query, *params)
        
        return CustomMilestoneResponse(
            id=str(updated['id']),
            character_id=str(updated['character_id']),
            character_name=milestone['character_name'],
            name=updated['custom_name'],
            description=updated['custom_description'],
            category=updated['custom_category'] or "general",
            current_progress=updated['current_progress'] or 0,
            target_progress=updated['target_progress'],
            completed=updated['completed_at'] is not None,
            notes=updated['notes'],
            shared_with_staff=updated['shared_with_staff'],
            completed_at=updated['completed_at'].isoformat() if updated['completed_at'] else None,
            created_at=updated['created_at'].isoformat(),
            updated_at=updated['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.delete("/custom-milestones/{milestone_id}")
async def delete_custom_milestone(milestone_id: str, user: AuthorizedUser):
    """Delete a custom milestone"""
    conn = await get_database_connection()
    try:
        # Get milestone and verify ownership
        milestone = await conn.fetchrow(
            """
            SELECT pm.character_id
            FROM player_milestones pm
            WHERE pm.id = $1 AND pm.is_custom = true
            """,
            UUID(milestone_id)
        )
        
        if not milestone:
            raise HTTPException(status_code=404, detail="Custom milestone not found")
        
        # Verify ownership
        if not await verify_character_ownership(str(milestone['character_id']), user.sub):
            raise HTTPException(status_code=403, detail="Not authorized to delete this milestone")
        
        await conn.execute(
            "DELETE FROM player_milestones WHERE id = $1",
            UUID(milestone_id)
        )
        
        return {"success": True, "message": "Milestone deleted"}
    finally:
        await conn.close()

# Journal Endpoints

@router.get("/character/{character_id}/journal", response_model=List[JournalEntryResponse])
async def get_character_journal_entries(character_id: str, user: AuthorizedUser):
    """Get all journal entries for a character"""
    # Verify ownership
    if not await verify_character_ownership(character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to view this character's journal")
    
    conn = await get_database_connection()
    try:
        entries = await conn.fetch(
            """
            SELECT 
                je.*,
                c.name as character_name,
                e.title as event_title
            FROM journal_entries je
            JOIN characters c ON je.character_id = c.id
            LEFT JOIN events e ON je.event_id = e.id
            WHERE je.character_id = $1
            ORDER BY je.created_at DESC
            """,
            UUID(character_id)
        )
        
        return [
            JournalEntryResponse(
                id=str(e['id']),
                character_id=str(e['character_id']),
                character_name=e['character_name'],
                title=e['title'],
                content=e['content'],
                tags=e['tags'] or [],
                event_id=str(e['event_id']) if e['event_id'] else None,
                event_title=e['event_title'],
                shared_with_staff=e['shared_with_staff'],
                created_at=e['created_at'].isoformat(),
                updated_at=e['updated_at'].isoformat()
            )
            for e in entries
        ]
    finally:
        await conn.close()

@router.post("/journal", response_model=JournalEntryResponse)
async def create_journal_entry(entry: JournalEntryCreate, user: AuthorizedUser):
    """Create a new journal entry"""
    # Verify ownership
    if not await verify_character_ownership(entry.character_id, user.sub):
        raise HTTPException(status_code=403, detail="Not authorized to create journal entries for this character")
    
    conn = await get_database_connection()
    try:
        # Validate event_id if provided
        if entry.event_id:
            event_exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM events WHERE id = $1)",
                UUID(entry.event_id)
            )
            if not event_exists:
                raise HTTPException(status_code=404, detail="Event not found")
        
        # Get character name
        char_name = await conn.fetchval(
            "SELECT name FROM characters WHERE id = $1",
            UUID(entry.character_id)
        )
        
        # Create entry
        new_entry = await conn.fetchrow(
            """
            INSERT INTO journal_entries (
                character_id, title, content, tags, event_id, shared_with_staff
            )
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
            """,
            UUID(entry.character_id),
            entry.title,
            entry.content,
            entry.tags,
            UUID(entry.event_id) if entry.event_id else None,
            entry.shared_with_staff
        )
        
        # Get event title if linked
        event_title = None
        if new_entry['event_id']:
            event_title = await conn.fetchval(
                "SELECT title FROM events WHERE id = $1",
                new_entry['event_id']
            )
        
        return JournalEntryResponse(
            id=str(new_entry['id']),
            character_id=str(new_entry['character_id']),
            character_name=char_name,
            title=new_entry['title'],
            content=new_entry['content'],
            tags=new_entry['tags'] or [],
            event_id=str(new_entry['event_id']) if new_entry['event_id'] else None,
            event_title=event_title,
            shared_with_staff=new_entry['shared_with_staff'],
            created_at=new_entry['created_at'].isoformat(),
            updated_at=new_entry['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.put("/journal/{entry_id}", response_model=JournalEntryResponse)
async def update_journal_entry(
    entry_id: str,
    update_data: JournalEntryUpdate,
    user: AuthorizedUser
):
    """Update a journal entry"""
    conn = await get_database_connection()
    try:
        # Get entry and verify ownership
        entry = await conn.fetchrow(
            """
            SELECT je.*, c.name as character_name
            FROM journal_entries je
            JOIN characters c ON je.character_id = c.id
            WHERE je.id = $1
            """,
            UUID(entry_id)
        )
        
        if not entry:
            raise HTTPException(status_code=404, detail="Journal entry not found")
        
        # Verify ownership
        if not await verify_character_ownership(str(entry['character_id']), user.sub):
            raise HTTPException(status_code=403, detail="Not authorized to modify this journal entry")
        
        # Validate event_id if provided
        if update_data.event_id:
            event_exists = await conn.fetchval(
                "SELECT EXISTS(SELECT 1 FROM events WHERE id = $1)",
                UUID(update_data.event_id)
            )
            if not event_exists:
                raise HTTPException(status_code=404, detail="Event not found")
        
        # Build update query
        update_fields = []
        params = []
        param_count = 1
        
        if update_data.title is not None:
            update_fields.append(f"title = ${param_count}")
            params.append(update_data.title)
            param_count += 1
        
        if update_data.content is not None:
            update_fields.append(f"content = ${param_count}")
            params.append(update_data.content)
            param_count += 1
        
        if update_data.tags is not None:
            update_fields.append(f"tags = ${param_count}")
            params.append(update_data.tags)
            param_count += 1
        
        if update_data.event_id is not None:
            update_fields.append(f"event_id = ${param_count}")
            params.append(UUID(update_data.event_id) if update_data.event_id else None)
            param_count += 1
        
        if update_data.shared_with_staff is not None:
            update_fields.append(f"shared_with_staff = ${param_count}")
            params.append(update_data.shared_with_staff)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        params.append(UUID(entry_id))
        
        query = f"UPDATE journal_entries SET {', '.join(update_fields)} WHERE id = ${param_count} RETURNING *"
        
        updated = await conn.fetchrow(query, *params)
        
        # Get event title if linked
        event_title = None
        if updated['event_id']:
            event_title = await conn.fetchval(
                "SELECT title FROM events WHERE id = $1",
                updated['event_id']
            )
        
        return JournalEntryResponse(
            id=str(updated['id']),
            character_id=str(updated['character_id']),
            character_name=entry['character_name'],
            title=updated['title'],
            content=updated['content'],
            tags=updated['tags'] or [],
            event_id=str(updated['event_id']) if updated['event_id'] else None,
            event_title=event_title,
            shared_with_staff=updated['shared_with_staff'],
            created_at=updated['created_at'].isoformat(),
            updated_at=updated['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.delete("/journal/{entry_id}")
async def delete_journal_entry(entry_id: str, user: AuthorizedUser):
    """Delete a journal entry"""
    conn = await get_database_connection()
    try:
        # Get entry and verify ownership
        entry = await conn.fetchrow(
            "SELECT character_id FROM journal_entries WHERE id = $1",
            UUID(entry_id)
        )
        
        if not entry:
            raise HTTPException(status_code=404, detail="Journal entry not found")
        
        # Verify ownership
        if not await verify_character_ownership(str(entry['character_id']), user.sub):
            raise HTTPException(status_code=403, detail="Not authorized to delete this journal entry")
        
        await conn.execute(
            "DELETE FROM journal_entries WHERE id = $1",
            UUID(entry_id)
        )
        
        return {"success": True, "message": "Journal entry deleted"}
    finally:
        await conn.close()
