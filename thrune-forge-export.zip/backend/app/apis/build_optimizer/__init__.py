from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
from app.libs.database import get_database_connection
from app.auth import AuthorizedUser
from datetime import datetime, timedelta
from collections import defaultdict
from fastapi import HTTPException
import json
from typing import Dict, Any
from fastapi.responses import StreamingResponse
from uuid import UUID

router = APIRouter()


# Rate limiting storage
# Structure: {user_id: [timestamp1, timestamp2, ...]}
rate_limit_requests = defaultdict(list)

def check_rate_limit(user_id: str) -> None:
    """
    Enforce rate limits:
    - 10 requests per minute
    - 100 requests per day
    Raises HTTPException if limit exceeded.
    """
    now = datetime.utcnow()
    user_requests = rate_limit_requests[user_id]
    
    # Clean up old requests (older than 24 hours)
    cutoff_day = now - timedelta(days=1)
    user_requests[:] = [req_time for req_time in user_requests if req_time > cutoff_day]
    
    # Check daily limit (100 requests per day)
    if len(user_requests) >= 100:
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded: Maximum 100 requests per day. Please try again tomorrow."
        )
    
    # Check minute limit (10 requests per minute)
    cutoff_minute = now - timedelta(minutes=1)
    recent_requests = [req_time for req_time in user_requests if req_time > cutoff_minute]
    if len(recent_requests) >= 10:
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded: Maximum 10 requests per minute. Please wait a moment."
        )
    
    # Record this request
    user_requests.append(now)

# Global cache for skill costs (refreshed every 10 minutes)
_skill_costs_cache: Optional[Dict[str, Any]] = None
_cache_timestamp: Optional[datetime] = None
CACHE_DURATION = timedelta(minutes=10)

class SelectedSkillRequest(BaseModel):
    skill_id: str
    quantity: int

class OptimizeBuildRequest(BaseModel):
    selected_skills: List[SelectedSkillRequest]
    heritage_id: str
    body: int
    stamina: int
    include_three_archetypes: bool = False  # Toggle for deep analysis

class SkillAssignment(BaseModel):
    skill_id: str
    skill_name: str
    best_archetype_id: str
    best_archetype_name: str
    cost: int
    penalty_cost: int

class ArchetypeCombination(BaseModel):
    archetype_id: str
    archetype_name: str
    secondary_archetype_id: Optional[str]
    secondary_archetype_name: Optional[str]
    tertiary_archetype_id: Optional[str]
    tertiary_archetype_name: Optional[str]
    xp_cost: int
    xp_savings: int
    skill_assignments: Optional[List[SkillAssignment]] = None

class OptimizeBuildResponse(BaseModel):
    current_xp: int
    optimal_combinations: List[ArchetypeCombination]
    potential_savings: int

async def get_cached_skill_costs(conn: asyncpg.Connection, heritage_id: str) -> tuple[list, dict, list]:
    """Get skill costs from cache or database."""
    global _skill_costs_cache, _cache_timestamp
    
    now = datetime.now()
    
    # Check if cache is valid
    if _skill_costs_cache is not None and _cache_timestamp is not None:
        if now - _cache_timestamp < CACHE_DURATION:
            return _skill_costs_cache['archetypes'], _skill_costs_cache['cost_lookup'], _skill_costs_cache['skills']
    
    # Cache miss - fetch from database
    print("📚 Cache miss - fetching archetype skill mappings from database...")
    
    # Get all archetypes
    archetypes_query = "SELECT id, name FROM archetypes ORDER BY name"
    archetypes = await conn.fetch(archetypes_query)
    
    # Get all skills
    skills_query = "SELECT id, name FROM skills"
    skills = await conn.fetch(skills_query)
    
    # Get primary skills for each archetype (cost = 5)
    primary_skills_query = """
    SELECT archetype_id, skill_id 
    FROM archetype_primary_skills
    """
    primary_skills = await conn.fetch(primary_skills_query)
    
    # Get secondary skills for each archetype (cost = 10)
    secondary_skills_query = """
    SELECT archetype_id, skill_id 
    FROM archetype_secondary_skills
    """
    secondary_skills = await conn.fetch(secondary_skills_query)
    
    # Get heritage secondary skills (cost = 10, applies to ALL archetypes)
    heritage_skills_query = """
    SELECT skill_id 
    FROM heritage_secondary_skills
    WHERE heritage_id = $1
    """
    heritage_skills = await conn.fetch(heritage_skills_query, UUID(heritage_id))
    
    # Build lookup dictionaries
    primary_lookup = {}
    for ps in primary_skills:
        skill_id = str(ps['skill_id'])
        archetype_id = str(ps['archetype_id'])
        if skill_id not in primary_lookup:
            primary_lookup[skill_id] = set()
        primary_lookup[skill_id].add(archetype_id)
    
    secondary_lookup = {}
    for ss in secondary_skills:
        skill_id = str(ss['skill_id'])
        archetype_id = str(ss['archetype_id'])
        if skill_id not in secondary_lookup:
            secondary_lookup[skill_id] = set()
        secondary_lookup[skill_id].add(archetype_id)
    
    # Build heritage secondary skills set
    heritage_skill_ids = {str(hs['skill_id']) for hs in heritage_skills}
    
    
    # Build cost lookup: skill_id -> archetype_id -> cost (5, 10, or 20)
    cost_lookup = {}
    for skill in skills:
        skill_id = str(skill['id'])
        cost_lookup[skill_id] = {}
        
        for archetype in archetypes:
            archetype_id = str(archetype['id'])
            
            # Determine cost based on skill classification
            if skill_id in primary_lookup and archetype_id in primary_lookup[skill_id]:
                # Primary skill: 5 XP
                cost_lookup[skill_id][archetype_id] = 5
            elif skill_id in heritage_skill_ids:
                # Heritage secondary skill: 10 XP (applies to ALL archetypes)
                cost_lookup[skill_id][archetype_id] = 10
            elif skill_id in secondary_lookup and archetype_id in secondary_lookup[skill_id]:
                # Archetype secondary skill: 10 XP
                cost_lookup[skill_id][archetype_id] = 10
            else:
                # Tertiary skill: 20 XP
                cost_lookup[skill_id][archetype_id] = 20
    
    print(f"📚 Built cost lookup for {len(skills)} skills across {len(archetypes)} archetypes")
    
    # Update cache
    _skill_costs_cache = {
        'archetypes': archetypes,
        'cost_lookup': cost_lookup,
        'skills': skills
    }
    _cache_timestamp = now
    
    return archetypes, cost_lookup, skills


@router.post("/optimize", tags=["stream"])
async def optimize_build(request: OptimizeBuildRequest, user: AuthorizedUser):
    """
    Analyzes selected skills and suggests optimal archetype combinations.
    Streams progress updates and returns top 5 combinations ranked by XP cost.
    """
    print(f"🚀 OPTIMIZE_BUILD STARTED for user {user.sub}")
    print(f"📊 Request data: {len(request.selected_skills)} skills, heritage={request.heritage_id}, body={request.body}, stamina={request.stamina}")
    
    # Check rate limits BEFORE processing
    check_rate_limit(user.sub)
    print(f"✅ Rate limit check passed")
    
    async def generate():
        print(f"🔄 GENERATOR FUNCTION STARTED")
        conn = await get_database_connection()
        print(f"🔌 Database connection established")
        try:
            # Validation
            if not request.selected_skills:
                print(f"❌ VALIDATION FAILED: No skills selected")
                yield f"data: {json.dumps({'type': 'error', 'message': 'No skills selected'})}\n\n"
                return
            
            print(f"✅ Validation passed")
            
            # Get heritage info for body/stamina base values
            print(f"🏛️ Fetching heritage info for {request.heritage_id}...")
            heritage_row = await conn.fetchrow(
                "SELECT base_body, base_stamina FROM heritages WHERE id = $1",
                UUID(request.heritage_id)
            )
            if not heritage_row:
                print(f"❌ VALIDATION FAILED: Invalid heritage")
                yield f"data: {json.dumps({'type': 'error', 'message': 'Invalid heritage'})}\n\n"
                return
            
            # Calculate body/stamina costs using tiered system
            body_cost = calculate_body_stamina_xp_cost(heritage_row['base_body'], request.body)
            stamina_cost = calculate_body_stamina_xp_cost(heritage_row['base_stamina'], request.stamina)
            stat_cost = body_cost + stamina_cost
            
            print(f"📊 Body/Stamina costs: {body_cost} + {stamina_cost} = {stat_cost} XP")
            
            # Get cached data
            print(f"📚 Fetching cached skill costs...")
            archetypes, cost_lookup, skills = await get_cached_skill_costs(conn, request.heritage_id)
            print(f"📚 Loaded {len(archetypes)} archetypes and {len(cost_lookup)} skill costs")
            num_archetypes = len(archetypes)
            
            # Calculate total combinations
            total_combinations = num_archetypes  # Single archetype
            total_combinations += num_archetypes * (num_archetypes - 1)  # Two archetypes
            if request.include_three_archetypes:
                total_combinations += num_archetypes * (num_archetypes - 1) * (num_archetypes - 2)  # Three archetypes
            
            print(f"🧮 Total combinations to analyze: {total_combinations:,}")
            
            # Send initial status
            initial_msg = f"data: {json.dumps({'type': 'status', 'message': f'Analyzing {total_combinations:,} combinations...', 'progress': 0, 'total': total_combinations})}\n\n"
            print(f"📤 YIELDING INITIAL STATUS: {initial_msg.strip()}")
            yield initial_msg
            
            combinations = []
            processed = 0
            best_so_far = float('inf')
            
            # Track top 5 to enable early termination
            top_5_threshold = float('inf')
            
            # Single archetype combinations
            for primary in archetypes:
                primary_id = str(primary['id'])
                
                xp = calculate_combination_xp(
                    cost_lookup, request.selected_skills, primary_id, None, None, stat_cost
                )
                combinations.append({
                    'primary_id': primary_id,
                    'primary_name': primary['name'],
                    'secondary_id': None,
                    'secondary_name': None,
                    'tertiary_id': None,
                    'tertiary_name': None,
                    'xp': xp
                })
                
                processed += 1
                best_so_far = min(best_so_far, xp)
                
                # Send progress every 10 combinations
                if processed % 10 == 0:
                    progress = (processed / total_combinations) * 100
                    yield f"data: {json.dumps({'type': 'progress', 'progress': processed, 'total': total_combinations, 'percent': round(progress, 1), 'best': best_so_far})}\n\n"
            
            # Two archetype combinations
            for primary in archetypes:
                primary_id = str(primary['id'])
                
                for secondary in archetypes:
                    secondary_id = str(secondary['id'])
                    if secondary_id == primary_id:
                        continue
                    
                    xp = calculate_combination_xp(
                        cost_lookup, request.selected_skills, primary_id, secondary_id, None, stat_cost
                    )
                    
                    # Early termination: skip if clearly worse than top 5
                    if len(combinations) >= 5:
                        combinations_sorted = sorted(combinations, key=lambda x: x['xp'])
                        top_5_threshold = combinations_sorted[4]['xp']
                        # Only add if better than worst in top 5
                        if xp < top_5_threshold * 1.5:  # 50% threshold
                            combinations.append({
                                'primary_id': primary_id,
                                'primary_name': primary['name'],
                                'secondary_id': secondary_id,
                                'secondary_name': secondary['name'],
                                'tertiary_id': None,
                                'tertiary_name': None,
                                'xp': xp
                            })
                    else:
                        combinations.append({
                            'primary_id': primary_id,
                            'primary_name': primary['name'],
                            'secondary_id': secondary_id,
                            'secondary_name': secondary['name'],
                            'tertiary_id': None,
                            'tertiary_name': None,
                            'xp': xp
                        })
                    
                    processed += 1
                    best_so_far = min(best_so_far, xp)
                    
                    if processed % 50 == 0:
                        progress = (processed / total_combinations) * 100
                        yield f"data: {json.dumps({'type': 'progress', 'progress': processed, 'total': total_combinations, 'percent': round(progress, 1), 'best': best_so_far})}\n\n"
            
            # Three archetype combinations (only if enabled)
            if request.include_three_archetypes:
                for primary in archetypes:
                    primary_id = str(primary['id'])
                    
                    for secondary in archetypes:
                        secondary_id = str(secondary['id'])
                        if secondary_id == primary_id:
                            continue
                        
                        for tertiary in archetypes:
                            tertiary_id = str(tertiary['id'])
                            if tertiary_id == primary_id or tertiary_id == secondary_id:
                                continue
                            
                            xp = calculate_combination_xp(
                                cost_lookup, request.selected_skills, primary_id, secondary_id, tertiary_id, stat_cost
                            )
                            
                            # Early termination for 3-archetype
                            if len(combinations) >= 5:
                                combinations_sorted = sorted(combinations, key=lambda x: x['xp'])
                                top_5_threshold = combinations_sorted[4]['xp']
                                if xp < top_5_threshold * 1.5:
                                    combinations.append({
                                        'primary_id': primary_id,
                                        'primary_name': primary['name'],
                                        'secondary_id': secondary_id,
                                        'secondary_name': secondary['name'],
                                        'tertiary_id': tertiary_id,
                                        'tertiary_name': tertiary['name'],
                                        'xp': xp
                                    })
                            else:
                                combinations.append({
                                    'primary_id': primary_id,
                                    'primary_name': primary['name'],
                                    'secondary_id': secondary_id,
                                    'secondary_name': secondary['name'],
                                    'tertiary_id': tertiary_id,
                                    'tertiary_name': tertiary['name'],
                                    'xp': xp
                                })
                            
                            processed += 1
                            best_so_far = min(best_so_far, xp)
                            
                            if processed % 100 == 0:
                                progress = (processed / total_combinations) * 100
                                yield f"data: {json.dumps({'type': 'progress', 'progress': processed, 'total': total_combinations, 'percent': round(progress, 1), 'best': best_so_far})}\n\n"
            
            # Sort and get top 5
            combinations.sort(key=lambda x: x['xp'])
            top_5 = combinations[:5]
            
            # Enrich top 5 with skill assignments
            for combo in top_5:
                combo['skill_assignments'] = get_skill_assignments(
                    cost_lookup, 
                    request.selected_skills,
                    combo['primary_id'], 
                    combo['primary_name'],
                    combo['secondary_id'], 
                    combo['secondary_name'],
                    combo['tertiary_id'],
                    combo['tertiary_name'],
                    skills
                )

            print(f"🏆 Top 5 combinations found. Best XP: {top_5[0]['xp'] if top_5 else 'N/A'}")
            
            # Format final response
            result = {
                'type': 'complete',
                'data': {
                    'current_xp': 0,
                    'optimal_combinations': [
                        {
                            'archetype_id': combo['primary_id'],
                            'archetype_name': combo['primary_name'],
                            'secondary_archetype_id': combo['secondary_id'],
                            'secondary_archetype_name': combo['secondary_name'],
                            'tertiary_archetype_id': combo['tertiary_id'],
                            'tertiary_archetype_name': combo['tertiary_name'],
                            'xp_cost': combo['xp'],
                            'xp_savings': 0,
                            'skill_assignments': combo['skill_assignments']
                        }
                        for combo in top_5
                    ],
                    'potential_savings': 0
                }
            }
            
            final_msg = f"data: {json.dumps(result)}\n\n"
            print(f"📤 YIELDING FINAL RESULT: {final_msg[:200]}...")
            yield final_msg
            print(f"✅ GENERATOR COMPLETED SUCCESSFULLY")
            
        except Exception as e:
            print(f"💥 EXCEPTION IN GENERATOR: {type(e).__name__}: {str(e)}")
            import traceback
            print(f"📋 TRACEBACK:\n{traceback.format_exc()}")
            error_msg = f"Internal error: {str(e)}"
            yield f"data: {json.dumps({'type': 'error', 'message': error_msg})}\n\n"
        finally:
            await conn.close()
            print(f"🔌 Database connection closed")
    
    print(f"🎬 Returning StreamingResponse")
    return StreamingResponse(generate(), media_type="text/event-stream")

def calculate_combination_xp(
    cost_lookup: dict,
    selected_skills: List[SelectedSkillRequest],
    primary_id: str,
    secondary_id: Optional[str],
    tertiary_id: Optional[str],
    stat_cost: int = 0  # ← ADD THIS PARAMETER
) -> int:
    """Calculate total XP cost for a specific archetype combination."""
    total_xp = stat_cost  # ← START WITH stat_cost INSTEAD OF 0
    
    # Add base archetype purchase costs
    if secondary_id:
        total_xp += 50  # Secondary archetype costs 50 XP
    if tertiary_id:
        total_xp += 50  # Tertiary archetype costs 50 XP
    
    for skill in selected_skills:
        skill_id = skill.skill_id
        quantity = skill.quantity
        
        if skill_id not in cost_lookup:
            # Skill not found, use max cost
            total_xp += 999 * quantity
            continue
        
        skill_costs = cost_lookup[skill_id]
        
        # Find the minimum cost across all selected archetypes
        min_cost = 999  # Default to max if not available
        
        # Check primary archetype
        if primary_id in skill_costs:
            min_cost = min(min_cost, skill_costs[primary_id])
        
        # Check secondary archetype if present
        if secondary_id and secondary_id in skill_costs:
            min_cost = min(min_cost, skill_costs[secondary_id])
        
        # Check tertiary archetype if present
        if tertiary_id and tertiary_id in skill_costs:
            min_cost = min(min_cost, skill_costs[tertiary_id])
        
        total_xp += min_cost * quantity
    
    return total_xp

# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def get_skill_assignments(
    cost_lookup: dict,
    selected_skills: List[SelectedSkillRequest],
    primary_id: str,
    primary_name: str,
    secondary_id: Optional[str],
    secondary_name: Optional[str],
    tertiary_id: Optional[str],
    tertiary_name: Optional[str],
    all_skills: List[dict]
) -> List[dict]:
    
    assignments = []
    skill_name_map = {str(s['id']): s['name'] for s in all_skills}
    
    archetype_map = {primary_id: primary_name}
    if secondary_id: archetype_map[secondary_id] = secondary_name
    if tertiary_id: archetype_map[tertiary_id] = tertiary_name
    
    for skill in selected_skills:
        skill_id = skill.skill_id
        
        if skill_id not in cost_lookup:
            continue
            
        skill_costs = cost_lookup[skill_id]
        
        best_cost = 999
        best_arch_id = primary_id # Default
        
        # Check available archetypes
        current_archetypes = [primary_id]
        if secondary_id: current_archetypes.append(secondary_id)
        if tertiary_id: current_archetypes.append(tertiary_id)
        
        for arch_id in current_archetypes:
            if arch_id in skill_costs:
                cost = skill_costs[arch_id]
                if cost < best_cost:
                    best_cost = cost
                    best_arch_id = arch_id
        
        # Calculate penalty cost (cost if we DON'T have the best archetype unlocked yet)
        # We assume we start with Primary. 
        # If best is Primary, penalty is same (no penalty).
        # If best is Secondary, penalty is cost with Primary.
        # If best is Tertiary, penalty is min(cost with Primary, cost with Secondary).
        
        penalty_cost = 20 # Worst case fallback
        
        if best_arch_id == primary_id:
             penalty_cost = best_cost
        elif best_arch_id == secondary_id:
             # Best is secondary, what if we only have primary?
             if primary_id in skill_costs:
                 penalty_cost = skill_costs[primary_id]
        elif best_arch_id == tertiary_id:
             # Best is tertiary, what if we only have primary or secondary?
             # We want the lowest cost available BEFORE tertiary is unlocked.
             # Assume we unlock secondary before tertiary usually.
             
             cost_primary = skill_costs.get(primary_id, 20)
             cost_secondary = skill_costs.get(secondary_id, 20) if secondary_id else 20
             penalty_cost = min(cost_primary, cost_secondary)

        assignments.append({
            'skill_id': skill_id,
            'skill_name': skill_name_map.get(skill_id, "Unknown Skill"),
            'best_archetype_id': best_arch_id,
            'best_archetype_name': archetype_map.get(best_arch_id, "Unknown"),
            'cost': best_cost,
            'penalty_cost': penalty_cost
        })
        
    return assignments

def calculate_body_stamina_xp_cost(current_value: int, target_value: int) -> int:
    """Calculate XP cost for body/stamina increases using the scaling system.
    
    XP Cost Logic:
    - 1-20: 1 XP per point
    - 21-40: 2 XP per point
    - 41-60: 3 XP per point
    - 61-80: 4 XP per point
    - 81-100: 5 XP per point
    - 101-120: 6 XP per point
    - 121-140: 7 XP per point
    - 141-160: 8 XP per point
    - 161-180: 9 XP per point
    - 181-200: 10 XP per point
    - 201+: 10 XP per point (capped)
    """
    if target_value <= current_value:
        return 0
    
    total_cost = 0
    
    for value in range(current_value + 1, target_value + 1):
        if value <= 20:
            total_cost += 1
        elif value <= 40:
            total_cost += 2
        elif value <= 60:
            total_cost += 3
        elif value <= 80:
            total_cost += 4
        elif value <= 100:
            total_cost += 5
        elif value <= 120:
            total_cost += 6
        elif value <= 140:
            total_cost += 7
        elif value <= 160:
            total_cost += 8
        elif value <= 180:
            total_cost += 9
        else:  # 181+
            total_cost += 10
    
    return total_cost

async def get_heritage_info(conn: asyncpg.Connection, heritage_id: str):
    pass
