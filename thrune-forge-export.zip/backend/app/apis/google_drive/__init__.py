from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import os
import requests
from typing import List

router = APIRouter()

class GoogleDrivePhoto(BaseModel):
    file_id: str
    name: str
    thumbnail_url: str
    web_view_link: str
    direct_link: str

class FolderPhotosRequest(BaseModel):
    folder_id: str

class FolderPhotosResponse(BaseModel):
    photos: List[GoogleDrivePhoto]
    folder_name: str
    total_count: int

@router.post("/google-drive/list-folder-photos")
async def list_folder_photos(request: FolderPhotosRequest) -> FolderPhotosResponse:
    """
    List all image files from a Google Drive folder
    Requires GOOGLE_DRIVE_API_KEY secret
    """
    api_key = os.environ.get("GOOGLE_DRIVE_API_KEY")
    if not api_key:
        raise HTTPException(
            status_code=500,
            detail="Google Drive API key not configured"
        )
    
    folder_id = request.folder_id
    
    # Get folder metadata
    folder_url = f"https://www.googleapis.com/drive/v3/files/{folder_id}"
    folder_params = {
        'key': api_key,
        'fields': 'name'
    }
    
    try:
        folder_response = requests.get(folder_url, params=folder_params)
        folder_response.raise_for_status()
        folder_data = folder_response.json()
        folder_name = folder_data.get('name', 'Unknown Folder')
    except requests.exceptions.RequestException as e:
        print(f"Error fetching folder metadata: {e}")
        raise HTTPException(status_code=400, detail="Invalid folder ID or insufficient permissions")
    
    # List files in folder (only images)
    list_url = "https://www.googleapis.com/drive/v3/files"
    params = {
        'key': api_key,
        'q': f"'{folder_id}' in parents and (mimeType contains 'image/')",
        'fields': 'files(id, name, thumbnailLink, webViewLink, mimeType)',
        'pageSize': 1000  # Max allowed by API
    }
    
    try:
        response = requests.get(list_url, params=params)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as e:
        print(f"Error listing folder contents: {e}")
        raise HTTPException(status_code=500, detail="Failed to list folder contents")
    
    files = data.get('files', [])
    
    photos = []
    for file in files:
        # Convert to direct image URL
        direct_link = f"https://drive.google.com/uc?export=view&id={file['id']}"
        
        photos.append(GoogleDrivePhoto(
            file_id=file['id'],
            name=file['name'],
            thumbnail_url=file.get('thumbnailLink', direct_link),
            web_view_link=file['webViewLink'],
            direct_link=direct_link
        ))
    
    return FolderPhotosResponse(
        photos=photos,
        folder_name=folder_name,
        total_count=len(photos)
    )