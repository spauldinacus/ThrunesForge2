from fastapi import APIRouter, HTTPException, Header, Request
from pydantic import BaseModel
from typing import Optional, Any
import asyncpg
import os
from datetime import datetime
import hmac
import hashlib

router = APIRouter(prefix="/webhooks/stack")

class StackWebhookPayload(BaseModel):
    """Stack Auth webhook payload"""
    data: dict[str, Any]
    user_id: Optional[str] = None

@router.post("/users")
async def stack_user_webhook(
    request: Request,
    x_stack_signature: Optional[str] = Header(None)
):
    """
    Webhook endpoint for Stack Auth user events.
    Syncs user data to neon_auth.users_sync table.
    
    This endpoint is UNPROTECTED (no auth required) as it receives webhooks from Stack Auth.
    Security is handled via webhook signature verification.
    """
    
    # Get raw body for signature verification
    body = await request.body()
    
    # Verify webhook signature if configured
    webhook_secret = os.environ.get("STACK_WEBHOOK_SECRET")
    if webhook_secret and x_stack_signature:
        expected_signature = hmac.new(
            webhook_secret.encode(),
            body,
            hashlib.sha256
        ).hexdigest()
        
        if not hmac.compare_digest(expected_signature, x_stack_signature):
            raise HTTPException(
                status_code=401,
                detail="Invalid webhook signature"
            )
    
    # Parse JSON payload
    import json
    try:
        payload = json.loads(body)
    except json.JSONDecodeError:
        raise HTTPException(
            status_code=400,
            detail="Invalid JSON payload"
        )
    
    # Get database connection
    from app.libs.database import get_database_connection
    conn = await get_database_connection()
    
    try:
        # Extract user data from Stack Auth webhook payload
        # Stack Auth sends user data in various formats depending on event type
        user_data = payload.get('data', payload)
        
        # Handle different Stack Auth webhook event types
        event_type = payload.get('type') or payload.get('event')
        
        if event_type in ['user.created', 'user.updated', 'user']:
            # Upsert to neon_auth.users_sync table
            await conn.execute(
                """
                INSERT INTO neon_auth.users_sync (raw_json, updated_at)
                VALUES ($1, $2)
                ON CONFLICT (id) 
                DO UPDATE SET 
                    raw_json = EXCLUDED.raw_json,
                    updated_at = EXCLUDED.updated_at
                """,
                json.dumps(user_data),
                datetime.utcnow()
            )
            
            print(f"✅ Synced user {user_data.get('id')} from Stack Auth webhook")
            
        elif event_type == 'user.deleted':
            # Mark user as deleted
            user_id = user_data.get('id')
            if user_id:
                await conn.execute(
                    """
                    UPDATE neon_auth.users_sync
                    SET deleted_at = $1
                    WHERE id = $2
                    """,
                    datetime.utcnow(),
                    user_id
                )
                print(f"✅ Marked user {user_id} as deleted from Stack Auth webhook")
        
        return {
            "success": True,
            "message": "Webhook processed successfully"
        }
        
    except asyncpg.PostgresError as e:
        print(f"❌ Database error processing Stack Auth webhook: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Database error: {str(e)}"
        )
    except Exception as e:
        print(f"❌ Error processing Stack Auth webhook: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Webhook processing error: {str(e)}"
        )
    finally:
        await conn.close()
