from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel
from typing import List, Optional, Any
from datetime import datetime
import json
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection

router = APIRouter(prefix="/admin/audit-logs")

# Models
class AuditLogEntry(BaseModel):
    id: str
    performed_by_user_id: Optional[str]
    performed_by_name: Optional[str]
    action_type: str
    action: str
    entity_id: Optional[str]
    entity_name: Optional[str] = None    
    entity_type: Optional[str]
    details: Any
    created_at: datetime

# Permission check
async def check_admin_permission(user: AuthorizedUser):
    """Check if user has admin permissions"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('view_admin_panel', 'view_audit_logs')
            )
            """,
            user.sub
        )
        if not admin_check:
            # Fallback to old is_admin check for backward compatibility
            admin_check = await conn.fetchval(
                "SELECT is_admin FROM player_profiles WHERE user_id = $1",
                user.sub
            )
        
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

@router.get("", response_model=List[AuditLogEntry])
async def get_audit_logs(
    user: AuthorizedUser, 
    limit: int = 50, 
    offset: int = 0,
    action_type: Optional[str] = None,
    user_id: Optional[str] = None,
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    action: Optional[str] = None,
    entity_type: Optional[str] = None,
    sort_by: str = "created_at",
    sort_direction: str = "desc"
):
    """Get audit logs with filtering"""
    await check_admin_permission(user)
    
    # Clean up inputs
    if action_type in ("null", ""): action_type = None
    if user_id in ("null", ""): user_id = None
    if action in ("null", ""): action = None
    if entity_type in ("null", ""): entity_type = None
    
    # Safe date parsing
    start_dt, end_dt = None, None
    try:
        if start_date and start_date not in ("null", ""):
            start_dt = datetime.fromisoformat(start_date.replace('Z', '+00:00'))
        if end_date and end_date not in ("null", ""):
            end_dt = datetime.fromisoformat(end_date.replace('Z', '+00:00'))
    except ValueError:
        pass # Ignore invalid dates
        
    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                al.*, 
                pp.first_name || ' ' || pp.last_name as performed_by_name,
                CASE
                    WHEN al.entity_type = 'character' THEN c.name || ' (' || COALESCE(pp_char.first_name || ' ' || pp_char.last_name, 'Unknown') || ')' || ')'
                    WHEN al.entity_type = 'player_profile' THEN pp_entity.first_name || ' ' || pp_entity.last_name
                    WHEN al.entity_type = 'gallery' THEN pg.name
                    ELSE al.entity_id::text
                END as entity_name
            FROM audit_logs al
            LEFT JOIN player_profiles pp ON al.performed_by_user_id = pp.user_id
            LEFT JOIN characters c ON al.entity_id = c.id AND al.entity_type = 'character'
            LEFT JOIN player_profiles pp_char ON c.player_profile_id = pp_char.id
            LEFT JOIN player_profiles pp_entity ON al.entity_id = pp_entity.id AND al.entity_type = 'player_profile'
            LEFT JOIN photo_galleries pg ON al.entity_id = pg.id AND al.entity_type = 'gallery'
            WHERE 1=1
        """
        params = []
        param_idx = 1
        
        if action_type:
            query += f" AND al.action_type = ${param_idx}"
            params.append(action_type)
            param_idx += 1
            
        if user_id:
            query += f" AND al.performed_by_user_id = ${param_idx}"
            params.append(user_id)
            param_idx += 1

        if action:
            query += f" AND al.action = ${param_idx}"
            params.append(action)
            param_idx += 1

        if entity_type:
            query += f" AND al.entity_type = ${param_idx}"
            params.append(entity_type)
            param_idx += 1

        if start_dt:
            query += f" AND al.created_at >= ${param_idx}"
            params.append(start_dt)
            param_idx += 1

        if end_dt:
            query += f" AND al.created_at <= ${param_idx}"
            params.append(end_dt)
            param_idx += 1
            
        # Validate sort_by to prevent SQL injection
        allowed_sort_cols = ["created_at", "action_type", "action", "entity_type", "performed_by_name", "entity_name"]
        if sort_by not in allowed_sort_cols:
            sort_by = "created_at"
        
        direction = "DESC" if sort_direction.lower() == "desc" else "ASC"
        
        # Special handling for aliases
        if sort_by == "performed_by_name":
             query += f" ORDER BY performed_by_name {direction} LIMIT ${param_idx} OFFSET ${param_idx+1}"
        elif sort_by == "entity_name":
             query += f" ORDER BY entity_name {direction} LIMIT ${param_idx} OFFSET ${param_idx+1}"
        else:
             query += f" ORDER BY al.{sort_by} {direction} LIMIT ${param_idx} OFFSET ${param_idx+1}"

        params.extend([limit, offset])
        
        rows = await conn.fetch(query, *params)
        
        # Manual conversion of UUIDs to strings to prevent Pydantic validation errors
        results = []
        
        # Collections for bulk fetching names
        sys_milestone_ids = set()
        event_ids = set()
        chapter_ids = set()

        # Temporary storage for processing
        processed_rows = []

        for row in rows:
            try:
                data = dict(row)
                data['id'] = str(data['id'])
                if data.get('entity_id'):
                    data['entity_id'] = str(data['entity_id'])
                
                # Parse details if string
                if isinstance(data.get('details'), str):
                    try:
                        data['details'] = json.loads(data['details'])
                    except:
                        pass
                
                # Collect IDs for enrichment
                if isinstance(data.get('details'), dict):
                    details = data['details']
                    if details.get('system_milestone_id'):
                        sys_milestone_ids.add(details['system_milestone_id'])
                    if details.get('event_id'):
                        event_ids.add(details['event_id'])
                    if details.get('chapter_id'):
                        chapter_ids.add(details['chapter_id'])
                        
                processed_rows.append(data)
            except Exception as e:
                print(f"CRITICAL ERROR processing audit log row {row.get('id')}: {e}")
                import traceback
                traceback.print_exc()
                continue

        # Bulk fetch names
        milestone_map = {}
        if sys_milestone_ids:
            # Filter valid UUIDs only to avoid SQL errors
            valid_ids = [uid for uid in sys_milestone_ids if len(str(uid)) == 36]
            if valid_ids:
                m_rows = await conn.fetch("SELECT id, name FROM system_milestones WHERE id = ANY($1::uuid[])", valid_ids)
                milestone_map = {str(r['id']): r['name'] for r in m_rows}

        event_map = {}
        if event_ids:
            valid_ids = [uid for uid in event_ids if len(str(uid)) == 36]
            if valid_ids:
                e_rows = await conn.fetch("SELECT id, title FROM events WHERE id = ANY($1::uuid[])", valid_ids)
                event_map = {str(r['id']): r['title'] for r in e_rows}
            
        chapter_map = {}
        if chapter_ids:
            valid_ids = [uid for uid in chapter_ids if len(str(uid)) == 36]
            if valid_ids:
                c_rows = await conn.fetch("SELECT id, name FROM chapters WHERE id = ANY($1::uuid[])", valid_ids)
                chapter_map = {str(r['id']): r['name'] for r in c_rows}

        # Enrich and build final results
        for data in processed_rows:
            if isinstance(data.get('details'), dict):
                details = data['details']
                
                # Replace System Milestone ID
                if details.get('system_milestone_id') and str(details['system_milestone_id']) in milestone_map:
                    details['system_milestone'] = milestone_map[str(details['system_milestone_id'])]
                    del details['system_milestone_id']
                
                # Replace Event ID
                if details.get('event_id') and str(details['event_id']) in event_map:
                    details['event'] = event_map[str(details['event_id'])]
                    del details['event_id']

                # Replace Chapter ID
                if details.get('chapter_id') and str(details['chapter_id']) in chapter_map:
                    details['chapter'] = chapter_map[str(details['chapter_id'])]
                    del details['chapter_id']
            
            results.append(AuditLogEntry(**data))
            
        return results
    finally:
        await conn.close()

@router.post("/backfill")
async def backfill_audit_logs(user: AuthorizedUser):
    """Backfill audit logs from existing transactions"""
    await check_admin_permission(user)
    conn = await get_database_connection()
    try:
        # Check if already backfilled to avoid duplicates (naive check)
        # count = await conn.fetchval("SELECT COUNT(*) FROM audit_logs WHERE action_type = 'system_backfill'")
        # if count > 0:
        #    return {"message": "Backfill likely already done", "count": count}

        total_processed = 0

        # 1. Backfill from candle_transactions (where granted_by_user_id is present)
        candle_txs = await conn.fetch("""
            SELECT * FROM candle_transactions 
            WHERE granted_by_user_id IS NOT NULL
        """)
        
        for tx in candle_txs:
            try:
                if not tx['player_profile_id']:
                    continue

                details = {
                    "amount": tx['amount'],
                    "reason": tx['reason'],
                    "used_for": tx['used_for']
                }
                action = 'grant' if tx['amount'] > 0 else 'deduct'
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['granted_by_user_id'],
                'candle',
                action,
                str(tx['player_profile_id']),
                'player_profile',
                json.dumps(details),
                tx['created_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill candle transaction {tx.get('id')}: {e}")
                continue

        # 2. Backfill from character_reassignment_history
        reassign_txs = await conn.fetch("SELECT * FROM character_reassignment_history")
        
        for tx in reassign_txs:
            try:
                details = {
                    "from_player_id": str(tx['from_player_id']) if tx['from_player_id'] else None,
                    "to_player_id": str(tx['to_player_id']),
                    "notes": tx['notes']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['reassigned_by'],
                'character',
                'reassign',
                str(tx['character_id']),
                'character',
                json.dumps(details),
                tx['reassigned_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill reassignment {tx.get('id')}: {e}")
                continue

        # 3. Backfill from player_milestones (where awarded_by is present)
        milestone_txs = await conn.fetch("""
            SELECT * FROM player_milestones 
            WHERE awarded_by IS NOT NULL
        """)
        
        for tx in milestone_txs:
            try:
                details = {
                    "system_milestone_id": str(tx['system_milestone_id']) if tx['system_milestone_id'] else None,
                    "custom_name": tx['custom_name'],
                    "notes": tx['notes']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['awarded_by'],
                'milestone',
                'award',
                str(tx['character_id']),
                'character',
                json.dumps(details),
                tx['created_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill milestone {tx.get('id')}: {e}")
                continue

        # 4. Backfill from xp_transactions (Admin updates)
        # Note: We use 'system-backfill' as user_id because admin ID is not explicitly stored in xp_transactions
        xp_txs = await conn.fetch("""
            SELECT * FROM xp_transactions 
            WHERE reason LIKE 'Admin update:%' OR transaction_type = 'admin_adjustment'
        """)
        
        for tx in xp_txs:
            try:
                # Skip if character_id is missing
                if not tx['character_id']:
                    continue

                details = {
                    "reason": tx['reason'], 
                    "amount": tx['amount'], 
                    "transaction_type": tx['transaction_type']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                'system-backfill', 
                'xp',
                tx['transaction_type'],
                str(tx['character_id']),
                'character',
                 json.dumps(details),
                tx['created_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill XP transaction {tx.get('id')}: {e}")
                continue

        # 5. Backfill from player_roles
        role_txs = await conn.fetch("""
            SELECT pr.*, r.name as role_name 
            FROM player_roles pr
            JOIN roles r ON pr.role_id = r.id
            WHERE pr.assigned_by_user_id IS NOT NULL
        """)
        
        for tx in role_txs:
            try:
                details = {
                    "role_id": str(tx['role_id']),
                    "role_name": tx['role_name']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['assigned_by_user_id'],
                'role',
                'assign',
                str(tx['player_profile_id']),
                'player_profile',
                json.dumps(details),
                tx['assigned_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill role {tx.get('id')}: {e}")
                continue

        # 6. Backfill from lore_submissions
        lore_txs = await conn.fetch("SELECT * FROM lore_submissions WHERE created_by IS NOT NULL")
        
        for tx in lore_txs:
            try:
                details = {
                    "event_id": str(tx['event_id']),
                    "chapter_id": str(tx['chapter_id']),
                    "outcome": tx['outcome']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['created_by'],
                'lore',
                'create',
                str(tx['id']),
                'lore_submission',
                json.dumps(details),
                tx['created_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill lore {tx.get('id')}: {e}")
                continue

        # 7. Backfill from photo_galleries
        gallery_txs = await conn.fetch("SELECT * FROM photo_galleries WHERE created_by_user_id IS NOT NULL")
        
        for tx in gallery_txs:
            try:
                details = {
                    "name": tx['name'],
                    "description": tx['description']
                }
                
                await conn.execute("""
                    INSERT INTO audit_logs (performed_by_user_id, action_type, action, entity_id, entity_type, details, created_at)
                    VALUES ($1, $2, $3, $4, $5, $6, $7)
                """, 
                tx['created_by_user_id'],
                'photo_gallery',
                'create',
                str(tx['id']),
                'gallery',
                json.dumps(details),
                tx['created_at']
                )
                total_processed += 1
            except Exception as e:
                print(f"Failed to backfill gallery {tx.get('id')}: {e}")
                continue

        
        # Add a marker record so we know backfill is done
        await conn.execute("""
            INSERT INTO audit_logs (performed_by_user_id, action_type, action, details)
            VALUES ($1, $2, $3, $4)
        """, 'system', 'system_backfill', 'completed', json.dumps({"count": total_processed}))

        return {"message": "Backfill completed", "processed": total_processed}
    finally:
        await conn.close()
