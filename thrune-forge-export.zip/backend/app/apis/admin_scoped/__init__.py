from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
import uuid
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.permissions import get_user_chapters_with_permission

router = APIRouter(prefix="/admin-scoped")

# --- Pydantic Models ---

class AdminEventResponse(BaseModel):
    id: str
    chapter_id: str
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    starts_at: datetime
    ends_at: datetime
    status: str
    created_at: datetime
    chapter_name: str
    total_rsvps: int
    attended_count: int
    no_show_count: int

class AdminEventListResponse(BaseModel):
    events: List[AdminEventResponse]

class ChapterResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None

class ChapterListResponse(BaseModel):
    chapters: List[ChapterResponse]
    
# --- Endpoints ---

@router.get("/events")
async def list_scoped_events(user: AuthorizedUser) -> AdminEventListResponse:
    """Get all events with admin data, filtered by user's chapter permissions"""
    # Check permission and get allowed chapters
    permitted_chapters = await get_user_chapters_with_permission(user.sub, "manage_events")
    
    # If permitted_chapters is empty list (not None), user has no access
    if permitted_chapters == []:
        return AdminEventListResponse(events=[])
        
    conn = None
    try:
        conn = await get_database_connection()
        
        # Base query
        query = """
            SELECT e.id, e.title, e.description, e.location, e.chapter_id, c.name as chapter_name, e.starts_at, e.ends_at, e.status, e.created_at,
                   COUNT(r.id) as total_rsvps,
                   COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attended_count,
                   COUNT(CASE WHEN r.attendance_status = 'no_show' THEN 1 END) as no_show_count
            FROM events e
            LEFT JOIN chapters c ON e.chapter_id = c.id
            LEFT JOIN rsvps r ON e.id = r.event_id
        """
        
        # Add filtering if not global admin
        args = []
        if permitted_chapters != [None]:
            query += " WHERE e.chapter_id = ANY($1::uuid[])"
            args.append(permitted_chapters)
            
        query += """
            GROUP BY e.id, c.name
            ORDER BY e.starts_at DESC
        """
        
        rows = await conn.fetch(query, *args)
        events = [
            AdminEventResponse(
                **{k: str(v) if k in ('id', 'chapter_id') else v for k, v in dict(row).items()}
            ) 
            for row in rows
        ]    
        return AdminEventListResponse(events=events)
    except Exception as e:
        print(f"Error listing admin events: {e}")
        raise HTTPException(status_code=500, detail="Failed to list events")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.get("/characters")
async def list_scoped_characters(user: AuthorizedUser) -> List[dict]:
    """Get all characters for admin management, filtered by user's chapter permissions"""
    # Check permission and get allowed chapters
    permitted_chapters = await get_user_chapters_with_permission(user.sub, "manage_characters")
    
    # If permitted_chapters is empty list (not None), user has no access
    if permitted_chapters == []:
        return []
        
    conn = None
    try:
        conn = await get_database_connection()
        
        # Base query
        query = """
            SELECT c.*, h.name as heritage_name, cu.name as culture_name, a.name as archetype_name,
                   sa.name as secondary_archetype_name, ta.name as tertiary_archetype_name,
                   pp.first_name || ' ' || pp.last_name as player_name, pp.player_number,
                   pp.chapter_id,
                   ch.name as chapter_name
            FROM characters c
            JOIN heritages h ON c.heritage_id = h.id
            JOIN cultures cu ON c.culture_id = cu.id
            JOIN archetypes a ON c.archetype_id = a.id
            LEFT JOIN archetypes sa ON c.secondary_archetype_id = sa.id
            LEFT JOIN archetypes ta ON c.tertiary_archetype_id = ta.id
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            JOIN chapters ch ON pp.chapter_id = ch.id
        """
        
        # Add filtering if not global admin
        args = []
        if permitted_chapters != [None]:
            query += " WHERE pp.chapter_id = ANY($1::uuid[])"
            args.append(permitted_chapters)
            
        query += " ORDER BY c.name ASC"
            
        rows = await conn.fetch(query, *args)
        
        rows = await conn.fetch(query, *args)
        
        # Convert rows to dict and handle UUIDs/Dates
        results = []
        for row in rows:
            item = dict(row)
            for k, v in item.items():
                if isinstance(v, (uuid.UUID, datetime)):
                    item[k] = str(v)
            
            # Calculate skill count from selected_skills JSONB field
            skill_count = 0
            if item.get('selected_skills'):
                skills_data = item['selected_skills']
                # asyncpg returns JSONB as string, need to parse it
                if isinstance(skills_data, str):
                    import json
                    skills_data = json.loads(skills_data)
                skill_count = len(skills_data) if isinstance(skills_data, list) else 0
            
            item['skill_count'] = skill_count
            
            results.append(item)
            
        return results
    except Exception as e:
        print(f"Error listing characters: {e}")
        raise HTTPException(status_code=500, detail="Failed to list characters")
    finally:
        if conn and not conn.is_closed():
            await conn.close()


@router.get("/chapters")
async def list_scoped_chapters(user: AuthorizedUser) -> ChapterListResponse:
    """Get all chapters filtered by user's chapter permissions"""
    # Check permission and get allowed chapters
    permitted_chapters = await get_user_chapters_with_permission(user.sub, "view_admin_panel")
    
    # If permitted_chapters is empty list (not None), user has no access
    if permitted_chapters == []:
        return ChapterListResponse(chapters=[])
        
    conn = None
    try:
        conn = await get_database_connection()
        
        # Base query
        query = "SELECT id, name, description FROM chapters"
        
        # Add filtering if not global admin
        args = []
        if permitted_chapters != [None]:
            query += " WHERE id = ANY($1::uuid[])"
            args.append(permitted_chapters)
            
        query += " ORDER BY name ASC"
        
        rows = await conn.fetch(query, *args)
        chapters = [ChapterResponse(id=str(row['id']), name=row['name'], description=row['description']) for row in rows]
        
        return ChapterListResponse(chapters=chapters)
    except Exception as e:
        print(f"Error listing chapters: {e}")
        raise HTTPException(status_code=500, detail="Failed to list chapters")
    finally:
        if conn and not conn.is_closed():
            await conn.close()