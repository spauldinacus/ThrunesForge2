from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any, Union
from uuid import UUID, uuid4
import asyncpg
import os
import json
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection

router = APIRouter(prefix="/characters")

# Import Heritage and Culture models from other APIs
class HeritageInfo(BaseModel):
    id: str
    name: str
    description: str
    costuming_requirements: str
    base_body: int
    base_stamina: int
    benefit: str
    benefit_name: str
    weakness: str
    weakness_name: str
    candle_cost: int = 0    

class CultureInfo(BaseModel):
    id: str
    name: str
    heritage_id: str
    description: str
    costuming_requirements: Optional[str] = None
    benefit: str
    benefit_name: Optional[str] = None
    candle_cost: int = 0    

# Pydantic Models
class CharacterBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    heritage_id: str
    culture_id: str
    archetype_id: str
    body: int = Field(..., ge=1, le=200)
    stamina: int = Field(..., ge=1, le=200)
    selected_skills: List[str] = Field(default_factory=list)  # List of skill UUIDs
    player_notes: Optional[str] = None
    addictions_diseases: Optional[str] = None

class CharacterCreate(CharacterBase):
    secondary_archetype_id: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    selected_skills: List[dict] = Field(default_factory=list)  # Changed to support [{"skill_id": str, "quantity": int}]

class CharacterUpdateRequest(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    heritage_id: Optional[str] = None
    culture_id: Optional[str] = None
    archetype_id: Optional[str] = None
    secondary_archetype_id: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    body: Optional[int] = Field(None, ge=1, le=200)
    stamina: Optional[int] = Field(None, ge=1, le=200)
    selected_skills: Optional[List[dict]] = None  # Changed to support {"skill_id": str, "quantity": int}
    player_notes: Optional[str] = None
    addictions_diseases: Optional[str] = None
    retired: Optional[bool] = None
    deaths: Optional[int] = Field(None, ge=0, le=10)
    corruption: Optional[int] = Field(None, ge=0, le=10)

class SkillInfo(BaseModel):
    id: str
    name: str
    description: str
    is_primary: bool
    is_secondary: bool
    xp_cost: int

class XPTransaction(BaseModel):
    id: str
    amount: int
    transaction_type: str
    reason: str
    skill_id: Optional[str] = None
    body_points: Optional[int] = None
    stamina_points: Optional[int] = None
    created_at: str

class CharacterDetail(BaseModel):
    id: str
    name: str
    heritage_id: str
    culture_id: str
    archetype_id: str
    secondary_archetype_id: str | None = None
    tertiary_archetype_id: str | None = None
    body: int
    stamina: int
    xp_total: int
    xp_spent: int
    xp_available: int
    player_notes: str | None = None
    addictions_diseases: str | None = None
    retired: bool
    deaths: int = 0
    corruption: int = 0
    created_at: str
    updated_at: str
    heritage_name: str
    culture_name: str
    heritage: HeritageInfo  # Add full heritage object
    culture: CultureInfo   # Add full culture object
    archetype_name: str
    secondary_archetype_name: str | None = None
    tertiary_archetype_name: str | None = None
    skills: list[SkillInfo]
    events_attended: int
    xp_transactions: list[XPTransaction]

class CharacterListItem(BaseModel):
    id: str
    name: str
    heritage_name: str
    culture_name: str
    archetype_name: str
    secondary_archetype_name: str | None = None
    body: int
    stamina: int
    xp_available: int
    xp_total: int  # ADD THIS LINE
    retired: bool
    deaths: int = 0
    corruption: int = 0
    events_attended: int
    skill_count: int

class XPCostCalculation(BaseModel):
    body_cost: int
    stamina_cost: int
    total_cost: int

class SkillCostCalculation(BaseModel):
    skill_id: str
    skill_name: str
    xp_cost: int
    is_available: bool
    missing_prerequisites: List[str]

# Helper Functions
def calculate_body_stamina_xp_cost(current_value: int, target_value: int) -> int:
    """Calculate XP cost for body/stamina increases using the scaling system.
    
    XP Cost Logic:
    - 1-20: 1 XP per point
    - 21-40: 2 XP per point
    - 41-60: 3 XP per point
    - 61-80: 4 XP per point
    - 81-100: 5 XP per point
    - 101-120: 6 XP per point
    - 121-140: 7 XP per point
    - 141-160: 8 XP per point
    - 161-180: 9 XP per point
    - 181+: 10 XP per point
    """
    if target_value <= current_value:
        return 0
    
    total_cost = 0
    
    for value in range(current_value + 1, target_value + 1):
        if value <= 20:
            total_cost += 1
        elif value <= 40:
            total_cost += 2
        elif value <= 60:
            total_cost += 3
        elif value <= 80:
            total_cost += 4
        elif value <= 100:
            total_cost += 5
        elif value <= 120:
            total_cost += 6
        elif value <= 140:
            total_cost += 7
        elif value <= 160:
            total_cost += 8
        elif value <= 180:
            total_cost += 9
        else:  # 181+
            total_cost += 10
    
    return total_cost

def get_skill_xp_cost(skill_id: str, archetype_primary_skills: List[str], 
                     heritage_secondary_skills: List[str], archetype_secondary_skills: List[str]) -> int:
    """Calculate XP cost for a skill based on character's archetype and heritage.
    
    - Primary skills: 5 XP
    - Secondary skills: 10 XP (heritage or archetype)
    - Other skills: 20 XP
    """
    if skill_id in archetype_primary_skills:
        return 5
    elif skill_id in heritage_secondary_skills or skill_id in archetype_secondary_skills:
        return 10
    else:
        return 20

async def get_character_skills(selected_skills: List[dict], character_id: str) -> List[SkillInfo]:
    """Get skill objects with XP cost info for selected skill purchases.
    selected_skills format: [{\
    
    "skill_id": "uuid", "quantity": 1}, ...] (new format)
    OR ["skill_id1", "skill_id2", ...] (old format for backward compatibility)
    """
    if not selected_skills:
        return []
        
    conn = await get_database_connection()
    try:
        # Handle both old format (array of strings) and new format (array of objects)
        skill_purchases = []
        
        for item in selected_skills:
            if isinstance(item, str):
                # Old format: just skill ID strings
                skill_purchases.append({"skill_id": item, "quantity": 1})
            elif isinstance(item, dict) and "skill_id" in item:
                # New format: skill purchase objects
                skill_purchases.append(item)
        
        # Extract unique skill IDs from the skill purchases
        skill_ids = list(set([skill_purchase["skill_id"] for skill_purchase in skill_purchases]))
        
        if not skill_ids:
            return []
        
        # Build dynamic query for skills with archetype and heritage relationships
        query = """
        SELECT s.id, s.name, s.description,
               CASE WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN true ELSE false END as is_primary,
               CASE WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN true ELSE false END as is_secondary
        FROM skills s
        LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = (
            SELECT archetype_id FROM characters WHERE id = $2
        )
        LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = (
            SELECT archetype_id FROM characters WHERE id = $2
        )
        LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = (
            SELECT heritage_id FROM characters WHERE id = $2
        )
        LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = (
            SELECT secondary_archetype_id FROM characters WHERE id = $2
        )
        LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = (
            SELECT secondary_archetype_id FROM characters WHERE id = $2
        )
        LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = (
            SELECT tertiary_archetype_id FROM characters WHERE id = $2
        )
        LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = (
            SELECT tertiary_archetype_id FROM characters WHERE id = $2
        )
        WHERE s.id = ANY($1)
        ORDER BY s.name
        """

        rows = await conn.fetch(query, skill_ids, character_id)

        character_skills = []
        for row in rows:
            # Calculate XP cost based on archetype/heritage relationship
            if row['is_primary']:
                xp_cost = 5
            elif row['is_secondary']:
                xp_cost = 10
            else:
                xp_cost = 20
                
            # Find quantity for this skill
            quantity = sum([sp["quantity"] for sp in skill_purchases if sp["skill_id"] == str(row['id'])])
            
            # Add one entry for each purchase of this skill
            for i in range(quantity):
                character_skills.append(SkillInfo(
                    id=str(row['id']),
                    name=f"{row['name']} ({i+1})" if quantity > 1 else row['name'],
                    description=row['description'],
                    is_primary=row['is_primary'],
                    is_secondary=row['is_secondary'],
                    xp_cost=xp_cost
                ))
        
        return character_skills
        
    finally:
        await conn.close()

@router.post("/calculate-xp-cost")
async def calculate_xp_cost(body: int, stamina: int, character_id: str, user: AuthorizedUser) -> XPCostCalculation:
    """Calculate XP cost for body/stamina changes."""
    conn = await get_database_connection()
    try:
        # Get current character stats and heritage base values
        query = """
        SELECT c.body, c.stamina, h.base_body, h.base_stamina 
        FROM characters c
        JOIN heritages h ON c.heritage_id = h.id
        WHERE c.id = $1 AND c.player_profile_id = (SELECT id FROM player_profiles WHERE user_id = $2)
        """
        row = await conn.fetchrow(query, character_id, user.sub)
        
        if not row:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Calculate heritage-relative costs using the same logic as character creation
        heritage_base_body = row['base_body']
        heritage_base_stamina = row['base_stamina']
        
        # Calculate cost from base to current value using the global scaling logic
        body_cost = calculate_body_stamina_xp_cost(heritage_base_body, body)
        stamina_cost = calculate_body_stamina_xp_cost(heritage_base_stamina, stamina)
        
        return XPCostCalculation(
            body_cost=body_cost,
            stamina_cost=stamina_cost,
            total_cost=body_cost + stamina_cost
        )
        
    finally:
        await conn.close()

@router.get("/my-characters")
async def list_my_characters(user: AuthorizedUser) -> List[CharacterListItem]:
    """Get list of characters for the authenticated user."""
    conn = await get_database_connection()
    try:
        # First get the player profile ID
        player_query = "SELECT id FROM public.player_profiles WHERE user_id = $1"
        player_row = await conn.fetchrow(player_query, user.sub)
        
        if not player_row:
            raise HTTPException(status_code=404, detail="Player profile not found")
        
        player_profile_id = player_row['id']
        
        query = """
        SELECT 
            c.id, c.name, c.body, c.stamina, c.xp_available, c.xp_total, c.retired,
            c.deaths, c.corruption, c.selected_skills,
            h.name as heritage_name,
            cu.name as culture_name,
            a1.name as archetype_name,
            a2.name as secondary_archetype_name,
            COALESCE((
                SELECT COUNT(*) FROM rsvps r 
                WHERE r.character_id = c.id 
                AND r.attendance_status = 'attended'
            ), 0) as events_attended
        FROM characters c
        LEFT JOIN heritages h ON c.heritage_id = h.id
        LEFT JOIN cultures cu ON c.culture_id = cu.id
        LEFT JOIN archetypes a1 ON c.archetype_id = a1.id
        LEFT JOIN archetypes a2 ON c.secondary_archetype_id = a2.id
        WHERE c.player_profile_id = $1
        ORDER BY c.created_at DESC
        """
        
        # Fetch character data
        rows = await conn.fetch(query, player_profile_id)
        
        characters = []
        for row in rows:
            # Calculate skill count from selected_skills JSON - count unique skills only
            skill_count = 0
            if row['selected_skills']:
                # Parse JSON string if it's a string, otherwise use as-is
                skills_data = row['selected_skills']
                if isinstance(skills_data, str):
                    import json
                    skills_data = json.loads(skills_data)
                
                # Count unique skills regardless of purchase quantities
                skill_count = len(skills_data)
                        
            characters.append(CharacterListItem(
                id=str(row['id']),
                name=row['name'],
                heritage_name=row['heritage_name'],
                culture_name=row['culture_name'],
                archetype_name=row['archetype_name'],
                secondary_archetype_name=row['secondary_archetype_name'],
                body=row['body'],
                stamina=row['stamina'],
                xp_available=row['xp_available'],
                xp_total=row['xp_total'],  # ADD THIS LINE
                retired=row['retired'],
                deaths=row['deaths'],
                corruption=row['corruption'],
                events_attended=row['events_attended'],
                skill_count=skill_count
            ))
            
        return characters
        
    finally:
        await conn.close()

@router.get("/my-characters/{character_id}")
async def get_my_character(character_id: str, user: AuthorizedUser) -> CharacterDetail:
    """Get detailed character information including skills and XP history."""
    conn = await get_database_connection()
    try:
        query = """
        SELECT c.*, h.name as heritage_name, cu.name as culture_name, a.name as archetype_name,
               sa.name as secondary_archetype_name, ta.name as tertiary_archetype_name,
               h.description as heritage_description, h.costuming_requirements as heritage_costuming,
               h.base_body, h.base_stamina, h.benefit as heritage_benefit, h.benefit_name as heritage_benefit_name,
               h.weakness as heritage_weakness, h.weakness_name as heritage_weakness_name, h.candle_cost as heritage_candle_cost,
               cu.description as culture_description, cu.costuming_requirements as culture_costuming,
               cu.benefit as culture_benefit, cu.benefit_name as culture_benefit_name, cu.candle_cost as culture_candle_cost,
               COALESCE((
                   SELECT COUNT(*) FROM rsvps r 
                   WHERE r.character_id = c.id 
                   AND r.attendance_status = 'attended'
               ), 0) as events_attended
        FROM characters c
        JOIN heritages h ON h.id = c.heritage_id
        JOIN cultures cu ON c.culture_id = cu.id
        JOIN archetypes a ON c.archetype_id = a.id
        LEFT JOIN archetypes sa ON sa.id = c.secondary_archetype_id
        LEFT JOIN archetypes ta ON ta.id = c.tertiary_archetype_id
        JOIN player_profiles pp ON pp.id = c.player_profile_id
        WHERE c.id = $1 AND pp.user_id = $2
        """
        
        row = await conn.fetchrow(query, character_id, user.sub)
        
        if not row:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Parse selected_skills from database (handle both old and new formats)
        if row['selected_skills']:
            try:
                raw_selected_skills = json.loads(row['selected_skills'])
                print(f"DEBUG: raw_selected_skills = {raw_selected_skills}")
                if raw_selected_skills and isinstance(raw_selected_skills[0], dict):
                    # Check if it's the current format: [{'id': '...', 'name': '...', 'xp_cost': X, 'purchase_count': Y}]
                    if 'id' in raw_selected_skills[0]:
                        # Current format - convert to expected format for get_character_skills
                        selected_skills = [{
                            'skill_id': item['id'], 
                            'quantity': item.get('purchase_count', 1)
                        } for item in raw_selected_skills]
                    elif 'skill_id' in raw_selected_skills[0]:
                        # Expected format: [{'skill_id': '...', 'quantity': 1}]
                        selected_skills = raw_selected_skills
                    else:
                        # Unknown dict format
                        selected_skills = []
                else:
                    # Old format: ["skill_id1", "skill_id2", ...]
                    selected_skills = raw_selected_skills
                print(f"DEBUG: selected_skills = {selected_skills}")
            except (json.JSONDecodeError, KeyError, IndexError) as e:
                print(f"DEBUG: Error parsing selected_skills: {e} - {row['selected_skills']}")
                selected_skills = []
        else:
            print("DEBUG: selected_skills is null/empty")
            selected_skills = []
        
        print(f"DEBUG: About to call get_character_skills with: {selected_skills}")
        skills = await get_character_skills(selected_skills, character_id)
        print(f"DEBUG: get_character_skills returned {len(skills)} skills: {[s.name for s in skills]}")
        
        # Get XP transactions
        xp_query = """
        SELECT * FROM xp_transactions 
        WHERE character_id = $1 
        ORDER BY created_at DESC
        """
        xp_rows = await conn.fetch(xp_query, character_id)
        
        xp_transactions = [
            XPTransaction(
                id=str(xp_row['id']),
                amount=xp_row['amount'],
                transaction_type=xp_row['transaction_type'],
                reason=xp_row['reason'],
                skill_id=str(xp_row['skill_id']) if xp_row['skill_id'] else None,
                body_points=xp_row.get('body_points'),
                stamina_points=xp_row.get('stamina_points'),
                created_at=xp_row['created_at'].isoformat()
            )
            for xp_row in xp_rows
        ]
        
        return CharacterDetail(
            id=str(row['id']),
            name=row['name'],
            heritage_id=str(row['heritage_id']),
            culture_id=str(row['culture_id']),
            archetype_id=str(row['archetype_id']),
            secondary_archetype_id=str(row['secondary_archetype_id']) if row['secondary_archetype_id'] else None,
            tertiary_archetype_id=str(row['tertiary_archetype_id']) if row['tertiary_archetype_id'] else None,
            body=row['body'],
            stamina=row['stamina'],
            xp_total=row['xp_total'],
            xp_spent=row['xp_spent'],
            xp_available=row['xp_available'],
            player_notes=row['player_notes'],
            addictions_diseases=row['addictions_diseases'],
            retired=row['retired'],
            deaths=row['deaths'],
            corruption=row['corruption'],
            created_at=row['created_at'].isoformat(),
            updated_at=row['updated_at'].isoformat(),
            heritage_name=row['heritage_name'],
            culture_name=row['culture_name'],
            heritage=HeritageInfo(
                id=str(row['heritage_id']),
                name=row['heritage_name'],
                description=row['heritage_description'],
                costuming_requirements=row['heritage_costuming'],
                base_body=row['base_body'],
                base_stamina=row['base_stamina'],
                benefit=row['heritage_benefit'],
                benefit_name=row['heritage_benefit_name'] or '',
                weakness=row['heritage_weakness'],
                weakness_name=row['heritage_weakness_name'] or '',
                candle_cost=row['heritage_candle_cost']
            ),
            culture=CultureInfo(
                id=str(row['culture_id']),
                name=row['culture_name'],
                heritage_id=str(row['heritage_id']),
                description=row['culture_description'],
                costuming_requirements=row['culture_costuming'],
                benefit=row['culture_benefit'],
                benefit_name=row['culture_benefit_name'],
                candle_cost=row['culture_candle_cost']
            ),
            archetype_name=row['archetype_name'],
            secondary_archetype_name=row['secondary_archetype_name'],
            tertiary_archetype_name=row['tertiary_archetype_name'],
            skills=skills,
            events_attended=row['events_attended'],
            xp_transactions=xp_transactions
        )
        
    finally:
        await conn.close()

@router.post("/create")
async def create_character(character_data: CharacterCreate, user: AuthorizedUser) -> CharacterDetail:
    """Create a new character."""
    print(f"DEBUG: Character creation started for user {user.sub}")
    print(f"DEBUG: Character data received: {character_data.dict()}")
    
    conn = await get_database_connection()
    try:
        # Get player profile
        profile_query = "SELECT id, candles_available FROM player_profiles WHERE user_id = $1"
        profile_row = await conn.fetchrow(profile_query, user.sub)
        
        if not profile_row:
            print(f"ERROR: Player profile not found for user {user.sub}")
            raise HTTPException(status_code=400, detail="Player profile not found")
        
        player_profile_id = profile_row['id']
        current_candles = profile_row['candles_available'] or 0
        print(f"DEBUG: Found player profile ID: {player_profile_id}, Candles: {current_candles}")
        
        # Check for existing character with the same name for this player
        existing_character = await conn.fetchrow(
            "SELECT id FROM characters WHERE player_profile_id = $1 AND name = $2",
            player_profile_id, character_data.name
        )
        print(f"DEBUG: Existing character check: {existing_character}")
        
        if existing_character:
            print(f"ERROR: Duplicate character name found: {character_data.name}")
            raise HTTPException(status_code=400, detail=f"You already have a character named '{character_data.name}'. Character names must be unique for each player.")
        
        # Validate heritage, culture, archetype exist and culture belongs to heritage
        validation_query = """
        SELECT h.id as heritage_id, c.id as culture_id, a.id as archetype_id,
               h.name as heritage_name, c.name as culture_name, a.name as archetype_name,
               h.candle_cost as heritage_cost, c.candle_cost as culture_cost, a.candle_cost as archetype_cost
        FROM heritages h
        CROSS JOIN archetypes a
        LEFT JOIN cultures c ON c.heritage_id = h.id AND c.id = $2
        WHERE h.id = $1 AND a.id = $3 AND c.id IS NOT NULL
        """
        print(f"DEBUG: Validating heritage_id={character_data.heritage_id}, culture_id={character_data.culture_id}, archetype_id={character_data.archetype_id}")
        
        validation_row = await conn.fetchrow(validation_query, character_data.heritage_id, 
                                           character_data.culture_id, character_data.archetype_id)
        print(f"DEBUG: Validation result: {validation_row}")
        
        if not validation_row:
            print("ERROR: Validation failed for heritage/culture/archetype combination")
            raise HTTPException(status_code=400, detail="Invalid heritage, culture, or archetype combination")
        
        print(f"SUCCESS: Validated character setup - Heritage: {validation_row['heritage_name']}, Culture: {validation_row['culture_name']}, Archetype: {validation_row['archetype_name']}")
        
        # Calculate initial candle cost
        total_candle_cost = (
            (validation_row['heritage_cost'] or 0) + 
            (validation_row['culture_cost'] or 0) + 
            (validation_row['archetype_cost'] or 0)
        )

        # Validate secondary archetype if provided
        if character_data.secondary_archetype_id:
            secondary_archetype_query = "SELECT id, name, candle_cost FROM archetypes WHERE id = $1"
            secondary_archetype_row = await conn.fetchrow(secondary_archetype_query, character_data.secondary_archetype_id)
            
            if not secondary_archetype_row:
                print(f"ERROR: Secondary archetype not found for ID: {character_data.secondary_archetype_id}")
                raise HTTPException(status_code=400, detail="Invalid secondary archetype")
            
            # Ensure secondary archetype is different from primary
            if character_data.secondary_archetype_id == character_data.archetype_id:
                print("ERROR: Secondary archetype cannot be the same as primary archetype")
                raise HTTPException(status_code=400, detail="Secondary archetype must be different from primary archetype")
            
            total_candle_cost += (secondary_archetype_row['candle_cost'] or 0)
            print(f"SUCCESS: Validated secondary archetype - {secondary_archetype_row['name']}")
        
        # Validate tertiary archetype if provided
        if character_data.tertiary_archetype_id:
            tertiary_archetype_query = "SELECT id, name, candle_cost FROM archetypes WHERE id = $1"
            tertiary_archetype_row = await conn.fetchrow(tertiary_archetype_query, character_data.tertiary_archetype_id)
            
            if not tertiary_archetype_row:
                print(f"ERROR: Tertiary archetype not found for ID: {character_data.tertiary_archetype_id}")
                raise HTTPException(status_code=400, detail="Invalid tertiary archetype")
            
            # Ensure tertiary archetype is different from primary and secondary
            if character_data.tertiary_archetype_id == character_data.archetype_id:
                print("ERROR: Tertiary archetype cannot be the same as primary archetype")
                raise HTTPException(status_code=400, detail="Tertiary archetype must be different from primary archetype")
            
            if character_data.secondary_archetype_id and character_data.tertiary_archetype_id == character_data.secondary_archetype_id:
                print("ERROR: Tertiary archetype cannot be the same as secondary archetype")
                raise HTTPException(status_code=400, detail="Tertiary archetype must be different from secondary archetype")
            
            total_candle_cost += (tertiary_archetype_row['candle_cost'] or 0)
            print(f"SUCCESS: Validated tertiary archetype - {tertiary_archetype_row['name']}")
            
        # Check candle balance
        if total_candle_cost > current_candles:
            raise HTTPException(
                status_code=400, 
                detail=f"Insufficient candles. Cost: {total_candle_cost}, Available: {current_candles}"
            )

        # Calculate total XP cost for selected skills
        total_skill_cost = 0
        skill_costs = {}
        
        print(f"DEBUG: Starting skill cost calculation for {len(character_data.selected_skills) if character_data.selected_skills else 0} skills")
        
        if character_data.selected_skills:
            # Extract unique skill IDs from skill purchases
            skill_ids = [purchase["skill_id"] for purchase in character_data.selected_skills]
            print(f"DEBUG: Skill IDs to process: {skill_ids}")
            
            # Get skill costs based on ALL archetypes (primary, secondary, tertiary) and heritage
            skill_cost_query = """
            SELECT s.id, s.name,
                   CASE 
                       -- Check if primary skill in ANY archetype (primary, secondary, or tertiary)
                       WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN 5
                       -- Check if secondary skill in ANY archetype or heritage
                       WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
                       ELSE 20
                   END as xp_cost
            FROM skills s
            -- Primary archetype
            LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = $1
            LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = $1
            -- Secondary archetype
            LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = $2
            LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = $2
            -- Tertiary archetype
            LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = $3
            LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = $3
            -- Heritage
            LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = $4
            WHERE s.id = ANY($5)
            """
            
            print(f"DEBUG: Running skill cost query with archetype_id={character_data.archetype_id}, secondary={character_data.secondary_archetype_id}, tertiary={character_data.tertiary_archetype_id}, heritage_id={character_data.heritage_id}")
            
            # Pass all archetype IDs (use primary if secondary/tertiary are None)
            skill_rows = await conn.fetch(
                skill_cost_query, 
                character_data.archetype_id, 
                character_data.secondary_archetype_id or character_data.archetype_id,  # Fallback to primary if None
                character_data.tertiary_archetype_id or character_data.archetype_id,   # Fallback to primary if None
                character_data.heritage_id, 
                skill_ids
            )
            
            # For new character creation, only use primary archetype (no secondary/tertiary)

            print(f"DEBUG: Skill cost query returned {len(skill_rows)} results")
            
            # Calculate total cost considering quantities
            for skill_row in skill_rows:
                skill_id = str(skill_row['id'])
                xp_cost = skill_row['xp_cost']
                
                # Find total quantity for this skill across all purchases
                total_quantity = sum(purchase["quantity"] for purchase in character_data.selected_skills 
                                   if purchase["skill_id"] == skill_id)
                
                skill_costs[skill_id] = {
                    'name': skill_row['name'],
                    'cost': xp_cost,
                    'quantity': total_quantity,
                    'total_cost': xp_cost * total_quantity
                }
                total_skill_cost += xp_cost * total_quantity
                print(f"DEBUG: Skill {skill_row['name']} - Cost: {xp_cost}, Quantity: {total_quantity}, Total: {xp_cost * total_quantity}")
            
            print(f"DEBUG: Total skill cost calculated: {total_skill_cost}")
        
        # Calculate remaining XP including body and stamina costs
        starting_xp = 25
        print(f"DEBUG: Starting XP: {starting_xp}")
        
        # Get heritage base values for body/stamina cost calculation
        heritage_query = """
        SELECT base_body, base_stamina 
        FROM heritages 
        WHERE id = $1
        """
        heritage_row = await conn.fetchrow(heritage_query, character_data.heritage_id)
        if not heritage_row:
            print(f"ERROR: Heritage not found for ID: {character_data.heritage_id}")
            raise HTTPException(status_code=400, detail="Heritage not found")
        
        heritage_base_body = heritage_row['base_body']
        heritage_base_stamina = heritage_row['base_stamina']
        print(f"DEBUG: Heritage base values - Body: {heritage_base_body}, Stamina: {heritage_base_stamina}")
        print(f"DEBUG: Character desired values - Body: {character_data.body}, Stamina: {character_data.stamina}")
        
        # Calculate body and stamina costs using heritage base values
        def calculate_stat_cost(stat_value: int, base_value: int) -> int:
            """Calculate XP cost for stat increases from heritage base using total value tiers"""
            if stat_value <= base_value:
                return 0  # Can't go below heritage base
            
            # Calculate cost for each point from (base_value + 1) to stat_value
            # Each point's cost is based on its TOTAL value position in the tier system
            total_cost = 0
            for point_value in range(base_value + 1, stat_value + 1):
                if point_value <= 20:
                    total_cost += 1
                elif point_value <= 40:
                    total_cost += 2
                elif point_value <= 60:
                    total_cost += 3
                elif point_value <= 80:
                    total_cost += 4
                elif point_value <= 100:
                    total_cost += 5
                elif point_value <= 120:
                    total_cost += 6
                elif point_value <= 140:
                    total_cost += 7
                elif point_value <= 160:
                    total_cost += 8
                elif point_value <= 180:
                    total_cost += 9
                else:
                    total_cost += 10
            
            return total_cost
        
        body_cost = calculate_stat_cost(character_data.body, heritage_base_body)
        stamina_cost = calculate_stat_cost(character_data.stamina, heritage_base_stamina)
        total_stat_cost = body_cost + stamina_cost
        print(f"DEBUG: Stat costs - Body: {body_cost}, Stamina: {stamina_cost}, Total: {total_stat_cost}")
        
        total_cost = total_skill_cost + total_stat_cost
        print(f"DEBUG: Total XP cost: {total_cost} (Skills: {total_skill_cost} + Stats: {total_stat_cost}), have {starting_xp}")
        
        if total_cost > starting_xp:
            error_msg = f"Insufficient XP. Need {total_cost} XP (Skills: {total_skill_cost}, Stats: {total_stat_cost}), have {starting_xp}"
            print(f"ERROR: {error_msg}")
            raise HTTPException(status_code=400, detail=error_msg)
        
        print(f"SUCCESS: XP validation passed - using {total_cost}/{starting_xp} XP")
        
        # Create character with correct XP values
        character_query = """
        INSERT INTO characters (player_profile_id, name, heritage_id, culture_id, archetype_id, secondary_archetype_id, tertiary_archetype_id,
                              body, stamina, xp_total, xp_spent, xp_available, selected_skills, player_notes, addictions_diseases)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15)
        RETURNING id
        """
        
        # Convert selected_skills list to JSON for database storage
        try:
            selected_skills_json = json.dumps(character_data.selected_skills)
            print(f"DEBUG: JSON serialization successful, length: {len(selected_skills_json)}")
        except Exception as e:
            print(f"ERROR: JSON serialization failed: {e}")
            raise HTTPException(status_code=400, detail=f"Failed to serialize selected skills: {e}")
        
        # Calculate correct XP values
        total_earned = starting_xp  # 25 XP base
        total_spent = total_skill_cost + total_stat_cost
        available_xp = total_earned - total_spent
        print(f"DEBUG: Final XP values - Earned: {total_earned}, Spent: {total_spent}, Available: {available_xp}")
        
        print("DEBUG: Attempting to insert character into database...")
        try:
            character_row = await conn.fetchrow(
                character_query, 
                player_profile_id, 
                character_data.name,
                character_data.heritage_id, 
                character_data.culture_id, 
                character_data.archetype_id,
                character_data.secondary_archetype_id,  # NEW - $6
                character_data.tertiary_archetype_id,   # NEW - $7
                character_data.body,                     # Now $8
                character_data.stamina,                  # Now $9
                total_earned,                            # Now $10
                total_spent,                             # Now $11
                available_xp,                            # Now $12
                selected_skills_json,                    # Now $13
                character_data.player_notes,             # Now $14
                character_data.addictions_diseases       # Now $15
            )
            character_id = str(character_row['id'])
            print(f"SUCCESS: Character created with ID: {character_id}")
        except Exception as e:
            print(f"ERROR: Database insert failed: {e}")
            raise HTTPException(status_code=400, detail=f"Failed to create character: {e}")
        
        # Deduct candles if cost > 0
        if total_candle_cost > 0:
            await conn.execute(
                "UPDATE player_profiles SET candles_available = candles_available - $1 WHERE id = $2",
                total_candle_cost, player_profile_id
            )
            
            # Log transaction
            await conn.execute(
                """
                INSERT INTO candle_transactions (player_profile_id, amount, reason, used_for)
                VALUES ($1, $2, $3, $4)
                """,
                player_profile_id, 
                -total_candle_cost, 
                f"Character creation cost for {character_data.name}",
                "Character Creation"
            )

        # Record initial XP transactions
        # 1. Initial XP Grant (25 XP)
        await conn.execute(
            """
            INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
            VALUES ($1, $2, 'initial', 'Starting character XP')
            """,
            character_id, 25
        )
        
        # 2. Skill Purchase XP Transactions
        for skill_id, skill_info in skill_costs.items():
            # Create one transaction per skill purchase quantity
            for i in range(skill_info['quantity']):
                skill_xp_query = """
                INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, skill_id)
                VALUES ($1, $2, 'skill_purchase', $3, $4)
                """
                purchase_description = f"Purchased skill: {skill_info['name']}"
                if skill_info['quantity'] > 1:
                    purchase_description += f" (Purchase {i+1}/{skill_info['quantity']})"
                    
                await conn.execute(skill_xp_query, character_id, -skill_info['cost'], 
                                 purchase_description, skill_id)
        
        # 3. Body Purchase XP Transaction
        if body_cost > 0:
            body_xp_query = """
            INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points)
            VALUES ($1, $2, 'body_purchase', $3, $4)
            """
            await conn.execute(body_xp_query, character_id, -body_cost, 
                             f"Body increased to {character_data.body}", character_data.body)
        
        # 4. Stamina Purchase XP Transaction
        if stamina_cost > 0:
            stamina_xp_query = """
            INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, stamina_points)
            VALUES ($1, $2, 'stamina_purchase', $3, $4)
            """
            await conn.execute(stamina_xp_query, character_id, -stamina_cost, 
                             f"Stamina increased to {character_data.stamina}", character_data.stamina)
        
        # Return the created character
        return await get_my_character(character_id, user)
        
    finally:
        await conn.close()

@router.put("/my-characters/{character_id}")
async def update_my_character(character_id: str, character_data: CharacterUpdateRequest, user: AuthorizedUser) -> CharacterDetail:
    """Update a character."""
    conn = await get_database_connection()
    try:
        # Verify character ownership
        ownership_query = """
        SELECT c.id FROM characters c
        JOIN player_profiles pp ON pp.id = c.player_profile_id
        WHERE c.id = $1 AND pp.user_id = $2
        """
        
        ownership_row = await conn.fetchrow(ownership_query, character_id, user.sub)
        if not ownership_row:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Build dynamic update query
        update_fields = []
        values = []
        param_count = 1
        
        for field, value in character_data.model_dump(exclude_unset=True).items():
            if value is not None:
                update_fields.append(f"{field} = ${param_count}")
                values.append(value)
                param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        values.append(character_id)
        
        update_query = """
        UPDATE characters 
        SET {}
        WHERE id = ${}
        """.format(', '.join(update_fields), param_count)
        
        await conn.execute(update_query, *values)
        
        # Return updated character
        return await get_my_character(character_id, user)
        
    finally:
        await conn.close()

@router.delete("/my-characters/{character_id}")
async def delete_my_character(character_id: str, user: AuthorizedUser):
    """Delete a character."""
    conn = await get_database_connection()
    try:
        # Verify character ownership and delete
        delete_query = """
        DELETE FROM characters 
        WHERE id = $1 AND player_profile_id = (SELECT id FROM player_profiles WHERE user_id = $2)
        """
        
        result = await conn.execute(delete_query, character_id, user.sub)
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Character not found")
        
        return {"message": "Character deleted successfully"}
        
    finally:
        await conn.close()

@router.get("/my-character-names")
async def get_my_character_names(user: AuthorizedUser) -> List[str]:
    """Get list of character names for the current player."""
    conn = await get_database_connection()
    try:
        # Get player profile
        profile_query = "SELECT id FROM player_profiles WHERE user_id = $1"
        profile_row = await conn.fetchrow(profile_query, user.sub)
        
        if not profile_row:
            return []  # Return empty list if no profile found
        
        player_profile_id = profile_row['id']
        
        # Get character names
        names_query = "SELECT name FROM characters WHERE player_profile_id = $1 ORDER BY name"
        name_rows = await conn.fetch(names_query, player_profile_id)
        
        return [row['name'] for row in name_rows]
        
    finally:
        await conn.close()
