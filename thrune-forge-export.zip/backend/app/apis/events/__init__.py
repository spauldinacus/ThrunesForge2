



"""Events API for Thrune's Forge LARP Management

Provides endpoints for listing events, getting event details, and managing RSVPs.
Integrates with the chapters, events, and rsvps database tables.
"""

from datetime import datetime
from typing import Optional, List, Literal
from uuid import UUID

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
import asyncpg
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection

router = APIRouter()

# Helper function to check admin permissions
async def check_admin_permission(user: AuthorizedUser, return_bool: bool = False) -> bool:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name LIKE '%admin%'
            )
            """,
            user.sub
        )
        
        if return_bool:
            return admin_check
        
        if not admin_check:
            raise HTTPException(
                status_code=403,
                detail="Admin permissions required"
            )
        
        return True
    finally:
        await conn.close()

# Pydantic models

# Database connection helper
async def get_db_connection():
    return await get_database_connection()

class Chapter(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    chapter_code: Optional[str] = None
    location: Optional[str] = None
    contact_email: Optional[str] = None
    website: Optional[str] = None
    created_at: datetime
    member_count: int = Field(0, description="Number of players in this chapter")

class ChapterListResponse(BaseModel):
    chapters: List[Chapter]

class RSVPStatus(BaseModel):
    """RSVP status information"""
    status: Literal['going', 'maybe', 'not_attending']
    created_at: datetime
    character_id: Optional[UUID] = None
    character_name: Optional[str] = None
    notes: Optional[str] = None
    ticket_xp: int = 0
    candle_xp: int = 0
    attendance_status: Optional[str] = "rsvp"

class EventBase(BaseModel):
    """Base event information"""
    id: UUID
    chapter_id: UUID
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    starts_at: datetime
    ends_at: datetime
    status: Literal['scheduled', 'upcoming', 'completed', 'cancelled']
    created_at: datetime

class EventSummary(EventBase):
    """Event summary for list views"""
    chapter: Chapter
    my_rsvps: List[RSVPStatus] = Field(description="User's RSVPs for this event", default=[])
    rsvp_count: int = Field(description="Total number of RSVPs")

class EventDetail(EventBase):
    """Detailed event information"""
    chapter: Chapter
    my_rsvps: List[RSVPStatus] = Field(description="User's RSVPs for this event", default=[])
    rsvp_count: int = Field(description="Total number of RSVPs")

class CreateRSVPRequest(BaseModel):
    """Request to create/update an RSVP"""
    status: Literal['going', 'maybe', 'not_attending']
    character_id: Optional[UUID] = Field(None, description="Character ID for this RSVP (optional)")
    notes: Optional[str] = Field(None, description="Player notes for this RSVP")
    ticket_xp: int = Field(0, ge=0, le=2, description="XP purchased with ticket (0-2)")
    candle_xp: int = Field(0, ge=0, le=2, description="XP purchased with candles (0-2, costs 10 candles per XP)")

class RSVPResponse(BaseModel):
    """RSVP creation/update response"""
    id: UUID
    event_id: UUID
    user_id: str
    status: Literal['going', 'maybe', 'not_attending']
    character_id: Optional[UUID] = None
    character_name: Optional[str] = None
    notes: Optional[str] = None
    ticket_xp: int = 0
    candle_xp: int = 0
    created_at: datetime

class MyRSVP(BaseModel):
    """User's RSVP with event summary"""
    id: UUID
    status: Literal['going', 'maybe', 'not_attending']
    character_id: Optional[UUID] = None
    character_name: Optional[str] = None
    notes: Optional[str] = None
    ticket_xp: int = 0
    candle_xp: int = 0
    created_at: datetime
    event: EventSummary

class EventsListResponse(BaseModel):
    """Response for events list endpoint"""
    events: List[EventSummary]
    total: int

class MyRSVPsResponse(BaseModel):
    """Response for user's RSVPs endpoint"""
    rsvps: List[MyRSVP]
    total: int


# Endpoints
@router.get("/chapters")
async def list_public_chapters() -> ChapterListResponse:
    """List all chapters (public endpoint)"""
    try:
        conn = await get_database_connection()
        
        query = """
            SELECT 
                c.id::text, c.name, c.description, c.chapter_code, 
                c.location, c.contact_email, c.website, c.created_at,
                COALESCE(COUNT(DISTINCT pp.id), 0) as member_count
            FROM chapters c
            LEFT JOIN player_profiles pp ON c.id = pp.chapter_id
            GROUP BY c.id, c.name, c.description, c.chapter_code, 
                     c.location, c.contact_email, c.website, c.created_at
            ORDER BY c.name ASC
        """
        
        rows = await conn.fetch(query)
        chapters = [Chapter(**dict(row)) for row in rows]
        
        print(f"Listed {len(chapters)} public chapters")
        return ChapterListResponse(chapters=chapters)
        
    except Exception as e:
        print(f"Error listing public chapters: {e}")
        raise HTTPException(status_code=500, detail="Failed to list chapters")
    finally:
        if 'conn' in locals():
            await conn.close()

@router.get("/events", response_model=EventsListResponse)
async def list_events(
    chapter_id: Optional[UUID] = None,
    status: Optional[Literal['scheduled', 'completed', 'cancelled']] = None,
    from_date: Optional[datetime] = None,
    to_date: Optional[datetime] = None,
    user: AuthorizedUser = None
):
    """List events with optional filtering."""
    
    conn = await get_db_connection()
    try:
        # Debug logging
        print(f"User authenticated: {user.sub}")
        
        # Check if user is admin for upcoming events visibility
        is_admin = await check_admin_permission(user, return_bool=True)
            
        # Build the main query with separate subqueries to avoid cross-join issues
        base_query = f"""
            SELECT 
                e.id, e.chapter_id, e.title, e.description, e.location, 
                e.starts_at, e.ends_at, e.status, e.created_at,
                c.name as chapter_name, c.description as chapter_description,
                COALESCE(rsvp_counts.total_rsvps, 0) as rsvp_count,
                COALESCE(user_rsvps.my_rsvps, '[]'::json) as my_rsvps
            FROM public.events e
            JOIN public.chapters c ON e.chapter_id = c.id
            LEFT JOIN (
                SELECT event_id, COUNT(*) as total_rsvps
                FROM public.rsvps
                GROUP BY event_id
            ) rsvp_counts ON e.id = rsvp_counts.event_id
            LEFT JOIN (
                SELECT 
                    event_id,
                    JSON_AGG(
                        JSON_BUILD_OBJECT(
                            'id', ur.id,
                            'status', ur.status,
                            'character_id', ur.character_id,
                            'character_name', ch.name,
                            'notes', ur.notes,
                            'ticket_xp', ur.ticket_xp,
                            'candle_xp', ur.candle_xp,
                            'attendance_status', ur.attendance_status,
                            'created_at', ur.created_at
                        ) ORDER BY ur.created_at
                    ) as my_rsvps
                FROM public.rsvps ur
                LEFT JOIN public.characters ch ON ur.character_id = ch.id
                WHERE ur.user_id = '{user.sub}'
                GROUP BY event_id
            ) user_rsvps ON e.id = user_rsvps.event_id
        """
        
        # Add WHERE clauses
        conditions = []
        
        if chapter_id:
            conditions.append(f"e.chapter_id = '{chapter_id}'")
        
        if status:
            conditions.append(f"e.status = '{status}'")

        
        if from_date:
            conditions.append(f"e.starts_at >= '{from_date.isoformat()}'")
        
        if to_date:
            conditions.append(f"e.ends_at <= '{to_date.isoformat()}'")
        
        if conditions:
            base_query += " WHERE " + " AND ".join(conditions)
        
        base_query += """
            ORDER BY e.starts_at DESC
        """
        
        print(f"Executing query: {base_query}")
        rows = await conn.fetch(base_query)
        print(f"Query returned {len(rows)} rows")
        
        events = []
        for row in rows:
            try:
                print(f"Processing event: {row['title']} (ID: {row['id']})")
                print(f"  Event data: status={row.get('status')}, starts_at={row.get('starts_at')}, ends_at={row.get('ends_at')}")
                print(f"  my_rsvps raw: {row['my_rsvps']}")
                
                # Defensive programming: validate required fields before processing
                if not row.get('id'):
                    print(f"  Skipping event with missing ID: {row}")
                    continue
                    
                if not row.get('title'):
                    print(f"  Skipping event with missing title: {row.get('id')}")
                    continue
                    
                if not row.get('chapter_id') or not row.get('chapter_name'):
                    print(f"  Skipping event with missing chapter data: {row.get('id')}")
                    continue
                
                # Create chapter with defensive programming
                try:
                    chapter = Chapter(
                        id=str(row['chapter_id']),
                        name=str(row['chapter_name'] or 'Unknown Chapter'),
                        description=str(row.get('chapter_description') or ''),
                        created_at=datetime.now()  # Temporary value since it's required
                    )
                except Exception as chapter_error:
                    print(f"  Error creating chapter for event {row.get('id')}: {chapter_error}")
                    continue
                
                # Process RSVPs with comprehensive error handling
                my_rsvps = []
                try:
                    if row.get('my_rsvps'):
                        # Handle JSON array properly - check if it's a list or needs parsing
                        rsvps_data = row['my_rsvps']
                        if isinstance(rsvps_data, str):
                            # If it's a string, parse it as JSON
                            import json
                            try:
                                rsvps_data = json.loads(rsvps_data)
                            except json.JSONDecodeError as json_error:
                                print(f"  JSON decode error for RSVPs in event {row.get('id')}: {json_error}")
                                rsvps_data = []
                        
                        # Only process if we have a list and it's not empty
                        if isinstance(rsvps_data, list) and rsvps_data:
                            for i, rsvp_data in enumerate(rsvps_data):
                                try:
                                    print(f"  Processing RSVP {i+1} data: {rsvp_data}")
                                    if isinstance(rsvp_data, dict) and rsvp_data.get('id'):  # Only include actual RSVPs
                                        # Defensive programming for RSVP fields
                                        rsvp_status = RSVPStatus(
                                            status=str(rsvp_data.get('status', 'pending')),
                                            created_at=rsvp_data.get('created_at') or datetime.now().isoformat(),
                                            character_id=rsvp_data.get('character_id'),
                                            character_name=rsvp_data.get('character_name'),
                                            notes=rsvp_data.get('notes'),
                                            ticket_xp=int(rsvp_data.get('ticket_xp', 0) or 0),
                                            candle_xp=int(rsvp_data.get('candle_xp', 0) or 0),
                                            attendance_status=str(rsvp_data.get('attendance_status', 'rsvp'))
                                        )
                                        my_rsvps.append(rsvp_status)
                                except Exception as rsvp_error:
                                    print(f"  Error processing RSVP {i+1} for event {row.get('id')}: {rsvp_error}")
                                    # Continue processing other RSVPs instead of failing the entire event
                                    continue
                except Exception as rsvps_error:
                    print(f"  Error processing all RSVPs for event {row.get('id')}: {rsvps_error}")
                    # Continue with empty RSVPs list instead of failing the event
                    my_rsvps = []
                
                print(f"  Final my_rsvps count: {len(my_rsvps)}")
                
                # Create event with defensive programming and data validation
                try:
                    # Ensure required fields have valid values
                    event_id = str(row['id'])
                    chapter_id = str(row['chapter_id'])
                    title = str(row['title'])
                    description = str(row.get('description') or '')
                    location = str(row.get('location') or '')
                    status = str(row.get('status', 'scheduled'))
                    
                    # Handle datetime fields with validation
                    starts_at = row.get('starts_at')
                    ends_at = row.get('ends_at')
                    created_at = row.get('created_at')
                    
                    if not starts_at:
                        print(f"  Skipping event {event_id} with missing starts_at")
                        continue
                        
                    if not ends_at:
                        print(f"  Skipping event {event_id} with missing ends_at")
                        continue
                        
                    if not created_at:
                        created_at = datetime.now()
                    
                    # Validate RSVP count
                    rsvp_count = int(row.get('rsvp_count', 0) or 0)
                    
                    event = EventSummary(
                        id=event_id,
                        chapter_id=chapter_id,
                        title=title,
                        description=description,
                        location=location,
                        starts_at=starts_at,
                        ends_at=ends_at,
                        status=status,
                        created_at=created_at,
                        chapter=chapter,
                        my_rsvps=my_rsvps,
                        rsvp_count=rsvp_count
                    )
                    events.append(event)
                    print(f"  Successfully processed event: {title}")
                    
                except Exception as event_error:
                    print(f"  Error creating event object for {row.get('id', 'unknown')}: {event_error}")
                    print(f"  Event data: {dict(row)}")
                    # Continue processing other events instead of failing the entire request
                    continue
                    
            except Exception as row_error:
                print(f"  Critical error processing event row {row.get('id', 'unknown')}: {row_error}")
                print(f"  Row data: {dict(row)}")
                # Continue processing other events instead of failing the entire request
                continue
        
        print(f"Successfully processed {len(events)} events out of {len(rows)} total rows")
        return EventsListResponse(events=events, total=len(events))
    
    finally:
        await conn.close()


@router.get("/events/{event_id}", response_model=EventDetail)
async def get_event_detail(
    event_id: UUID,
    user: Optional[AuthorizedUser] = None
):
    """Get detailed information about a specific event."""
    
    conn = await get_db_connection()
    try:
        query = """
            SELECT 
                e.id, e.chapter_id, e.title, e.description, e.location, 
                e.starts_at, e.ends_at, e.status, e.created_at,
                c.name as chapter_name, c.description as chapter_description,
                COUNT(DISTINCT r.id) as rsvp_count
        """
        
        if user:
            query += """,
                COALESCE(
                    JSON_AGG(
                        JSON_BUILD_OBJECT(
                            'id', ur.id,
                            'status', ur.status,
                            'character_id', ur.character_id,
                            'character_name', ch.name,
                            'notes', ur.notes,
                            'ticket_xp', ur.ticket_xp,
                            'candle_xp', ur.candle_xp,
                            'attendance_status', ur.attendance_status,
                            'created_at', ur.created_at
                        ) ORDER BY ur.created_at
                    ) FILTER (WHERE ur.id IS NOT NULL),
                    '[]'::json
                ) as my_rsvps
            """
        
        query += """
            FROM public.events e
            JOIN public.chapters c ON e.chapter_id = c.id
            LEFT JOIN public.rsvps r ON e.id = r.event_id
        """
        
        if user:
            query += f"""
                LEFT JOIN public.rsvps ur ON e.id = ur.event_id AND ur.user_id = '{user.sub}'
                LEFT JOIN public.characters ch ON ur.character_id = ch.id
            """
        
        query += f"""
            WHERE e.id = '{event_id}'
            GROUP BY e.id, e.chapter_id, e.title, e.description, e.location, 
                     e.starts_at, e.ends_at, e.status, e.created_at,
                     c.name, c.description
        """
        
        row = await conn.fetchrow(query)
        
        if not row:
            raise HTTPException(status_code=404, detail="Event not found")
        
        chapter = Chapter(
            id=row['chapter_id'],
            name=row['chapter_name'],
            description=row['chapter_description']
        )
        
        my_rsvps = []
        if user and row.get('my_rsvps'):
            for rsvp_data in row['my_rsvps']:
                if rsvp_data.get('id'):  # Only include actual RSVPs
                    my_rsvps.append(RSVPStatus(
                        status=rsvp_data['status'],
                        created_at=rsvp_data['created_at'],
                        character_id=rsvp_data.get('character_id'),
                        character_name=rsvp_data.get('character_name'),
                        notes=rsvp_data.get('notes'),
                        ticket_xp=rsvp_data.get('ticket_xp', 0),
                        candle_xp=rsvp_data.get('candle_xp', 0),
                        attendance_status=rsvp_data.get('attendance_status', 'rsvp')
                    ))
        
        return EventDetail(
            id=row['id'],
            chapter_id=row['chapter_id'],
            title=row['title'],
            description=row['description'],
            location=row['location'],
            starts_at=row['starts_at'],
            ends_at=row['ends_at'],
            status=row['status'],
            created_at=row['created_at'],
            chapter=chapter,
            my_rsvps=my_rsvps,
            rsvp_count=row['rsvp_count']
        )
    
    finally:
        await conn.close()


@router.post("/events/{event_id}/rsvp", response_model=RSVPResponse)
async def create_or_update_rsvp(
    event_id: UUID,
    rsvp_data: CreateRSVPRequest,
    user: AuthorizedUser
):
    """Create or update user's RSVP for an event with enhanced features."""
    
    conn = await get_db_connection()
    try:
        # Start transaction
        async with conn.transaction():
            # Verify the event exists
            event_check = await conn.fetchrow(
                "SELECT id FROM public.events WHERE id = $1",
                event_id
            )
            
            if not event_check:
                raise HTTPException(status_code=404, detail="Event not found")
            
            # Get player profile for candle transactions
            player_profile = await conn.fetchrow(
                "SELECT id, candles_available FROM public.player_profiles WHERE user_id = $1",
                user.sub
            )
            
            if not player_profile:
                raise HTTPException(status_code=400, detail="Player profile not found")
            
            # Verify character belongs to user if character_id provided
            character_name = None
            if rsvp_data.character_id:
                character_check = await conn.fetchrow(
                    """
                    SELECT c.name FROM public.characters c
                    JOIN public.player_profiles pp ON c.player_profile_id = pp.id
                    WHERE c.id = $1 AND pp.user_id = $2
                    """,
                    rsvp_data.character_id, user.sub
                )
                
                if not character_check:
                    raise HTTPException(status_code=400, detail="Character not found or does not belong to user")
                
                character_name = character_check['name']
            
            # Check for existing RSVP
            existing_rsvp = None
            previous_candle_xp = 0  # Track previous candle XP for proper charging
            if rsvp_data.character_id:
                # Check for existing character RSVP
                existing_rsvp = await conn.fetchrow(
                    "SELECT id, candle_xp FROM public.rsvps WHERE event_id = $1 AND character_id = $2",
                    event_id, rsvp_data.character_id
                )
                
                if existing_rsvp:
                    previous_candle_xp = existing_rsvp['candle_xp']
            else:
                # Check for existing user-only RSVP
                existing_rsvp = await conn.fetchrow(
                    "SELECT id, candle_xp FROM public.rsvps WHERE event_id = $1 AND user_id = $2 AND character_id IS NULL",
                    event_id, user.sub
                )
                
                if existing_rsvp:
                    previous_candle_xp = existing_rsvp['candle_xp']
            
            # Calculate candle cost difference (only charge/refund the difference)
            candle_cost_difference = (rsvp_data.candle_xp - previous_candle_xp) * 10
            
            # Insert or update RSVP
            if existing_rsvp:
                # Update existing RSVP
                rsvp_row = await conn.fetchrow(
                    """
                    UPDATE public.rsvps 
                    SET status = $2, notes = $3, ticket_xp = $4, candle_xp = $5
                    WHERE id = $1
                    RETURNING id, event_id, user_id, status, character_id, notes, ticket_xp, candle_xp, attendance_status, created_at
                    """,
                    existing_rsvp['id'], rsvp_data.status, rsvp_data.notes, 
                    rsvp_data.ticket_xp, rsvp_data.candle_xp
                )
            else:
                # Create new RSVP
                rsvp_row = await conn.fetchrow(
                    """
                    INSERT INTO public.rsvps (event_id, user_id, character_id, status, notes, ticket_xp, candle_xp, attendance_status)
                    VALUES ($1, $2, $3, $4, $5, $6, $7, 'rsvp')
                    RETURNING id, event_id, user_id, status, character_id, notes, ticket_xp, candle_xp, attendance_status, created_at
                    """,
                    event_id, user.sub, rsvp_data.character_id, rsvp_data.status, 
                    rsvp_data.notes, rsvp_data.ticket_xp, rsvp_data.candle_xp
                )
            
            # Handle candle transactions based on the difference
            if candle_cost_difference != 0:
                # Update player's candle balance
                await conn.execute(
                    "UPDATE public.player_profiles SET candles_available = candles_available - $1 WHERE id = $2",
                    candle_cost_difference, player_profile['id']
                )
                
                # Log candle transaction
                if candle_cost_difference > 0:
                    # Player is purchasing more XP
                    reason = f"XP purchase increase for event RSVP ({rsvp_data.candle_xp - previous_candle_xp} additional XP)"
                    used_for = "Event RSVP XP increase"
                elif candle_cost_difference < 0:
                    # Player is reducing XP purchase (refund)
                    reason = f"XP purchase refund for event RSVP ({previous_candle_xp - rsvp_data.candle_xp} XP refunded)"
                    used_for = "Event RSVP XP refund"
                
                await conn.execute(
                    """
                    INSERT INTO public.candle_transactions (player_profile_id, amount, reason, used_for)
                    VALUES ($1, $2, $3, $4)
                    """,
                    player_profile['id'], -candle_cost_difference, reason, used_for
                )
            
            return RSVPResponse(
                id=rsvp_row['id'],
                event_id=rsvp_row['event_id'],
                user_id=rsvp_row['user_id'],
                status=rsvp_row['status'],
                character_id=rsvp_row['character_id'],
                character_name=character_name,
                notes=rsvp_row['notes'],
                ticket_xp=rsvp_row['ticket_xp'],
                candle_xp=rsvp_row['candle_xp'],
                created_at=rsvp_row['created_at']
            )
    
    finally:
        await conn.close()


@router.get("/my/rsvps", response_model=MyRSVPsResponse)
async def get_my_rsvps(user: AuthorizedUser):
    """Get all of the current user's RSVPs with event details."""
    
    conn = await get_db_connection()
    try:
        query = """
            SELECT 
                r.id, r.status, r.character_id, r.notes, r.ticket_xp, r.candle_xp, r.created_at,
                c.name as character_name,
                e.id as event_id, e.chapter_id, e.title, e.description, e.location,
                e.starts_at, e.ends_at, e.status as event_status, e.created_at as event_created_at,
                ch.name as chapter_name, ch.description as chapter_description,
                COUNT(re.id) as rsvp_count
            FROM public.rsvps r
            JOIN public.events e ON r.event_id = e.id
            JOIN public.chapters ch ON e.chapter_id = ch.id
            LEFT JOIN public.characters c ON r.character_id = c.id
            LEFT JOIN public.rsvps re ON e.id = re.event_id
            WHERE r.user_id = $1
            GROUP BY r.id, r.status, r.character_id, r.notes, r.ticket_xp, r.candle_xp, r.created_at,
                     c.name,
                     e.id, e.chapter_id, e.title, e.description, e.location,
                     e.starts_at, e.ends_at, e.status, e.created_at,
                     ch.name, ch.description
            ORDER BY e.starts_at ASC
        """
        
        rows = await conn.fetch(query, user.sub)
        
        rsvps = []
        for row in rows:
            chapter = Chapter(
                id=row['chapter_id'],
                name=row['chapter_name'],
                description=row['chapter_description']
            )
            
            event = EventSummary(
                id=row['event_id'],
                chapter_id=row['chapter_id'],
                title=row['title'],
                description=row['description'],
                location=row['location'],
                starts_at=row['starts_at'],
                ends_at=row['ends_at'],
                status=row['event_status'],
                created_at=row['event_created_at'],
                chapter=chapter,
                my_rsvps=[],  # Don't include nested RSVPs
                rsvp_count=row['rsvp_count']
            )
            
            rsvp = MyRSVP(
                id=row['id'],
                status=row['status'],
                character_id=row['character_id'],
                character_name=row['character_name'],
                notes=row['notes'],
                ticket_xp=row['ticket_xp'],
                candle_xp=row['candle_xp'],
                created_at=row['created_at'],
                event=event
            )
            rsvps.append(rsvp)
        
        return MyRSVPsResponse(rsvps=rsvps, total=len(rsvps))
    
    finally:
        await conn.close()
