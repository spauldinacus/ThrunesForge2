from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import asyncpg
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from uuid import UUID

router = APIRouter(prefix="/archetypes")

# Pydantic Models
class ArchetypeCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1)
    primary_skill_ids: List[str] = Field(default=[], description="List of primary skill UUIDs")
    secondary_skill_ids: List[str] = Field(default=[], description="List of secondary skill UUIDs")
    candle_cost: int = 0    

class ArchetypeUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    primary_skill_ids: Optional[List[str]] = None
    secondary_skill_ids: Optional[List[str]] = None
    candle_cost: Optional[int] = None    

class SkillSummary(BaseModel):
    id: str
    name: str
    description: str

class ArchetypeResponse(BaseModel):
    id: str
    name: str
    description: str
    primary_skills: List[SkillSummary] = Field(default=[])
    secondary_skills: List[SkillSummary] = Field(default=[])
    created_at: str
    candle_cost: int = 0    

# Helper function to check admin permissions
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_archetypes', 'view_admin_panel')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

@router.get("/", response_model=List[ArchetypeResponse])
async def list_archetypes():
    """List all archetypes with their associated skills"""
    conn = await get_database_connection()
    try:
        # Get all archetypes
        archetypes = await conn.fetch(
            "SELECT id, name, description, created_at, candle_cost FROM archetypes ORDER BY name"
        )
        
        result = []
        for archetype in archetypes:
            # Get primary skills
            primary_skills_rows = await conn.fetch(
                """
                SELECT s.id, s.name, s.description 
                FROM skills s
                JOIN archetype_primary_skills aps ON s.id = aps.skill_id::uuid
                WHERE aps.archetype_id = $1
                ORDER BY s.name
                """,
                str(archetype['id'])
            )
            
            # Get secondary skills
            secondary_skills_rows = await conn.fetch(
                """
                SELECT s.id, s.name, s.description 
                FROM skills s
                JOIN archetype_secondary_skills ass ON s.id = ass.skill_id::uuid
                WHERE ass.archetype_id = $1
                ORDER BY s.name
                """,
                str(archetype['id'])
            )
            
            primary_skills = [
                SkillSummary(
                    id=str(row['id']),
                    name=row['name'],
                    description=row['description']
                )
                for row in primary_skills_rows
            ]
            
            secondary_skills = [
                SkillSummary(
                    id=str(row['id']),
                    name=row['name'],
                    description=row['description']
                )
                for row in secondary_skills_rows
            ]
            
            result.append(ArchetypeResponse(
                id=str(archetype['id']),
                name=archetype['name'],
                description=archetype['description'],
                primary_skills=primary_skills,
                secondary_skills=secondary_skills,
                created_at=archetype['created_at'].isoformat(),
                candle_cost=archetype['candle_cost']
            ))
        
        return result
        
    finally:
        await conn.close()

@router.post("/", response_model=ArchetypeResponse)
async def create_archetype(archetype: ArchetypeCreate, user: AuthorizedUser):
    """Create a new archetype (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Validate that all skill IDs exist
        all_skill_ids = archetype.primary_skill_ids + archetype.secondary_skill_ids
        if all_skill_ids:
            skill_count = await conn.fetchval(
                "SELECT COUNT(*) FROM skills WHERE id = ANY($1::uuid[])",
                all_skill_ids
            )
            if skill_count != len(set(all_skill_ids)):  # Use set to handle duplicates
                raise HTTPException(status_code=400, detail="One or more skill IDs are invalid")
        
        # Insert archetype
        archetype_row = await conn.fetchrow(
            """
            INSERT INTO archetypes (name, description, candle_cost)
            VALUES ($1, $2, $3)
            RETURNING id, name, description, created_at, candle_cost
            """,
            archetype.name,
            archetype.description,
            archetype.candle_cost
        )
        
        archetype_id = str(archetype_row['id'])
        
        # Insert primary skills associations
        if archetype.primary_skill_ids:
            for skill_id in archetype.primary_skill_ids:
                await conn.execute(
                    "INSERT INTO archetype_primary_skills (archetype_id, skill_id) VALUES ($1, $2)",
                    archetype_id, skill_id
                )
        
        # Insert secondary skills associations
        if archetype.secondary_skill_ids:
            for skill_id in archetype.secondary_skill_ids:
                await conn.execute(
                    "INSERT INTO archetype_secondary_skills (archetype_id, skill_id) VALUES ($1, $2)",
                    archetype_id, skill_id
                )
        
        # Return full archetype with skills
        # Log creation
        await log_admin_action(
            user.sub, "archetype", "create", archetype_id, "archetype",
            {"name": archetype.name}
        )
        return await get_archetype_by_id(archetype_id, conn)
        
    finally:
        await conn.close()

@router.get("/{archetype_id}", response_model=ArchetypeResponse)
async def get_archetype(archetype_id: str):
    """Get a specific archetype by ID"""
    conn = await get_database_connection()
    try:
        return await get_archetype_by_id(archetype_id, conn)
    finally:
        await conn.close()

@router.put("/{archetype_id}", response_model=ArchetypeResponse)
async def update_archetype(archetype_id: str, archetype: ArchetypeUpdate, user: AuthorizedUser):
    """Update an archetype (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if archetype exists
        existing = await conn.fetchrow(
            "SELECT id FROM archetypes WHERE id = $1",
            UUID(archetype_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Archetype not found")
        
        # Update basic fields if provided
        if archetype.name is not None or archetype.description is not None:
            update_fields = []
            update_values = []
            
            if archetype.name is not None:
                update_fields.append("name = $" + str(len(update_values) + 1))
                update_values.append(archetype.name)
            
            if archetype.description is not None:
                update_fields.append("description = $" + str(len(update_values) + 1))
                update_values.append(archetype.description)
            
            if archetype.candle_cost is not None:
                update_fields.append("candle_cost = $" + str(len(update_values) + 1))
                update_values.append(archetype.candle_cost)
            
            update_values.append(UUID(archetype_id))
            
            await conn.execute(
                f"UPDATE archetypes SET {', '.join(update_fields)} WHERE id = ${len(update_values)}",
                *update_values
            )
        
        # Update skill associations if provided
        if archetype.primary_skill_ids is not None:
            # Validate skill IDs
            if archetype.primary_skill_ids:
                skill_count = await conn.fetchval(
                    "SELECT COUNT(*) FROM skills WHERE id = ANY($1::uuid[])",
                    archetype.primary_skill_ids
                )
                if skill_count != len(set(archetype.primary_skill_ids)):
                    raise HTTPException(status_code=400, detail="One or more primary skill IDs are invalid")
            
            # Remove existing primary skills
            await conn.execute(
                "DELETE FROM archetype_primary_skills WHERE archetype_id = $1",
                archetype_id
            )
            
            # Add new primary skills
            for skill_id in archetype.primary_skill_ids:
                await conn.execute(
                    "INSERT INTO archetype_primary_skills (archetype_id, skill_id) VALUES ($1, $2)",
                    archetype_id, skill_id
                )
        
        if archetype.secondary_skill_ids is not None:
            # Validate skill IDs
            if archetype.secondary_skill_ids:
                skill_count = await conn.fetchval(
                    "SELECT COUNT(*) FROM skills WHERE id = ANY($1::uuid[])",
                    archetype.secondary_skill_ids
                )
                if skill_count != len(set(archetype.secondary_skill_ids)):
                    raise HTTPException(status_code=400, detail="One or more secondary skill IDs are invalid")
            
            # Remove existing secondary skills
            await conn.execute(
                "DELETE FROM archetype_secondary_skills WHERE archetype_id = $1",
                archetype_id
            )
            
            # Add new secondary skills
            for skill_id in archetype.secondary_skill_ids:
                await conn.execute(
                    "INSERT INTO archetype_secondary_skills (archetype_id, skill_id) VALUES ($1, $2)",
                    archetype_id, skill_id
                )
        
        # Return updated archetype
        # Log update
        await log_admin_action(
            user.sub, "archetype", "update", archetype_id, "archetype",
            {"updated_fields": [k for k, v in archetype.dict(exclude_unset=True).items()]}
        )
        return await get_archetype_by_id(archetype_id, conn)
        
    finally:
        await conn.close()

@router.delete("/{archetype_id}")
async def delete_archetype(archetype_id: str, user: AuthorizedUser):
    """Delete an archetype (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if archetype exists
        existing = await conn.fetchrow(
            "SELECT id FROM archetypes WHERE id = $1",
            UUID(archetype_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Archetype not found")
        
        # Delete skill associations first (foreign key constraints)
        await conn.execute(
            "DELETE FROM archetype_primary_skills WHERE archetype_id = $1",
            archetype_id
        )
        await conn.execute(
            "DELETE FROM archetype_secondary_skills WHERE archetype_id = $1",
            archetype_id
        )
        
        # Delete the archetype
        await conn.execute(
            "DELETE FROM archetypes WHERE id = $1",
            UUID(archetype_id)
        )

        await log_admin_action(
            user.sub, "archetype", "delete", archetype_id, "archetype", {}
        )
        
        return {"message": "Archetype deleted successfully"}
        
    finally:
        await conn.close()

# Helper function to get archetype with skills
async def get_archetype_by_id(archetype_id: str, conn) -> ArchetypeResponse:
    """Get archetype by ID with all associated skills"""
    # Get archetype basic info
    archetype = await conn.fetchrow(
        "SELECT id, name, description, created_at, candle_cost FROM archetypes WHERE id = $1",
        UUID(archetype_id)
    )
    
    if not archetype:
        raise HTTPException(status_code=404, detail="Archetype not found")
    
    # Get primary skills
    primary_skills_rows = await conn.fetch(
        """
        SELECT s.id, s.name, s.description 
        FROM skills s
        JOIN archetype_primary_skills aps ON s.id = aps.skill_id::uuid
        WHERE aps.archetype_id = $1
        ORDER BY s.name
        """,
        archetype_id
    )
    
    # Get secondary skills
    secondary_skills_rows = await conn.fetch(
        """
        SELECT s.id, s.name, s.description 
        FROM skills s
        JOIN archetype_secondary_skills ass ON s.id = ass.skill_id::uuid
        WHERE ass.archetype_id = $1
        ORDER BY s.name
        """,
        archetype_id
    )
    
    primary_skills = [
        SkillSummary(
            id=str(row['id']),
            name=row['name'],
            description=row['description']
        )
        for row in primary_skills_rows
    ]
    
    secondary_skills = [
        SkillSummary(
            id=str(row['id']),
            name=row['name'],
            description=row['description']
        )
        for row in secondary_skills_rows
    ]
    
    return ArchetypeResponse(
        id=str(archetype['id']),
        name=archetype['name'],
        description=archetype['description'],
        primary_skills=primary_skills,
        secondary_skills=secondary_skills,
        created_at=archetype['created_at'].isoformat(),
        candle_cost=archetype['candle_cost']
    )
