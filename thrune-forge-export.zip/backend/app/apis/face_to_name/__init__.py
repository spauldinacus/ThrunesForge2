from fastapi import APIRouter
from pydantic import BaseModel
from typing import List
from uuid import UUID
from app.libs.database import get_database_connection
from app.auth import AuthorizedUser
from app.libs.permissions import get_user_chapters_with_permission

router = APIRouter()

# PYDANTIC MODELS SECTION (Lines 9-29)
class CharacterListItem(BaseModel):
    character_id: str
    character_name: str
    heritage_name: str
    culture_name: str
    player_name: str
    chapter_name: str
    photo_count: int

class CharacterPhoto(BaseModel):
    tag_id: str
    photo_id: str
    photo_url: str
    thumbnail_url: str | None
    tagged_at: str
    x_position: float
    y_position: float
    player_profile_id: str  # Added for permission checking

# ENDPOINT 1: List all characters (Lines 31-75)
@router.get("/characters", response_model=List[CharacterListItem])
async def list_all_characters_with_photos(user: AuthorizedUser):
    """Get all characters with heritage, culture, player, chapter, and photo count"""
    
    # Check permission and get allowed chapters (using manage_characters or manage_photo_galleries as proxy for access)
    permitted_chapters = await get_user_chapters_with_permission(user.sub, "manage_characters")
    
    # If permitted_chapters is empty list (not None), user has no access
    if permitted_chapters == []:
        return []

    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                c.id as character_id,
                c.name as character_name,
                h.name as heritage_name,
                cu.name as culture_name,
                pp.first_name || ' ' || pp.last_name as player_name,
                ch.name as chapter_name,
                COUNT(DISTINCT gp.photo_id) as photo_count
            FROM public.characters c
            JOIN public.heritages h ON c.heritage_id = h.id
            JOIN public.cultures cu ON c.culture_id = cu.id
            JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            JOIN public.chapters ch ON pp.chapter_id = ch.id
            LEFT JOIN public.photo_tags pt ON c.id = pt.character_id
            LEFT JOIN public.gallery_photos gp ON pt.photo_id = gp.photo_id
            WHERE c.retired = false
        """
        
        args = []
        if permitted_chapters != [None]:
            query += " AND pp.chapter_id = ANY($1::uuid[])"
            args.append(permitted_chapters)
            
        query += """
            GROUP BY c.id, c.name, h.name, cu.name, pp.first_name, pp.last_name, ch.name
            ORDER BY c.name
        """

        characters_data = await conn.fetch(query, *args)
        
        return [
            CharacterListItem(
                character_id=str(row['character_id']),
                character_name=row['character_name'],
                heritage_name=row['heritage_name'],
                culture_name=row['culture_name'],
                player_name=row['player_name'],
                chapter_name=row['chapter_name'],
                photo_count=row['photo_count']
            )
            for row in characters_data
        ]
    finally:
        await conn.close()

# ENDPOINT 2: Get character photos (Lines 77-140)
@router.get("/characters/{character_id}/photos", response_model=List[CharacterPhoto])
async def get_character_photos(character_id: str, user: AuthorizedUser):
    """Get all photos where a character is tagged"""
    conn = await get_database_connection()
    try:
        character_uuid = UUID(character_id)
        
        photos_data = await conn.fetch(
            """
            SELECT DISTINCT
                pt.id as tag_id,
                gp.photo_id,
                gp.photo_url,
                gp.thumbnail_url,
                pt.created_at as tagged_at,
                pt.x_position,
                pt.y_position,
                c.player_profile_id
            FROM public.photo_tags pt
            JOIN public.gallery_photos gp ON pt.photo_id = gp.photo_id
            JOIN public.characters c ON pt.character_id = c.id
            WHERE pt.character_id = $1
            ORDER BY pt.created_at DESC
            """,
            character_uuid
        )
        
        return [
            CharacterPhoto(
                tag_id=str(row['tag_id']),
                photo_id=row['photo_id'],
                photo_url=row['photo_url'],
                thumbnail_url=row['thumbnail_url'],
                tagged_at=row['tagged_at'].isoformat(),
                x_position=float(row['x_position']),
                y_position=float(row['y_position']),
                player_profile_id=str(row['player_profile_id'])
            )
            for row in photos_data
        ]
    finally:
        await conn.close()
