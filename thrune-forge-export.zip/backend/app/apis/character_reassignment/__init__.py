from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from app.libs.permissions import get_user_chapters_with_permission

router = APIRouter(prefix="/character-reassignment")

# Helper function to check character_reassignment permission
async def check_reassignment_permission(user: AuthorizedUser) -> None:
    """Check if user has character_reassignment permission"""
    conn = await get_database_connection()
    try:
        # Check if user has character_reassignment permission through their roles
        has_permission = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name = 'character_reassignment'
            )
            """,
            user.sub
        )
        
        if not has_permission:
            raise HTTPException(
                status_code=403, 
                detail="Character reassignment permission required"
            )
    finally:
        await conn.close()

# Pydantic models
class CharacterSummary(BaseModel):
    id: str
    name: str
    heritage_name: str
    culture_name: str
    archetype_name: str
    player_id: str | None
    player_name: str | None

class PlayerSummary(BaseModel):
    id: str
    name: str
    player_number: str

class ReassignmentRequest(BaseModel):
    character_id: str
    to_player_id: str
    notes: Optional[str] = None

class ReassignmentHistoryRecord(BaseModel):
    id: str
    character_id: str
    from_player_name: str | None
    to_player_name: str
    reassigned_by_name: str
    notes: str | None
    reassigned_at: str

@router.get("/characters", response_model=List[CharacterSummary])
async def list_all_characters_for_reassignment(user: AuthorizedUser):
    """List all characters with heritage, culture, archetype, and current player assignment"""
    # Check permission and get allowed chapters
    permitted_chapters = await get_user_chapters_with_permission(user.sub, "character_reassignment")
    
    # If permitted_chapters is empty list (not None), user has no access
    if permitted_chapters == []:
        return []
    
    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                c.id,
                c.name,
                h.name as heritage_name,
                cu.name as culture_name,
                a.name as archetype_name,
                pp.id as player_id,
                CONCAT(pp.first_name, ' ', pp.last_name) as player_name
            FROM characters c
            JOIN heritages h ON c.heritage_id = h.id
            JOIN cultures cu ON c.culture_id = cu.id
            JOIN archetypes a ON c.archetype_id = a.id
            LEFT JOIN player_profiles pp ON c.player_profile_id = pp.id
            WHERE c.retired = false
        """
        
        args = []
        if permitted_chapters != [None]:
            # Filter by player's chapter
            query += " AND pp.chapter_id = ANY($1::uuid[])"
            args.append(permitted_chapters)
            
        query += " ORDER BY c.name ASC"

        characters = await conn.fetch(query, *args)
        
        return [
            CharacterSummary(
                id=str(char["id"]),
                name=char["name"],
                heritage_name=char["heritage_name"],
                culture_name=char["culture_name"],
                archetype_name=char["archetype_name"],
                player_id=str(char["player_id"]) if char["player_id"] else None,
                player_name=char["player_name"]
            )
            for char in characters
        ]
    finally:
        await conn.close()

@router.get("/players-by-chapter/{chapter_id}", response_model=List[PlayerSummary])
async def get_players_by_chapter(chapter_id: str, user: AuthorizedUser):
    """Get all players filtered by chapter"""
    await check_reassignment_permission(user)
    
    conn = await get_database_connection()
    try:
        players = await conn.fetch(
            """
            SELECT 
                id,
                CONCAT(first_name, ' ', last_name) as name,
                player_number
            FROM player_profiles
            WHERE chapter_id = $1
            ORDER BY first_name, last_name
            """,
            UUID(chapter_id)
        )
        
        return [
            PlayerSummary(
                id=str(player["id"]),
                name=player["name"],
                player_number=player["player_number"]
            )
            for player in players
        ]
    finally:
        await conn.close()

@router.post("/reassign")
async def reassign_character(request: ReassignmentRequest, user: AuthorizedUser):
    """Reassign a character to a different player"""
    await check_reassignment_permission(user)
    
    conn = await get_database_connection()
    try:
        # Get current character data
        character = await conn.fetchrow(
            """
            SELECT c.id, c.name, c.player_profile_id,
                   CONCAT(pp.first_name, ' ', pp.last_name) as current_player_name
            FROM characters c
            LEFT JOIN player_profiles pp ON c.player_profile_id = pp.id
            WHERE c.id = $1
            """,
            UUID(request.character_id)
        )
        
        if not character:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Verify target player exists
        target_player = await conn.fetchrow(
            "SELECT id, CONCAT(first_name, ' ', last_name) as name FROM player_profiles WHERE id = $1",
            UUID(request.to_player_id)
        )
        
        if not target_player:
            raise HTTPException(status_code=404, detail="Target player not found")
        
        # Don't allow reassigning to the same player
        if character["player_profile_id"] and str(character["player_profile_id"]) == request.to_player_id:
            raise HTTPException(
                status_code=400, 
                detail="Character is already assigned to this player"
            )
        
        # Create reassignment history record
        await conn.execute(
            """
            INSERT INTO character_reassignment_history 
                (character_id, from_player_id, to_player_id, reassigned_by, notes)
            VALUES ($1, $2, $3, $4, $5)
            """,
            UUID(request.character_id),
            character["player_profile_id"],  # Can be None for initial assignment
            UUID(request.to_player_id),
            user.sub,
            request.notes
        )
        
        # Update character's player
        await conn.execute(
            "UPDATE characters SET player_profile_id = $1, updated_at = NOW() WHERE id = $2",
            UUID(request.to_player_id),
            UUID(request.character_id)
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="character",
            action="reassign",
            entity_id=request.character_id,
            entity_type="character",
            details={
                "from_player_id": str(character["player_profile_id"]) if character["player_profile_id"] else None,
                "to_player_id": request.to_player_id,
                "notes": request.notes
            }
        )        
        return {
            "success": True,
            "message": f"Character '{character['name']}' reassigned from {character['current_player_name'] or 'no player'} to {target_player['name']}"
        }
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error reassigning character: {e}")
        raise HTTPException(status_code=500, detail="Failed to reassign character")
    finally:
        await conn.close()

@router.get("/history/{character_id}", response_model=List[ReassignmentHistoryRecord])
async def get_reassignment_history(character_id: str, user: AuthorizedUser):
    """Get reassignment history for a character"""
    await check_reassignment_permission(user)
    
    conn = await get_database_connection()
    try:
        history = await conn.fetch(
            """
            SELECT 
                crh.id,
                crh.character_id,
                CONCAT(from_pp.first_name, ' ', from_pp.last_name) as from_player_name,
                CONCAT(to_pp.first_name, ' ', to_pp.last_name) as to_player_name,
                CONCAT(admin_pp.first_name, ' ', admin_pp.last_name) as reassigned_by_name,
                crh.notes,
                crh.reassigned_at
            FROM character_reassignment_history crh
            LEFT JOIN player_profiles from_pp ON crh.from_player_id = from_pp.id
            JOIN player_profiles to_pp ON crh.to_player_id = to_pp.id
            LEFT JOIN player_profiles admin_pp ON crh.reassigned_by = admin_pp.user_id
            WHERE crh.character_id = $1
            ORDER BY crh.reassigned_at DESC
            """,
            UUID(character_id)
        )
        
        return [
            ReassignmentHistoryRecord(
                id=str(record["id"]),
                character_id=str(record["character_id"]),
                from_player_name=record["from_player_name"],
                to_player_name=record["to_player_name"],
                reassigned_by_name=record["reassigned_by_name"] or "Unknown Admin",
                notes=record["notes"],
                reassigned_at=record["reassigned_at"].isoformat()
            )
            for record in history
        ]
    finally:
        await conn.close()
