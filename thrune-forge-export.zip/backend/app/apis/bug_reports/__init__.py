import os
import resend
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, EmailStr
from datetime import datetime, timedelta
from collections import defaultdict

router = APIRouter()

# Rate limiting: track submissions by email
rate_limit_store: dict[str, list[datetime]] = defaultdict(list)
RATE_LIMIT_WINDOW = timedelta(hours=1)
RATE_LIMIT_MAX = 3

class ConsoleError(BaseModel):
    message: str
    type: str
    timestamp: str
    stack: str | None = None

class BugReportRequest(BaseModel):
    email: EmailStr
    description: str
    page_url: str | None = None
    player_name: str | None = None
    console_errors: list[ConsoleError] | None = None

@router.post("/submit")
async def submit_bug_report(report: BugReportRequest):
    """
    Submit a bug report via email.
    Rate limited to 3 submissions per hour per email address.
    """
    # Rate limiting check
    now = datetime.now()
    email_lower = report.email.lower()
    
    # Clean old timestamps
    rate_limit_store[email_lower] = [
        ts for ts in rate_limit_store[email_lower]
        if now - ts < RATE_LIMIT_WINDOW
    ]
    
    # Check if rate limit exceeded
    if len(rate_limit_store[email_lower]) >= RATE_LIMIT_MAX:
        raise HTTPException(
            status_code=429,
            detail="Rate limit exceeded. Please wait before submitting another report."
        )
    
    # Get Resend API key
    api_key = os.environ.get("RESEND_API_KEY")
    if not api_key:
        raise HTTPException(status_code=500, detail="Email service not configured")
    
    resend.api_key = api_key
    
    # Format console errors
    errors_text = "\nNo console errors captured."
    if report.console_errors and len(report.console_errors) > 0:
        errors_text = f"\n\nConsole Errors ({len(report.console_errors)} total):\n"
        for i, error in enumerate(report.console_errors[-10:], 1):  # Last 10 errors
            errors_text += f"\n{i}. [{error.type.upper()}] {error.message}"
            if error.timestamp:
                errors_text += f"\n   Time: {error.timestamp}"
            if error.stack:
                errors_text += f"\n   Stack: {error.stack[:200]}..."  # Truncate long stacks
            errors_text += "\n"
    
    # Prepare email content
    email_body = f"""Bug Report Submission

From: {report.email}
Player Name: {report.player_name or 'Anonymous'}
Page: {report.page_url or 'Not provided'}

Description:
{report.description}
{errors_text}

Submitted at: {now.isoformat()}
"""

    try:
        # Send email via Resend
        resend.Emails.send({
            "from": "onboarding@resend.dev",
            "to": "jamescspaulding@gmail.com",
            "subject": f"Bug Report from {report.email}",
            "text": email_body,
        })
        
        # Record successful submission
        rate_limit_store[email_lower].append(now)
        
        return {"success": True, "message": "Bug report submitted successfully"}
    
    except Exception as e:
        print(f"Failed to send bug report email: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail="Failed to send bug report. Please try again later."
        )
