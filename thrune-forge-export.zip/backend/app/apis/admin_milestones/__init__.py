from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID

from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/admin-milestones")

# Permission checking helper
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has permission to view shared milestones"""
    conn = await get_database_connection()
    try:
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name = 'view_shared_milestones'
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

# Pydantic Models

class SharedMilestoneResponse(BaseModel):
    """Shared milestone with player/character info"""
    id: str
    character_id: str
    character_name: str
    player_id: str
    player_name: str
    player_number: str
    chapter_name: str
    is_custom: bool
    milestone_name: str
    milestone_description: str
    category: str
    current_progress: int
    target_progress: Optional[int]
    completed: bool
    notes: Optional[str]
    completed_at: Optional[str]
    created_at: str
    updated_at: str

class SharedJournalResponse(BaseModel):
    """Shared journal entry with player/character info"""
    id: str
    character_id: str
    character_name: str
    player_id: str
    player_name: str
    player_number: str
    chapter_name: str
    title: str
    content: str
    tags: List[str]
    event_id: Optional[str]
    event_title: Optional[str]
    created_at: str
    updated_at: str

class SystemMilestoneCreate(BaseModel):
    """Create a new system milestone definition"""
    name: str = Field(..., min_length=1, max_length=255)
    description: str = Field(..., min_length=1)
    category: str = Field(..., max_length=100)
    milestone_type: str = Field(..., description="event_count, xp_total, skill_count, candle_total, character_age_days")
    threshold_value: int = Field(..., gt=0)
    enabled: bool = True

class SystemMilestoneUpdate(BaseModel):
    """Update a system milestone definition"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = Field(None, min_length=1)
    category: Optional[str] = None
    milestone_type: Optional[str] = None
    threshold_value: Optional[int] = Field(None, gt=0)
    enabled: Optional[bool] = None

class SystemMilestoneResponse(BaseModel):
    """System milestone definition"""
    id: str
    name: str
    description: str
    category: str
    milestone_type: str
    threshold_value: int
    enabled: bool
    created_at: str
    updated_at: str

class CharacterSelectionResponse(BaseModel):
    """Character info for selection"""
    id: str
    name: str
    player_name: str
    player_number: str

class MilestoneAssignmentRequest(BaseModel):
    """Request to assign milestone to character"""
    system_milestone_id: str
    character_id: str
    notes: Optional[str] = None

# Shared Content Endpoints

@router.get("/shared-milestones", response_model=List[SharedMilestoneResponse])
async def get_shared_milestones(
    user: AuthorizedUser,
    chapter_id: Optional[str] = None,
    character_id: Optional[str] = None,
    player_id: Optional[str] = None
):
    """Get all milestones shared with staff (filterable)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                pm.id,
                pm.character_id,
                c.name as character_name,
                pp.id as player_id,
                pp.first_name || ' ' || pp.last_name as player_name,
                pp.player_number,
                ch.name as chapter_name,
                pm.is_custom,
                COALESCE(pm.custom_name, sm.name) as milestone_name,
                COALESCE(pm.custom_description, sm.description) as milestone_description,
                COALESCE(pm.custom_category, sm.category, 'general') as category,
                COALESCE(pm.current_progress, 0) as current_progress,
                COALESCE(pm.target_progress, sm.threshold_value) as target_progress,
                pm.completed_at,
                pm.notes,
                pm.created_at,
                pm.updated_at
            FROM player_milestones pm
            JOIN characters c ON pm.character_id = c.id
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            JOIN chapters ch ON pp.chapter_id = ch.id
            LEFT JOIN system_milestones sm ON pm.system_milestone_id = sm.id
            WHERE pm.shared_with_staff = true
        """
        
        params = []
        param_count = 1
        
        if chapter_id:
            query += f" AND ch.id = ${param_count}"
            params.append(UUID(chapter_id))
            param_count += 1
        
        if character_id:
            query += f" AND c.id = ${param_count}"
            params.append(UUID(character_id))
            param_count += 1
        
        if player_id:
            query += f" AND pp.id = ${param_count}"
            params.append(UUID(player_id))
            param_count += 1
        
        query += " ORDER BY pm.created_at DESC"
        
        milestones = await conn.fetch(query, *params)
        
        return [
            SharedMilestoneResponse(
                id=str(m['id']),
                character_id=str(m['character_id']),
                character_name=m['character_name'],
                player_id=str(m['player_id']),
                player_name=m['player_name'],
                player_number=m['player_number'],
                chapter_name=m['chapter_name'],
                is_custom=m['is_custom'],
                milestone_name=m['milestone_name'],
                milestone_description=m['milestone_description'],
                category=m['category'],
                current_progress=m['current_progress'],
                target_progress=m['target_progress'],
                completed=m['completed_at'] is not None,
                notes=m['notes'],
                completed_at=m['completed_at'].isoformat() if m['completed_at'] else None,
                created_at=m['created_at'].isoformat(),
                updated_at=m['updated_at'].isoformat()
            )
            for m in milestones
        ]
    finally:
        await conn.close()

@router.get("/shared-journals", response_model=List[SharedJournalResponse])
async def get_shared_journals(
    user: AuthorizedUser,
    chapter_id: Optional[str] = None,
    character_id: Optional[str] = None,
    player_id: Optional[str] = None,
    event_id: Optional[str] = None  # ADD THIS LINE
):
    """Get all journal entries shared with staff (filterable)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                je.id,
                c.id as character_id,
                c.name as character_name,
                pp.id as player_id,
                pp.first_name || ' ' || pp.last_name as player_name,
                pp.player_number,
                ch.name as chapter_name,
                je.title,
                je.content,
                je.tags,
                je.event_id,
                e.title as event_title,
                je.created_at,
                je.updated_at
            FROM journal_entries je
            JOIN characters c ON je.character_id = c.id
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            JOIN chapters ch ON pp.chapter_id = ch.id
            LEFT JOIN events e ON je.event_id = e.id
            WHERE je.shared_with_staff = true
        """
        
        params = []
        param_count = 1
        
        if chapter_id:
            query += f" AND ch.id = ${param_count}"
            params.append(UUID(chapter_id))
            param_count += 1
        
        if character_id:
            query += f" AND c.id = ${param_count}"
            params.append(UUID(character_id))
            param_count += 1
        
        if player_id:
            query += f" AND pp.id = ${param_count}"
            params.append(UUID(player_id))
            param_count += 1

        if event_id:
            query += f" AND je.event_id = ${param_count}"
            params.append(UUID(event_id))
            param_count += 1
        
        query += " ORDER BY je.created_at DESC"
        
        journals = await conn.fetch(query, *params)
        
        return [
            SharedJournalResponse(
                id=str(j['id']),
                character_id=str(j['character_id']),
                character_name=j['character_name'],
                player_id=str(j['player_id']),
                player_name=j['player_name'],
                player_number=j['player_number'],
                chapter_name=j['chapter_name'],
                title=j['title'],
                content=j['content'],
                tags=j['tags'],
                event_id=str(j['event_id']) if j['event_id'] else None,
                event_title=j['event_title'],
                created_at=j['created_at'].isoformat(),
                updated_at=j['updated_at'].isoformat()
            )
            for j in journals
        ]
    finally:
        await conn.close()

# System Milestone Management Endpoints

@router.get("/system-milestones", response_model=List[SystemMilestoneResponse])
async def list_system_milestones(
    user: AuthorizedUser,
    include_disabled: bool = False
):
    """List all system milestone definitions (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        if include_disabled:
            query = "SELECT * FROM system_milestones ORDER BY category, name"
            milestones = await conn.fetch(query)
        else:
            query = "SELECT * FROM system_milestones WHERE enabled = true ORDER BY category, name"
            milestones = await conn.fetch(query)
        
        return [
            SystemMilestoneResponse(
                id=str(m['id']),
                name=m['name'],
                description=m['description'],
                category=m['category'],
                milestone_type=m['milestone_type'],
                threshold_value=m['threshold_value'],
                enabled=m['enabled'],
                created_at=m['created_at'].isoformat(),
                updated_at=m['updated_at'].isoformat()
            )
            for m in milestones
        ]
    finally:
        await conn.close()

@router.post("/system-milestones", response_model=SystemMilestoneResponse)
async def create_system_milestone(
    milestone: SystemMilestoneCreate,
    user: AuthorizedUser
):
    """Create a new system milestone definition (admin only)"""
    await check_admin_permission(user)
    
    # Validate milestone_type
    valid_types = ['event_count', 'xp_total', 'skill_count', 'candle_total', 'character_age_days', 'other']
    if milestone.milestone_type not in valid_types:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid milestone_type. Must be one of: {', '.join(valid_types)}"
        )
    
    conn = await get_database_connection()
    try:
        new_milestone = await conn.fetchrow(
            """
            INSERT INTO system_milestones (
                name, description, category, milestone_type, threshold_value, enabled
            )
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING *
            """,
            milestone.name,
            milestone.description,
            milestone.category,
            milestone.milestone_type,
            milestone.threshold_value,
            milestone.enabled
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="system_milestone",
            action="create",
            entity_id=str(new_milestone['id']),
            entity_type="system_milestone",
            details=milestone.dict()
        )
        
        return SystemMilestoneResponse(
            id=str(new_milestone['id']),
            name=new_milestone['name'],
            description=new_milestone['description'],
            category=new_milestone['category'],
            milestone_type=new_milestone['milestone_type'],
            threshold_value=new_milestone['threshold_value'],
            enabled=new_milestone['enabled'],
            created_at=new_milestone['created_at'].isoformat(),
            updated_at=new_milestone['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.put("/system-milestones/{milestone_id}", response_model=SystemMilestoneResponse)
async def update_system_milestone(
    milestone_id: str,
    update_data: SystemMilestoneUpdate,
    user: AuthorizedUser
):
    """Update a system milestone definition (admin only)"""
    await check_admin_permission(user)
    
    # Validate milestone_type if provided
    if update_data.milestone_type:
        valid_types = ['event_count', 'xp_total', 'skill_count', 'candle_total', 'character_age_days', 'other']
        if update_data.milestone_type not in valid_types:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid milestone_type. Must be one of: {', '.join(valid_types)}"
            )
    
    conn = await get_database_connection()
    try:
        # Check if milestone exists
        existing = await conn.fetchrow(
            "SELECT id FROM system_milestones WHERE id = $1",
            UUID(milestone_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="System milestone not found")
        
        # Build update query
        update_fields = []
        params = []
        param_count = 1
        
        if update_data.name is not None:
            update_fields.append(f"name = ${param_count}")
            params.append(update_data.name)
            param_count += 1
        
        if update_data.description is not None:
            update_fields.append(f"description = ${param_count}")
            params.append(update_data.description)
            param_count += 1
        
        if update_data.category is not None:
            update_fields.append(f"category = ${param_count}")
            params.append(update_data.category)
            param_count += 1
        
        if update_data.milestone_type is not None:
            update_fields.append(f"milestone_type = ${param_count}")
            params.append(update_data.milestone_type)
            param_count += 1
        
        if update_data.threshold_value is not None:
            update_fields.append(f"threshold_value = ${param_count}")
            params.append(update_data.threshold_value)
            param_count += 1
        
        if update_data.enabled is not None:
            update_fields.append(f"enabled = ${param_count}")
            params.append(update_data.enabled)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        update_fields.append("updated_at = CURRENT_TIMESTAMP")
        params.append(UUID(milestone_id))
        
        query = f"UPDATE system_milestones SET {', '.join(update_fields)} WHERE id = ${param_count} RETURNING *"
        
        updated = await conn.fetchrow(query, *params)

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="system_milestone",
            action="update",
            entity_id=milestone_id,
            entity_type="system_milestone",
            details=update_data.dict(exclude_unset=True)
        )
        
        return SystemMilestoneResponse(
            id=str(updated['id']),
            name=updated['name'],
            description=updated['description'],
            category=updated['category'],
            milestone_type=updated['milestone_type'],
            threshold_value=updated['threshold_value'],
            enabled=updated['enabled'],
            created_at=updated['created_at'].isoformat(),
            updated_at=updated['updated_at'].isoformat()
        )
    finally:
        await conn.close()

@router.delete("/system-milestones/{milestone_id}")
async def delete_system_milestone(milestone_id: str, user: AuthorizedUser):
    """Delete a system milestone definition (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if milestone exists
        existing = await conn.fetchrow(
            "SELECT id, name FROM system_milestones WHERE id = $1",
            UUID(milestone_id)
        )
        if not existing:
            raise HTTPException(status_code=404, detail="System milestone not found")
        
        # Delete milestone (cascade will handle player_milestones)
        await conn.execute(
            "DELETE FROM system_milestones WHERE id = $1",
            UUID(milestone_id)
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="system_milestone",
            action="delete",
            entity_id=milestone_id,
            entity_type="system_milestone",
            details={"name": existing['name']}
        )
        
        return {
            "success": True,
            "message": f"System milestone '{existing['name']}' deleted"
        }
    finally:
        await conn.close()

@router.get("/characters", response_model=List[CharacterSelectionResponse])
async def list_characters_for_assignment(user: AuthorizedUser):
    """List all characters for milestone assignment (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        query = """
            SELECT 
                c.id,
                c.name,
                pp.first_name || ' ' || pp.last_name as player_name,
                pp.player_number
            FROM characters c
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            WHERE c.retired = false AND c.deaths < 3
            ORDER BY c.name
        """
        rows = await conn.fetch(query)
        return [
            CharacterSelectionResponse(
                id=str(r['id']),
                name=r['name'],
                player_name=r['player_name'],
                player_number=r['player_number']
            )
            for r in rows
        ]
    finally:
        await conn.close()

@router.post("/assign")
async def assign_system_milestone(
    assignment: MilestoneAssignmentRequest,
    user: AuthorizedUser
):
    """Assign a system milestone to a character (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if milestone exists
        milestone = await conn.fetchrow(
            "SELECT * FROM system_milestones WHERE id = $1",
            UUID(assignment.system_milestone_id)
        )
        if not milestone:
            raise HTTPException(status_code=404, detail="System milestone not found")
        
        # Check if already assigned
        exists = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_milestones 
                WHERE character_id = $1 AND system_milestone_id = $2
            )
            """,
            UUID(assignment.character_id),
            UUID(assignment.system_milestone_id)
        )
        
        if exists:
            raise HTTPException(status_code=400, detail="Milestone already assigned to this character")
            
        # Create assignment
        await conn.execute(
            """
            INSERT INTO player_milestones (
                character_id, 
                system_milestone_id,
                current_progress,
                target_progress,
                notes,
                awarded_by,
                completed_at
            )
            VALUES ($1, $2, $3, $3, $4, $5, CURRENT_TIMESTAMP)
            """,
            UUID(assignment.character_id),
            UUID(assignment.system_milestone_id),
            milestone['threshold_value'],
            assignment.notes,
            user.sub
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="milestone",
            action="assign",
            entity_id=assignment.character_id,
            entity_type="character",
            details={
                "system_milestone_id": assignment.system_milestone_id, 
                "notes": assignment.notes
            }
        )        
        return {"success": True, "message": "Milestone assigned successfully"}
        
    finally:
        await conn.close()
