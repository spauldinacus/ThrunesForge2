from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/photo-gallery")

# --- Models ---

class PhotoMetadata(BaseModel):
    """Metadata for a photo from Google Photos"""
    photo_id: str
    photo_url: str
    thumbnail_url: Optional[str] = None
    description: Optional[str] = None
    taken_at: Optional[str] = None

class CreatePhotoTagRequest(BaseModel):
    """Request to tag a character in a photo"""
    photo_url: str = Field(..., description="Full URL of the photo")
    photo_id: str = Field(..., description="Google Photos ID")
    character_id: str = Field(..., description="Character UUID to tag")
    x_position: float = Field(..., ge=0, le=100, description="X position percentage")
    y_position: float = Field(..., ge=0, le=100, description="Y position percentage")

class PhotoTagResponse(BaseModel):
    """Response for a photo tag"""
    id: str
    photo_url: str
    photo_id: str
    character_id: str
    character_name: str
    player_name: str
    tagged_by_user_id: str
    tagged_by_name: str
    x_position: float
    y_position: float
    created_at: str

class PhotoWithTags(BaseModel):
    """Photo with all its character tags"""
    photo_url: str
    photo_id: str
    tags: List[PhotoTagResponse]

# --- Helper Functions ---

async def check_character_ownership_or_admin(user_id: str, character_id: UUID) -> tuple[bool, bool]:
    """Check if user owns the character or has admin permissions
    Returns: (is_owner, is_admin)
    """
    conn = await get_database_connection()
    try:
        # Check character ownership
        ownership_check = await conn.fetchrow(
            """
            SELECT 
                c.id,
                pp.user_id,
                (pp.user_id = $1) as is_owner
            FROM public.characters c
            JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            WHERE c.id = $2
            """,
            user_id, character_id
        )
        
        if not ownership_check:
            raise HTTPException(status_code=404, detail="Character not found")
        
        is_owner = ownership_check['is_owner']
        
        # Check admin permissions
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name = 'manage_photo_galleries'
            )
            """,
            user_id
        )
        
        is_admin = bool(admin_check)
        
        return is_owner, is_admin
    finally:
        await conn.close()

# --- Endpoints ---

@router.post("/tags", response_model=PhotoTagResponse)
async def create_photo_tag(request: CreatePhotoTagRequest, user: AuthorizedUser):
    """
    Tag a character in a photo.
    Players can only tag their own characters.
    Admins can tag any character.
    """
    character_uuid = UUID(request.character_id)
    print(f"DEBUG: Creating tag - photo_id={request.photo_id}, character_id={request.character_id}, user={user.sub}")
    
    # Check permissions
    is_owner, is_admin = await check_character_ownership_or_admin(user.sub, character_uuid)
    
    if not is_owner and not is_admin:
        raise HTTPException(
            status_code=403,
            detail="You can only tag your own characters. Admins can tag any character."
        )
    
    conn = await get_database_connection()
    try:
        # Check if character is already tagged in this photo
        existing_tag = await conn.fetchval(
            "SELECT id FROM public.photo_tags WHERE photo_url = $1 AND photo_id = $2 AND character_id = $3",
            request.photo_url, request.photo_id, character_uuid
        )
        
        if existing_tag:
            raise HTTPException(
                status_code=400,
                detail="This character is already tagged in this photo"
            )
        
        # Create the tag
        tag_id = await conn.fetchval(
            """
            INSERT INTO public.photo_tags 
            (photo_url, photo_id, character_id, tagged_by_user_id, x_position, y_position)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id
            """,
            request.photo_url,
            request.photo_id,
            character_uuid,
            user.sub,
            request.x_position,
            request.y_position
        )
        
        # Fetch the created tag with character and player info
        tag_data = await conn.fetchrow(
            """
            SELECT 
                pt.id,
                pt.photo_url,
                pt.photo_id,
                pt.character_id,
                c.name as character_name,
                pp.first_name || ' ' || pp.last_name as player_name,
                pt.tagged_by_user_id,
                tagger.first_name || ' ' || tagger.last_name as tagged_by_name,
                pt.x_position,
                pt.y_position,
                pt.created_at
            FROM public.photo_tags pt
            JOIN public.characters c ON pt.character_id = c.id
            JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            JOIN public.player_profiles tagger ON pt.tagged_by_user_id = tagger.user_id
            WHERE pt.id = $1
            """,
            tag_id
        )
        
        return PhotoTagResponse(
            id=str(tag_data['id']),
            photo_url=tag_data['photo_url'],
            photo_id=tag_data['photo_id'],
            character_id=str(tag_data['character_id']),
            character_name=tag_data['character_name'],
            player_name=tag_data['player_name'],
            tagged_by_user_id=tag_data['tagged_by_user_id'],
            tagged_by_name=tag_data['tagged_by_name'],
            x_position=float(tag_data['x_position']),
            y_position=float(tag_data['y_position']),
            created_at=tag_data['created_at'].isoformat()
        )
    finally:
        await conn.close()

@router.get("/photos/{photo_id}/tags", response_model=List[PhotoTagResponse])
async def get_photo_tags(photo_id: str):
    """Get all tags for a specific photo"""
    conn = await get_database_connection()
    try:
        tags_data = await conn.fetch(
            """
            SELECT 
                pt.id,
                pt.photo_url,
                pt.photo_id,
                pt.character_id,
                COALESCE(c.name, 'Unknown Character') as character_name,
                COALESCE(pp.first_name || ' ' || pp.last_name, 'Unknown Player') as player_name,
                pt.tagged_by_user_id,
                COALESCE(tagger.first_name || ' ' || tagger.last_name, 'Unknown User') as tagged_by_name,
                pt.x_position,
                pt.y_position,
                pt.created_at
            FROM public.photo_tags pt
            LEFT JOIN public.characters c ON pt.character_id = c.id
            LEFT JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            LEFT JOIN public.player_profiles tagger ON pt.tagged_by_user_id = tagger.user_id
            WHERE pt.photo_id = $1
            ORDER BY pt.created_at DESC
            """,
            photo_id
        )
        
        return [
            PhotoTagResponse(
                id=str(tag['id']),
                photo_url=tag['photo_url'],
                photo_id=tag['photo_id'],
                character_id=str(tag['character_id']),
                character_name=tag['character_name'],
                player_name=tag['player_name'],
                tagged_by_user_id=tag['tagged_by_user_id'],
                tagged_by_name=tag['tagged_by_name'],
                x_position=float(tag['x_position']),
                y_position=float(tag['y_position']),
                created_at=tag['created_at'].isoformat()
            )
            for tag in tags_data
        ]
    finally:
        await conn.close()

@router.delete("/tags/{tag_id}")
async def delete_photo_tag(tag_id: str, user: AuthorizedUser):
    """Delete a photo tag. Only the creator or admin can delete."""
    tag_uuid = UUID(tag_id)
    
    conn = await get_database_connection()
    try:
        # Get tag info
        tag_info = await conn.fetchrow(
            """
            SELECT pt.tagged_by_user_id, pt.character_id
            FROM public.photo_tags pt
            WHERE pt.id = $1
            """,
            tag_uuid
        )
        
        if not tag_info:
            raise HTTPException(status_code=404, detail="Tag not found")
        
        # Check if user is the tagger
        is_tagger = tag_info['tagged_by_user_id'] == user.sub
        
        # Check if user is admin
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_all_characters', 'view_admin_panel')
            )
            """,
            user.sub
        )
        
        is_admin = bool(admin_check)
        
        if not is_tagger and not is_admin:
            raise HTTPException(
                status_code=403,
                detail="You can only delete your own tags"
            )
        
        # Delete the tag
        await conn.execute(
            "DELETE FROM public.photo_tags WHERE id = $1",
            tag_uuid
        )
        
        return {"message": "Tag deleted successfully"}
    finally:
        await conn.close()

@router.get("/tags/all", response_model=List[PhotoTagResponse])
async def get_all_photo_tags():
    """Get all photo tags in one query for efficient loading"""
    conn = await get_database_connection()
    try:
        tags_data = await conn.fetch(
            """
            SELECT 
                pt.id,
                pt.photo_url,
                pt.photo_id,
                pt.character_id,
                COALESCE(c.name, 'Unknown Character') as character_name,
                COALESCE(pp.first_name || ' ' || pp.last_name, 'Unknown Player') as player_name,
                pt.tagged_by_user_id,
                COALESCE(tagger.first_name || ' ' || tagger.last_name, 'Unknown User') as tagged_by_name,
                pt.x_position,
                pt.y_position,
                pt.created_at
            FROM public.photo_tags pt
            LEFT JOIN public.characters c ON pt.character_id = c.id
            LEFT JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            LEFT JOIN public.player_profiles tagger ON pt.tagged_by_user_id = tagger.user_id
            ORDER BY pt.created_at DESC
            """
        )
        
        return [
            PhotoTagResponse(
                id=str(tag['id']),
                photo_url=tag['photo_url'],
                photo_id=tag['photo_id'],
                character_id=str(tag['character_id']),
                character_name=tag['character_name'],
                player_name=tag['player_name'],
                tagged_by_user_id=tag['tagged_by_user_id'],
                tagged_by_name=tag['tagged_by_name'],
                x_position=float(tag['x_position']),
                y_position=float(tag['y_position']),
                created_at=tag['created_at'].isoformat()
            )
            for tag in tags_data
        ]
    finally:
        await conn.close()
        
@router.get("/my-characters")
async def get_my_characters_for_tagging(user: AuthorizedUser):
    """Get user's characters for tagging dropdown"""
    conn = await get_database_connection()
    try:
        # Get user's profile
        profile = await conn.fetchrow(
            "SELECT id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        
        if not profile:
            return []
        
        # Get user's active characters
        characters = await conn.fetch(
            """
            SELECT 
                c.id,
                c.name,
                h.name as heritage_name,
                cu.name as culture_name
            FROM public.characters c
            JOIN public.heritages h ON c.heritage_id = h.id
            JOIN public.cultures cu ON c.culture_id = cu.id
            WHERE c.player_profile_id = $1 AND c.retired = false
            ORDER BY c.name
            """,
            profile['id']
        )
        
        return [
            {
                "id": str(char['id']),
                "name": char['name'],
                "heritage_name": char['heritage_name'],
                "culture_name": char['culture_name']
            }
            for char in characters
        ]
    finally:
        await conn.close()

@router.get("/all-characters")
async def get_all_characters_for_tagging(user: AuthorizedUser):
    """Get all characters for admin tagging (admin only)"""
    conn = await get_database_connection()
    try:
        # Check admin permissions
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_all_characters', 'view_admin_panel')
            )
            """,
            user.sub
        )
        
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
        
        # Get all active characters with player info
        characters = await conn.fetch(
            """
            SELECT 
                c.id,
                c.name as character_name,
                pp.first_name || ' ' || pp.last_name as player_name,
                h.name as heritage_name,
                cu.name as culture_name
            FROM public.characters c
            JOIN public.player_profiles pp ON c.player_profile_id = pp.id
            JOIN public.heritages h ON c.heritage_id = h.id
            JOIN public.cultures cu ON c.culture_id = cu.id
            WHERE c.retired = false
            ORDER BY c.name
            """,
        )
        
        return [
            {
                "id": str(char['id']),
                "character_name": char['character_name'],
                "player_name": char['player_name'],
                "heritage_name": char['heritage_name'],
                "culture_name": char['culture_name']
            }
            for char in characters
        ]
    finally:
        await conn.close()