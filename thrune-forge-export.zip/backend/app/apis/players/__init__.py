from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field, validator
from typing import List, Optional
from datetime import datetime
from uuid import UUID
import asyncpg
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.sync_utils import sync_player_profiles_to_dev, log_sync_attempt

router = APIRouter()

# Pydantic Models
class CreatePlayerProfileRequest(BaseModel):
    """Request model for creating a new player profile"""
    first_name: str = Field(..., min_length=1, max_length=100)
    last_name: str = Field(..., min_length=1, max_length=100)
    phone_number: Optional[str] = Field(None, max_length=20)
    emergency_contact_name: Optional[str] = Field(None, max_length=200)
    emergency_contact_phone: Optional[str] = Field(None, max_length=20)
    chapter_id: UUID = Field(..., description="Chapter the player belongs to")

class UpdatePlayerProfileRequest(BaseModel):
    """Request model for updating player profile"""
    first_name: Optional[str] = Field(None, min_length=1, max_length=100)
    last_name: Optional[str] = Field(None, min_length=1, max_length=100)
    phone_number: Optional[str] = Field(None, max_length=20)
    emergency_contact_name: Optional[str] = Field(None, max_length=200)
    emergency_contact_phone: Optional[str] = Field(None, max_length=20)
    email: Optional[str] = Field(None, max_length=255, description="Player email address")
    referred_by_player_id: Optional[UUID] = None

class PlayerProfile(BaseModel):
    """Player profile response model"""
    id: UUID
    user_id: str
    first_name: str
    last_name: str
    phone_number: Optional[str]
    emergency_contact_name: Optional[str]
    emergency_contact_phone: Optional[str]
    chapter_id: UUID
    chapter_name: str
    player_number: str
    candles_available: int
    email: Optional[str]
    created_at: datetime
    updated_at: datetime
    referred_by_player_id: Optional[UUID] = None
    referred_by_player_name: Optional[str] = None
    referred_by_player_number: Optional[str] = None
    referral_acknowledged: bool = False
    referral_acknowledged_at: Optional[datetime] = None
    referral_acknowledged_by_user_id: Optional[str] = None
    referral_acknowledged_by_name: Optional[str] = None

class CandleTransaction(BaseModel):
    """Candle transaction model"""
    id: UUID
    amount: int
    reason: str
    granted_by_user_id: Optional[str]
    granted_by_name: Optional[str]  # Admin name who granted
    used_for: Optional[str]
    created_at: datetime

class CandleHistoryResponse(BaseModel):
    """Response model for candle history"""
    transactions: List[CandleTransaction]
    total_earned: int
    total_spent: int
    current_balance: int

class CreateCandleTransactionRequest(BaseModel):
    """Request model for creating candle transactions (admin only)"""
    player_profile_id: UUID
    amount: int = Field(..., description="Positive for earned, negative for spent")
    reason: str = Field(..., min_length=1, max_length=500)
    used_for: Optional[str] = Field(None, max_length=500)

class UpdatePlayerNumberRequest(BaseModel):
    """Request model for updating player number (admin only)"""
    player_number: str = Field(..., min_length=9, max_length=9, pattern=r"^[A-Z]{2}\d{7}$")
    reason: str = Field(..., min_length=1, max_length=500, description="Reason for changing player number")

# Helper functions
async def generate_player_number(chapter_id: UUID, conn) -> str:
    """Generate a unique player number in format CCYYMMNNN"""
    # Get chapter info for code
    chapter = await conn.fetchrow(
        "SELECT chapter_code FROM public.chapters WHERE id = $1", chapter_id
    )
    if not chapter:
        raise HTTPException(status_code=400, detail="Invalid chapter")
    
    # Use the actual chapter_code from database
    chapter_code = chapter['chapter_code']
    if not chapter_code:
        raise HTTPException(status_code=400, detail="Chapter missing chapter code")
    
    # Get current year/month
    from datetime import datetime
    now = datetime.now()
    year = now.year % 100  # Last 2 digits
    month = now.month
    
    # Get or create sequence for this chapter/year/month
    sequence_row = await conn.fetchrow(
        """
        INSERT INTO public.player_number_sequences (chapter_id, year, month, next_sequence)
        VALUES ($1, $2, $3, 1)
        ON CONFLICT (chapter_id, year, month)
        DO UPDATE SET next_sequence = player_number_sequences.next_sequence + 1
        RETURNING next_sequence
        """,
        chapter_id, year, month
    )
    
    sequence = sequence_row['next_sequence']
    
    # Format: CCYYMMNNN
    player_number = f"{chapter_code}{year:02d}{month:02d}{sequence:03d}"
    
    return player_number

# API Endpoints
@router.post("/players/profile", response_model=PlayerProfile)
async def create_player_profile(
    profile_data: CreatePlayerProfileRequest,
    user: AuthorizedUser
):
    """Create a new player profile for the authenticated user"""
    
    conn = await get_database_connection()
    try:
        # Check if user already has a profile
        existing = await conn.fetchrow(
            "SELECT id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        if existing:
            raise HTTPException(
                status_code=400, 
                detail="Player profile already exists for this user"
            )
        
        # Get user email directly from AuthorizedUser token
        user_email = user.email
        
        # Verify chapter exists
        chapter_check = await conn.fetchrow(
            "SELECT id, name FROM public.chapters WHERE id = $1",
            profile_data.chapter_id
        )
        if not chapter_check:
            raise HTTPException(status_code=400, detail="Invalid chapter ID")
        
        # Generate player number
        player_number = await generate_player_number(profile_data.chapter_id, conn)
        
        # Create profile with email from Stack Auth
        profile_row = await conn.fetchrow(
            """
            INSERT INTO public.player_profiles (
                user_id, first_name, last_name, phone_number,
                emergency_contact_name, emergency_contact_phone,
                chapter_id, player_number, candles_available, email
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, 0, $9)
            RETURNING *
            """,
            user.sub, profile_data.first_name, profile_data.last_name,
            profile_data.phone_number, profile_data.emergency_contact_name,
            profile_data.emergency_contact_phone, profile_data.chapter_id,
            player_number, user_email
        )
        
        # Return profile with chapter name
        profile = PlayerProfile(
            id=profile_row['id'],
            user_id=profile_row['user_id'],
            first_name=profile_row['first_name'],
            last_name=profile_row['last_name'],
            phone_number=profile_row['phone_number'],
            emergency_contact_name=profile_row['emergency_contact_name'],
            emergency_contact_phone=profile_row['emergency_contact_phone'],
            chapter_id=profile_row['chapter_id'],
            chapter_name=chapter_check['name'],
            player_number=profile_row['player_number'],
            candles_available=profile_row['candles_available'],
            email=profile_row['email'],
            created_at=profile_row['created_at'],
            updated_at=profile_row['updated_at']
        )
        
        # Automatically assign "Player" role to new users
        try:
            player_role = await conn.fetchval(
                "SELECT id FROM public.roles WHERE name = 'Player'"
            )
            if player_role:
                await conn.execute(
                    "INSERT INTO public.player_roles (player_profile_id, role_id) VALUES ($1, $2)",
                    profile_row['id'], player_role
                )
                print(f"Assigned 'Player' role to new user: {profile.first_name} {profile.last_name}")
            else:
                print("Warning: 'Player' role not found - unable to assign default role")
        except Exception as role_error:
            # Log the error but don't fail the profile creation
            print(f"Warning: Failed to assign default role to new user: {role_error}")
        
        # Trigger sync to development (non-blocking)
        try:
            sync_success = await sync_player_profiles_to_dev()
            log_sync_attempt("create_player_profile", str(profile.id), sync_success)
        except Exception as sync_error:
            log_sync_attempt("create_player_profile", str(profile.id), False, str(sync_error))
        
        return profile
        
    except Exception as e:
        print(f"Error creating player profile: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to create player profile")
    finally:
        await conn.close()

@router.get("/my-player-profile")
async def get_my_player_profile(user: AuthorizedUser) -> PlayerProfile:
    """Get the current user's player profile"""
    print(f"Getting player profile for user_id: {user.sub}")
    
    conn = await get_database_connection()
    try:
        print(f"Looking for profile with user_id: {user.sub}")
        profile_row = await conn.fetchrow(
            """
            SELECT 
                p.*, 
                c.name as chapter_name, 
                p.is_admin,
                referrer.first_name || ' ' || referrer.last_name as referrer_name,
                referrer.player_number as referrer_number,
                acknowledger.first_name || ' ' || acknowledger.last_name as acknowledger_name
            FROM public.player_profiles p
            JOIN public.chapters c ON p.chapter_id = c.id
            LEFT JOIN public.player_profiles referrer ON p.referred_by_player_id = referrer.id
            LEFT JOIN public.player_profiles acknowledger ON p.referral_acknowledged_by_user_id = acknowledger.user_id
            WHERE p.user_id = $1
            """,
            user.sub
        )
        
        print(f"Query result: {profile_row}")
        if not profile_row:
            raise HTTPException(status_code=404, detail="Player profile not found")
        
        # Auto-update NULL email from auth token
        email = profile_row['email']
        if not email:
            # Get email from auth token
            user_email = getattr(user, 'email', None)
            if user_email:
                # Update the database with the email
                await conn.execute(
                    "UPDATE public.player_profiles SET email = $1, updated_at = NOW() WHERE id = $2",
                    user_email, profile_row['id']
                )
                email = user_email
                print(f"Auto-updated missing email for profile {profile_row['id']}: {user_email}")

        return PlayerProfile(
            id=profile_row['id'],
            user_id=profile_row['user_id'],
            first_name=profile_row['first_name'],
            last_name=profile_row['last_name'],
            phone_number=profile_row['phone_number'],
            emergency_contact_name=profile_row['emergency_contact_name'],
            emergency_contact_phone=profile_row['emergency_contact_phone'],
            chapter_id=profile_row['chapter_id'],
            chapter_name=profile_row['chapter_name'],
            player_number=profile_row['player_number'],
            candles_available=profile_row['candles_available'],
            email=email,
            created_at=profile_row['created_at'],
            updated_at=profile_row['updated_at'],
            referred_by_player_id=profile_row['referred_by_player_id'],
            referral_acknowledged=profile_row['referral_acknowledged'],
            referral_acknowledged_at=profile_row['referral_acknowledged_at'],
            referral_acknowledged_by_user_id=profile_row['referral_acknowledged_by_user_id'],
            referred_by_player_name=profile_row['referrer_name'],
            referred_by_player_number=profile_row['referrer_number'],
            referral_acknowledged_by_name=profile_row.get('acknowledger_name')
        )
        
    except Exception as e:
        print(f"Error getting player profile: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to get player profile")
    finally:
        await conn.close()

@router.put("/players/profile", response_model=PlayerProfile)
async def update_my_player_profile(
    profile_data: UpdatePlayerProfileRequest,
    user: AuthorizedUser
):
    """Update the current user's player profile"""
    
    conn = await get_database_connection()
    try:
        # Get current profile to check referral status
        current_profile = await conn.fetchrow(
            "SELECT id, referral_acknowledged, referred_by_player_id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        
        if not current_profile:
            raise HTTPException(status_code=404, detail="Player profile not found")
        
        # Validate referral changes - only if actually changing
        if profile_data.referred_by_player_id is not None:
            # Only validate if the referral is actually changing
            if profile_data.referred_by_player_id != current_profile['referred_by_player_id']:
                # Check if referral is already acknowledged (locked)
                if current_profile['referral_acknowledged']:
                    raise HTTPException(
                        status_code=400, 
                        detail="Referral has been acknowledged by an admin and cannot be changed"
                    )
                
                # Prevent self-referral
                if profile_data.referred_by_player_id == current_profile['id']:
                    raise HTTPException(status_code=400, detail="You cannot refer yourself")
                
                # Validate referrer exists
                referrer = await conn.fetchrow(
                    "SELECT id FROM public.player_profiles WHERE id = $1",
                    profile_data.referred_by_player_id
                )
                if not referrer:
                    raise HTTPException(status_code=400, detail="Invalid referrer player ID")        
        # Build dynamic update query
        update_fields = []
        values = []
        param_count = 1
        
        for field_name, field_value in profile_data.model_dump(exclude_unset=True).items():
            if field_value is not None:
                update_fields.append(f"{field_name} = ${param_count}")
                values.append(field_value)
                param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add updated_at
        update_fields.append(f"updated_at = ${param_count}")
        values.append(datetime.now())
        param_count += 1
        
        # Add user_id for WHERE clause
        values.append(user.sub)
        
        query = f"""
            UPDATE public.player_profiles 
            SET {', '.join(update_fields)}
            WHERE user_id = ${param_count}
            RETURNING *
        """
        
        profile_row = await conn.fetchrow(query, *values)
        
        if not profile_row:
            raise HTTPException(status_code=404, detail="Player profile not found")
        
        # Get chapter name
        chapter = await conn.fetchrow(
            "SELECT name FROM public.chapters WHERE id = $1",
            profile_row['chapter_id']
        )
        
        return PlayerProfile(
            id=profile_row['id'],
            user_id=profile_row['user_id'],
            first_name=profile_row['first_name'],
            last_name=profile_row['last_name'],
            phone_number=profile_row['phone_number'],
            emergency_contact_name=profile_row['emergency_contact_name'],
            emergency_contact_phone=profile_row['emergency_contact_phone'],
            chapter_id=profile_row['chapter_id'],
            chapter_name=chapter['name'],
            player_number=profile_row['player_number'],
            candles_available=profile_row['candles_available'],
            email=profile_row['email'],
            created_at=profile_row['created_at'],
            updated_at=profile_row['updated_at'],
            referred_by_player_id=profile_row['referred_by_player_id'],
            referral_acknowledged=profile_row['referral_acknowledged'],
            referral_acknowledged_at=profile_row['referral_acknowledged_at'],
            referral_acknowledged_by_user_id=profile_row['referral_acknowledged_by_user_id'],
            referred_by_player_name=None,
            referred_by_player_number=None
        )
        
    except Exception as e:
        print(f"Error updating player profile: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to update player profile")
    finally:
        await conn.close()

@router.get("/players/candle-history", response_model=CandleHistoryResponse)
async def get_my_candle_history(user: AuthorizedUser):
    """Get the current user's candle transaction history"""
    
    print(f"DEBUG: Candle history request for user_id: {user.sub}")
    
    conn = await get_database_connection()
    try:
        # Get player profile
        profile = await conn.fetchrow(
            "SELECT id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        
        if not profile:
            raise HTTPException(status_code=404, detail="Player profile not found")
        
        # Get all transactions
        transactions = await conn.fetch(
            """
            SELECT 
                id, amount, reason, granted_by_user_id, used_for, created_at
            FROM public.candle_transactions
            WHERE player_profile_id = $1
            ORDER BY created_at DESC
            """,
            profile['id']
        )
        
        # Get granted_by names for admin-granted transactions
        transaction_list = []
        for t in transactions:
            granted_by_name = None
            if t['granted_by_user_id']:
                admin = await conn.fetchrow(
                    "SELECT first_name, last_name FROM public.player_profiles WHERE user_id = $1",
                    t['granted_by_user_id']
                )
                if admin:
                    granted_by_name = f"{admin['first_name']} {admin['last_name']}"
            
            transaction_list.append(CandleTransaction(
                id=t['id'],
                amount=t['amount'],
                reason=t['reason'],
                granted_by_user_id=t['granted_by_user_id'],
                granted_by_name=granted_by_name,
                used_for=t['used_for'],
                created_at=t['created_at']
            ))
        
        # Calculate totals
        total_earned = sum(t.amount for t in transaction_list if t.amount > 0)
        total_spent = abs(sum(t.amount for t in transaction_list if t.amount < 0))
        current_balance = total_earned - total_spent
        
        return CandleHistoryResponse(
            transactions=transaction_list,
            total_earned=total_earned,
            total_spent=total_spent,
            current_balance=current_balance
        )
        
    except Exception as e:
        print(f"Error fetching candle history: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to fetch candle history")
    finally:
        await conn.close()
        
# Database-driven admin checking
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_players', 'view_admin_panel')
            )
            """,
            user.sub
        )
        
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

# Admin-only endpoints for player number management
@router.put("/admin/players/{player_id}/player-number", response_model=PlayerProfile)
async def update_player_number(
    player_id: UUID,
    request: UpdatePlayerNumberRequest,
    user: AuthorizedUser
):
    """Update a player's number (admin only)"""
    
    # Check admin permission via database
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if player exists
        player = await conn.fetchrow(
            "SELECT id, user_id, player_number FROM public.player_profiles WHERE id = $1",
            player_id
        )
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
        
        # Check if new player number is already taken
        existing_player = await conn.fetchrow(
            "SELECT id, first_name, last_name FROM public.player_profiles WHERE player_number = $1 AND id != $2",
            request.player_number, player_id
        )
        if existing_player:
            raise HTTPException(
                status_code=400, 
                detail=f"Player number {request.player_number} is already assigned to {existing_player['first_name']} {existing_player['last_name']}"
            )
        
        # Update the player number
        await conn.execute(
            "UPDATE public.player_profiles SET player_number = $1, updated_at = NOW() WHERE id = $2",
            request.player_number, player_id
        )
        
        # Log the change (optional - could add audit table later)
        print(f"Admin {user.user_id} updated player {player_id} number from {player['player_number']} to {request.player_number}. Reason: {request.reason}")
        
        # Return updated profile
        profile_row = await conn.fetchrow(
            """
            SELECT p.*, c.name as chapter_name
            FROM public.player_profiles p
            JOIN public.chapters c ON p.chapter_id = c.id
            WHERE p.id = $1
            """,
            player_id
        )
        
        # Use email from profile if available, otherwise fall back to user token email
        email = profile_row['email'] or getattr(user, 'email', None)
        
        return PlayerProfile(
            id=profile_row['id'],
            user_id=profile_row['user_id'],
            first_name=profile_row['first_name'],
            last_name=profile_row['last_name'],
            phone_number=profile_row['phone_number'],
            emergency_contact_name=profile_row['emergency_contact_name'],
            emergency_contact_phone=profile_row['emergency_contact_phone'],
            chapter_id=profile_row['chapter_id'],
            chapter_name=profile_row['chapter_name'],
            player_number=profile_row['player_number'],
            candles_available=profile_row['candles_available'],
            email=email,
            created_at=profile_row['created_at'],
            updated_at=profile_row['updated_at']
        )
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating player number: {e}")
        raise HTTPException(status_code=500, detail="Failed to update player number")
    finally:
        await conn.close()

@router.get("/debug/user-info")
async def get_current_user_info(user: AuthorizedUser):
    """Debug endpoint to check current user ID and admin status"""
    # First let's see what attributes are available
    available_attrs = [attr for attr in dir(user) if not attr.startswith('_')]
    
    # Try different possible ID fields
    user_id = None
    if hasattr(user, 'id'):
        user_id = user.id
    elif hasattr(user, 'sub'):
        user_id = user.sub
    
    # Get email value
    email_value = getattr(user, 'email', 'not_available')
    
    conn = await get_database_connection()
    try:
        # Check if user has a profile
        profile_row = None
        if user_id:
            profile_row = await conn.fetchrow(
                "SELECT id FROM public.player_profiles WHERE user_id = $1",
                user_id
            )
        
        profile_exists = profile_row is not None
        
        # Check admin status using role-based permissions (same logic as check_admin_permission but return boolean)
        admin_status = False
        if profile_exists:
            admin_check = await conn.fetchval(
                """
                SELECT EXISTS(
                    SELECT 1 FROM player_profiles pp
                    JOIN player_roles pr ON pp.id = pr.player_profile_id
                    JOIN role_permissions rp ON pr.role_id = rp.role_id
                    JOIN permissions p ON rp.permission_id = p.id
                    WHERE pp.user_id = $1 
                    AND p.name IN ('manage_players', 'view_admin_panel', 'manage_roles')
                )
                """,
                user_id
            )
            admin_status = bool(admin_check)
        
        return {
            "available_attributes": available_attrs,
            "user_id": user_id,
            "user_sub": user.sub if hasattr(user, 'sub') else 'not_available',
            "user_id_attr": getattr(user, 'user_id', 'not_available'),
            "email": email_value,
            "is_admin": admin_status,
            "has_profile": profile_exists
        }
    finally:
        await conn.close()

@router.get("/my/permissions")
async def get_my_permissions(user: AuthorizedUser):
    """Get current user's roles and permissions"""
    conn = await get_database_connection()
    try:
        # First check if user has a profile
        profile_row = await conn.fetchrow(
            "SELECT id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        
        if not profile_row:
            return {
                "hasProfile": False,
                "isAdmin": False,
                "roles": [],
                "permissions": []
            }
        
        # Get user's roles with their permissions
        roles_data = await conn.fetch(
            """
            SELECT 
                r.id as role_id,
                r.name as role_name,
                r.description as role_description,
                r.is_system_role,
                p.name as permission_name
            FROM public.player_roles pr
            JOIN public.roles r ON pr.role_id = r.id
            LEFT JOIN public.role_permissions rp ON r.id = rp.role_id
            LEFT JOIN public.permissions p ON rp.permission_id = p.id
            WHERE pr.player_profile_id = $1
            ORDER BY r.name, p.name
            """,
            profile_row['id']
        )
        
        # Group by roles and collect permissions
        roles_dict = {}
        all_permissions = set()
        
        for row in roles_data:
            role_id = str(row['role_id'])
            if role_id not in roles_dict:
                roles_dict[role_id] = {
                    "id": role_id,
                    "name": row['role_name'],
                    "description": row['role_description'],
                    "is_system_role": row['is_system_role'],
                    "permissions": []
                }
            
            if row['permission_name']:
                roles_dict[role_id]['permissions'].append(row['permission_name'])
                all_permissions.add(row['permission_name'])
        
        # Check admin status using role-based permissions
        admin_permissions = {'manage_players', 'view_admin_panel', 'manage_roles'}
        is_admin = bool(admin_permissions.intersection(all_permissions))
        
        return {
            "hasProfile": True,
            "isAdmin": is_admin,
            "roles": list(roles_dict.values()),
            "permissions": sorted(list(all_permissions))
        }
        
    except Exception as e:
        print(f"Error getting user permissions: {e}")
        # Return safe fallback that won't break the UI
        return {
            "hasProfile": False,
            "isAdmin": False,
            "roles": [],
            "permissions": []
        }
    finally:
        await conn.close()
