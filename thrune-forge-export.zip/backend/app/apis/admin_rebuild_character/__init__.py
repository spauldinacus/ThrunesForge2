from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from uuid import UUID
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
import json

router = APIRouter(prefix="/admin")

async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
            )
            """,
            user.sub
        )
        
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin permission required")
    finally:
        await conn.close()

@router.post("/characters/{character_id}/rebuild")
async def rebuild_character(character_id: UUID, user: AuthorizedUser) -> dict:
    """
    Resets a character to a clean state for rebuilding:
    - Removes all skills
    - Removes secondary/tertiary archetypes
    - Resets body/stamina to heritage base
    - Resets XP spent
    """
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        async with conn.transaction():
            # Get character's heritage info to reset stats correctly
            # We need to know the base_body and base_stamina of the current heritage
            row = await conn.fetchrow("""
                SELECT h.base_body, h.base_stamina 
                FROM characters c
                JOIN heritages h ON c.heritage_id = h.id
                WHERE c.id = $1
            """, character_id)
            
            if not row:
                raise HTTPException(status_code=404, detail="Character or Heritage not found")
            
            base_body = row['base_body']
            base_stamina = row['base_stamina']
            
            # Update character
            # Resets skills, extra archetypes, and stats to base
            # Preserves heritage_id, culture_id, archetype_id
            # Delete all spending and refund transactions to align ledger with clean slate
            await conn.execute("""
                DELETE FROM xp_transactions 
                WHERE character_id = $1 
                AND transaction_type IN (
                    'skill_purchase', 'skill_refund',
                    'body_purchase', 'body_refund',
                    'stamina_purchase', 'stamina_refund',
                    'archetype_purchase', 'archetype_refund'
                )
            """, character_id)

            await conn.execute("""
                UPDATE characters 
                SET 
                    selected_skills = '{}'::jsonb,
                    skills_bitwise = 0,
                    secondary_archetype_id = NULL,
                    tertiary_archetype_id = NULL,
                    body = $2,
                    stamina = $3,
                    xp_spent = 0,
                    xp_available = xp_total,
                    updated_at = NOW()
                WHERE id = $1
            """, character_id, base_body, base_stamina)

            await log_admin_action(
                performed_by_user_id=user.sub,
                action_type="character",
                action="rebuild",
                entity_id=str(character_id),
                entity_type="character",
                details={"reason": "Admin Rebuild"}
            )
            
            return {"message": "Character rebuilt successfully", "character_id": str(character_id)}

    except HTTPException:
        raise
    except Exception as e:
        print(f"Error rebuilding character: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if conn and not conn.is_closed():
            await conn.close()
