"""
Analytics API for admin dashboard metrics and insights.
"""

from fastapi import APIRouter, Query
from pydantic import BaseModel
from datetime import datetime, timezone, timedelta
from typing import Optional
import asyncpg
import os
from app.env import Mode, mode
from app.libs.analytics_helpers import (
    get_total_characters_count,
    get_recent_attendance_rate,
    get_total_xp_distributed,
)

router = APIRouter(prefix="/analytics")


class AnalyticsOverview(BaseModel):
    """High-level KPI metrics for analytics hub page."""
    total_corruption: int
    total_characters: int
    total_deaths: int
    attendance_rate: float
    total_xp_distributed: int
    total_events: int
    last_updated: datetime


class SkillPopularity(BaseModel):
    """Skill popularity metrics."""
    skill_id: str
    skill_name: str
    character_count: int
    percentage: float


class OptionDistribution(BaseModel):
    """Distribution of archetype/heritage/culture."""
    id: str
    name: str
    count: int
    percentage: float


class BuildCombination(BaseModel):
    """Combination of build options."""
    combination: str
    count: int
    percentage: float
    details: dict  # Contains IDs and names of components


class SkillSynergy(BaseModel):
    """Skill pair synergy."""
    skill1_id: str
    skill1_name: str
    skill2_id: str
    skill2_name: str
    pair_count: int

class OrphanedOption(BaseModel):
    """Unused option."""
    type: str  # 'archetype', 'heritage', 'culture', or 'skill'
    id: str
    name: str

class StatDistribution(BaseModel):
    """Distribution of a stat value."""
    value: int  # The stat value (e.g., 0, 1, 2, 3...)
    count: int  # Number of characters with this value

class CharacterBuildsAnalytics(BaseModel):
    """Character builds analytics response."""
    # Popularity rankings
    top_skills: list[SkillPopularity]
    least_popular_skills: list[SkillPopularity]
    all_skills: list[SkillPopularity]
    archetype_distribution: list[OptionDistribution]
    heritage_distribution: list[OptionDistribution]
    culture_distribution: list[OptionDistribution]
    orphaned_options: list[OrphanedOption]
    
    # Build combinations
    top_archetype_heritage_combos: list[BuildCombination]
    top_archetype_culture_combos: list[BuildCombination]
    top_heritage_culture_combos: list[BuildCombination]
    top_trifecta_combos: list[BuildCombination]
    
    # Skill patterns
    skill_distribution: dict  # {"primary": count, "secondary": count, "other": count}
    skill_synergies: list[SkillSynergy]
    
    # Metadata
    total_characters_analyzed: int
    average_body: float
    average_stamina: float
    body_distribution: list[StatDistribution]
    stamina_distribution: list[StatDistribution]
    last_updated: datetime


class XPBracketDistribution(BaseModel):
    """Player count by XP bracket."""
    bracket: str
    player_count: int
    percentage: float


class TopXPEarner(BaseModel):
    """Top XP earner."""
    player_id: str
    player_name: str
    player_number: str
    total_xp: int


class XPSpendingCategory(BaseModel):
    """XP spending by category."""
    category: str
    total_xp: int
    percentage: float


class MonthlyXPTrend(BaseModel):
    """Monthly XP distribution trend."""
    month: str
    year: int
    total_xp: int
    candle_xp: int
    event_xp: int


class CandleMetrics(BaseModel):
    """Candle purchase metrics."""
    total_candles_purchased: int
    purchase_count: int
    avg_candles_per_purchase: float
    players_who_purchased: int
    total_players: int
    purchase_percentage: float


class XPEconomyAnalytics(BaseModel):
    """XP economy analytics response."""
    # Distribution metrics
    xp_brackets: list[XPBracketDistribution]
    average_xp_per_player: float
    median_xp_per_player: float
    top_earners: list[TopXPEarner]
    
    # Spending patterns
    spending_by_category: list[XPSpendingCategory]
    avg_xp_spent_per_character: float
    skill_type_spending: dict  # {"primary": x, "secondary": y, "other": z}
    
    # Earning trends
    monthly_xp_trend: list[MonthlyXPTrend]
    avg_xp_per_event: float
    
    # Candle economy
    candle_metrics: CandleMetrics
    
    # Metadata
    total_characters_analyzed: int
    last_updated: datetime


@router.get("/overview")
async def get_analytics_overview() -> AnalyticsOverview:
    """
    Get high-level KPI metrics for the analytics hub page.
    
    Returns:
        AnalyticsOverview with current system metrics
    """
    # Get database connection string based on environment
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    # Connect to database and gather metrics
    conn = await asyncpg.connect(db_url)
    
    try:
        # Gather all metrics
        total_characters = await get_total_characters_count(conn, active_only=True)
        attendance_rate = await get_recent_attendance_rate(conn, event_count=5)
        total_xp = await get_total_xp_distributed(conn)
        
        # Get total corruption across all active characters
        total_corruption = await conn.fetchval("""
            SELECT COALESCE(SUM(corruption), 0)
            FROM characters
            WHERE retired = false
        """)
        
        # Get total deaths across all characters
        total_deaths = await conn.fetchval("""
            SELECT COALESCE(SUM(deaths), 0)
            FROM characters
            WHERE retired = false
        """)
        
        # Get total events count (completed or scheduled only, exclude cancelled)
        total_events = await conn.fetchval("""
            SELECT COUNT(*) FROM events
            WHERE status IN ('completed', 'scheduled')
        """)
        
        return AnalyticsOverview(
            total_corruption=total_corruption or 0,
            total_characters=total_characters,
            total_deaths=total_deaths or 0,
            attendance_rate=attendance_rate,
            total_xp_distributed=total_xp,
            total_events=total_events or 0,
            last_updated=datetime.now(timezone.utc),
        )
    finally:
        await conn.close()


@router.get("/character-builds")
async def get_character_builds_analytics(
    active_only: bool = Query(True, description="Only include active (non-retired) characters"),
    start_date: Optional[datetime] = Query(None, description="Start date for character creation filter"),
    end_date: Optional[datetime] = Query(None, description="End date for character creation filter")
) -> CharacterBuildsAnalytics:
    """
    Get comprehensive character build analytics including popularity, combinations, and patterns.
    
    Args:
        active_only: Filter to only active characters
        start_date: Optional start date for filtering
        end_date: Optional end date for filtering
    
    Returns:
        CharacterBuildsAnalytics with all build metrics
    """
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    
    try:
        # Build WHERE clause for character filtering
        where_clauses = []
        params = []
        param_count = 1
        
        if active_only:
            where_clauses.append("c.retired = false")
        
        if start_date:
            where_clauses.append(f"c.created_at >= ${param_count}")
            params.append(start_date)
            param_count += 1
        
        if end_date:
            where_clauses.append(f"c.created_at <= ${param_count}")
            params.append(end_date)
            param_count += 1
        
        where_clause = "WHERE " + " AND ".join(where_clauses) if where_clauses else ""
        
        # Get total character count
        total_chars_query = f"SELECT COUNT(*) FROM characters c {where_clause}"
        total_chars = await conn.fetchval(total_chars_query, *params)

        # Calculate average body and stamina
        stats_query = f"""
            SELECT 
                COALESCE(AVG(body), 0) as avg_body,
                COALESCE(AVG(stamina), 0) as avg_stamina
            FROM characters c
            {where_clause}
        """
        stats_row = await conn.fetchrow(stats_query, *params)

        
        # Get body distribution
        body_dist_query = f"""
            SELECT 
                body as value,
                COUNT(*) as count
            FROM characters c
            {where_clause}
            GROUP BY body
            ORDER BY body
        """
        body_dist_rows = await conn.fetch(body_dist_query, *params)
        body_distribution = [
            StatDistribution(value=int(row['value'] or 0), count=row['count'])
            for row in body_dist_rows
        ]
        
        # Get stamina distribution
        stamina_dist_query = f"""
            SELECT 
                stamina as value,
                COUNT(*) as count
            FROM characters c
            {where_clause}
            GROUP BY stamina
            ORDER BY stamina
        """
        stamina_dist_rows = await conn.fetch(stamina_dist_query, *params)
        stamina_distribution = [
            StatDistribution(value=int(row['value'] or 0), count=row['count'])
            for row in stamina_dist_rows
        ]
        
        if total_chars == 0:
            # Return empty analytics if no characters match
            return CharacterBuildsAnalytics(
                top_skills=[],
                all_skills=[],
                least_popular_skills=[],
                archetype_distribution=[],
                heritage_distribution=[],
                culture_distribution=[],
                orphaned_options=[],
                top_archetype_heritage_combos=[],
                top_archetype_culture_combos=[],
                top_heritage_culture_combos=[],
                top_trifecta_combos=[],
                skill_distribution={"primary": 0, "secondary": 0, "other": 0},
                skill_synergies=[],
                total_characters_analyzed=0,
                average_body=0.0,
                average_stamina=0.0,
                body_distribution=[],
                stamina_distribution=[],
                last_updated=datetime.now(timezone.utc)
            )
        
        skill_popularity_query = f"""
            WITH character_filter AS (
                SELECT id, selected_skills FROM characters c
                {where_clause}
            )
            SELECT 
                s.id::text,
                s.name,
                COUNT(DISTINCT cf.id) as char_count,
                ROUND((COUNT(DISTINCT cf.id)::float / NULLIF({total_chars}, 0)::float * 100)::numeric, 2) as percentage
            FROM skills s
            LEFT JOIN character_filter cf ON cf.selected_skills::jsonb @> jsonb_build_array(jsonb_build_object('skill_id', s.id::text))
            WHERE s.hidden = false
            GROUP BY s.id, s.name
            ORDER BY char_count DESC, s.name
        """
        
        skill_rows = await conn.fetch(skill_popularity_query, *params)
        
        all_skills = [
            SkillPopularity(
                skill_id=row['id'],
                skill_name=row['name'],
                character_count=row['char_count'],
                percentage=float(row['percentage'] or 0)
            )
            for row in skill_rows
        ]
        
        top_skills = all_skills[:10]
        least_popular_skills = [s for s in all_skills if s.character_count > 0][-5:]
        
        # === ARCHETYPE DISTRIBUTION ===
        archetype_dist_query = f"""
            SELECT 
                a.id::text,
                a.name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM archetypes a
            LEFT JOIN characters c ON c.archetype_id = a.id AND c.id IN (
                SELECT id FROM characters c {where_clause}
            )
            GROUP BY a.id, a.name
            ORDER BY count DESC, a.name
        """
        
        archetype_rows = await conn.fetch(archetype_dist_query, *params)
        archetype_distribution = [
            OptionDistribution(
                id=row['id'],
                name=row['name'],
                count=row['count'],
                percentage=float(row['percentage'] or 0)
            )
            for row in archetype_rows
        ]
        
        # === HERITAGE DISTRIBUTION ===
        heritage_dist_query = f"""
            SELECT 
                h.id::text,
                h.name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM heritages h
            LEFT JOIN characters c ON c.heritage_id = h.id AND c.id IN (
                SELECT id FROM characters c {where_clause}
            )
            GROUP BY h.id, h.name
            ORDER BY count DESC, h.name
        """
        
        heritage_rows = await conn.fetch(heritage_dist_query, *params)
        heritage_distribution = [
            OptionDistribution(
                id=row['id'],
                name=row['name'],
                count=row['count'],
                percentage=float(row['percentage'] or 0)
            )
            for row in heritage_rows
        ]
        
        # === CULTURE DISTRIBUTION ===
        culture_dist_query = f"""
            SELECT 
                cu.id::text,
                cu.name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM cultures cu
            LEFT JOIN characters c ON c.culture_id = cu.id AND c.id IN (
                SELECT id FROM characters c {where_clause}
            )
            GROUP BY cu.id, cu.name
            ORDER BY count DESC, cu.name
        """
        
        culture_rows = await conn.fetch(culture_dist_query, *params)
        culture_distribution = [
            OptionDistribution(
                id=row['id'],
                name=row['name'],
                count=row['count'],
                percentage=float(row['percentage'] or 0)
            )
            for row in culture_rows
        ]
        
        # === ORPHANED OPTIONS ===
        orphaned_options = []
        
        # Orphaned archetypes
        for arch in archetype_distribution:
            if arch.count == 0:
                orphaned_options.append(OrphanedOption(type="archetype", id=arch.id, name=arch.name))
        
        # Orphaned heritages
        for heritage in heritage_distribution:
            if heritage.count == 0:
                orphaned_options.append(OrphanedOption(type="heritage", id=heritage.id, name=heritage.name))
        
        # Orphaned cultures
        for culture in culture_distribution:
            if culture.count == 0:
                orphaned_options.append(OrphanedOption(type="culture", id=culture.id, name=culture.name))
        
        # Orphaned skills
        for skill in all_skills:
            if skill.character_count == 0:
                orphaned_options.append(OrphanedOption(type="skill", id=skill.skill_id, name=skill.skill_name))
        
        # === BUILD COMBINATIONS ===
        
        # Archetype + Heritage combinations
        arch_heritage_query = f"""
            SELECT 
                a.id::text as archetype_id,
                a.name as archetype_name,
                h.id::text as heritage_id,
                h.name as heritage_name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM characters c
            JOIN archetypes a ON c.archetype_id = a.id
            JOIN heritages h ON c.heritage_id = h.id
            {where_clause}
            GROUP BY a.id, a.name, h.id, h.name
            ORDER BY count DESC
            LIMIT 10
        """
        
        arch_heritage_rows = await conn.fetch(arch_heritage_query, *params)
        top_archetype_heritage_combos = [
            BuildCombination(
                combination=f"{row['archetype_name']} + {row['heritage_name']}",
                count=row['count'],
                percentage=float(row['percentage'] or 0),
                details={
                    "archetype_id": row['archetype_id'],
                    "archetype_name": row['archetype_name'],
                    "heritage_id": row['heritage_id'],
                    "heritage_name": row['heritage_name']
                }
            )
            for row in arch_heritage_rows
        ]
        
        # Archetype + Culture combinations
        arch_culture_query = f"""
            SELECT 
                a.id::text as archetype_id,
                a.name as archetype_name,
                cu.id::text as culture_id,
                cu.name as culture_name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM characters c
            JOIN archetypes a ON c.archetype_id = a.id
            JOIN cultures cu ON c.culture_id = cu.id
            {where_clause}
            GROUP BY a.id, a.name, cu.id, cu.name
            ORDER BY count DESC
            LIMIT 10
        """
        
        arch_culture_rows = await conn.fetch(arch_culture_query, *params)
        top_archetype_culture_combos = [
            BuildCombination(
                combination=f"{row['archetype_name']} + {row['culture_name']}",
                count=row['count'],
                percentage=float(row['percentage'] or 0),
                details={
                    "archetype_id": row['archetype_id'],
                    "archetype_name": row['archetype_name'],
                    "culture_id": row['culture_id'],
                    "culture_name": row['culture_name']
                }
            )
            for row in arch_culture_rows
        ]
        
        # Heritage + Culture combinations
        heritage_culture_query = f"""
            SELECT 
                h.id::text as heritage_id,
                h.name as heritage_name,
                cu.id::text as culture_id,
                cu.name as culture_name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM characters c
            JOIN heritages h ON c.heritage_id = h.id
            JOIN cultures cu ON c.culture_id = cu.id
            {where_clause}
            GROUP BY h.id, h.name, cu.id, cu.name
            ORDER BY count DESC
            LIMIT 10
        """
        
        heritage_culture_rows = await conn.fetch(heritage_culture_query, *params)
        top_heritage_culture_combos = [
            BuildCombination(
                combination=f"{row['heritage_name']} + {row['culture_name']}",
                count=row['count'],
                percentage=float(row['percentage'] or 0),
                details={
                    "heritage_id": row['heritage_id'],
                    "heritage_name": row['heritage_name'],
                    "culture_id": row['culture_id'],
                    "culture_name": row['culture_name']
                }
            )
            for row in heritage_culture_rows
        ]
        
        # Full trifecta combinations
        trifecta_query = f"""
            SELECT 
                a.id::text as archetype_id,
                a.name as archetype_name,
                h.id::text as heritage_id,
                h.name as heritage_name,
                cu.id::text as culture_id,
                cu.name as culture_name,
                COUNT(c.id) as count,
                ROUND((COUNT(c.id)::float / {total_chars}::float * 100)::numeric, 2) as percentage
            FROM characters c
            JOIN archetypes a ON c.archetype_id = a.id
            JOIN heritages h ON c.heritage_id = h.id
            JOIN cultures cu ON c.culture_id = cu.id
            {where_clause}
            GROUP BY a.id, a.name, h.id, h.name, cu.id, cu.name
            ORDER BY count DESC
            LIMIT 10
        """

        trifecta_rows = await conn.fetch(trifecta_query, *params)
        top_trifecta_combos = [
            BuildCombination(
                combination=f"{row['archetype_name']} + {row['heritage_name']} + {row['culture_name']}",
                count=row['count'],
                percentage=float(row['percentage'] or 0),
                details={
                    "archetype_id": row['archetype_id'],
                    "archetype_name": row['archetype_name'],
                    "heritage_id": row['heritage_id'],
                    "heritage_name": row['heritage_name'],
                    "culture_id": row['culture_id'],
                    "culture_name": row['culture_name']
                }
            )
            for row in trifecta_rows
        ]
        
        # === SKILL PATTERNS ===
        
        # For now, we'll provide simplified skill distribution
        # This would require more complex logic to determine primary/secondary/other based on archetype
        skill_distribution = {
            "primary": 0,
            "secondary": 0,
            "other": 0
        }
        
        # Skill synergies - skills commonly taken together
        skill_synergy_query = f"""
            WITH character_skills AS (
                SELECT 
                    c.id as character_id,
                    jsonb_array_elements(c.selected_skills) ->> 'id' as skill_id
                FROM characters c
                {where_clause}
            ),
            skill_pairs AS (
                SELECT 
                    cs1.skill_id as skill1_id,
                    cs2.skill_id as skill2_id,
                    COUNT(DISTINCT cs1.character_id) as pair_count
                FROM character_skills cs1
                JOIN character_skills cs2 ON cs1.character_id = cs2.character_id AND cs1.skill_id < cs2.skill_id
                GROUP BY cs1.skill_id, cs2.skill_id
                HAVING COUNT(DISTINCT cs1.character_id) >= 2
                ORDER BY pair_count DESC
                LIMIT 10
            )
            SELECT 
                sp.skill1_id,
                s1.name as skill1_name,
                sp.skill2_id,
                s2.name as skill2_name,
                sp.pair_count
            FROM skill_pairs sp
            JOIN skills s1 ON s1.id::text = sp.skill1_id
            JOIN skills s2 ON s2.id::text = sp.skill2_id
        """
        
        try:
            synergy_rows = await conn.fetch(skill_synergy_query, *params)
            skill_synergies = [
                SkillSynergy(
                    skill1_id=row['skill1_id'],
                    skill1_name=row['skill1_name'],
                    skill2_id=row['skill2_id'],
                    skill2_name=row['skill2_name'],
                    pair_count=row['pair_count']
                )
                for row in synergy_rows
            ]
        except Exception as e:
            print(f"Error calculating skill synergies: {e}")
            skill_synergies = []
        
        return CharacterBuildsAnalytics(
            top_skills=top_skills,
            all_skills=all_skills,  # ADD THIS LINE
            least_popular_skills=least_popular_skills,
            archetype_distribution=archetype_distribution,
            heritage_distribution=heritage_distribution,
            culture_distribution=culture_distribution,
            orphaned_options=orphaned_options,
            top_archetype_heritage_combos=top_archetype_heritage_combos[:10],
            top_archetype_culture_combos=top_archetype_culture_combos[:10],
            top_heritage_culture_combos=top_heritage_culture_combos[:10],
            top_trifecta_combos=top_trifecta_combos[:10],
            skill_distribution=skill_distribution,
            skill_synergies=skill_synergies[:10],
            total_characters_analyzed=total_chars,
            average_body=round(float(stats_row['avg_body']), 2),
            average_stamina=round(float(stats_row['avg_stamina']), 2),
            body_distribution=body_distribution,
            stamina_distribution=stamina_distribution,
            last_updated=datetime.now(timezone.utc)
        )
    finally:
        await conn.close()


@router.get("/xp-economy")
async def get_xp_economy_analytics(
    start_date: Optional[datetime] = Query(None, description="Start date for filtering"),
    end_date: Optional[datetime] = Query(None, description="End date for filtering")
) -> XPEconomyAnalytics:
    """
    Get comprehensive XP economy analytics including distribution, spending patterns,
    earning trends, and candle purchase metrics.
    
    Args:
        start_date: Optional start date for filtering transactions
        end_date: Optional end date for filtering transactions
    
    Returns:
        XPEconomyAnalytics with all XP economy metrics
    """
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    
    try:
        # === PLAYER XP DISTRIBUTION ===
        
        # Get all active players with their total XP
        player_xp_query = """
            SELECT 
                pp.id::text,
                pp.first_name || ' ' || pp.last_name as player_name,
                pp.player_number,
                COALESCE(SUM(c.xp_total), 0) as total_xp
            FROM player_profiles pp
            LEFT JOIN characters c ON c.player_profile_id = pp.id AND c.retired = false
            GROUP BY pp.id, pp.first_name, pp.last_name, pp.player_number
            HAVING COALESCE(SUM(c.xp_total), 0) > 0
            ORDER BY total_xp DESC
        """
        
        player_xp_rows = await conn.fetch(player_xp_query)
        
        # Calculate XP brackets
        brackets = {
            "0-50": 0,
            "51-100": 0,
            "101-200": 0,
            "201-300": 0,
            "300+": 0
        }
        
        total_xp_sum = 0
        xp_values = []
        
        for row in player_xp_rows:
            xp = row['total_xp']
            total_xp_sum += xp
            xp_values.append(xp)
            
            if xp <= 50:
                brackets["0-50"] += 1
            elif xp <= 100:
                brackets["51-100"] += 1
            elif xp <= 200:
                brackets["101-200"] += 1
            elif xp <= 300:
                brackets["201-300"] += 1
            else:
                brackets["300+"] += 1
        
        total_players = len(player_xp_rows)
        avg_xp = total_xp_sum / total_players if total_players > 0 else 0
        
        # Calculate median
        if xp_values:
            sorted_xp = sorted(xp_values)
            mid = len(sorted_xp) // 2
            median_xp = sorted_xp[mid] if len(sorted_xp) % 2 == 1 else (sorted_xp[mid - 1] + sorted_xp[mid]) / 2
        else:
            median_xp = 0
        
        xp_brackets = [
            XPBracketDistribution(
                bracket=bracket,
                player_count=count,
                percentage=round((count / total_players * 100) if total_players > 0 else 0, 2)
            )
            for bracket, count in brackets.items()
        ]
        
        # Top 10 earners
        top_earners = [
            TopXPEarner(
                player_id=row['id'],
                player_name=row['player_name'],
                player_number=row['player_number'],
                total_xp=row['total_xp']
            )
            for row in player_xp_rows[:10]
        ]
        
        # === XP SPENDING PATTERNS ===
        
        # Build date filter for transactions
        date_filter = ""
        date_params = []
        if start_date:
            date_filter += " AND xt.created_at >= $1"
            date_params.append(start_date)
        if end_date:
            param_num = len(date_params) + 1
            date_filter += f" AND xt.created_at <= ${param_num}"
            date_params.append(end_date)
        
        # Spending by category
        spending_query = f"""
            SELECT 
                CASE 
                    WHEN transaction_type IN ('skill_purchase') THEN 'Skills'
                    WHEN transaction_type IN ('body_purchase', 'stamina_purchase') THEN 'Attributes'
                    WHEN transaction_type IN ('archetype_purchase') THEN 'Archetypes'
                    ELSE 'Other'
                END as category,
                SUM(ABS(amount)) as total_xp
            FROM xp_transactions xt
            WHERE amount < 0 {date_filter}
            GROUP BY category
            ORDER BY total_xp DESC
        """
        
        spending_rows = await conn.fetch(spending_query, *date_params)
        total_spent = sum(row['total_xp'] for row in spending_rows)
        
        spending_by_category = [
            XPSpendingCategory(
                category=row['category'],
                total_xp=row['total_xp'],
                percentage=round((row['total_xp'] / total_spent * 100) if total_spent > 0 else 0, 2)
            )
            for row in spending_rows
        ]
        
        # Average XP spent per character
        avg_spent_query = """
            SELECT AVG(xp_spent) as avg_spent
            FROM characters
            WHERE retired = false
        """
        avg_spent = await conn.fetchval(avg_spent_query)
        avg_xp_spent_per_character = float(avg_spent or 0)
        
        # Skill type spending (simplified for now)
        skill_type_spending = {
            "primary": 0,
            "secondary": 0,
            "other": 0
        }
        
        # === EARNING TRENDS ===
        
        # Monthly XP distribution for last 12 months
        monthly_trend_query = f"""
            WITH monthly_xp AS (
                SELECT 
                    DATE_TRUNC('month', xt.created_at) as month,
                    SUM(amount) FILTER (WHERE amount > 0) as total_xp,
                    SUM(amount) FILTER (WHERE amount > 0 AND reason LIKE '%candle%') as candle_xp,
                    SUM(amount) FILTER (WHERE amount > 0 AND transaction_type = 'event_reward') as event_xp
                FROM xp_transactions xt
                WHERE xt.created_at >= NOW() - INTERVAL '12 months'
                AND amount > 0
                GROUP BY month
                ORDER BY month DESC
            )
            SELECT 
                TO_CHAR(month, 'Mon') as month_name,
                EXTRACT(YEAR FROM month)::int as year,
                COALESCE(total_xp, 0) as total_xp,
                COALESCE(candle_xp, 0) as candle_xp,
                COALESCE(event_xp, 0) as event_xp
            FROM monthly_xp
        """
        
        monthly_rows = await conn.fetch(monthly_trend_query)
        monthly_xp_trend = [
            MonthlyXPTrend(
                month=row['month_name'],
                year=row['year'],
                total_xp=row['total_xp'],
                candle_xp=row['candle_xp'],
                event_xp=row['event_xp']
            )
            for row in monthly_rows
        ]
        
        # Average XP per event
        avg_event_xp_query = """
            SELECT 
                COALESCE(AVG(event_xp), 0) as avg_xp
            FROM (
                SELECT 
                    SUM(ticket_xp + candle_xp) as event_xp
                FROM rsvps
                WHERE attendance_status = 'attended'
                GROUP BY event_id
            ) event_totals
        """
        avg_event_xp = await conn.fetchval(avg_event_xp_query)
        avg_xp_per_event = float(avg_event_xp or 0)
        
        # === CANDLE ECONOMY ===
        
        candle_stats_query = """
            SELECT 
                COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) as total_purchased,
                COUNT(CASE WHEN amount > 0 THEN 1 END) as purchase_count,
                COALESCE(AVG(CASE WHEN amount > 0 THEN amount END), 0) as avg_per_purchase,
                COUNT(DISTINCT CASE WHEN amount > 0 THEN player_profile_id END) as buyers
            FROM candle_transactions
        """
        
        candle_row = await conn.fetchrow(candle_stats_query)
        total_players_count = await conn.fetchval("SELECT COUNT(*) FROM player_profiles")
        
        candle_metrics = CandleMetrics(
            total_candles_purchased=candle_row['total_purchased'],
            purchase_count=candle_row['purchase_count'],
            avg_candles_per_purchase=round(float(candle_row['avg_per_purchase'] or 0), 2),
            players_who_purchased=candle_row['buyers'],
            total_players=total_players_count,
            purchase_percentage=round((candle_row['buyers'] / total_players_count * 100) if total_players_count > 0 else 0, 2)
        )
        
        # Total characters analyzed
        total_chars = await conn.fetchval("SELECT COUNT(*) FROM characters WHERE retired = false")
        
        return XPEconomyAnalytics(
            xp_brackets=xp_brackets,
            average_xp_per_player=round(avg_xp, 2),
            median_xp_per_player=round(median_xp, 2),
            top_earners=top_earners,
            spending_by_category=spending_by_category,
            avg_xp_spent_per_character=round(avg_xp_spent_per_character, 2),
            skill_type_spending=skill_type_spending,
            monthly_xp_trend=monthly_xp_trend,
            avg_xp_per_event=round(avg_xp_per_event, 2),
            candle_metrics=candle_metrics,
            total_characters_analyzed=total_chars,
            last_updated=datetime.now(timezone.utc)
        )
    finally:
        await conn.close()


class AttendanceTrend(BaseModel):
    """Monthly attendance trend."""
    month: str
    year: int
    event_count: int
    total_attendance: int
    avg_attendance: float


class UpcomingEventRSVP(BaseModel):
    """Upcoming event with RSVP counts."""
    event_id: str
    title: str
    starts_at: datetime
    chapter_name: str
    rsvp_count: int
    going_count: int


class RSVPAccuracyByEvent(BaseModel):
    """RSVP accuracy for a specific event."""
    event_id: str
    title: str
    event_date: datetime
    rsvp_yes_count: int
    actual_attended: int
    accuracy_rate: float


class EventRanking(BaseModel):
    """Event ranking by attendance."""
    event_id: str
    title: str
    event_date: datetime
    chapter_name: str
    attendance_count: int


class ChapterComparison(BaseModel):
    """Chapter performance comparison."""
    chapter_id: str
    chapter_name: str
    event_count: int
    avg_attendance: float
    rsvp_accuracy: float

class XPPurchaseMetrics(BaseModel):
    """XP purchase statistics."""
    total_ticket_xp_purchased: int
    total_candle_xp_purchased: int
    total_xp_purchased: int
    avg_ticket_xp_per_event: float
    avg_candle_xp_per_event: float
    players_purchasing_ticket_xp: int
    players_purchasing_candle_xp: int
    candles_spent_on_xp: int


class MonthlyXPPurchaseTrend(BaseModel): 
    """Monthly XP purchase trend."""
    month: str
    year: int
    ticket_xp: int
    candle_xp: int
    total_xp_purchased: int

class EventPerformanceAnalytics(BaseModel):
    """Event performance analytics response."""
    # Attendance trends
    total_events: int
    total_past_events: int
    monthly_trends: list[AttendanceTrend]
    avg_attendance_per_event: float
    attendance_trend: str  # "growing", "stable", "declining"
    upcoming_events: list[UpcomingEventRSVP]
    
    # RSVP accuracy
    overall_rsvp_accuracy: float
    no_show_rate: float
    surprise_attendance_rate: float
    rsvp_accuracy_by_event: list[RSVPAccuracyByEvent]
    
    # Event rankings
    most_attended_events: list[EventRanking]
    least_attended_events: list[EventRanking]
    
    # Chapter comparison
    chapter_comparisons: list[ChapterComparison]

    # XP Purchase Economics
    xp_purchase_metrics: XPPurchaseMetrics
    monthly_xp_purchase_trend: list[MonthlyXPPurchaseTrend]
    
    # Metadata
    last_updated: datetime


@router.get("/event-performance")
async def get_event_performance_analytics(
    start_date: Optional[datetime] = Query(None, description="Start date for filtering"),
    end_date: Optional[datetime] = Query(None, description="End date for filtering"),
    chapter_id: Optional[str] = Query(None, description="Filter by specific chapter")
) -> EventPerformanceAnalytics:
    """
    Get comprehensive event performance analytics including attendance trends,
    RSVP accuracy, event rankings, and chapter comparisons.
    
    Args:
        start_date: Optional start date for filtering events
        end_date: Optional end date for filtering events
        chapter_id: Optional chapter ID to filter by
    
    Returns:
        EventPerformanceAnalytics with all event performance metrics
    """
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    
    try:
        # Build date and chapter filters
        date_filter = ""
        filter_params = []
        if start_date:
            date_filter += " AND e.starts_at >= $1"
            filter_params.append(start_date)
        if end_date:
            param_num = len(filter_params) + 1
            date_filter += f" AND e.starts_at <= ${param_num}"
            filter_params.append(end_date)
        
        chapter_filter = ""
        if chapter_id:
            param_num = len(filter_params) + 1
            chapter_filter = f" AND e.chapter_id = ${param_num}"
            filter_params.append(chapter_id)
        
        # === ATTENDANCE TRENDS ===
        
        # Total events count
        total_events_query = f"""
            SELECT COUNT(*) FROM events e WHERE 1=1 {chapter_filter}
        """
        total_events = await conn.fetchval(
            total_events_query,
            *([chapter_id] if chapter_id else [])
        )
        
        # Past events count
        past_events_query = f"""
            SELECT COUNT(*) 
            FROM events e 
            WHERE e.starts_at < NOW() {chapter_filter}
        """
        total_past_events = await conn.fetchval(
            past_events_query,
            *([chapter_id] if chapter_id else [])
        )
        
        # Monthly trends (last 12 months)
        monthly_trends_query = """
            SELECT 
                TO_CHAR(DATE_TRUNC('month', e.starts_at), 'Mon') as month,
                EXTRACT(YEAR FROM e.starts_at)::int as year,
                COUNT(DISTINCT e.id) as event_count,
                COUNT(DISTINCT CASE WHEN r.attendance_status = 'attended' THEN r.id END) as total_attendance,
                COALESCE(AVG(event_attendance.attended), 0) as avg_attendance
            FROM events e
            LEFT JOIN rsvps r ON r.event_id = e.id
            LEFT JOIN (
                SELECT 
                    event_id,
                    COUNT(DISTINCT CASE WHEN attendance_status = 'attended' THEN id END) as attended
                FROM rsvps
                GROUP BY event_id
            ) event_attendance ON event_attendance.event_id = e.id
            WHERE e.starts_at >= NOW() - INTERVAL '12 months'
            AND e.starts_at < NOW()
            GROUP BY DATE_TRUNC('month', e.starts_at), EXTRACT(YEAR FROM e.starts_at)
            ORDER BY DATE_TRUNC('month', e.starts_at) DESC
        """
        
        monthly_rows = await conn.fetch(monthly_trends_query)
        monthly_trends = [
            AttendanceTrend(
                month=row['month'],
                year=row['year'],
                event_count=row['event_count'],
                total_attendance=row['total_attendance'],
                avg_attendance=round(float(row['avg_attendance'] or 0), 2)
            )
            for row in monthly_rows
        ]
        
        # Average attendance per event
        avg_attendance_query = f"""
            SELECT COALESCE(AVG(attended), 0) as avg_attendance
            FROM (
                SELECT 
                    e.id,
                    COUNT(DISTINCT CASE WHEN r.attendance_status = 'attended' THEN r.id END) as attended
                FROM events e
                LEFT JOIN rsvps r ON r.event_id = e.id
                WHERE e.starts_at < NOW() {chapter_filter}
                GROUP BY e.id
            ) event_stats
        """
        avg_attendance = await conn.fetchval(
            avg_attendance_query,
            *([chapter_id] if chapter_id else [])
        )
        avg_attendance_per_event = round(float(avg_attendance or 0), 2)
        
        # Attendance trend calculation (compare last 3 months to previous 3)
        attendance_trend = "stable"
        if len(monthly_trends) >= 6:
            recent_avg = sum(t.avg_attendance for t in monthly_trends[:3]) / 3
            previous_avg = sum(t.avg_attendance for t in monthly_trends[3:6]) / 3
            if recent_avg > previous_avg * 1.1:
                attendance_trend = "growing"
            elif recent_avg < previous_avg * 0.9:
                attendance_trend = "declining"
        
        # Upcoming events (next 30 days)
        upcoming_events_query = f"""
            SELECT 
                e.id::text,
                e.title,
                e.starts_at,
                c.name as chapter_name,
                COUNT(DISTINCT r.id) as rsvp_count,
                COUNT(DISTINCT CASE WHEN r.status = 'going' THEN r.id END) as going_count
            FROM events e
            LEFT JOIN chapters c ON c.id = e.chapter_id
            LEFT JOIN rsvps r ON r.event_id = e.id
            WHERE e.starts_at >= NOW()
            AND e.starts_at <= NOW() + INTERVAL '30 days' {chapter_filter}
            GROUP BY e.id, e.title, e.starts_at, c.name
            ORDER BY e.starts_at ASC
        """
        
        upcoming_rows = await conn.fetch(
            upcoming_events_query,
            *([chapter_id] if chapter_id else [])
        )
        upcoming_events = [
            UpcomingEventRSVP(
                event_id=row['id'],
                title=row['title'],
                starts_at=row['starts_at'],
                chapter_name=row['chapter_name'] or "Unknown",
                rsvp_count=row['rsvp_count'],
                going_count=row['going_count']
            )
            for row in upcoming_rows
        ]
        
        # === RSVP ACCURACY ===
        
        # Overall RSVP accuracy (RSVPed yes and actually attended / RSVPed yes)
        rsvp_accuracy_query = f"""
            SELECT 
                COUNT(CASE WHEN r.status = 'going' THEN 1 END) as rsvp_yes,
                COUNT(CASE WHEN r.status = 'going' AND r.attendance_status = 'attended' THEN 1 END) as attended,
                COUNT(CASE WHEN r.status != 'going' AND r.attendance_status = 'attended' THEN 1 END) as surprise_attendance,
                COUNT(CASE WHEN r.status = 'going' AND r.attendance_status != 'attended' THEN 1 END) as no_shows
            FROM rsvps r
            JOIN events e ON e.id = r.event_id
            WHERE e.starts_at < NOW() {chapter_filter}
        """
        
        rsvp_stats = await conn.fetchrow(
            rsvp_accuracy_query,
            *([chapter_id] if chapter_id else [])
        )
        
        rsvp_yes = rsvp_stats['rsvp_yes'] or 0
        attended = rsvp_stats['attended'] or 0
        surprise_attendance = rsvp_stats['surprise_attendance'] or 0
        no_shows = rsvp_stats['no_shows'] or 0
        
        overall_rsvp_accuracy = round((attended / rsvp_yes * 100) if rsvp_yes > 0 else 0, 2)
        no_show_rate = round((no_shows / rsvp_yes * 100) if rsvp_yes > 0 else 0, 2)
        surprise_attendance_rate = round((surprise_attendance / (attended + surprise_attendance) * 100) if (attended + surprise_attendance) > 0 else 0, 2)
        
        # RSVP accuracy by event
        rsvp_by_event_query = f"""
            SELECT 
                e.id::text,
                e.title,
                e.starts_at,
                COUNT(CASE WHEN r.status = 'going' THEN 1 END) as rsvp_yes,
                COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attended
            FROM events e
            LEFT JOIN rsvps r ON r.event_id = e.id
            WHERE e.starts_at < NOW() {chapter_filter}
            GROUP BY e.id, e.title, e.starts_at
            ORDER BY e.starts_at DESC
            LIMIT 20
        """
        
        rsvp_event_rows = await conn.fetch(
            rsvp_by_event_query,
            *([chapter_id] if chapter_id else [])
        )
        rsvp_accuracy_by_event = [
            RSVPAccuracyByEvent(
                event_id=row['id'],
                title=row['title'],
                event_date=row['starts_at'],
                rsvp_yes_count=row['rsvp_yes'],
                actual_attended=row['attended'],
                accuracy_rate=round((row['attended'] / row['rsvp_yes'] * 100) if row['rsvp_yes'] > 0 else 0, 2)
            )
            for row in rsvp_event_rows
        ]
        
        # === EVENT RANKINGS ===
        
        # Most attended events
        most_attended_query = f"""
            SELECT 
                e.id::text,
                e.title,
                e.starts_at,
                c.name as chapter_name,
                COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attendance
            FROM events e
            LEFT JOIN chapters c ON c.id = e.chapter_id
            LEFT JOIN rsvps r ON r.event_id = e.id
            WHERE e.starts_at < NOW() {chapter_filter}
            GROUP BY e.id, e.title, e.starts_at, c.name
            ORDER BY attendance DESC
            LIMIT 10
        """
        
        most_attended_rows = await conn.fetch(
            most_attended_query,
            *([chapter_id] if chapter_id else [])
        )
        most_attended_events = [
            EventRanking(
                event_id=row['id'],
                title=row['title'],
                event_date=row['starts_at'],
                chapter_name=row['chapter_name'] or "Unknown",
                attendance_count=row['attendance']
            )
            for row in most_attended_rows
        ]
        
        # Least attended events
        least_attended_query = f"""
            SELECT 
                e.id::text,
                e.title,
                e.starts_at,
                c.name as chapter_name,
                COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attendance
            FROM events e
            LEFT JOIN chapters c ON c.id = e.chapter_id
            LEFT JOIN rsvps r ON r.event_id = e.id
            WHERE e.starts_at < NOW() {chapter_filter}
            GROUP BY e.id, e.title, e.starts_at, c.name
            ORDER BY attendance ASC
            LIMIT 10
        """
        
        least_attended_rows = await conn.fetch(
            least_attended_query,
            *([chapter_id] if chapter_id else [])
        )
        least_attended_events = [
            EventRanking(
                event_id=row['id'],
                title=row['title'],
                event_date=row['starts_at'],
                chapter_name=row['chapter_name'] or "Unknown",
                attendance_count=row['attendance']
            )
            for row in least_attended_rows
        ]
        
        # === CHAPTER COMPARISON ===
        
        chapter_comparison_query = """
            SELECT 
                c.id::text,
                c.name,
                COUNT(DISTINCT e.id) as event_count,
                COALESCE(AVG(event_stats.attendance), 0) as avg_attendance,
                COALESCE(AVG(event_stats.accuracy), 0) as avg_accuracy
            FROM chapters c
            LEFT JOIN events e ON e.chapter_id = c.id AND e.starts_at < NOW()
            LEFT JOIN (
                SELECT 
                    e.id,
                    COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attendance,
                    CASE 
                        WHEN COUNT(CASE WHEN r.status = 'going' THEN 1 END) > 0 
                        THEN (COUNT(CASE WHEN r.status = 'going' AND r.attendance_status = 'attended' THEN 1 END)::float / 
                              COUNT(CASE WHEN r.status = 'going' THEN 1 END) * 100)
                        ELSE 0
                    END as accuracy
                FROM events e
                LEFT JOIN rsvps r ON r.event_id = e.id
                WHERE e.starts_at < NOW()
                GROUP BY e.id
            ) event_stats ON event_stats.id = e.id
            GROUP BY c.id, c.name
            ORDER BY event_count DESC
        """
        
        chapter_rows = await conn.fetch(chapter_comparison_query)
        chapter_comparisons = [
            ChapterComparison(
                chapter_id=row['id'],
                chapter_name=row['name'],
                event_count=row['event_count'],
                avg_attendance=round(float(row['avg_attendance'] or 0), 2),
                rsvp_accuracy=round(float(row['avg_accuracy'] or 0), 2)
            )
            for row in chapter_rows
        ]

                # === XP PURCHASE METRICS ===
        
        # Overall XP purchase statistics
        xp_purchase_stats_query = f"""
            SELECT 
                COALESCE(SUM(ticket_xp), 0) as total_ticket_xp,
                COALESCE(SUM(candle_xp), 0) as total_candle_xp,
                COUNT(DISTINCT CASE WHEN ticket_xp > 0 THEN user_id END) as ticket_xp_buyers,
                COUNT(DISTINCT CASE WHEN candle_xp > 0 THEN user_id END) as candle_xp_buyers
            FROM rsvps r
            JOIN events e ON e.id = r.event_id
            WHERE e.starts_at < NOW() {chapter_filter}
        """
        
        xp_stats = await conn.fetchrow(
            xp_purchase_stats_query,
            *([chapter_id] if chapter_id else [])
        )
        
        total_ticket_xp = xp_stats['total_ticket_xp'] or 0
        total_candle_xp = xp_stats['total_candle_xp'] or 0
        
        # Average XP per event
        avg_xp_per_event_query = f"""
            SELECT 
                COALESCE(AVG(event_ticket_xp), 0) as avg_ticket_xp,
                COALESCE(AVG(event_candle_xp), 0) as avg_candle_xp
            FROM (
                SELECT 
                    e.id,
                    SUM(r.ticket_xp) as event_ticket_xp,
                    SUM(r.candle_xp) as event_candle_xp
                FROM events e
                LEFT JOIN rsvps r ON r.event_id = e.id
                WHERE e.starts_at < NOW() {chapter_filter}
                GROUP BY e.id
            ) event_xp_stats
        """
        
        avg_xp_stats = await conn.fetchrow(
            avg_xp_per_event_query,
            *([chapter_id] if chapter_id else [])
        )
        
        xp_purchase_metrics = XPPurchaseMetrics(
            total_ticket_xp_purchased=total_ticket_xp,
            total_candle_xp_purchased=total_candle_xp,
            total_xp_purchased=total_ticket_xp + total_candle_xp,
            avg_ticket_xp_per_event=round(float(avg_xp_stats['avg_ticket_xp'] or 0), 2),
            avg_candle_xp_per_event=round(float(avg_xp_stats['avg_candle_xp'] or 0), 2),
            players_purchasing_ticket_xp=xp_stats['ticket_xp_buyers'] or 0,
            players_purchasing_candle_xp=xp_stats['candle_xp_buyers'] or 0,
            candles_spent_on_xp=(total_candle_xp * 10)  # Each candle XP costs 10 candles
        )
        
        # Monthly XP purchase trends (last 12 months)
        monthly_xp_trend_query = f"""
            SELECT 
                TO_CHAR(DATE_TRUNC('month', e.starts_at), 'Mon') as month,
                EXTRACT(YEAR FROM e.starts_at)::int as year,
                COALESCE(SUM(r.ticket_xp), 0) as ticket_xp,
                COALESCE(SUM(r.candle_xp), 0) as candle_xp
            FROM events e
            LEFT JOIN rsvps r ON r.event_id = e.id
            WHERE e.starts_at >= NOW() - INTERVAL '12 months'
            AND e.starts_at < NOW() {chapter_filter}
            GROUP BY DATE_TRUNC('month', e.starts_at), EXTRACT(YEAR FROM e.starts_at)
            ORDER BY DATE_TRUNC('month', e.starts_at) DESC
        """
        
        monthly_xp_rows = await conn.fetch(
            monthly_xp_trend_query,
            *([chapter_id] if chapter_id else [])
        )
        monthly_xp_purchase_trend = [
            MonthlyXPPurchaseTrend(
                month=row['month'],
                year=row['year'],
                ticket_xp=row['ticket_xp'],
                candle_xp=row['candle_xp'],
                total_xp_purchased=row['ticket_xp'] + row['candle_xp']
            )
            for row in monthly_xp_rows
        ]
        
        return EventPerformanceAnalytics(
            total_events=total_events,
            total_past_events=total_past_events,
            monthly_trends=monthly_trends,
            avg_attendance_per_event=avg_attendance_per_event,
            attendance_trend=attendance_trend,
            upcoming_events=upcoming_events,
            overall_rsvp_accuracy=overall_rsvp_accuracy,
            no_show_rate=no_show_rate,
            surprise_attendance_rate=surprise_attendance_rate,
            rsvp_accuracy_by_event=rsvp_accuracy_by_event,
            most_attended_events=most_attended_events,
            least_attended_events=least_attended_events,
            chapter_comparisons=chapter_comparisons,
            xp_purchase_metrics=xp_purchase_metrics,
            monthly_xp_purchase_trend=monthly_xp_purchase_trend,
            last_updated=datetime.now(timezone.utc)
        )
    finally:
        await conn.close()


class ActivityStatusBreakdown(BaseModel):
    """Player activity status by time period."""
    period: str  # "30d", "60d", "90d", "180d"
    active_count: int
    percentage: float


class RetentionCohort(BaseModel):
    """Player retention by cohort."""
    month: str
    year: int
    new_players: int
    retained_1mo: int
    retained_3mo: int
    retained_6mo: int
    retained_1yr: int
    retention_1mo_rate: float
    retention_3mo_rate: float
    retention_6mo_rate: float
    retention_1yr_rate: float


class EngagedPlayer(BaseModel):
    """Top engaged player."""
    player_id: str
    player_name: str
    player_number: str
    events_attended: int
    character_count: int


class AtRiskPlayer(BaseModel):
    """At-risk player with declining attendance."""
    player_id: str
    player_name: str
    player_number: str
    last_event_date: datetime
    days_since_last_event: int
    events_last_3mo: int
    events_previous_3mo: int
    trend: str  # "declining", "stopped"


class EventsAttendedDistribution(BaseModel):
    """Distribution of events attended."""
    bracket: str  # "1", "2-5", "6-10", "11-20", "20+"
    player_count: int
    percentage: float


class CharacterCountDistribution(BaseModel):
    """Distribution of characters per player."""
    character_count: int
    player_count: int
    percentage: float


class MostPlayedCharacter(BaseModel):
    """Most played character."""
    character_id: str
    character_name: str
    player_name: str
    events_attended: int


class PlayerEngagementAnalytics(BaseModel):
    """Player engagement analytics response."""
    # Activity status
    total_players: int
    active_players: int
    inactive_players: int
    active_rate: float
    activity_breakdown: list[ActivityStatusBreakdown]
    
    # Retention analysis
    retention_cohorts: list[RetentionCohort]
    overall_churn_rate: float
    new_player_conversion_rate: float  # % who attended 2+ events
    
    # Engagement patterns
    avg_events_per_player: float
    events_distribution: list[EventsAttendedDistribution]
    top_engaged_players: list[EngagedPlayer]
    at_risk_players: list[AtRiskPlayer]
    
    # Character ownership
    avg_characters_per_player: float
    character_distribution: list[CharacterCountDistribution]
    most_played_characters: list[MostPlayedCharacter]
    
    # Metadata
    last_updated: datetime


@router.get("/player-engagement")
async def get_player_engagement_analytics(
    active_days: int = Query(90, description="Days to consider a player active")
) -> PlayerEngagementAnalytics:
    """
    Get comprehensive player engagement analytics including activity status,
    retention analysis, engagement patterns, and character ownership.
    
    Args:
        active_days: Number of days to consider a player active (default 90)
    
    Returns:
        PlayerEngagementAnalytics with all player engagement metrics
    """
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    
    try:
        # === ACTIVITY STATUS ===
        
        # Total players
        total_players = await conn.fetchval("SELECT COUNT(*) FROM player_profiles")
        
        # Active players (attended event in last N days)
        active_players_query = """
            SELECT COUNT(DISTINCT pp.id)
            FROM player_profiles pp
            JOIN rsvps r ON r.user_id = pp.user_id
            JOIN events e ON e.id = r.event_id
            WHERE r.attendance_status = 'attended'
            AND e.starts_at >= NOW() - INTERVAL '1 day' * $1
        """
        active_players = await conn.fetchval(active_players_query, active_days)
        
        inactive_players = total_players - active_players
        active_rate = round((active_players / total_players * 100) if total_players > 0 else 0, 2)
        
        # Activity breakdown by time periods
        activity_periods = [
            (30, "30d"),
            (60, "60d"),
            (90, "90d"),
            (180, "180d")
        ]
        
        activity_breakdown = []
        for days, label in activity_periods:
            count = await conn.fetchval(active_players_query, days)
            activity_breakdown.append(
                ActivityStatusBreakdown(
                    period=label,
                    active_count=count,
                    percentage=round((count / total_players * 100) if total_players > 0 else 0, 2)
                )
            )
        
        # === RETENTION ANALYSIS ===
        
        # Monthly cohorts (last 12 months)
        retention_query = """
            WITH player_first_event AS (
                SELECT 
                    pp.id,
                    MIN(e.starts_at) as first_event_date
                FROM player_profiles pp
                JOIN rsvps r ON r.user_id = pp.user_id
                JOIN events e ON e.id = r.event_id
                WHERE r.attendance_status = 'attended'
                GROUP BY pp.id
            ),
            monthly_cohorts AS (
                SELECT 
                    DATE_TRUNC('month', first_event_date) as cohort_month,
                    COUNT(DISTINCT id) as new_players,
                    COUNT(DISTINCT CASE 
                        WHEN EXISTS (
                            SELECT 1 FROM rsvps r2
                            JOIN events e2 ON e2.id = r2.event_id
                            WHERE r2.user_id = (SELECT user_id FROM player_profiles WHERE id = player_first_event.id)
                            AND r2.attendance_status = 'attended'
                            AND e2.starts_at > first_event_date + INTERVAL '1 month'
                            AND e2.starts_at <= first_event_date + INTERVAL '2 months'
                        ) THEN id
                    END) as retained_1mo,
                    COUNT(DISTINCT CASE 
                        WHEN EXISTS (
                            SELECT 1 FROM rsvps r2
                            JOIN events e2 ON e2.id = r2.event_id
                            WHERE r2.user_id = (SELECT user_id FROM player_profiles WHERE id = player_first_event.id)
                            AND r2.attendance_status = 'attended'
                            AND e2.starts_at > first_event_date + INTERVAL '3 months'
                            AND e2.starts_at <= first_event_date + INTERVAL '4 months'
                        ) THEN id
                    END) as retained_3mo,
                    COUNT(DISTINCT CASE 
                        WHEN EXISTS (
                            SELECT 1 FROM rsvps r2
                            JOIN events e2 ON e2.id = r2.event_id
                            WHERE r2.user_id = (SELECT user_id FROM player_profiles WHERE id = player_first_event.id)
                            AND r2.attendance_status = 'attended'
                            AND e2.starts_at > first_event_date + INTERVAL '6 months'
                            AND e2.starts_at <= first_event_date + INTERVAL '7 months'
                        ) THEN id
                    END) as retained_6mo,
                    COUNT(DISTINCT CASE 
                        WHEN EXISTS (
                            SELECT 1 FROM rsvps r2
                            JOIN events e2 ON e2.id = r2.event_id
                            WHERE r2.user_id = (SELECT user_id FROM player_profiles WHERE id = player_first_event.id)
                            AND r2.attendance_status = 'attended'
                            AND e2.starts_at > first_event_date + INTERVAL '12 months'
                            AND e2.starts_at <= first_event_date + INTERVAL '13 months'
                        ) THEN id
                    END) as retained_1yr
                FROM player_first_event
                WHERE first_event_date >= NOW() - INTERVAL '12 months'
                GROUP BY cohort_month
            )
            SELECT 
                TO_CHAR(cohort_month, 'Mon') as month,
                EXTRACT(YEAR FROM cohort_month)::int as year,
                new_players,
                retained_1mo,
                retained_3mo,
                retained_6mo,
                retained_1yr
            FROM monthly_cohorts
            ORDER BY cohort_month DESC
        """
        
        retention_rows = await conn.fetch(retention_query)
        retention_cohorts = []
        for row in retention_rows:
            new_players = row['new_players']
            retention_cohorts.append(
                RetentionCohort(
                    month=row['month'],
                    year=row['year'],
                    new_players=new_players,
                    retained_1mo=row['retained_1mo'],
                    retained_3mo=row['retained_3mo'],
                    retained_6mo=row['retained_6mo'],
                    retained_1yr=row['retained_1yr'],
                    retention_1mo_rate=round((row['retained_1mo'] / new_players * 100) if new_players > 0 else 0, 2),
                    retention_3mo_rate=round((row['retained_3mo'] / new_players * 100) if new_players > 0 else 0, 2),
                    retention_6mo_rate=round((row['retained_6mo'] / new_players * 100) if new_players > 0 else 0, 2),
                    retention_1yr_rate=round((row['retained_1yr'] / new_players * 100) if new_players > 0 else 0, 2)
                )
            )
        
        # Churn rate (players who haven't attended in 6+ months)
        churn_query = """
            SELECT COUNT(DISTINCT pp.id)
            FROM player_profiles pp
            WHERE NOT EXISTS (
                SELECT 1 FROM rsvps r
                JOIN events e ON e.id = r.event_id
                WHERE r.user_id = pp.user_id
                AND r.attendance_status = 'attended'
                AND e.starts_at >= NOW() - INTERVAL '6 months'
            )
            AND EXISTS (
                SELECT 1 FROM rsvps r
                JOIN events e ON e.id = r.event_id
                WHERE r.user_id = pp.user_id
                AND r.attendance_status = 'attended'
            )
        """
        churned_players = await conn.fetchval(churn_query)
        overall_churn_rate = round((churned_players / total_players * 100) if total_players > 0 else 0, 2)
        
        # New player conversion (attended 2+ events)
        conversion_query = """
            WITH player_event_counts AS (
                SELECT 
                    pp.id,
                    COUNT(DISTINCT e.id) as event_count
                FROM player_profiles pp
                JOIN rsvps r ON r.user_id = pp.user_id
                JOIN events e ON e.id = r.event_id
                WHERE r.attendance_status = 'attended'
                GROUP BY pp.id
            )
            SELECT 
                COUNT(CASE WHEN event_count >= 2 THEN 1 END)::float / 
                NULLIF(COUNT(*), 0)::float * 100 as conversion_rate
            FROM player_event_counts
        """
        conversion_rate = await conn.fetchval(conversion_query)
        new_player_conversion_rate = round(conversion_rate or 0, 2)
        
        # === ENGAGEMENT PATTERNS ===
        
        # Average events per player
        avg_events_query = """
            SELECT COALESCE(AVG(event_count), 0) as avg_events
            FROM (
                SELECT 
                    pp.id,
                    COUNT(DISTINCT e.id) as event_count
                FROM player_profiles pp
                LEFT JOIN rsvps r ON r.user_id = pp.user_id
                LEFT JOIN events e ON e.id = r.event_id AND r.attendance_status = 'attended'
                GROUP BY pp.id
            ) player_events
        """
        avg_events = await conn.fetchval(avg_events_query)
        avg_events_per_player = round(float(avg_events or 0), 2)
        
        # Events attended distribution
        distribution_query = """
            WITH player_event_counts AS (
                SELECT 
                    pp.id,
                    COUNT(DISTINCT e.id) as event_count
                FROM player_profiles pp
                LEFT JOIN rsvps r ON r.user_id = pp.user_id
                LEFT JOIN events e ON e.id = r.event_id AND r.attendance_status = 'attended'
                GROUP BY pp.id
            )
            SELECT 
                CASE 
                    WHEN event_count = 0 THEN '0'
                    WHEN event_count = 1 THEN '1'
                    WHEN event_count BETWEEN 2 AND 5 THEN '2-5'
                    WHEN event_count BETWEEN 6 AND 10 THEN '6-10'
                    WHEN event_count BETWEEN 11 AND 20 THEN '11-20'
                    ELSE '20+'
                END as bracket,
                COUNT(*) as player_count
            FROM player_event_counts
            GROUP BY bracket
            ORDER BY MIN(event_count)
        """
        
        dist_rows = await conn.fetch(distribution_query)
        events_distribution = []
        for row in dist_rows:
            events_distribution.append(
                EventsAttendedDistribution(
                    bracket=row['bracket'],
                    player_count=row['player_count'],
                    percentage=round((row['player_count'] / total_players * 100) if total_players > 0 else 0, 2)
                )
            )
        
        # Top engaged players
        top_engaged_query = """
            SELECT 
                pp.id::text,
                pp.first_name || ' ' || pp.last_name as player_name,
                pp.player_number,
                COUNT(DISTINCT e.id) as events_attended,
                COUNT(DISTINCT c.id) as character_count
            FROM player_profiles pp
            LEFT JOIN rsvps r ON r.user_id = pp.user_id
            LEFT JOIN events e ON e.id = r.event_id AND r.attendance_status = 'attended'
            LEFT JOIN characters c ON c.player_profile_id = pp.id AND c.retired = false
            GROUP BY pp.id, pp.first_name, pp.last_name, pp.player_number
            ORDER BY events_attended DESC
            LIMIT 10
        """
        
        engaged_rows = await conn.fetch(top_engaged_query)
        top_engaged_players = []
        for row in engaged_rows:
            top_engaged_players.append(
                EngagedPlayer(
                    player_id=row['id'],
                    player_name=row['player_name'],
                    player_number=row['player_number'],
                    events_attended=row['events_attended'],
                    character_count=row['character_count']
                )
            )
        
        # At-risk players (declining attendance)
        at_risk_query = """
            WITH player_recent_activity AS (
                SELECT 
                    pp.id,
                    pp.first_name || ' ' || pp.last_name as player_name,
                    pp.player_number,
                    pp.user_id,
                    MAX(e.starts_at) as last_event_date,
                    COUNT(DISTINCT CASE 
                        WHEN e.starts_at >= NOW() - INTERVAL '3 months' 
                        THEN e.id 
                    END) as events_last_3mo,
                    COUNT(DISTINCT CASE 
                        WHEN e.starts_at >= NOW() - INTERVAL '6 months'
                        AND e.starts_at < NOW() - INTERVAL '3 months'
                        THEN e.id 
                    END) as events_previous_3mo
                FROM player_profiles pp
                JOIN rsvps r ON r.user_id = pp.user_id
                JOIN events e ON e.id = r.event_id
                WHERE r.attendance_status = 'attended'
                AND e.starts_at < NOW()
                GROUP BY pp.id, pp.first_name, pp.last_name, pp.player_number, pp.user_id
                HAVING MAX(e.starts_at) < NOW() - INTERVAL '60 days'
                OR (COUNT(DISTINCT CASE WHEN e.starts_at >= NOW() - INTERVAL '3 months' THEN e.id END) < 
                    COUNT(DISTINCT CASE WHEN e.starts_at >= NOW() - INTERVAL '6 months' AND e.starts_at < NOW() - INTERVAL '3 months' THEN e.id END))
            )
            SELECT 
                id::text,
                player_name,
                player_number,
                last_event_date,
                EXTRACT(DAY FROM NOW() - last_event_date)::int as days_since,
                events_last_3mo,
                events_previous_3mo,
                CASE 
                    WHEN last_event_date < NOW() - INTERVAL '90 days' THEN 'stopped'
                    ELSE 'declining'
                END as trend
            FROM player_recent_activity
            ORDER BY last_event_date DESC
            LIMIT 20
        """
        
        at_risk_rows = await conn.fetch(at_risk_query)
        at_risk_players = []
        for row in at_risk_rows:
            at_risk_players.append(
                AtRiskPlayer(
                    player_id=row['id'],
                    player_name=row['player_name'],
                    player_number=row['player_number'],
                    last_event_date=row['last_event_date'],
                    days_since_last_event=row['days_since'],
                    events_last_3mo=row['events_last_3mo'],
                    events_previous_3mo=row['events_previous_3mo'],
                    trend=row['trend']
                )
            )
        
        # === CHARACTER OWNERSHIP ===
        
        # Average characters per player
        avg_chars_query = """
            SELECT COALESCE(AVG(char_count), 0) as avg_chars
            FROM (
                SELECT 
                    pp.id,
                    COUNT(c.id) as char_count
                FROM player_profiles pp
                LEFT JOIN characters c ON c.player_profile_id = pp.id AND c.retired = false
                GROUP BY pp.id
            ) player_chars
        """
        avg_chars = await conn.fetchval(avg_chars_query)
        avg_characters_per_player = round(float(avg_chars or 0), 2)
        
        # Character count distribution
        char_dist_query = """
            WITH player_char_counts AS (
                SELECT 
                    pp.id,
                    COUNT(c.id) as char_count
                FROM player_profiles pp
                LEFT JOIN characters c ON c.player_profile_id = pp.id AND c.retired = false
                GROUP BY pp.id
            )
            SELECT 
                char_count,
                COUNT(*) as player_count
            FROM player_char_counts
            GROUP BY char_count
            ORDER BY char_count
        """
        
        char_dist_rows = await conn.fetch(char_dist_query)
        character_distribution = []
        for row in char_dist_rows:
            character_distribution.append(
                CharacterCountDistribution(
                    character_count=row['char_count'],
                    player_count=row['player_count'],
                    percentage=round((row['player_count'] / total_players * 100) if total_players > 0 else 0, 2)
                )
            )
        
        # Most played characters (by events attended)
        most_played_query = """
            SELECT 
                c.id::text,
                c.name as character_name,
                pp.first_name || ' ' || pp.last_name as player_name,
                COUNT(DISTINCT r.event_id) as events_attended
            FROM characters c
            JOIN player_profiles pp ON pp.id = c.player_profile_id
            LEFT JOIN rsvps r ON r.user_id = pp.user_id AND r.character_id = c.id AND r.attendance_status = 'attended'
            WHERE c.retired = false
            GROUP BY c.id, c.name, pp.first_name, pp.last_name
            ORDER BY events_attended DESC
            LIMIT 10
        """
        
        most_played_rows = await conn.fetch(most_played_query)
        most_played_characters = []
        for row in most_played_rows:
            most_played_characters.append(
                MostPlayedCharacter(
                    character_id=row['id'],
                    character_name=row['character_name'],
                    player_name=row['player_name'],
                    events_attended=row['events_attended']
                )
            )
        
        return PlayerEngagementAnalytics(
            total_players=total_players,
            active_players=active_players,
            inactive_players=inactive_players,
            active_rate=active_rate,
            activity_breakdown=activity_breakdown,
            retention_cohorts=retention_cohorts,
            overall_churn_rate=overall_churn_rate,
            new_player_conversion_rate=new_player_conversion_rate,
            avg_events_per_player=avg_events_per_player,
            events_distribution=events_distribution,
            top_engaged_players=top_engaged_players,
            at_risk_players=at_risk_players,
            avg_characters_per_player=avg_characters_per_player,
            character_distribution=character_distribution,
            most_played_characters=most_played_characters,
            last_updated=datetime.now(timezone.utc)
        )
    finally:
        await conn.close()


# === CHAPTER HEALTH ANALYTICS ===

class ChapterOverview(BaseModel):
    """Individual chapter overview statistics."""
    chapter_id: str
    chapter_name: str
    events_hosted: int
    avg_attendance: float
    last_event_date: Optional[datetime]
    status: str
    unique_players: int


class ChapterGrowthTrend(BaseModel):
    """Chapter growth trend over time."""
    chapter_id: str
    chapter_name: str
    month: str
    year: int
    player_count: int
    trend_status: str


class ChapterComparisonMetric(BaseModel):
    """Chapter comparison metrics."""
    chapter_id: str
    chapter_name: str
    total_events: int
    avg_attendance: float
    unique_players: int
    xp_distributed: int
    rsvp_accuracy: float


class CrossChapterPlayer(BaseModel):
    """Player who attends multiple chapters."""
    player_id: str
    player_name: str
    player_number: str
    chapters_attended: int
    chapter_names: list[str]
    total_events: int


class ChapterOverlapFlow(BaseModel):
    """Chapter to chapter attendance flow."""
    from_chapter_id: str
    from_chapter_name: str
    to_chapter_id: str
    to_chapter_name: str
    player_count: int


class ChapterConsistencyMetric(BaseModel):
    """Chapter event consistency metrics."""
    chapter_id: str
    chapter_name: str
    events_per_month: float
    consistency_score: float
    longest_gap_days: int


class ChapterHealthAnalytics(BaseModel):
    """Chapter health analytics response."""
    total_chapters: int
    active_chapters: int
    inactive_chapters: int
    chapter_list: list[ChapterOverview]
    growth_trends: list[ChapterGrowthTrend]
    chapter_comparisons: list[ChapterComparisonMetric]
    total_cross_chapter_players: int
    cross_chapter_percentage: float
    cross_chapter_players: list[CrossChapterPlayer]
    chapter_overlap_flows: list[ChapterOverlapFlow]
    consistency_metrics: list[ChapterConsistencyMetric]
    last_updated: datetime



@router.get("/chapter-health")
async def get_chapter_health_analytics(
    chapter_id: Optional[str] = Query(None, description="Filter by specific chapter"),
    start_date: Optional[datetime] = Query(None, description="Start date for filtering"),
    end_date: Optional[datetime] = Query(None, description="End date for filtering")
) -> ChapterHealthAnalytics:
    """
    Get comprehensive chapter health analytics.
    """
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    
    try:
        total_chapters = await conn.fetchval("SELECT COUNT(*) FROM chapters")
        
        # Chapter list with stats
        chapter_list_query = """
            SELECT 
                c.id::text,
                c.name,
                COUNT(DISTINCT e.id) as events_hosted,
                COALESCE(AVG(event_stats.attendance), 0) as avg_attendance,
                MAX(e.starts_at) as last_event_date,
                COUNT(DISTINCT r.user_id) as unique_players
            FROM chapters c
            LEFT JOIN events e ON e.chapter_id = c.id
            LEFT JOIN rsvps r ON r.event_id = e.id AND r.attendance_status = 'attended'
            LEFT JOIN (
                SELECT 
                    e2.id,
                    COUNT(DISTINCT r2.id) as attendance
                FROM events e2
                LEFT JOIN rsvps r2 ON r2.event_id = e2.id AND r2.attendance_status = 'attended'
                GROUP BY e2.id
            ) event_stats ON event_stats.id = e.id
            GROUP BY c.id, c.name
            ORDER BY events_hosted DESC
        """
        
        chapter_rows = await conn.fetch(chapter_list_query)
        
        chapter_list = []
        active_chapters = 0
        inactive_chapters = 0
        
        for row in chapter_rows:
            is_active = row['last_event_date'] and row['last_event_date'] >= datetime.now(timezone.utc) - timedelta(days=90)
            status = "active" if is_active else "inactive"
            
            if is_active:
                active_chapters += 1
            else:
                inactive_chapters += 1
            
            chapter_list.append(
                ChapterOverview(
                    chapter_id=row['id'],
                    chapter_name=row['name'],
                    events_hosted=row['events_hosted'],
                    avg_attendance=round(float(row['avg_attendance'] or 0), 2),
                    last_event_date=row['last_event_date'],
                    status=status,
                    unique_players=row['unique_players']
                )
            )
        
        # Growth trends
        growth_trends_query = """
            WITH monthly_chapter_players AS (
                SELECT 
                    c.id,
                    c.name,
                    DATE_TRUNC('month', e.starts_at) as month,
                    COUNT(DISTINCT r.user_id) as player_count
                FROM chapters c
                JOIN events e ON e.chapter_id = c.id
                JOIN rsvps r ON r.event_id = e.id AND r.attendance_status = 'attended'
                WHERE e.starts_at >= NOW() - INTERVAL '12 months'
                AND e.starts_at < NOW()
                GROUP BY c.id, c.name, DATE_TRUNC('month', e.starts_at)
            ),
            trend_calc AS (
                SELECT 
                    *,
                    LAG(player_count) OVER (PARTITION BY id ORDER BY month) as prev_count
                FROM monthly_chapter_players
            )
            SELECT 
                id::text,
                name,
                TO_CHAR(month, 'Mon') as month_name,
                EXTRACT(YEAR FROM month)::int as year,
                player_count,
                CASE 
                    WHEN prev_count IS NULL THEN 'stable'
                    WHEN player_count > prev_count * 1.1 THEN 'growing'
                    WHEN player_count < prev_count * 0.9 THEN 'declining'
                    ELSE 'stable'
                END as trend_status
            FROM trend_calc
            ORDER BY month DESC, name
        """
        
        growth_rows = await conn.fetch(growth_trends_query)
        growth_trends = [
            ChapterGrowthTrend(
                chapter_id=row['id'],
                chapter_name=row['name'],
                month=row['month_name'],
                year=row['year'],
                player_count=row['player_count'],
                trend_status=row['trend_status']
            )
            for row in growth_rows
        ]
        
        # Chapter comparisons
        comparison_query = """
            SELECT 
                c.id::text,
                c.name,
                COUNT(DISTINCT e.id) as total_events,
                COALESCE(AVG(event_stats.attendance), 0) as avg_attendance,
                COUNT(DISTINCT r.user_id) as unique_players,
                COALESCE(SUM(r.ticket_xp + r.candle_xp), 0) as xp_distributed,
                CASE 
                    WHEN COUNT(CASE WHEN r.status = 'going' THEN 1 END) > 0
                    THEN (COUNT(CASE WHEN r.status = 'going' AND r.attendance_status = 'attended' THEN 1 END)::float /
                          COUNT(CASE WHEN r.status = 'going' THEN 1 END) * 100)
                    ELSE 0
                END as rsvp_accuracy
            FROM chapters c
            LEFT JOIN events e ON e.chapter_id = c.id
            LEFT JOIN rsvps r ON r.event_id = e.id
            LEFT JOIN (
                SELECT 
                    e2.id,
                    COUNT(DISTINCT r2.id) as attendance
                FROM events e2
                LEFT JOIN rsvps r2 ON r2.event_id = e2.id AND r2.attendance_status = 'attended'
                GROUP BY e2.id
            ) event_stats ON event_stats.id = e.id
            GROUP BY c.id, c.name
            ORDER BY total_events DESC
        """
        
        comparison_rows = await conn.fetch(comparison_query)
        chapter_comparisons = [
            ChapterComparisonMetric(
                chapter_id=row['id'],
                chapter_name=row['name'],
                total_events=row['total_events'],
                avg_attendance=round(float(row['avg_attendance'] or 0), 2),
                unique_players=row['unique_players'],
                xp_distributed=row['xp_distributed'],
                rsvp_accuracy=round(float(row['rsvp_accuracy'] or 0), 2)
            )
            for row in comparison_rows
        ]
        
        # Cross-chapter players
        cross_chapter_query = """
            WITH player_chapters AS (
                SELECT 
                    pp.id,
                    pp.first_name || ' ' || pp.last_name as player_name,
                    pp.player_number,
                    COUNT(DISTINCT e.chapter_id) as chapters_attended,
                    ARRAY_AGG(DISTINCT c.name ORDER BY c.name) as chapter_names,
                    COUNT(DISTINCT e.id) as total_events
                FROM player_profiles pp
                JOIN rsvps r ON r.user_id = pp.user_id AND r.attendance_status = 'attended'
                JOIN events e ON e.id = r.event_id
                JOIN chapters c ON c.id = e.chapter_id
                GROUP BY pp.id, pp.first_name, pp.last_name, pp.player_number
                HAVING COUNT(DISTINCT e.chapter_id) > 1
            )
            SELECT 
                id::text,
                player_name,
                player_number,
                chapters_attended,
                chapter_names,
                total_events
            FROM player_chapters
            ORDER BY chapters_attended DESC, total_events DESC
            LIMIT 50
        """
        
        cross_chapter_rows = await conn.fetch(cross_chapter_query)
        total_cross_chapter_players = len(cross_chapter_rows)
        
        total_players_with_events = await conn.fetchval("""
            SELECT COUNT(DISTINCT pp.id)
            FROM player_profiles pp
            JOIN rsvps r ON r.user_id = pp.user_id AND r.attendance_status = 'attended'
        """)
        
        cross_chapter_percentage = round(
            (total_cross_chapter_players / total_players_with_events * 100) if total_players_with_events > 0 else 0,
            2
        )
        
        cross_chapter_players = [
            CrossChapterPlayer(
                player_id=row['id'],
                player_name=row['player_name'],
                player_number=row['player_number'],
                chapters_attended=row['chapters_attended'],
                chapter_names=row['chapter_names'],
                total_events=row['total_events']
            )
            for row in cross_chapter_rows
        ]
        
        # Chapter overlap flows
        overlap_flow_query = """
            WITH player_chapter_pairs AS (
                SELECT DISTINCT
                    pp.id as player_id,
                    e1.chapter_id as from_chapter,
                    e2.chapter_id as to_chapter
                FROM player_profiles pp
                JOIN rsvps r1 ON r1.user_id = pp.user_id AND r1.attendance_status = 'attended'
                JOIN events e1 ON e1.id = r1.event_id
                JOIN rsvps r2 ON r2.user_id = pp.user_id AND r2.attendance_status = 'attended'
                JOIN events e2 ON e2.id = r2.event_id
                WHERE e1.chapter_id != e2.chapter_id
            )
            SELECT 
                from_chapter::text,
                c1.name as from_chapter_name,
                to_chapter::text,
                c2.name as to_chapter_name,
                COUNT(DISTINCT player_id) as player_count
            FROM player_chapter_pairs
            JOIN chapters c1 ON c1.id = from_chapter
            JOIN chapters c2 ON c2.id = to_chapter
            GROUP BY from_chapter, c1.name, to_chapter, c2.name
            ORDER BY player_count DESC
            LIMIT 20
        """
        
        flow_rows = await conn.fetch(overlap_flow_query)
        chapter_overlap_flows = [
            ChapterOverlapFlow(
                from_chapter_id=row['from_chapter'],
                from_chapter_name=row['from_chapter_name'],
                to_chapter_id=row['to_chapter'],
                to_chapter_name=row['to_chapter_name'],
                player_count=row['player_count']
            )
            for row in flow_rows
        ]
        
        # Consistency metrics
        consistency_query = """
            WITH chapter_event_dates AS (
                SELECT 
                    c.id,
                    c.name,
                    e.starts_at,
                    LAG(e.starts_at) OVER (PARTITION BY c.id ORDER BY e.starts_at) as prev_event_date
                FROM chapters c
                LEFT JOIN events e ON e.chapter_id = c.id
                WHERE e.starts_at < NOW()
            ),
            chapter_gaps AS (
                SELECT 
                    id,
                    name,
                    EXTRACT(DAY FROM MAX(starts_at - prev_event_date))::int as longest_gap_days,
                    COUNT(*) as event_count,
                    EXTRACT(DAY FROM MAX(starts_at) - MIN(starts_at))::int as total_days
                FROM chapter_event_dates
                WHERE prev_event_date IS NOT NULL
                GROUP BY id, name
            )
            SELECT 
                id::text,
                name,
                CASE 
                    WHEN total_days > 0 THEN (event_count::float / (total_days / 30.0))
                    ELSE 0
                END as events_per_month,
                CASE 
                    WHEN longest_gap_days <= 30 THEN 1.0
                    WHEN longest_gap_days <= 60 THEN 0.75
                    WHEN longest_gap_days <= 90 THEN 0.5
                    ELSE 0.25
                END as consistency_score,
                longest_gap_days
            FROM chapter_gaps
            ORDER BY consistency_score DESC, events_per_month DESC
        """
        
        consistency_rows = await conn.fetch(consistency_query)
        consistency_metrics = [
            ChapterConsistencyMetric(
                chapter_id=row['id'],
                chapter_name=row['name'],
                events_per_month=round(float(row['events_per_month'] or 0), 2),
                consistency_score=float(row['consistency_score'] or 0),
                longest_gap_days=row['longest_gap_days'] or 0
            )
            for row in consistency_rows
        ]
        
        return ChapterHealthAnalytics(
            total_chapters=total_chapters,
            active_chapters=active_chapters,
            inactive_chapters=inactive_chapters,
            chapter_list=chapter_list,
            growth_trends=growth_trends,
            chapter_comparisons=chapter_comparisons,
            total_cross_chapter_players=total_cross_chapter_players,
            cross_chapter_percentage=cross_chapter_percentage,
            cross_chapter_players=cross_chapter_players,
            chapter_overlap_flows=chapter_overlap_flows,
            consistency_metrics=consistency_metrics,
            last_updated=datetime.now(timezone.utc)
        )
    finally:
        await conn.close()