from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.auth import AuthorizedUser
import asyncpg
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from datetime import datetime

router = APIRouter()

class LoreSubmissionCreate(BaseModel):
    event_id: str
    chapter_id: str
    character_id: str
    lores_used: str | None = None
    items_used: str | None = None
    outcome: str
    link: str | None = None

class LoreSubmissionUpdate(BaseModel):
    event_id: str | None = None
    chapter_id: str | None = None
    character_id: str | None = None
    lores_used: str | None = None
    items_used: str | None = None
    outcome: str | None = None
    link: str | None = None

class LoreSubmissionResponse(BaseModel):
    id: str
    event_id: str
    event_name: str
    chapter_id: str
    chapter_name: str
    character_id: str
    character_name: str
    lores_used: str
    outcome: str
    items_used: str | None
    link: str | None
    created_at: str
    created_by: str

@router.post("/lore-submissions/create")
async def create_lore_submission(body: LoreSubmissionCreate, user: AuthorizedUser) -> LoreSubmissionResponse:
    """
    Create a new lore submission (admin only).
    """
    conn = await get_database_connection()

        # Check admin permissions
    try:
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_events', 'manage_chapters', 'view_admin_panel', 'manage_characters')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error checking admin permission: {e}")
        raise HTTPException(status_code=500, detail="Permission check failed")
        
    try:
        # Verify event exists
        event = await conn.fetchrow(
            "SELECT id, title as name FROM events WHERE id = $1",
            body.event_id
        )
        if not event:
            raise HTTPException(status_code=404, detail="Event not found")
        
        # Verify chapter exists
        chapter = await conn.fetchrow(
            "SELECT id, name FROM chapters WHERE id = $1",
            body.chapter_id
        )
        if not chapter:
            raise HTTPException(status_code=404, detail="Chapter not found")
        
        # Verify character exists
        character = await conn.fetchrow(
            "SELECT id, name FROM characters WHERE id = $1",
            body.character_id
        )
        if not character:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Create the lore submission
        submission = await conn.fetchrow(
            """
            INSERT INTO lore_submissions 
            (event_id, chapter_id, character_id, lores_used, items_used, outcome, link, created_by)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
            RETURNING id, event_id, chapter_id, character_id, lores_used, items_used, outcome, link, created_at, created_by
            """,
            body.event_id,
            body.chapter_id,
            body.character_id,
            body.lores_used,
            body.items_used,
            body.outcome,
            body.link,
            user.sub
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="lore",
            action="create",
            entity_id=str(submission['id']),
            entity_type="lore_submission",
            details=body.dict()
        )
        
        return LoreSubmissionResponse(
            id=str(submission['id']),
            event_id=str(submission['event_id']),
            event_name=event['name'],
            chapter_id=str(submission['chapter_id']),
            chapter_name=chapter['name'],
            character_id=str(submission['character_id']),
            character_name=character['name'],
            lores_used=submission['lores_used'],
            items_used=submission['items_used'],
            outcome=submission['outcome'],
            link=submission['link'],
            created_at=submission['created_at'].isoformat(),
            created_by=submission['created_by']
        )
    finally:
        await conn.close()

@router.get("/lore-submissions/admin")
async def get_admin_lore_submissions(
    user: AuthorizedUser,
    chapter_id: str | None = None,
    event_id: str | None = None,
    character_id: str | None = None
) -> list[LoreSubmissionResponse]:
    """
    Get all lore submissions with optional filters (admin only).
    """
    conn = await get_database_connection()
    
    try:
        # Check admin permissions
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_events', 'manage_chapters', 'view_admin_panel', 'manage_characters')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
        
        query = """
            SELECT 
                ls.id,
                ls.event_id,
                e.title as event_name,
                ls.chapter_id,
                ch.name as chapter_name,
                ls.character_id,
                c.name as character_name,
                ls.lores_used,
                ls.outcome,
                ls.items_used,
                ls.link,
                ls.created_at,
                ls.created_by
            FROM lore_submissions ls
            JOIN events e ON ls.event_id = e.id
            JOIN chapters ch ON ls.chapter_id = ch.id
            JOIN characters c ON ls.character_id = c.id
            WHERE 1=1
        """
        params = []
        param_count = 1
        
        if chapter_id:
            query += f" AND ls.chapter_id = ${param_count}"
            params.append(chapter_id)
            param_count += 1
        
        if event_id:
            query += f" AND ls.event_id = ${param_count}"
            params.append(event_id)
            param_count += 1
        
        if character_id:
            query += f" AND ls.character_id = ${param_count}"
            params.append(character_id)
            param_count += 1
        
        query += " ORDER BY ls.created_at DESC"
        
        rows = await conn.fetch(query, *params)
        
        return [
            LoreSubmissionResponse(
                id=str(row['id']),
                event_id=str(row['event_id']),
                event_name=row['event_name'],
                chapter_id=str(row['chapter_id']),
                chapter_name=row['chapter_name'],
                character_id=str(row['character_id']),
                character_name=row['character_name'],
                lores_used=row['lores_used'],
                outcome=row['outcome'],
                items_used=row['items_used'],
                link=row['link'],
                created_at=row['created_at'].isoformat(),
                created_by=row['created_by']
            )
            for row in rows
        ]
    finally:
        await conn.close()

@router.get("/lore-submissions/my-submissions")
async def get_my_lore_submissions(user: AuthorizedUser) -> list[LoreSubmissionResponse]:
    """
    Get lore submissions for characters owned by the authenticated player.
    """
    conn = await get_database_connection()
    
    try:
        rows = await conn.fetch(
            """
            SELECT 
                ls.id,
                ls.event_id,
                e.title as event_name,
                ls.chapter_id,
                ch.name as chapter_name,
                ls.character_id,
                c.name as character_name,
                ls.lores_used,
                ls.items_used,
                ls.outcome,
                ls.link,
                ls.created_at,
                ls.created_by
            FROM lore_submissions ls
            JOIN events e ON ls.event_id = e.id
            JOIN chapters ch ON ls.chapter_id = ch.id
            JOIN characters c ON ls.character_id = c.id
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            WHERE pp.user_id = $1
            ORDER BY ls.created_at DESC
            """,
            user.sub
        )
        
        return [
            LoreSubmissionResponse(
                id=str(row['id']),
                event_id=str(row['event_id']),
                event_name=row['event_name'],
                chapter_id=str(row['chapter_id']),
                chapter_name=row['chapter_name'],
                character_id=str(row['character_id']),
                character_name=row['character_name'],
                lores_used=row['lores_used'],
                items_used=row['items_used'],
                outcome=row['outcome'],
                link=row['link'],
                created_at=row['created_at'].isoformat(),
                created_by=row['created_by']
            )
            for row in rows
        ]
    finally:
        await conn.close()

@router.put("/lore-submissions/{submission_id}")
async def update_lore_submission(
    submission_id: str,
    body: LoreSubmissionUpdate,
    user: AuthorizedUser
) -> LoreSubmissionResponse:
    """
    Update an existing lore submission (admin only).
    """
    conn = await get_database_connection()

        # Check admin permissions
    try:
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_events', 'manage_chapters', 'view_admin_panel', 'manage_characters')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error checking admin permission: {e}")
        raise HTTPException(status_code=500, detail="Permission check failed")
        
    try:
        # Check if submission exists
        existing = await conn.fetchrow(
            "SELECT id FROM lore_submissions WHERE id = $1",
            submission_id
        )
        if not existing:
            raise HTTPException(status_code=404, detail="Lore submission not found")
        
        # Build update query dynamically based on provided fields
        updates = []
        params = []
        param_count = 1
        
        if body.event_id is not None:
            # Verify event exists
            event_check = await conn.fetchrow(
                "SELECT id FROM events WHERE id = $1",
                body.event_id
            )
            if not event_check:
                raise HTTPException(status_code=404, detail="Event not found")
            updates.append(f"event_id = ${param_count}")
            params.append(body.event_id)
            param_count += 1
        
        if body.chapter_id is not None:
            # Verify chapter exists
            chapter_check = await conn.fetchrow(
                "SELECT id FROM chapters WHERE id = $1",
                body.chapter_id
            )
            if not chapter_check:
                raise HTTPException(status_code=404, detail="Chapter not found")
            updates.append(f"chapter_id = ${param_count}")
            params.append(body.chapter_id)
            param_count += 1
        
        if body.character_id is not None:
            # Verify character exists
            character_check = await conn.fetchrow(
                "SELECT id FROM characters WHERE id = $1",
                body.character_id
            )
            if not character_check:
                raise HTTPException(status_code=404, detail="Character not found")
            updates.append(f"character_id = ${param_count}")
            params.append(body.character_id)
            param_count += 1
        
        if body.lores_used is not None:
            updates.append(f"lores_used = ${param_count}")
            params.append(body.lores_used)
            param_count += 1

        if body.items_used is not None:
            updates.append(f"items_used = ${param_count}")
            params.append(body.items_used)
            param_count += 1
            
        if body.outcome is not None:
            updates.append(f"outcome = ${param_count}")
            params.append(body.outcome)
            param_count += 1
        
        if body.link is not None:
            updates.append(f"link = ${param_count}")
            params.append(body.link)
            param_count += 1
        
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        # Add submission_id as the last parameter
        params.append(submission_id)
        
        # Perform the update
        query = f"""
            UPDATE lore_submissions 
            SET {', '.join(updates)}
            WHERE id = ${param_count}
        """
        await conn.execute(query, *params)
        
        # Fetch and return the updated submission with joined data
        updated = await conn.fetchrow(
            """
            SELECT 
                ls.id,
                ls.event_id,
                e.title as event_name,
                ls.chapter_id,
                ch.name as chapter_name,
                ls.character_id,
                c.name as character_name,
                ls.lores_used,
                ls.items_used,
                ls.outcome,
                ls.link,
                ls.created_at,
                ls.created_by
            FROM lore_submissions ls
            JOIN events e ON ls.event_id = e.id
            JOIN chapters ch ON ls.chapter_id = ch.id
            JOIN characters c ON ls.character_id = c.id
            WHERE ls.id = $1
            """,
            submission_id
        )

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="lore",
            action="update",
            entity_id=submission_id,
            entity_type="lore_submission",
            details=body.dict(exclude_unset=True)
        )
        
        return LoreSubmissionResponse(
            id=str(updated['id']),
            event_id=str(updated['event_id']),
            event_name=updated['event_name'],
            chapter_id=str(updated['chapter_id']),
            chapter_name=updated['chapter_name'],
            character_id=str(updated['character_id']),
            character_name=updated['character_name'],
            lores_used=updated['lores_used'],
            items_used=updated['items_used'],
            outcome=updated['outcome'],
            link=updated['link'],
            created_at=updated['created_at'].isoformat(),
            created_by=updated['created_by']
        )
    finally:
        await conn.close()

@router.delete("/lore-submissions/{submission_id}")
async def delete_lore_submission(submission_id: str, user: AuthorizedUser):
    """
    Delete a lore submission (admin only).
    """
    conn = await get_database_connection()

        # Check admin permissions
    try:
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_events', 'manage_chapters', 'view_admin_panel', 'manage_characters')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error checking admin permission: {e}")
        raise HTTPException(status_code=500, detail="Permission check failed")
    
    
    try:
        result = await conn.execute(
            "DELETE FROM lore_submissions WHERE id = $1",
            submission_id
        )
        
        # Check if any row was deleted
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Lore submission not found")
        
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="lore",
            action="delete",
            entity_id=submission_id,
            entity_type="lore_submission"
        )

        return {"success": True, "message": "Lore submission deleted successfully"}
    finally:
        await conn.close()
