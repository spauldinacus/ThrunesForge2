from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from typing import List, Optional
import asyncpg
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/cultures")

# Pydantic Models
class CultureBase(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    heritage_id: str = Field(..., description="UUID of the heritage this culture belongs to")
    description: str = Field(..., min_length=1)
    costuming_requirements: Optional[str] = None
    benefit: str = Field(..., min_length=1)
    benefit_name: Optional[str] = Field(None, max_length=255)
    candle_cost: int = 0    

class CultureCreate(CultureBase):
    pass

class CultureUpdate(CultureBase):
    pass

class CultureResponse(CultureBase):
    id: str
    heritage_name: str = Field(..., description="Name of the heritage this culture belongs to")
    created_at: str

# Helper function to check admin permissions
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name IN ('manage_cultures', 'view_admin_panel')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    finally:
        await conn.close()

@router.get("/cultures/", response_model=List[CultureResponse])
async def list_cultures(heritage_id: Optional[str] = None):
    """List all cultures, optionally filtered by heritage"""
    conn = await get_database_connection()
    try:
        # Build the main query
        query = """
            SELECT c.id, c.name, c.heritage_id, c.description, 
                   c.costuming_requirements, c.benefit, c.benefit_name, c.created_at, c.candle_cost,
                   h.name as heritage_name
            FROM cultures c
            JOIN heritages h ON c.heritage_id = h.id
            ORDER BY c.name
        """
        if heritage_id:
            query = """
                SELECT c.id, c.name, c.heritage_id, c.description, 
                       c.costuming_requirements, c.benefit, c.benefit_name, c.created_at, c.candle_cost,
                       h.name as heritage_name
                FROM cultures c
                JOIN heritages h ON c.heritage_id = h.id
                WHERE c.heritage_id = $1
                ORDER BY c.name
            """
            rows = await conn.fetch(query, heritage_id)
        else:
            query = """
                SELECT c.id, c.name, c.heritage_id, c.description, 
                       c.costuming_requirements, c.benefit, c.benefit_name, c.created_at, c.candle_cost,
                       h.name as heritage_name
                FROM cultures c
                JOIN heritages h ON c.heritage_id = h.id
                ORDER BY c.name
            """
            rows = await conn.fetch(query)
        
        return [
            CultureResponse(
                id=str(row["id"]),
                name=row["name"],
                heritage_id=str(row["heritage_id"]),
                description=row["description"],
                costuming_requirements=row["costuming_requirements"],
                benefit=row["benefit"],
                benefit_name=row["benefit_name"],
                heritage_name=row["heritage_name"],
                created_at=row["created_at"].isoformat(),
                candle_cost=row["candle_cost"]
            )
            for row in rows
        ]
    except asyncpg.exceptions.PostgresError as e:
        print(f"Database error in list_cultures: {e}")
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        await conn.close()

@router.get("/cultures/{culture_id}", response_model=CultureResponse)
async def get_culture(culture_id: str):
    """Get a specific culture by ID"""
    conn = await get_database_connection()
    try:
        query = """
            SELECT c.id, c.name, c.heritage_id, c.description, 
                   c.costuming_requirements, c.benefit, c.benefit_name, c.created_at, c.candle_cost,
                   h.name as heritage_name
            FROM cultures c
            JOIN heritages h ON c.heritage_id = h.id
            WHERE c.id = $1
        """
        row = await conn.fetchrow(query, culture_id)
        
        if not row:
            raise HTTPException(status_code=404, detail="Culture not found")
        
        return CultureResponse(
            id=str(row["id"]),
            name=row["name"],
            heritage_id=str(row["heritage_id"]),
            description=row["description"],
            costuming_requirements=row["costuming_requirements"],
            benefit=row["benefit"],
            benefit_name=row["benefit_name"],
            heritage_name=row["heritage_name"],
            created_at=row["created_at"].isoformat(),
            candle_cost=row["candle_cost"]
        )
    except asyncpg.exceptions.PostgresError as e:
        print(f"Database error in get_culture: {e}")
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        await conn.close()

@router.post("/cultures/", response_model=CultureResponse)
async def create_culture(culture: CultureCreate, user: AuthorizedUser):
    """Create a new culture (admin only)"""
    await check_admin_permission(user)
    
    # Validate heritage_id is not empty
    if not culture.heritage_id or culture.heritage_id.strip() == "":
        raise HTTPException(status_code=400, detail="Heritage ID is required")
    
    conn = await get_database_connection()
    try:
        # Validate heritage exists
        heritage_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM heritages WHERE id = $1)",
            culture.heritage_id
        )
        if not heritage_exists:
            raise HTTPException(status_code=400, detail="Heritage not found")
        
        # Check if culture name already exists
        name_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM cultures WHERE LOWER(name) = LOWER($1))",
            culture.name
        )
        if name_exists:
            raise HTTPException(status_code=400, detail="Culture name already exists")
        
        # Insert the new culture
        query = """
            INSERT INTO cultures (name, heritage_id, description, costuming_requirements, benefit, benefit_name, candle_cost)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, created_at
        """
        row = await conn.fetchrow(
            query,
            culture.name,
            culture.heritage_id,
            culture.description,
            culture.costuming_requirements,
            culture.benefit,
            culture.benefit_name,
            culture.candle_cost
        )
        
        # Get heritage name for response
        heritage_name = await conn.fetchval(
            "SELECT name FROM heritages WHERE id = $1",
            culture.heritage_id
        )
        
        print(f"Created culture: {culture.name} for heritage: {heritage_name}")
        
        return CultureResponse(
            id=str(row["id"]),
            name=culture.name,
            heritage_id=culture.heritage_id,
            description=culture.description,
            costuming_requirements=culture.costuming_requirements,
            benefit=culture.benefit,
            benefit_name=culture.benefit_name,
            heritage_name=heritage_name,
            created_at=row["created_at"].isoformat()
        )
    except asyncpg.exceptions.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Culture name already exists")
    except asyncpg.exceptions.ForeignKeyViolationError:
        raise HTTPException(status_code=400, detail="Invalid heritage ID")
    except asyncpg.exceptions.PostgresError as e:
        print(f"Database error in create_culture: {e}")
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        await conn.close()

@router.put("/cultures/{culture_id}", response_model=CultureResponse)
async def update_culture(culture_id: str, culture: CultureUpdate, user: AuthorizedUser):
    """Update an existing culture (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if culture exists
        culture_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM cultures WHERE id = $1)",
            culture_id
        )
        if not culture_exists:
            raise HTTPException(status_code=404, detail="Culture not found")
        
        # Validate heritage exists
        heritage_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM heritages WHERE id = $1)",
            culture.heritage_id
        )
        if not heritage_exists:
            raise HTTPException(status_code=400, detail="Heritage not found")
        
        # Check if name already exists for another culture
        name_exists = await conn.fetchval(
            "SELECT EXISTS(SELECT 1 FROM cultures WHERE LOWER(name) = LOWER($1) AND id != $2)",
            culture.name, culture_id
        )
        if name_exists:
            raise HTTPException(status_code=400, detail="Culture name already exists")
        
        # Update the culture
        query = """
            UPDATE cultures 
            SET name = $2, heritage_id = $3, description = $4, 
                costuming_requirements = $5, benefit = $6, benefit_name = $7, candle_cost = $8
            WHERE id = $1
            RETURNING created_at
        """
        row = await conn.fetchrow(
            query,
            culture_id,
            culture.name,
            culture.heritage_id,
            culture.description,
            culture.costuming_requirements,
            culture.benefit,
            culture.benefit_name,
            culture.candle_cost
        )
        
        # Get heritage name for response
        heritage_name = await conn.fetchval(
            "SELECT name FROM heritages WHERE id = $1",
            culture.heritage_id
        )
        
        print(f"Updated culture: {culture.name} for heritage: {heritage_name}")

        await log_admin_action(
            user.sub, "culture", "update", culture_id, "culture",
            {"updated_fields": [k for k, v in culture.dict(exclude_unset=True).items()]}
        )
        
        return CultureResponse(
            id=culture_id,
            name=culture.name,
            heritage_id=culture.heritage_id,
            description=culture.description,
            costuming_requirements=culture.costuming_requirements,
            benefit=culture.benefit,
            benefit_name=culture.benefit_name,
            heritage_name=heritage_name,
            created_at=row["created_at"].isoformat()
        )
    except asyncpg.exceptions.UniqueViolationError:
        raise HTTPException(status_code=400, detail="Culture name already exists")
    except asyncpg.exceptions.ForeignKeyViolationError:
        raise HTTPException(status_code=400, detail="Invalid heritage ID")
    except asyncpg.exceptions.PostgresError as e:
        print(f"Database error in update_culture: {e}")
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        await conn.close()

@router.delete("/cultures/{culture_id}")
async def delete_culture(culture_id: str, user: AuthorizedUser):
    """Delete a culture (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Check if culture exists
        culture_name = await conn.fetchval(
            "SELECT name FROM cultures WHERE id = $1",
            culture_id
        )
        if not culture_name:
            raise HTTPException(status_code=404, detail="Culture not found")
        
        # Delete culture
        await conn.execute("DELETE FROM cultures WHERE id = $1", culture_id)
        
        print(f"Deleted culture: {culture_name}")


        
        return {"message": f"Culture '{culture_name}' deleted successfully"}
    except asyncpg.exceptions.PostgresError as e:
        print(f"Database error in delete_culture: {e}")
        raise HTTPException(status_code=500, detail="Database error")
    finally:
        await conn.close()
