from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import List, Optional
from uuid import UUID, uuid4
import asyncpg
from datetime import datetime
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/admin-galleries")

# --- Models ---

class GalleryCreate(BaseModel):
    """Request to create a new gallery"""
    name: str = Field(..., min_length=1, max_length=255)
    description: Optional[str] = None
    event_date: Optional[datetime] = None

class GalleryUpdate(BaseModel):
    """Request to update a gallery"""
    name: Optional[str] = Field(None, min_length=1, max_length=255)
    description: Optional[str] = None
    event_date: Optional[datetime] = None

class GalleryResponse(BaseModel):
    """Response for a gallery"""
    id: str
    name: str
    description: Optional[str]
    event_date: Optional[str]
    created_by_user_id: str
    created_at: str
    updated_at: str
    photo_count: int = 0

class PhotoCreate(BaseModel):
    """Request to create a new photo
    
    For Google Drive photos, use the direct image URL format:
    https://drive.google.com/uc?export=view&id=FILE_ID
    """
    photo_url: str = Field(..., description="URL to the photo (e.g., Google Drive direct link)")
    thumbnail_url: Optional[str] = None
    description: Optional[str] = None
    display_order: int = Field(default=0, ge=0)

class PhotoUpdate(BaseModel):
    """Request to update a photo"""
    photo_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    description: Optional[str] = None
    display_order: Optional[int] = Field(None, ge=0)

class PhotoResponse(BaseModel):
    """Response for a photo"""
    gallery_id: str
    photo_url: str
    thumbnail_url: Optional[str]
    photo_id: str
    description: Optional[str]
    display_order: int

class PhotoReorderRequest(BaseModel):
    photo_ids: List[str]

# New models for bulk upload
class BulkPhotoResult(BaseModel):
    photo_url: str
    status: str  # 'success' or 'duplicate' or 'error'
    photo_id: Optional[str] = None
    error_message: Optional[str] = None

class BulkPhotoUploadRequest(BaseModel):
    photos: List[PhotoCreate]

class BulkPhotoUploadResponse(BaseModel):
    results: List[BulkPhotoResult]
    success_count: int
    duplicate_count: int
    error_count: int

class PublicPhotoResponse(BaseModel):
    """Public response for photos (for PhotoGallery page)"""
    photo_id: str
    photo_url: str
    thumbnail_url: Optional[str]
    description: Optional[str]
    gallery_name: str
    event_date: Optional[str]
    tags: List[dict] = []  # List of photo tags with character info

# --- Helper Functions ---

async def require_permission(user_id: str, permission_name: str) -> None:
    """Check if user has specific permission using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has the required permission through their roles
        has_permission = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 AND p.name = $2
            )
            """,
            user_id,
            permission_name
        )
        
        if not has_permission:
            raise HTTPException(
                status_code=403,
                detail=f"Permission '{permission_name}' required"
            )
    finally:
        await conn.close()

# --- Admin Endpoints ---

@router.post("/galleries", response_model=GalleryResponse)
async def create_gallery(request: GalleryCreate, user: AuthorizedUser):
    """Create a new photo gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    conn = await get_database_connection()
    try:
        gallery_id = await conn.fetchval(
            """
            INSERT INTO public.photo_galleries 
            (name, description, event_date, created_by_user_id)
            VALUES ($1, $2, $3, $4)
            RETURNING id
            """,
            request.name,
            request.description,
            request.event_date,
            user.sub
        )
        
        gallery_data = await conn.fetchrow(
            """
            SELECT id, name, description, event_date, created_by_user_id, 
                   created_at, updated_at
            FROM public.photo_galleries
            WHERE id = $1
            """,
            gallery_id
        )

        await log_admin_action(
            user.sub, "photo_gallery", "create", str(gallery_data['id']), "gallery",
            {"name": request.name}
        )
        
        return GalleryResponse(
            id=str(gallery_data['id']),
            name=gallery_data['name'],
            description=gallery_data['description'],
            event_date=gallery_data['event_date'].isoformat() if gallery_data['event_date'] else None,
            created_by_user_id=gallery_data['created_by_user_id'],
            created_at=gallery_data['created_at'].isoformat(),
            updated_at=gallery_data['updated_at'].isoformat(),
            photo_count=0
        )
    finally:
        await conn.close()

@router.get("/galleries", response_model=List[GalleryResponse])
async def list_galleries(user: AuthorizedUser):
    """List all galleries with photo counts (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    conn = await get_database_connection()
    try:
        
        galleries_data = await conn.fetch(
            """
            SELECT 
                pg.id, pg.name, pg.description, pg.event_date, 
                pg.created_by_user_id, pg.created_at, pg.updated_at,
                COUNT(gp.id) as photo_count
            FROM public.photo_galleries pg
            LEFT JOIN public.gallery_photos gp ON pg.id = gp.gallery_id
            GROUP BY pg.id, pg.name, pg.description, pg.event_date, 
                     pg.created_by_user_id, pg.created_at, pg.updated_at
            ORDER BY pg.created_at DESC
            """
        )
        
        return [
            GalleryResponse(
                id=str(g['id']),
                name=g['name'],
                description=g['description'],
                event_date=g['event_date'].isoformat() if g['event_date'] else None,
                created_by_user_id=g['created_by_user_id'],
                created_at=g['created_at'].isoformat(),
                updated_at=g['updated_at'].isoformat(),
                photo_count=g['photo_count']
            )
            for g in galleries_data
        ]
    finally:
        await conn.close()

@router.put("/galleries/{gallery_id}", response_model=GalleryResponse)
async def update_gallery(gallery_id: str, request: GalleryUpdate, user: AuthorizedUser):
    """Update a gallery (admin only)"""
    gallery_uuid = UUID(gallery_id)
    await require_permission(user.sub, "manage_photo_galleries")
    
    conn = await get_database_connection()
    try:
        
        # Build dynamic update query
        update_fields = []
        params = []
        param_count = 1
        
        if request.name is not None:
            update_fields.append(f"name = ${param_count}")
            params.append(request.name)
            param_count += 1
        
        if request.description is not None:
            update_fields.append(f"description = ${param_count}")
            params.append(request.description)
            param_count += 1
        
        if request.event_date is not None:
            update_fields.append(f"event_date = ${param_count}")
            params.append(request.event_date)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        params.append(gallery_uuid)
        query = f"""
            UPDATE public.photo_galleries
            SET {', '.join(update_fields)}
            WHERE id = ${param_count}
            RETURNING id
        """
        
        updated_id = await conn.fetchval(query, *params)
        if not updated_id:
            raise HTTPException(status_code=404, detail="Gallery not found")
        
        # Fetch updated gallery
        gallery_data = await conn.fetchrow(
            """
            SELECT 
                pg.id, pg.name, pg.description, pg.event_date, 
                pg.created_by_user_id, pg.created_at, pg.updated_at,
                COUNT(gp.id) as photo_count
            FROM public.photo_galleries pg
            LEFT JOIN public.gallery_photos gp ON pg.id = gp.gallery_id
            WHERE pg.id = $1
            GROUP BY pg.id, pg.name, pg.description, pg.event_date, 
                     pg.created_by_user_id, pg.created_at, pg.updated_at
            """,
            gallery_uuid
        )

        await log_admin_action(
            user.sub, "photo_gallery", "update", gallery_id, "gallery",
            {"updated_fields": [k for k, v in request.dict(exclude_unset=True).items()]}
        )
        
        return GalleryResponse(
            id=str(gallery_data['id']),
            name=gallery_data['name'],
            description=gallery_data['description'],
            event_date=gallery_data['event_date'].isoformat() if gallery_data['event_date'] else None,
            created_by_user_id=gallery_data['created_by_user_id'],
            created_at=gallery_data['created_at'].isoformat(),
            updated_at=gallery_data['updated_at'].isoformat(),
            photo_count=gallery_data['photo_count']
        )
    finally:
        await conn.close()

@router.delete("/galleries/{gallery_id}")
async def delete_gallery(gallery_id: str, user: AuthorizedUser):
    """Delete a gallery and all its photos (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    gallery_uuid = UUID(gallery_id)
    conn = await get_database_connection()
    try:
        result = await conn.execute(
            "DELETE FROM public.photo_galleries WHERE id = $1",
            gallery_uuid
        )
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Gallery not found")

        await log_admin_action(
            user.sub, "photo_gallery", "delete", gallery_id, "gallery", {}
        )
        
        return {"message": "Gallery deleted successfully"}
    finally:
        await conn.close()

@router.get("/public/galleries", response_model=List[GalleryResponse])
async def list_public_galleries():
    """Get all galleries with photo counts (public endpoint for PhotoGallery page)"""
    conn = await get_database_connection()
    try:
        galleries_data = await conn.fetch(
            """
            SELECT 
                pg.id, pg.name, pg.description, pg.event_date, 
                pg.created_by_user_id, pg.created_at, pg.updated_at,
                COUNT(gp.id) as photo_count
            FROM public.photo_galleries pg
            LEFT JOIN public.gallery_photos gp ON pg.id = gp.gallery_id
            GROUP BY pg.id, pg.name, pg.description, pg.event_date, 
                     pg.created_by_user_id, pg.created_at, pg.updated_at
            ORDER BY pg.event_date DESC NULLS LAST, pg.created_at DESC
            """
        )
        
        return [
            GalleryResponse(
                id=str(g['id']),
                name=g['name'],
                description=g['description'],
                event_date=g['event_date'].isoformat() if g['event_date'] else None,
                created_by_user_id=g['created_by_user_id'],
                created_at=g['created_at'].isoformat(),
                updated_at=g['updated_at'].isoformat(),
                photo_count=g['photo_count']
            )
            for g in galleries_data
        ]
    finally:
        await conn.close()

@router.get("/public/galleries/{gallery_id}/photos", response_model=List[PublicPhotoResponse])
async def list_public_gallery_photos(gallery_id: str):
    """Get all photos from a specific gallery with their tags (public endpoint)"""
    gallery_uuid = UUID(gallery_id)
    conn = await get_database_connection()
    try:
        photos_data = await conn.fetch(
            """
            SELECT 
                gp.photo_id, gp.photo_url, gp.thumbnail_url, gp.description,
                pg.name as gallery_name, pg.event_date,
                pt.id as tag_id,
                pt.character_id,
                c.name as character_name,
                COALESCE(CONCAT(pp_tagged.first_name, ' ', pp_tagged.last_name), pp_tagged.email, 'Unknown Player') as player_name,
                pt.x_position,
                pt.y_position,
                pt.tagged_by_user_id,
                COALESCE(CONCAT(pp_tagger.first_name, ' ', pp_tagger.last_name), pp_tagger.email, 'Unknown User') as tagged_by_name,
                pt.created_at as tag_created_at
            FROM public.gallery_photos gp
            JOIN public.photo_galleries pg ON gp.gallery_id = pg.id
            LEFT JOIN public.photo_tags pt ON gp.photo_id = pt.photo_id
            LEFT JOIN public.characters c ON pt.character_id = c.id
            LEFT JOIN public.player_profiles pp_tagged ON c.player_profile_id = pp_tagged.id
            LEFT JOIN public.player_profiles pp_tagger ON pt.tagged_by_user_id = pp_tagger.user_id
            WHERE gp.gallery_id = $1
            ORDER BY gp.display_order, gp.created_at DESC
            """,
            gallery_uuid
        )
        
        # Group photos and their tags
        photos_map = {}
        for row in photos_data:
            photo_id = row['photo_id']
            if photo_id not in photos_map:
                photos_map[photo_id] = {
                    'photo_id': str(photo_id),
                    'photo_url': row['photo_url'],
                    'thumbnail_url': row['thumbnail_url'],
                    'description': row['description'],
                    'gallery_name': row['gallery_name'],
                    'event_date': row['event_date'].isoformat() if row['event_date'] else None,
                    'tags': []
                }
            
            # Add tag if it exists
            if row['tag_id'] is not None:
                photos_map[photo_id]['tags'].append({
                    'id': str(row['tag_id']),
                    'photo_url': row['photo_url'],
                    'photo_id': str(photo_id),
                    'character_id': str(row['character_id']),
                    'character_name': row['character_name'],
                    'player_name': row['player_name'],
                    'x_position': float(row['x_position']),
                    'y_position': float(row['y_position']),
                    'tagged_by_user_id': row['tagged_by_user_id'],
                    'tagged_by_name': row['tagged_by_name'],
                    'created_at': row['tag_created_at'].isoformat()
                })
        
        return [
            PublicPhotoResponse(**photo_data)
            for photo_data in photos_map.values()
        ]
    finally:
        await conn.close()

# Photo endpoints would continue here...
# (Add photo CRUD, reorder, and public endpoints)

@router.get("/public/photos", response_model=List[PublicPhotoResponse])
async def list_public_photos():
    """Get all photos from all galleries (public endpoint for PhotoGallery page)"""
    conn = await get_database_connection()
    try:
        photos_data = await conn.fetch(
            """
            SELECT 
                gp.photo_id, gp.photo_url, gp.thumbnail_url, gp.description,
                pg.name as gallery_name, pg.event_date
            FROM public.gallery_photos gp
            JOIN public.photo_galleries pg ON gp.gallery_id = pg.id
            ORDER BY gp.display_order, gp.created_at DESC
            """
        )
        
        return [
            PublicPhotoResponse(
                photo_id=p['photo_id'],
                photo_url=p['photo_url'],
                thumbnail_url=p['thumbnail_url'],
                description=p['description'],
                gallery_name=p['gallery_name'],
                event_date=p['event_date'].isoformat() if p['event_date'] else None,
                tags=[]
            )
            for p in photos_data
        ]
    finally:
        await conn.close()

@router.post("/galleries/{gallery_id}/photos", response_model=PhotoResponse)
async def add_photo_to_gallery(gallery_id: str, request: PhotoCreate, user: AuthorizedUser):
    """Add a photo to a gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    gallery_uuid = UUID(gallery_id)
    photo_id = str(uuid4())
    conn = await get_database_connection()
    try:
        # Get max display_order for this gallery
        max_order = await conn.fetchval(
            "SELECT COALESCE(MAX(display_order), -1) FROM public.gallery_photos WHERE gallery_id = $1",
            gallery_uuid
        )
        
        await conn.execute(
            """
            INSERT INTO public.gallery_photos 
            (photo_id, gallery_id, photo_url, thumbnail_url, description, display_order)
            VALUES ($1, $2, $3, $4, $5, $6)
            """,
            photo_id, gallery_uuid, request.photo_url, request.thumbnail_url,
            request.description, max_order + 1
        )

        await log_admin_action(
            user.sub, "gallery_photo", "create", str(photo_id), "photo",
            {"gallery_id": gallery_id}
        )
        
        return PhotoResponse(
            photo_id=str(photo_id),
            gallery_id=gallery_id,
            photo_url=request.photo_url,
            thumbnail_url=request.thumbnail_url,
            description=request.description,
            display_order=max_order + 1
        )
    finally:
        await conn.close()

@router.post("/galleries/{gallery_id}/photos/bulk", response_model=BulkPhotoUploadResponse)
async def bulk_add_photos_to_gallery(gallery_id: str, request: BulkPhotoUploadRequest, user: AuthorizedUser):
    """Bulk add photos to a gallery with duplicate detection (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    gallery_uuid = UUID(gallery_id)
    conn = await get_database_connection()
    
    results = []
    success_count = 0
    duplicate_count = 0
    error_count = 0
    
    try:
        # Get max display_order for this gallery
        max_order = await conn.fetchval(
            "SELECT COALESCE(MAX(display_order), -1) FROM public.gallery_photos WHERE gallery_id = $1",
            gallery_uuid
        )
        
        current_order = max_order + 1
        
        for photo_request in request.photos:
            photo_id = str(uuid4())
            
            try:
                await conn.execute(
                    """
                    INSERT INTO public.gallery_photos 
                    (photo_id, gallery_id, photo_url, thumbnail_url, description, display_order)
                    VALUES ($1, $2, $3, $4, $5, $6)
                    """,
                    photo_id, gallery_uuid, photo_request.photo_url, photo_request.thumbnail_url,
                    photo_request.description, current_order
                )
                
                results.append(BulkPhotoResult(
                    photo_url=photo_request.photo_url,
                    status="success",
                    photo_id=photo_id
                ))
                success_count += 1
                current_order += 1
                
            except asyncpg.UniqueViolationError:
                # Duplicate photo_url for this gallery
                results.append(BulkPhotoResult(
                    photo_url=photo_request.photo_url,
                    status="duplicate",
                    error_message="Photo URL already exists in this gallery"
                ))
                duplicate_count += 1
                
            except Exception as e:
                # Other errors
                results.append(BulkPhotoResult(
                    photo_url=photo_request.photo_url,
                    status="error",
                    error_message=str(e)
                ))
                error_count += 1
        
        return BulkPhotoUploadResponse(
            results=results,
            success_count=success_count,
            duplicate_count=duplicate_count,
            error_count=error_count
        )
        
    finally:
        await conn.close()

@router.get("/galleries/{gallery_id}/photos", response_model=List[PhotoResponse])
async def list_gallery_photos(gallery_id: str, user: AuthorizedUser):
    """List all photos in a gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    gallery_uuid = UUID(gallery_id)
    conn = await get_database_connection()
    try:
        photos_data = await conn.fetch(
            """
            SELECT photo_id, gallery_id, photo_url, thumbnail_url, description, display_order, created_at
            FROM public.gallery_photos
            WHERE gallery_id = $1
            ORDER BY display_order, created_at DESC
            """,
            gallery_uuid
        )
        
        return [
            PhotoResponse(
                photo_id=str(p['photo_id']),
                gallery_id=str(p['gallery_id']),
                photo_url=p['photo_url'],
                thumbnail_url=p['thumbnail_url'],
                description=p['description'],
                display_order=p['display_order']
            )
            for p in photos_data
        ]
    finally:
        await conn.close()

@router.put("/galleries/{gallery_id}/photos/{photo_id}", response_model=PhotoResponse)
async def update_gallery_photo(gallery_id: str, photo_id: str, request: PhotoUpdate, user: AuthorizedUser):
    """Update a photo in gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    photo_uuid = UUID(photo_id)
    gallery_uuid = UUID(gallery_id)
    
    conn = await get_database_connection()
    try:
        # Build dynamic update query
        updates = []
        values = []
        param_idx = 1
        
        if request.photo_url is not None:
            updates.append(f"photo_url = ${param_idx}")
            values.append(request.photo_url)
            param_idx += 1
        
        if request.thumbnail_url is not None:
            updates.append(f"thumbnail_url = ${param_idx}")
            values.append(request.thumbnail_url)
            param_idx += 1
        
        if request.description is not None:
            updates.append(f"description = ${param_idx}")
            values.append(request.description)
            param_idx += 1

        if request.display_order is not None:
            updates.append(f"display_order = ${param_idx}")
            values.append(request.display_order)
            param_idx += 1
            
        if not updates:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        values.extend([str(photo_uuid), str(gallery_uuid)])
        
        result = await conn.fetchrow(
            f"""
            UPDATE public.gallery_photos
            SET {', '.join(updates)}
            WHERE photo_id = ${param_idx} AND gallery_id = ${param_idx + 1}
            RETURNING photo_id, gallery_id, photo_url, thumbnail_url, description, display_order
            """,
            *values
        )
                
        if not result:
            raise HTTPException(status_code=404, detail="Photo not found")
        
        return PhotoResponse(
            photo_id=str(result['photo_id']),
            gallery_id=str(result['gallery_id']),
            photo_url=result['photo_url'],
            thumbnail_url=result['thumbnail_url'],
            description=result['description'],
            display_order=result['display_order']
        )
    finally:
        await conn.close()
        
@router.delete("/galleries/{gallery_id}/photos/{photo_id}")
async def delete_gallery_photo(gallery_id: str, photo_id: str, user: AuthorizedUser):
    """Delete a photo from gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    # Validate UUID format
    try:
        UUID(photo_id)
        UUID(gallery_id)
    except ValueError as err:
        raise HTTPException(status_code=400, detail="Invalid photo or gallery ID format") from err
    
    conn = await get_database_connection()
    try:
        result = await conn.execute(
            "DELETE FROM public.gallery_photos WHERE photo_id = $1 AND gallery_id = $2",
            photo_id, gallery_id
        )
        
        if result == "DELETE 0":
            raise HTTPException(status_code=404, detail="Photo not found")

        await log_admin_action(
            user.sub, "gallery_photo", "delete", photo_id, "photo",
            {"gallery_id": gallery_id}
        )
        
        return {"message": "Photo deleted successfully"}
    finally:
        await conn.close()

@router.post("/galleries/{gallery_id}/photos/reorder")
async def reorder_gallery_photos(gallery_id: str, request: PhotoReorderRequest, user: AuthorizedUser):
    """Reorder photos in a gallery (admin only)"""
    await require_permission(user.sub, "manage_photo_galleries")
    
    gallery_uuid = UUID(gallery_id)
    conn = await get_database_connection()
    
    try:
        # Update each photo's display_order
        for idx, photo_id_str in enumerate(request.photo_ids):
            photo_uuid = UUID(photo_id_str)
            await conn.execute(
                """
                UPDATE public.gallery_photos
                SET display_order = $1
                WHERE photo_id = $2 AND gallery_id = $3
                """,
                idx, photo_uuid, gallery_uuid
            )
        
        return {"message": "Photos reordered successfully"}
    finally:
        await conn.close()
