from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
from uuid import UUID, uuid4
from typing import List, Optional
from datetime import datetime
import asyncpg
from app.auth import AuthorizedUser
from app.libs.database import get_db_connection
from app.libs.audit import log_admin_action

router = APIRouter(prefix="/skills")

# Pydantic Models
class SkillCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=1)
    hidden: bool = False
    admin_only: bool = False
    prerequisite_skill_ids: list[str] = Field(default=[])
    prerequisite_count: int = Field(default=0, ge=0)  # Allow 0 when no prerequisites
    max_purchases: int = Field(default=1, ge=1, le=10)

class SkillUpdate(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=1)
    hidden: bool = False
    admin_only: bool = False
    prerequisite_skill_ids: list[str] = Field(default=[])
    prerequisite_count: int = Field(default=0, ge=0)  # Allow 0 when no prerequisites
    max_purchases: int = Field(default=1, ge=1, le=10)

class SkillResponse(BaseModel):
    id: str
    name: str
    description: str
    hidden: bool
    admin_only: bool
    prerequisite_count: int
    max_purchases: int
    prerequisites: List['SkillResponse'] = Field(default_factory=list)
    created_at: datetime

class SkillListResponse(BaseModel):
    skills: List[SkillResponse]
    total: int

@router.get("/", response_model=SkillListResponse)
async def list_skills(user: AuthorizedUser, show_hidden: bool = False):
    """List all skills with their prerequisite counts"""
    conn = await get_db_connection()
    try:
        # Build query based on show_hidden parameter
        if show_hidden:
            base_query = "SELECT id, name, description, hidden, admin_only, prerequisite_count, max_purchases, created_at FROM skills ORDER BY name"
        else:
            base_query = "SELECT id, name, description, hidden, admin_only, prerequisite_count, max_purchases, created_at FROM skills WHERE hidden = false ORDER BY name"
        
        # Get all skills
        rows = await conn.fetch(base_query)
        
        # Get all skill IDs for prerequisite lookup
        skill_ids = [row['id'] for row in rows]
        
        # Single query to get all prerequisites for all skills
        prereq_query = """
            SELECT 
                sp.skill_id,
                s.id as prereq_id, 
                s.name as prereq_name, 
                s.description as prereq_description, 
                s.hidden as prereq_hidden,
                s.admin_only as prereq_admin_only,
                s.prerequisite_count as prereq_prerequisite_count,
                s.max_purchases as prereq_max_purchases,
                s.created_at as prereq_created_at
            FROM skill_prerequisites sp
            JOIN skills s ON s.id = sp.prerequisite_skill_id
            WHERE sp.skill_id = ANY($1)
            ORDER BY sp.skill_id, s.name
        """
        
        prereq_rows = await conn.fetch(prereq_query, skill_ids)
        
        # Group prerequisites by skill_id
        skill_prereqs = {}
        for prereq_row in prereq_rows:
            skill_id = prereq_row['skill_id']
            if skill_id not in skill_prereqs:
                skill_prereqs[skill_id] = []
            
            skill_prereqs[skill_id].append(SkillResponse(
                id=str(prereq_row['prereq_id']),
                name=prereq_row['prereq_name'],
                description=prereq_row['prereq_description'],
                hidden=prereq_row['prereq_hidden'],
                admin_only=prereq_row['prereq_admin_only'],
                prerequisite_count=prereq_row['prereq_prerequisite_count'],
                max_purchases=prereq_row['prereq_max_purchases'],
                prerequisites=[],
                created_at=prereq_row['prereq_created_at']
            ))
        
        # Build final skills list with prerequisites
        skills = []
        for row in rows:
            skill_id = row['id']
            prerequisites = skill_prereqs.get(skill_id, [])
            
            skills.append(SkillResponse(
                id=str(row['id']),
                name=row['name'],
                description=row['description'],
                hidden=row['hidden'],
                admin_only=row['admin_only'],
                prerequisite_count=row['prerequisite_count'],
                max_purchases=row['max_purchases'],
                prerequisites=prerequisites,
                created_at=row['created_at']
            ))
        
        return SkillListResponse(skills=skills, total=len(skills))
        
    finally:
        await conn.close()

@router.get("/{skill_id}", response_model=SkillResponse)
async def get_skill(skill_id: str, user: AuthorizedUser):
    """Get a specific skill with its prerequisites"""
    conn = await get_db_connection()
    try:
        # Get the main skill
        skill_row = await conn.fetchrow(
            "SELECT id, name, description, hidden, admin_only, prerequisite_count, max_purchases, created_at FROM skills WHERE id = $1",
            UUID(skill_id)
        )
        
        if not skill_row:
            raise HTTPException(status_code=404, detail="Skill not found")
        
        # Get prerequisites
        prereq_rows = await conn.fetch(
            """
            SELECT s.id, s.name, s.description, s.hidden, s.admin_only, s.prerequisite_count, s.max_purchases, s.created_at
            FROM skills s
            JOIN skill_prerequisites sp ON s.id = sp.prerequisite_skill_id
            WHERE sp.skill_id = $1
            """,
            UUID(skill_id)
        )
        
        # Build prerequisite list
        prerequisites = [
            SkillResponse(
                id=str(row['id']),
                name=row['name'],
                description=row['description'],
                hidden=row['hidden'],
                admin_only=row['admin_only'],
                prerequisite_count=row['prerequisite_count'],
                max_purchases=row['max_purchases'],
                prerequisites=[],
                created_at=row['created_at']
            )
            for row in prereq_rows
        ]
        
        return SkillResponse(
            id=str(skill_row['id']),
            name=skill_row['name'],
            description=skill_row['description'],
            hidden=skill_row['hidden'],
            admin_only=skill_row['admin_only'],
            prerequisite_count=skill_row['prerequisite_count'],
            max_purchases=skill_row['max_purchases'],
            prerequisites=prerequisites,
            created_at=skill_row['created_at']
        )
        
    finally:
        await conn.close()

@router.post("/", response_model=SkillResponse)
async def create_skill(skill_data: SkillCreate, user: AuthorizedUser):
    """Create a new skill with prerequisites"""
    conn = await get_db_connection()
    try:
        # Validate prerequisite count doesn't exceed available prerequisites
        if skill_data.prerequisite_skill_ids and skill_data.prerequisite_count > len(skill_data.prerequisite_skill_ids):
            raise HTTPException(
                status_code=400, 
                detail=f"Prerequisite count ({skill_data.prerequisite_count}) cannot exceed number of selected prerequisites ({len(skill_data.prerequisite_skill_ids)})"
            )
        
        # Create the skill
        skill_id = uuid4()
        try:
            await conn.execute(
                "INSERT INTO skills (id, name, description, hidden, admin_only, prerequisite_count, max_purchases) VALUES ($1, $2, $3, $4, $5, $6, $7)",
                skill_id, skill_data.name, skill_data.description, skill_data.hidden, skill_data.admin_only, skill_data.prerequisite_count, skill_data.max_purchases
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(
                status_code=400,
                detail=f"A skill with the name '{skill_data.name}' already exists. Please choose a different name."
            )
        
        # Add prerequisites if any
        if skill_data.prerequisite_skill_ids:
            # Validate all prerequisite skills exist
            prereq_check = await conn.fetch(
                "SELECT id FROM skills WHERE id = ANY($1)",
                [UUID(pid) for pid in skill_data.prerequisite_skill_ids]
            )
            
            if len(prereq_check) != len(skill_data.prerequisite_skill_ids):
                raise HTTPException(status_code=400, detail="One or more prerequisite skills not found")
            
            # Insert prerequisites
            prereq_values = [(skill_id, UUID(pid)) for pid in skill_data.prerequisite_skill_ids]
            if prereq_values:
                await conn.executemany(
                    "INSERT INTO skill_prerequisites (skill_id, prerequisite_skill_id) VALUES ($1, $2)",
                    prereq_values
                )
        
        # Return the created skill
        # Log creation
        await log_admin_action(
            user.sub, "skill", "create", str(skill_id), "skill",
            {"name": skill_data.name}
        )        
        return await get_skill(str(skill_id), user)
        
    finally:
        await conn.close()

@router.put("/{skill_id}", response_model=SkillResponse)
async def update_skill(skill_id: str, skill_data: SkillUpdate, user: AuthorizedUser):
    """Update a skill and its prerequisites"""
    conn = await get_db_connection()
    try:
        # Check skill exists
        existing = await conn.fetchrow(
            "SELECT id FROM skills WHERE id = $1",
            UUID(skill_id)
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Skill not found")
        
        # Validate prerequisite count doesn't exceed available prerequisites
        if skill_data.prerequisite_skill_ids and skill_data.prerequisite_count > len(skill_data.prerequisite_skill_ids):
            raise HTTPException(
                status_code=400, 
                detail=f"Prerequisite count ({skill_data.prerequisite_count}) cannot exceed number of selected prerequisites ({len(skill_data.prerequisite_skill_ids)})"
            )
        
        # Validate prerequisite skills exist
        if skill_data.prerequisite_skill_ids:
            prereq_check = await conn.fetch(
                "SELECT id FROM skills WHERE id = ANY($1) AND id != $2",
                [UUID(pid) for pid in skill_data.prerequisite_skill_ids],
                UUID(skill_id)
            )
            
            if len(prereq_check) != len(skill_data.prerequisite_skill_ids):
                raise HTTPException(status_code=400, detail="One or more prerequisite skills not found")
        
        # Update the skill
        try:
            await conn.execute(
                "UPDATE skills SET name = $1, description = $2, hidden = $3, admin_only = $4, prerequisite_count = $5, max_purchases = $6 WHERE id = $7",
                skill_data.name, skill_data.description, skill_data.hidden, skill_data.admin_only, skill_data.prerequisite_count, skill_data.max_purchases, UUID(skill_id)
            )
        except asyncpg.UniqueViolationError:
            raise HTTPException(
                status_code=400,
                detail=f"A skill with the name '{skill_data.name}' already exists. Please choose a different name."
            )
        
        # Update prerequisites - delete existing and insert new ones
        await conn.execute(
            "DELETE FROM skill_prerequisites WHERE skill_id = $1",
            UUID(skill_id)
        )
        
        if skill_data.prerequisite_skill_ids:
            prereq_values = [(UUID(skill_id), UUID(pid)) for pid in skill_data.prerequisite_skill_ids]
            if prereq_values:
                await conn.executemany(
                    "INSERT INTO skill_prerequisites (skill_id, prerequisite_skill_id) VALUES ($1, $2)",
                    prereq_values
                )
        
        # Return the updated skill
        # Log update
        await log_admin_action(
            user.sub, "skill", "update", skill_id, "skill",
            {"updated_fields": [k for k, v in skill_data.dict(exclude_unset=True).items()]}
        )        
        return await get_skill(skill_id, user)
        
    finally:
        await conn.close()

@router.delete("/{skill_id}")
async def delete_skill(skill_id: str, user: AuthorizedUser):
    """Delete a skill and all its relationships with cascade cleanup and XP refunds"""
    conn = await get_db_connection()
    try:
        # Check if skill exists
        skill_row = await conn.fetchrow(
            "SELECT id, name FROM skills WHERE id = $1",
            UUID(skill_id)
        )
        
        if not skill_row:
            raise HTTPException(status_code=404, detail="Skill not found")
        
        skill_name = skill_row['name']
        
        # Start transaction for atomic cascade deletion
        async with conn.transaction():
            # 1. Check for dependent skills (skills that have this as prerequisite)
            dependent_skills = await conn.fetch(
                "SELECT s.name FROM skills s JOIN skill_prerequisites sp ON s.id = sp.skill_id WHERE sp.prerequisite_skill_id = $1",
                UUID(skill_id)
            )
            
            if dependent_skills:
                skill_names = [row['name'] for row in dependent_skills]
                print(f"Deleting skill '{skill_name}' will affect these dependent skills: {', '.join(skill_names)}")
            
            # 2. Remove from heritage secondary skills
            heritage_deletions = await conn.execute(
                "DELETE FROM heritage_secondary_skills WHERE skill_id = $1",
                UUID(skill_id)
            )
            print(f"Removed skill '{skill_name}' from {heritage_deletions.split()[-1]} heritage(s)")
            
            # 3. Remove from archetype primary skills
            archetype_primary_deletions = await conn.execute(
                "DELETE FROM archetype_primary_skills WHERE skill_id = $1",
                UUID(skill_id)
            )
            print(f"Removed skill '{skill_name}' from {archetype_primary_deletions.split()[-1]} archetype primary skill(s)")
            
            # 4. Remove from archetype secondary skills
            archetype_secondary_deletions = await conn.execute(
                "DELETE FROM archetype_secondary_skills WHERE skill_id = $1",
                UUID(skill_id)
            )
            print(f"Removed skill '{skill_name}' from {archetype_secondary_deletions.split()[-1]} archetype secondary skill(s)")
            
            # 5. Handle character skills - Note: character_skills table doesn't exist yet
            # This section is ready for when character system is implemented
            affected_characters = 0
            total_xp_refunded = 0
            print(f"Character skills system not yet implemented - no character data affected")
            
            # 6. Remove skill prerequisites (where this skill is a prerequisite)
            await conn.execute(
                "DELETE FROM skill_prerequisites WHERE prerequisite_skill_id = $1",
                UUID(skill_id)
            )
            
            # 7. Remove prerequisites where this skill depends on others
            await conn.execute(
                "DELETE FROM skill_prerequisites WHERE skill_id = $1",
                UUID(skill_id)
            )
            
            # 8. Finally delete the skill itself
            await conn.execute(
                "DELETE FROM skills WHERE id = $1",
                UUID(skill_id)
            )

        await log_admin_action(
            user.sub, "skill", "delete", skill_id, "skill",
            {"name": skill_name}
        )
        
        return {
            "message": f"Skill '{skill_name}' deleted successfully with cascade cleanup",
            "details": {
                "characters_affected": affected_characters,
                "xp_refunded": total_xp_refunded,
                "dependent_skills_affected": len(dependent_skills)
            }
        }
        
    finally:
        await conn.close()

# Helper function to check for circular dependencies
async def would_create_cycle(conn, skill_id: UUID, prerequisite_id: UUID) -> bool:
    """Check if adding a prerequisite would create a circular dependency"""
    if skill_id == prerequisite_id:
        return True
    
    # Check if skill_id is already a prerequisite of prerequisite_id (direct or indirect)
    visited = set()
    to_check = [prerequisite_id]
    
    while to_check:
        current = to_check.pop()
        if current == skill_id:
            return True
        
        if current in visited:
            continue
        
        visited.add(current)
        
        # Get prerequisites of current skill
        prereqs = await conn.fetch(
            "SELECT prerequisite_skill_id FROM skill_prerequisites WHERE skill_id = $1",
            current
        )
        
        for prereq in prereqs:
            to_check.append(prereq['prerequisite_skill_id'])
    
    return False

print("Skills API loaded with CRUD operations and prerequisite validation")
