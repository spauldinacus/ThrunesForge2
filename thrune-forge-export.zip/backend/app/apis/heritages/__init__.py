
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import asyncpg
import os
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from uuid import UUID

router = APIRouter(prefix="/heritages")

# Pydantic Models
class HeritageCreate(BaseModel):
    name: str
    description: str
    costuming_requirements: str
    base_body: int
    base_stamina: int
    benefit: str
    benefit_name: str
    weakness: str
    weakness_name: str
    secondary_skill_ids: List[str] = []
    candle_cost: int = 0    

class HeritageUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    costuming_requirements: Optional[str] = None
    base_body: Optional[int] = None
    base_stamina: Optional[int] = None
    benefit: Optional[str] = None
    benefit_name: Optional[str] = None
    weakness: Optional[str] = None
    weakness_name: Optional[str] = None
    secondary_skill_ids: Optional[List[str]] = None
    candle_cost: Optional[int] = None    

class SkillSummary(BaseModel):
    id: str
    name: str

class HeritageResponse(BaseModel):
    id: str
    name: str
    description: str
    costuming_requirements: str
    base_body: int
    base_stamina: int
    benefit: str
    benefit_name: str
    weakness: str
    weakness_name: str
    created_at: str
    secondary_skills: List[SkillSummary] = []
    secondary_skill_count: int = 0
    candle_cost: int = 0    

class HeritageListResponse(BaseModel):
    heritages: List[HeritageResponse]
    total: int

@router.get("/", response_model=HeritageListResponse)
async def list_heritages(user: AuthorizedUser):
    """List all heritages with their secondary skills"""
    conn = await get_database_connection()
    try:
        # Get all heritages first
        heritage_rows = await conn.fetch("""
            SELECT id, name, description, costuming_requirements, 
                   base_body, base_stamina, benefit, benefit_name, 
                   weakness, weakness_name, created_at, candle_cost
            FROM heritages 
            ORDER BY name
        """)
        
        heritages = []
        for heritage_row in heritage_rows:
            heritage_id = heritage_row['id']
            
            # Get secondary skills for this heritage
            skill_rows = await conn.fetch("""
                SELECT s.id, s.name 
                FROM skills s
                JOIN heritage_secondary_skills hs ON s.id = hs.skill_id
                WHERE hs.heritage_id = $1
                ORDER BY s.name
            """, heritage_id)
            
            skills = [SkillSummary(id=str(row['id']), name=row['name']) for row in skill_rows]
            
            heritages.append(HeritageResponse(
                id=str(heritage_row['id']),
                name=heritage_row['name'],
                description=heritage_row['description'],
                costuming_requirements=heritage_row['costuming_requirements'],
                base_body=heritage_row['base_body'],
                base_stamina=heritage_row['base_stamina'],
                benefit=heritage_row['benefit'],
                benefit_name=heritage_row['benefit_name'] or '',
                weakness=heritage_row['weakness'],
                weakness_name=heritage_row['weakness_name'] or '',
                created_at=heritage_row['created_at'].isoformat(),
                secondary_skills=skills,
                secondary_skill_count=len(skills),
                candle_cost=heritage_row['candle_cost']
            ))
        
        return HeritageListResponse(heritages=heritages, total=len(heritages))
        
    finally:
        await conn.close()

@router.get("/{heritage_id}", response_model=HeritageResponse)
async def get_heritage(heritage_id: str, user: AuthorizedUser):
    """Get a specific heritage with its secondary skills"""
    conn = await get_database_connection()
    try:
        # Get the main heritage
        heritage_row = await conn.fetchrow("""
            SELECT id, name, description, costuming_requirements, 
                   base_body, base_stamina, benefit, benefit_name, weakness, weakness_name, created_at, candle_cost
            FROM heritages WHERE id = $1
        """, UUID(heritage_id))
        
        if not heritage_row:
            raise HTTPException(status_code=404, detail="Heritage not found")
        
        # Get secondary skills
        skill_rows = await conn.fetch("""
            SELECT s.id, s.name 
            FROM skills s
            JOIN heritage_secondary_skills hs ON s.id = hs.skill_id
            WHERE hs.heritage_id = $1
            ORDER BY s.name
        """, UUID(heritage_id))
        
        skills = [SkillSummary(id=str(row['id']), name=row['name']) for row in skill_rows]
        
        return HeritageResponse(
            id=str(heritage_row['id']),
            name=heritage_row['name'],
            description=heritage_row['description'],
            costuming_requirements=heritage_row['costuming_requirements'],
            base_body=heritage_row['base_body'],
            base_stamina=heritage_row['base_stamina'],
            benefit=heritage_row['benefit'],
            benefit_name=heritage_row['benefit_name'] or '',
            weakness=heritage_row['weakness'],
            weakness_name=heritage_row['weakness_name'] or '',
            created_at=heritage_row['created_at'].isoformat(),
            secondary_skills=skills,
            secondary_skill_count=len(skills),
            candle_cost=heritage_row['candle_cost']
        )
        
    finally:
        await conn.close()

@router.post("/", response_model=HeritageResponse)
async def create_heritage(heritage_data: HeritageCreate, user: AuthorizedUser):
    """Create a new heritage with secondary skills"""
    conn = await get_database_connection()
    try:
        # Check for duplicate name
        existing = await conn.fetchrow(
            "SELECT id FROM heritages WHERE name = $1",
            heritage_data.name
        )
        
        if existing:
            raise HTTPException(status_code=400, detail="Heritage name already exists")
        
        # Validate secondary skills exist
        if heritage_data.secondary_skill_ids:
            try:
                skill_uuids = [UUID(sid) for sid in heritage_data.secondary_skill_ids]
            except ValueError:
                raise HTTPException(status_code=400, detail="Invalid skill ID format")
            
            valid_skills = await conn.fetch(
                "SELECT id FROM skills WHERE id = ANY($1)",
                skill_uuids
            )
            
            if len(valid_skills) != len(heritage_data.secondary_skill_ids):
                raise HTTPException(status_code=400, detail="One or more secondary skills not found")
        
        # Validate base stats
        if heritage_data.base_body < 0 or heritage_data.base_stamina < 0:
            raise HTTPException(status_code=400, detail="Base body and stamina must be non-negative")
        
        # Start transaction
        async with conn.transaction():
            # Create the heritage
            heritage_id = await conn.fetchval("""
                INSERT INTO heritages (name, description, costuming_requirements, 
                                     base_body, base_stamina, benefit, benefit_name, weakness, weakness_name, candle_cost)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
                RETURNING id
            """, heritage_data.name, heritage_data.description, heritage_data.costuming_requirements,
                heritage_data.base_body, heritage_data.base_stamina, heritage_data.benefit, heritage_data.benefit_name,
                heritage_data.weakness, heritage_data.weakness_name, heritage_data.candle_cost)
            
            # Add secondary skills if any
            if heritage_data.secondary_skill_ids:
                skill_values = [(heritage_id, UUID(sid)) for sid in heritage_data.secondary_skill_ids]
                await conn.executemany(
                    "INSERT INTO heritage_secondary_skills (heritage_id, skill_id) VALUES ($1, $2)",
                    skill_values
                )
        
        # Return the created heritage
        # Log action
        await log_admin_action(
            user.sub, "heritage", "create", str(heritage_id), "heritage",
            {"name": heritage_data.name}
        )        
        return await get_heritage(str(heritage_id), user)
        
    finally:
        await conn.close()

@router.put("/{heritage_id}", response_model=HeritageResponse)
async def update_heritage(heritage_id: str, heritage_data: HeritageUpdate, user: AuthorizedUser):
    """Update a heritage and its secondary skills"""
    conn = await get_database_connection()
    try:
        # Check heritage exists
        existing = await conn.fetchrow(
            "SELECT id, name FROM heritages WHERE id = $1",
            UUID(heritage_id)
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Heritage not found")
        
        # Check for name conflicts (if name is being updated)
        if heritage_data.name and heritage_data.name != existing['name']:
            name_conflict = await conn.fetchrow(
                "SELECT id FROM heritages WHERE name = $1 AND id != $2",
                heritage_data.name, UUID(heritage_id)
            )
            
            if name_conflict:
                raise HTTPException(status_code=400, detail="Heritage name already exists")
        
        # Validate secondary skills if provided
        if heritage_data.secondary_skill_ids is not None:
            if heritage_data.secondary_skill_ids:
                try:
                    skill_uuids = [UUID(sid) for sid in heritage_data.secondary_skill_ids]
                except ValueError:
                    raise HTTPException(status_code=400, detail="Invalid skill ID format")
                
                valid_skills = await conn.fetch(
                    "SELECT id FROM skills WHERE id = ANY($1)",
                    skill_uuids
                )
                
                if len(valid_skills) != len(heritage_data.secondary_skill_ids):
                    raise HTTPException(status_code=400, detail="One or more secondary skills not found")
        
        # Validate base stats if provided
        if heritage_data.base_body is not None and heritage_data.base_body < 0:
            raise HTTPException(status_code=400, detail="Base body must be non-negative")
        
        if heritage_data.base_stamina is not None and heritage_data.base_stamina < 0:
            raise HTTPException(status_code=400, detail="Base stamina must be non-negative")
        
        # Start transaction
        async with conn.transaction():
            # Update heritage fields
            update_fields = []
            update_values = []
            
            if heritage_data.name is not None:
                update_fields.append("name = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.name)
            
            if heritage_data.description is not None:
                update_fields.append("description = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.description)
            
            if heritage_data.costuming_requirements is not None:
                update_fields.append("costuming_requirements = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.costuming_requirements)
            
            if heritage_data.base_body is not None:
                update_fields.append("base_body = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.base_body)
            
            if heritage_data.base_stamina is not None:
                update_fields.append("base_stamina = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.base_stamina)
            
            if heritage_data.benefit is not None:
                update_fields.append("benefit = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.benefit)
            
            if heritage_data.benefit_name is not None:
                update_fields.append("benefit_name = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.benefit_name)
            
            if heritage_data.weakness is not None:
                update_fields.append("weakness = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.weakness)
            
            if heritage_data.weakness_name is not None:
                update_fields.append("weakness_name = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.weakness_name)

            if heritage_data.candle_cost is not None:
                update_fields.append("candle_cost = $" + str(len(update_values) + 1))
                update_values.append(heritage_data.candle_cost)            
            
            if update_fields:
                update_values.append(UUID(heritage_id))
                await conn.execute(
                    f"UPDATE heritages SET {', '.join(update_fields)} WHERE id = $" + str(len(update_values)),
                    *update_values
                )
            
            # Update secondary skills if provided
            if heritage_data.secondary_skill_ids is not None:
                # Remove existing secondary skills
                await conn.execute(
                    "DELETE FROM heritage_secondary_skills WHERE heritage_id = $1",
                    UUID(heritage_id)
                )
                
                # Add new secondary skills
                if heritage_data.secondary_skill_ids:
                    skill_values = [(UUID(heritage_id), UUID(sid)) for sid in heritage_data.secondary_skill_ids]
                    await conn.executemany(
                        "INSERT INTO heritage_secondary_skills (heritage_id, skill_id) VALUES ($1, $2)",
                        skill_values
                    )
        
        # Return the updated heritage
        # Log action
        await log_admin_action(
            user.sub, "heritage", "update", heritage_id, "heritage",
            {"updated_fields": [k for k, v in heritage_data.dict(exclude_unset=True).items()]}
        )        
        return await get_heritage(heritage_id, user)
        
    finally:
        await conn.close()

@router.delete("/{heritage_id}")
async def delete_heritage(heritage_id: str, user: AuthorizedUser):
    """Delete a heritage and all its relationships"""
    conn = await get_database_connection()
    try:
        # Check if heritage exists
        existing = await conn.fetchrow(
            "SELECT id FROM heritages WHERE id = $1",
            UUID(heritage_id)
        )
        
        if not existing:
            raise HTTPException(status_code=404, detail="Heritage not found")
        
        # Check if heritage is used by cultures
        dependent_cultures = await conn.fetch(
            "SELECT name FROM cultures WHERE heritage_id = $1",
            UUID(heritage_id)
        )
        
        if dependent_cultures:
            culture_names = [row['name'] for row in dependent_cultures]
            raise HTTPException(
                status_code=400, 
                detail=f"Cannot delete heritage. It is used by cultures: {', '.join(culture_names)}"
            )
        
        # Delete the heritage (cascading deletes will handle secondary skills)
        await conn.execute(
            "DELETE FROM heritages WHERE id = $1",
            UUID(heritage_id)
        )

        await log_admin_action(
            user.sub, "heritage", "delete", heritage_id, "heritage", {}
        )
        
        return {"message": "Heritage deleted successfully"}
        
    finally:
        await conn.close()

print("Heritage API loaded with CRUD operations and skills association")
