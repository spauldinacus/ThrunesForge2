from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from uuid import UUID
import asyncpg
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection

router = APIRouter()

# Helper function to check admin permissions
async def check_admin_permission(user: AuthorizedUser) -> None:
    """Check if user has admin permissions using role-based system"""
    conn = await get_database_connection()
    try:
        # Check if user has any admin permissions through their roles
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_players', 'view_admin_panel')
            )
            """,
            user.sub
        )
        
        if not admin_check:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
    finally:
        await conn.close()
        
# Pydantic Models
class ReferralRecord(BaseModel):
    """Individual referral record"""
    id: UUID
    player_id: UUID
    player_name: str
    player_number: str
    referred_by_id: UUID
    referred_by_name: str
    referred_by_number: str
    referral_acknowledged: bool
    referral_acknowledged_at: Optional[datetime]
    referral_acknowledged_by_user_id: Optional[str]
    referral_acknowledged_by_name: Optional[str]
    created_at: datetime

class ReferralListResponse(BaseModel):
    """Response for referral list"""
    referrals: List[ReferralRecord]
    total_count: int

class TopReferrer(BaseModel):
    """Top referrer statistics"""
    player_id: str
    player_name: str
    player_number: str
    referral_count: int
class ReferralStatsResponse(BaseModel):
    """Statistics about referrals"""
    total_referrals: int
    pending_referrals: int
    acknowledged_referrals: int
    top_referrers: List[TopReferrer]  # [{player_name, player_number, referral_count}]

class AcknowledgeReferralRequest(BaseModel):
    """Request to acknowledge a referral"""
    player_id: UUID

class AcknowledgeReferralResponse(BaseModel):
    """Response after acknowledging a referral"""
    success: bool
    message: str

@router.get("/referrals/list", response_model=ReferralListResponse)
async def list_referrals(
    filter_type: Optional[str] = "all",  # all, pending, acknowledged
    user: AuthorizedUser = None
):
    """List all referrals with optional filtering (admin only)"""
    conn = await get_database_connection()
    try:
        # Check admin permissions
        await check_admin_permission(user)
        
        # Build query based on filter
        where_clause = ""
        if filter_type == "pending":
            where_clause = "WHERE p.referral_acknowledged = FALSE"
        elif filter_type == "acknowledged":
            where_clause = "WHERE p.referral_acknowledged = TRUE"
        
        query = f"""
            SELECT 
                p.id,
                p.id as player_id,
                p.first_name || ' ' || p.last_name as player_name,
                p.player_number,
                p.referred_by_player_id as referred_by_id,
                referrer.first_name || ' ' || referrer.last_name as referred_by_name,
                referrer.player_number as referred_by_number,
                p.referral_acknowledged,
                p.referral_acknowledged_at,
                p.referral_acknowledged_by_user_id,
                acknowledger.first_name || ' ' || acknowledger.last_name as referral_acknowledged_by_name,
                p.created_at
            FROM public.player_profiles p
            INNER JOIN public.player_profiles referrer ON p.referred_by_player_id = referrer.id
            LEFT JOIN public.player_profiles acknowledger ON p.referral_acknowledged_by_user_id = acknowledger.user_id
            {where_clause}
            ORDER BY p.referral_acknowledged ASC, p.created_at DESC
        """
        
        referrals = await conn.fetch(query)
        
        referral_records = [
            ReferralRecord(
                id=r['id'],
                player_id=r['player_id'],
                player_name=r['player_name'],
                player_number=r['player_number'],
                referred_by_id=r['referred_by_id'],
                referred_by_name=r['referred_by_name'],
                referred_by_number=r['referred_by_number'],
                referral_acknowledged=r['referral_acknowledged'],
                referral_acknowledged_at=r['referral_acknowledged_at'],
                referral_acknowledged_by_user_id=r['referral_acknowledged_by_user_id'],
                referral_acknowledged_by_name=r['referral_acknowledged_by_name'],
                created_at=r['created_at']
            )
            for r in referrals
        ]
        
        return ReferralListResponse(
            referrals=referral_records,
            total_count=len(referral_records)
        )
        
    except Exception as e:
        print(f"Error listing referrals: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to list referrals")
    finally:
        await conn.close()

@router.post("/referrals/acknowledge", response_model=AcknowledgeReferralResponse)
async def acknowledge_referral(
    request: AcknowledgeReferralRequest,
    user: AuthorizedUser
):
    """Acknowledge and lock a referral (admin only)"""
    conn = await get_database_connection()
    try:
        # Check admin permissions
        await check_admin_permission(user)
        
        # Check if referral exists and is not already acknowledged
        player = await conn.fetchrow(
            "SELECT id, referral_acknowledged, referred_by_player_id FROM public.player_profiles WHERE id = $1",
            request.player_id
        )
        
        if not player:
            raise HTTPException(status_code=404, detail="Player not found")
        
        if not player['referred_by_player_id']:
            raise HTTPException(status_code=400, detail="Player has no referral to acknowledge")
        
        if player['referral_acknowledged']:
            raise HTTPException(status_code=400, detail="Referral already acknowledged")
        
        # Update referral as acknowledged
        await conn.execute(
            """
            UPDATE public.player_profiles 
            SET 
                referral_acknowledged = TRUE,
                referral_acknowledged_at = NOW(),
                referral_acknowledged_by_user_id = $1
            WHERE id = $2
            """,
            user.sub,
            request.player_id
        )
        
        return AcknowledgeReferralResponse(
            success=True,
            message="Referral acknowledged and locked successfully"
        )
        
    except Exception as e:
        print(f"Error acknowledging referral: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to acknowledge referral")
    finally:
        await conn.close()

@router.get("/referrals/stats", response_model=ReferralStatsResponse)
async def get_referral_stats(user: AuthorizedUser):
    """Get referral statistics and top referrers (admin only)"""
    conn = await get_database_connection()
    try:
        # Check admin permissions
        await check_admin_permission(user)
        
        # Get total counts
        stats = await conn.fetchrow(
            """
            SELECT 
                COUNT(*) as total,
                COUNT(*) FILTER (WHERE referral_acknowledged = FALSE) as pending,
                COUNT(*) FILTER (WHERE referral_acknowledged = TRUE) as acknowledged
            FROM public.player_profiles
            WHERE referred_by_player_id IS NOT NULL
            """
        )
        
        # Get top referrers
        top_referrers = await conn.fetch(
            """
            SELECT 
                referrer.id,
                referrer.first_name || ' ' || referrer.last_name as player_name,
                referrer.player_number,
                COUNT(referred.id) as referral_count
            FROM public.player_profiles referrer
            INNER JOIN public.player_profiles referred ON referred.referred_by_player_id = referrer.id
            GROUP BY referrer.id, referrer.first_name, referrer.last_name, referrer.player_number
            ORDER BY referral_count DESC
            LIMIT 10
            """
        )
        
        return ReferralStatsResponse(
            total_referrals=stats['total'] or 0,
            pending_referrals=stats['pending'] or 0,
            acknowledged_referrals=stats['acknowledged'] or 0,
            top_referrers=[
                {
                    "player_id": str(r['id']),  # ← ADD THIS LINE
                    "player_name": r['player_name'],
                    "player_number": r['player_number'],
                    "referral_count": r['referral_count']
                }
                for r in top_referrers
            ]
        )
        
    except Exception as e:
        print(f"Error getting referral stats: {e}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(status_code=500, detail="Failed to get referral stats")
    finally:
        await conn.close()

class PlayerListItem(BaseModel):
    """Individual player for referral selection"""
    id: UUID
    name: str
    player_number: str
    chapter_id: UUID
    chapter_name: str

class ChapterPlayersGroup(BaseModel):
    """Players grouped by chapter"""
    chapter_id: UUID
    chapter_name: str
    players: List[PlayerListItem]

@router.get("/referrals/players-for-referral", response_model=List[ChapterPlayersGroup])
async def list_players_for_referral(user: AuthorizedUser):
    """Get all players grouped by chapter for referral selection"""
    conn = await get_database_connection()
    try:
        # Get current user's player profile to exclude self
        current_player = await conn.fetchrow(
            "SELECT id FROM public.player_profiles WHERE user_id = $1",
            user.sub
        )
        
        # Get all players with their chapter info
        players = await conn.fetch(
            """
            SELECT 
                p.id,
                p.first_name || ' ' || p.last_name as name,
                p.player_number,
                c.id as chapter_id,
                c.name as chapter_name
            FROM public.player_profiles p
            INNER JOIN public.chapters c ON p.chapter_id = c.id
            WHERE p.id != $1
            ORDER BY c.name, p.first_name, p.last_name
            """,
            current_player['id'] if current_player else None
        )
        
        # Group by chapter
        chapters_dict = {}
        for player in players:
            chapter_id = player['chapter_id']
            if chapter_id not in chapters_dict:
                chapters_dict[chapter_id] = {
                    'chapter_id': chapter_id,
                    'chapter_name': player['chapter_name'],
                    'players': []
                }
            
            chapters_dict[chapter_id]['players'].append(
                PlayerListItem(
                    id=player['id'],
                    name=player['name'],
                    player_number=player['player_number'],
                    chapter_id=player['chapter_id'],
                    chapter_name=player['chapter_name']
                )
            )
        
        # Convert to list of ChapterPlayersGroup
        result = [
            ChapterPlayersGroup(
                chapter_id=chapter_data['chapter_id'],
                chapter_name=chapter_data['chapter_name'],
                players=chapter_data['players']
            )
            for chapter_data in chapters_dict.values()
        ]
        
        return result
        
    except Exception as e:
        print(f"Error loading players for referral: {e}")
        raise HTTPException(status_code=500, detail="Failed to load players")
    finally:
        await conn.close()