import uuid
import json
import asyncpg
import os
import io
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, validator
from typing import List, Optional, Union, Literal
from datetime import datetime
from uuid import UUID
from app.auth import AuthorizedUser
from app.libs.database import get_database_connection
from app.libs.audit import log_admin_action
from app.apis.characters import calculate_body_stamina_xp_cost
from typing import Dict, Any

class AdminCharacterUpdate(BaseModel):
    name: Optional[str] = None
    heritage_id: Optional[UUID] = None
    culture_id: Optional[UUID] = None
    archetype_id: Optional[UUID] = None
    secondary_archetype_id: Optional[UUID] = None
    tertiary_archetype_id: Optional[UUID] = None
    body: Optional[int] = None
    stamina: Optional[int] = None
    selected_skills: Optional[List[dict]] = None
    bio: Optional[str] = None
    player_profile_id: Optional[UUID] = None
    chapter_id: Optional[UUID] = None


class AdminCharacterListItem(BaseModel):
    """Response model for character list items in admin view"""
    id: str
    name: str
    heritage_id: str
    heritage_name: Optional[str] = None
    culture_id: str
    culture_name: Optional[str] = None
    archetype_id: str
    archetype_name: Optional[str] = None
    secondary_archetype_id: Optional[str] = None
    secondary_archetype_name: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    tertiary_archetype_name: Optional[str] = None
    body: int
    stamina: int
    player_profile_id: str
    player_name: str
    player_number: str
    chapter_id: str
    deaths: int
    corruption: int
    retired: bool
    events_attended: int
    last_attended_event_id: Optional[str] = None
    xp_total: int
    xp_available: int
    xp_spent: int
    skill_count: int
    created_at: datetime

class AdminCharacterListResponse(BaseModel):
    """Response model for list of characters"""
    characters: List[AdminCharacterListItem]

# Assuming these functions exist from the context of the original file
from app.libs.pdf_form_filler import generate_character_sheet_pdf, generate_bulk_character_sheets

router = APIRouter(prefix="/admin")

# --- Database Helpers ---

async def get_db_connection():
    """Get database connection"""
    return await get_database_connection()

async def check_admin_permission(user: AuthorizedUser):
    """Check if user has admin permissions using role-based system"""
    conn = None
    try:
        conn = await get_db_connection()
        admin_check = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1
                AND p.name IN ('manage_events', 'manage_chapters', 'view_admin_panel', 'manage_characters')
            )
            """,
            user.sub
        )
        if not admin_check:
            raise HTTPException(status_code=403, detail="Admin access required")
    except HTTPException:
        raise
    except Exception as e:
        print(f"DEBUG: Error checking admin permission: {e}")
        raise HTTPException(status_code=500, detail="Permission check failed")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- Pydantic Models ---
class AdminXPTransactionCreate(BaseModel):
    amount: int
    transaction_type: str
    reason: str

class ChapterResponse(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    chapter_code: Optional[str] = None
    location: Optional[str] = None
    contact_email: Optional[str] = None
    website: Optional[str] = None
    created_at: datetime

class ChapterListResponse(BaseModel):
    chapters: List[ChapterResponse]

class AdminEventResponse(BaseModel):
    id: str
    chapter_id: str
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    starts_at: datetime
    ends_at: datetime
    status: str
    created_at: datetime
    chapter_name: str
    total_rsvps: int
    attended_count: int
    no_show_count: int

class AdminEventListResponse(BaseModel):
    events: List[AdminEventResponse]

class Chapter(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    chapter_code: Optional[str] = None
    location: Optional[str] = None
    contact_email: Optional[str] = None
    website: Optional[str] = None
    created_at: datetime

class ChapterCreate(BaseModel):
    name: str
    description: Optional[str] = None
    chapter_code: str
    location: Optional[str] = None
    contact_email: Optional[str] = None
    website: Optional[str] = None

    @validator('chapter_code')
    def validate_chapter_code(cls, v):
        if not v or len(v) != 2 or not v.isalpha() or not v.isupper():
            raise ValueError('Chapter code must be exactly 2 uppercase letters')
        return v

class ChapterUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    chapter_code: Optional[str] = None
    location: Optional[str] = None
    contact_email: Optional[str] = None
    website: Optional[str] = None

    @validator('chapter_code')
    def validate_chapter_code(cls, v):
        if v is not None and (len(v) != 2 or not v.isalpha() or not v.isupper()):
            raise ValueError('Chapter code must be exactly 2 uppercase letters')
        return v

class CreateEventRequest(BaseModel):
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    chapter_id: str
    starts_at: datetime
    ends_at: datetime
    status: str = "scheduled"

    @validator('ends_at')
    def validate_end_after_start(cls, v, values):
        if 'starts_at' in values and v <= values['starts_at']:
            raise ValueError('End time must be after start time')
        return v

    @validator('status')
    def validate_status(cls, v):
        valid_statuses = ['scheduled', 'completed', 'cancelled', 'upcoming']
        if v not in valid_statuses:
            raise ValueError(f'Status must be one of: {", ".join(valid_statuses)}')
        return v

class EventCreated(BaseModel):
    id: str
    title: str
    chapter_id: str
    starts_at: datetime
    ends_at: datetime
    status: str
    created_at: datetime

class UpdateEventRequest(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    location: Optional[str] = None
    chapter_id: Optional[str] = None
    starts_at: Optional[datetime] = None
    ends_at: Optional[datetime] = None
    status: Optional[Literal['scheduled', 'completed', 'cancelled', 'upcoming']] = None

class EventUpdated(BaseModel):
    id: str
    title: str
    description: Optional[str]
    location: Optional[str]
    chapter_id: str
    starts_at: datetime
    ends_at: datetime
    status: str
    created_at: datetime

class EventResponse(BaseModel):
    id: str
    title: str
    description: Optional[str] = None
    location: Optional[str] = None
    chapter_id: str
    chapter_name: str
    starts_at: datetime
    ends_at: datetime
    status: str
    rsvp_count: int
    attended_count: int
    created_at: datetime

class AttendeeInfo(BaseModel):
    id: str
    character_id: Optional[str] = None
    character_name: Optional[str] = None
    player_name: str
    player_number: str
    ticket_xp: int
    candle_xp: int
    rsvp_status: str  # ADD THIS LINE - The original RSVP status (going/maybe/not_attending)
    attendance_status: str
    notes: Optional[str] = None
    processed_by_user_id: Optional[str] = None
    attendance_processed_at: Optional[datetime] = None
    created_at: datetime

class EventAttendanceResponse(BaseModel):
    event: EventResponse
    attendees: List[AttendeeInfo]
    total_attendees: int

class UpdateAttendanceRequest(BaseModel):
    rsvp_id: str
    attendance_status: Literal['rsvp', 'attended', 'no_show']
    ticket_xp: Optional[int] = None
    candle_xp: Optional[int] = None
    notes: Optional[str] = None

class ManualRSVPRequest(BaseModel):
    character_id: UUID
    ticket_xp: int = 0
    candle_xp: int = 0
    notes: Optional[str] = None
    attendance_status: Literal['rsvp', 'attended', 'no_show'] = 'rsvp'

class ManualRSVPResponse(BaseModel):
    id: UUID
    message: str

class AddXPTransactionRequest(BaseModel):
    amount: int
    transaction_type: str
    reason: str

class AdminCharacterUpdate(BaseModel):
    name: Optional[str] = None
    body: Optional[int] = None
    stamina: Optional[int] = None
    heritage_id: Optional[str] = None
    culture_id: Optional[str] = None
    archetype_id: Optional[str] = None
    secondary_archetype_id: Optional[str] = None
    tertiary_archetype_id: Optional[str] = None
    selected_skills: Optional[List[dict]] = None
    player_notes: Optional[str] = None
    addictions_diseases: Optional[str] = None
    deaths: Optional[int] = None
    corruption: Optional[int] = None
    retired: Optional[bool] = None
    
# --- Chapter Endpoints ---

@router.get("/chapters")
async def list_chapters(user: AuthorizedUser) -> ChapterListResponse:
    """List all chapters"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_db_connection()
        query = "SELECT id::text, name, description, chapter_code, location, contact_email, website, created_at FROM chapters ORDER BY name ASC"
        rows = await conn.fetch(query)
        chapters = [ChapterResponse(**dict(row)) for row in rows]
        return ChapterListResponse(chapters=chapters)
    except Exception as e:
        print(f"Error listing chapters: {e}")
        raise HTTPException(status_code=500, detail="Failed to list chapters")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.post("/chapters")
async def create_chapter(chapter_data: ChapterCreate, user: AuthorizedUser) -> Chapter:
    """Create a new chapter (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        existing_code = await conn.fetchrow("SELECT id FROM chapters WHERE chapter_code = $1", chapter_data.chapter_code)
        if existing_code:
            raise HTTPException(status_code=400, detail="Chapter code already exists")

        query = """
            INSERT INTO chapters (name, description, chapter_code, location, contact_email, website)
            VALUES ($1, $2, $3, $4, $5, $6)
            RETURNING id, name, description, chapter_code, location, contact_email, website, created_at
        """
        row = await conn.fetchrow(
            query,
            chapter_data.name, chapter_data.description, chapter_data.chapter_code,
            chapter_data.location, chapter_data.contact_email, chapter_data.website
        )
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="chapter",
            action="create",
            entity_type="chapter",
            entity_id=str(row['id']),
            details={
                "name": chapter_data.name,
                "chapter_code": chapter_data.chapter_code,
                "location": chapter_data.location
            }
        )
        return Chapter(id=str(row['id']), name=row['name'], description=row['description'], 
                      chapter_code=row['chapter_code'], location=row['location'], 
                      contact_email=row['contact_email'], website=row['website'], 
                      created_at=row['created_at'])
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating chapter: {e}")
        raise HTTPException(status_code=500, detail="Failed to create chapter") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()


@router.put("/chapters/{chapter_id}")
async def update_chapter(chapter_id: str, chapter_data: ChapterUpdate, user: AuthorizedUser) -> Chapter:
    """Update an existing chapter (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        if not await conn.fetchrow("SELECT id FROM chapters WHERE id = $1", chapter_id):
            raise HTTPException(status_code=404, detail="Chapter not found")

        if chapter_data.chapter_code:
            existing_code = await conn.fetchrow("SELECT id FROM chapters WHERE chapter_code = $1 AND id != $2", chapter_data.chapter_code, chapter_id)
            if existing_code:
                raise HTTPException(status_code=400, detail="Chapter code already exists")

        update_fields = []
        update_values = []
        param_count = 1
        update_dict = chapter_data.dict(exclude_unset=True)

        for key, value in update_dict.items():
            update_fields.append(f"{key} = ${param_count}")
            update_values.append(value)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")
        
        update_values.append(chapter_id)
        query = f"""
            UPDATE chapters SET {', '.join(update_fields)}
            WHERE id = ${param_count}
            RETURNING id, name, description, chapter_code, location, contact_email, website, created_at
        """
        row = await conn.fetchrow(query, *update_values)
        return Chapter(id=str(row['id']), **dict(row))
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating chapter: {e}")
        raise HTTPException(status_code=500, detail="Failed to update chapter") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.delete("/chapters/{chapter_id}")
async def delete_chapter(chapter_id: str, user: AuthorizedUser):
    """Delete a chapter (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        
        # Check if chapter exists
        chapter = await conn.fetchrow("SELECT id FROM chapters WHERE id = $1", chapter_id)
        if not chapter:
            raise HTTPException(status_code=404, detail="Chapter not found")
        
        # Check if chapter has events
        events = await conn.fetchrow("SELECT COUNT(*) as count FROM events WHERE chapter_id = $1", chapter_id)
        if events['count'] > 0:
            raise HTTPException(status_code=400, detail="Cannot delete chapter with existing events")
        
        # Delete chapter
        await conn.execute("DELETE FROM chapters WHERE id = $1", chapter_id)
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="chapter",
            action="delete",
            entity_id=chapter_id,
            entity_type="chapter"
        )
        return {"message": "Chapter deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting chapter: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete chapter") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- Event Endpoints ---

@router.post("/events", response_model=EventCreated)
async def create_event(event_data: CreateEventRequest, user: AuthorizedUser):
    """Create a new event (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        if not await conn.fetchrow("SELECT id FROM chapters WHERE id = $1", event_data.chapter_id):
            raise HTTPException(status_code=400, detail="Chapter not found")

        query = """
            INSERT INTO events (title, description, location, chapter_id, starts_at, ends_at, status)
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id, title, chapter_id, starts_at, ends_at, status, created_at
        """
        row = await conn.fetchrow(query, event_data.title, event_data.description, event_data.location, event_data.chapter_id, event_data.starts_at, event_data.ends_at, event_data.status)
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="event",
            action="create",
            entity_id=str(row['id']),
            entity_type="event",
            details=event_data.dict()
        )
        return EventCreated(
            id=str(row['id']),
            title=row['title'],
            chapter_id=str(row['chapter_id']),
            starts_at=row['starts_at'],
            ends_at=row['ends_at'],
            status=row['status'],
            created_at=row['created_at']
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error creating event: {e}")
        raise HTTPException(status_code=500, detail="Failed to create event") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.get("/events")
async def list_admin_events(user: AuthorizedUser) -> AdminEventListResponse:
    """Get all events with admin data (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        query = """
            SELECT e.id, e.title, e.description, e.location, e.chapter_id, c.name as chapter_name, e.starts_at, e.ends_at, e.status, e.created_at,
                   COUNT(r.id) as total_rsvps,
                   COUNT(CASE WHEN r.attendance_status = 'attended' THEN 1 END) as attended_count,
                   COUNT(CASE WHEN r.attendance_status = 'no_show' THEN 1 END) as no_show_count
            FROM events e
            LEFT JOIN chapters c ON e.chapter_id = c.id
            LEFT JOIN rsvps r ON e.id = r.event_id
            GROUP BY e.id, c.name
            ORDER BY e.starts_at DESC
        """
        rows = await conn.fetch(query)
        events = [
            AdminEventResponse(
                **{k: str(v) if k in ('id', 'chapter_id') else v for k, v in dict(row).items()}
            ) 
            for row in rows
        ]    
        return AdminEventListResponse(events=events)
    except Exception as e:
        print(f"Error listing admin events: {e}")
        raise HTTPException(status_code=500, detail="Failed to list events")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.put("/events/{event_id}")
async def update_event(event_id: str, update_data: UpdateEventRequest, user: AuthorizedUser) -> EventUpdated:
    """Update an existing event (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        if not await conn.fetchrow("SELECT id FROM events WHERE id = $1", event_id):
            raise HTTPException(status_code=404, detail="Event not found")
        
        if update_data.chapter_id and not await conn.fetchrow("SELECT id FROM chapters WHERE id = $1", update_data.chapter_id):
            raise HTTPException(status_code=400, detail="Chapter not found")

        update_fields = []
        values = []
        param_count = 1
        update_dict = update_data.dict(exclude_unset=True)

        for key, value in update_dict.items():
            update_fields.append(f"{key} = ${param_count}")
            values.append(value)
            param_count += 1
        
        if not update_fields:
            raise HTTPException(status_code=400, detail="No fields to update")

        values.append(event_id)
        query = f"""
            UPDATE events SET {', '.join(update_fields)}
            WHERE id = ${param_count}
            RETURNING id, title, description, location, chapter_id, starts_at, ends_at, status, created_at
        """
        updated_row = await conn.fetchrow(query, *values)
        row_dict = dict(updated_row)
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="event",
            action="update",
            entity_id=event_id,
            entity_type="event",
            details=update_dict
        )
        return EventUpdated(
            id=str(row_dict['id']),
            chapter_id=str(row_dict['chapter_id']),
            title=row_dict['title'],
            description=row_dict['description'],
            location=row_dict['location'],
            starts_at=row_dict['starts_at'],
            ends_at=row_dict['ends_at'],
            status=row_dict['status'],
            created_at=row_dict['created_at']
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating event: {e}")
        raise HTTPException(status_code=500, detail="Failed to update event") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.delete("/events/{event_id}")
async def delete_event(event_id: str, user: AuthorizedUser) -> dict:
    """Delete an event and all related data (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        async with conn.transaction():
            existing_event = await conn.fetchrow("SELECT id, title FROM events WHERE id = $1", event_id)
            if not existing_event:
                raise HTTPException(status_code=404, detail="Event not found")

            rsvps = await conn.fetch("SELECT character_id, candle_xp FROM rsvps WHERE event_id = $1", event_id)
            
            for rsvp in rsvps:
                if rsvp['candle_xp'] > 0 and rsvp['character_id']:
                    player_profile_id = await conn.fetchval(
                        "SELECT player_profile_id FROM characters WHERE id = $1", rsvp['character_id']
                    )
                    if player_profile_id:
                        await conn.execute("UPDATE player_profiles SET candles_available = candles_available + $1 WHERE id = $2", rsvp['candle_xp'], player_profile_id)
                        await conn.execute(
                            """
                            INSERT INTO candle_transactions (player_profile_id, amount, reason, used_for, granted_by_user_id)
                            VALUES ($1, $2, $3, 'Event cancellation refund', $4)
                            """,
                            player_profile_id, rsvp['candle_xp'], f"Event cancellation refund for '{existing_event['title']}'", user.sub
                        )
            
            # Simplified XP reversal: Just delete transactions tied to this event
            await conn.execute("DELETE FROM xp_transactions WHERE reason LIKE $1", f"%{existing_event['title']}%")

            # Note: This simplified logic doesn't recalculate character XP totals. A more robust solution might
            # iterate through affected characters and call recalculate_character_xp(). For now, we assume this is handled separately or is acceptable.
            
            await conn.execute("DELETE FROM rsvps WHERE event_id = $1", event_id)
            await conn.execute("DELETE FROM events WHERE id = $1", event_id)

        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="event",
            action="delete",
            entity_id=event_id,
            entity_type="event",
            details={"title": existing_event['title']}
        )
        return {"success": True, "message": f"Event '{existing_event['title']}' deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting event: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete event") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- Attendance & RSVP Endpoints ---

@router.get("/events/{event_id}/attendees")
async def get_event_attendees(event_id: str, user: AuthorizedUser) -> EventAttendanceResponse:
    """Get all attendees for an event with attendance management data"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        event_query = "SELECT e.*, c.name as chapter_name FROM events e JOIN chapters c ON e.chapter_id = c.id WHERE e.id = $1"
        event_row = await conn.fetchrow(event_query, event_id)
        if not event_row:
            raise HTTPException(status_code=404, detail="Event not found")

        attendees_query = """
            SELECT r.*, c.name as character_name, pp.first_name, pp.last_name, pp.player_number
            FROM rsvps r
            JOIN player_profiles pp ON r.user_id = pp.user_id
            LEFT JOIN characters c ON r.character_id = c.id
            WHERE r.event_id = $1
            ORDER BY pp.last_name, pp.first_name
        """
        attendee_rows = await conn.fetch(attendees_query, event_id)
        attendees = [
             AttendeeInfo(
               id=str(row['id']),
                character_id=str(row['character_id']) if row['character_id'] else None,
                 player_name=f"{row['first_name']} {row['last_name']}",
                 player_number=row['player_number'],
                 ticket_xp=row['ticket_xp'],
                 candle_xp=row['candle_xp'],
                 rsvp_status=row['status'],  # ADD THIS LINE - Include the RSVP status
                 attendance_status=row['attendance_status'],
                 notes=row['notes'],
                 processed_by_user_id=str(row['processed_by_user_id']) if row['processed_by_user_id'] else None,
                 attendance_processed_at=row['attendance_processed_at'],
                 created_at=row['created_at'],
                 character_name=row['character_name']
             ) for row in attendee_rows
         ]
        
        total_rsvps = await conn.fetchval("SELECT COUNT(*) FROM rsvps WHERE event_id = $1", event_id)
        
        # Convert event_row to dict and add computed fields
        event_dict = dict(event_row)
        event_dict['id'] = str(event_dict['id'])
        event_dict['chapter_id'] = str(event_dict['chapter_id'])
        event_dict['rsvp_count'] = total_rsvps
        event_dict['attended_count'] = len([a for a in attendees if a.attendance_status == 'attended'])
        
        event_response = EventResponse(**event_dict)
        return EventAttendanceResponse(event=event_response, attendees=attendees, total_attendees=len(attendees))
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting event attendees: {e}")
        raise HTTPException(status_code=500, detail="Failed to get attendees")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.put("/events/rsvp/{rsvp_id}/attendance")
async def update_attendance_status(rsvp_id: str, update_data: UpdateAttendanceRequest, user: AuthorizedUser) -> dict:
    """Update attendance status and process XP rewards"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        async with conn.transaction():
            rsvp_row = await conn.fetchrow("SELECT * FROM rsvps WHERE id = $1", rsvp_id)
            if not rsvp_row:
                raise HTTPException(status_code=404, detail="RSVP not found")

            # --- START OF FIX ---
            # 1. Determine effective new values (fixing the "or" bug here too)
            new_candle_xp = update_data.candle_xp if update_data.candle_xp is not None else rsvp_row['candle_xp']
            
            # 2. Handle Candle Deduction
            old_candle_xp = rsvp_row['candle_xp']
            candle_cost_difference = (new_candle_xp - old_candle_xp) * 10
            
            if candle_cost_difference != 0:
                # Fetch player profile for this RSVP's user
                player_profile = await conn.fetchrow(
                    "SELECT id FROM player_profiles WHERE user_id = $1", 
                    rsvp_row['user_id']
                )
                
                if player_profile:
                    # Update balance
                    await conn.execute(
                        "UPDATE player_profiles SET candles_available = candles_available - $1 WHERE id = $2",
                        candle_cost_difference, player_profile['id']
                    )
                    
                    # Log transaction
                    reason = ""
                    used_for = ""
                    if candle_cost_difference > 0:
                        reason = f"Admin adjustment: XP purchase increase for event ({new_candle_xp - old_candle_xp} additional XP)"
                        used_for = "Event RSVP XP increase (Admin)"
                    else:
                        reason = f"Admin adjustment: XP purchase refund for event ({old_candle_xp - new_candle_xp} XP refunded)"
                        used_for = "Event RSVP XP refund (Admin)"

                    await conn.execute(
                        """
                        INSERT INTO candle_transactions (player_profile_id, amount, reason, used_for)
                        VALUES ($1, $2, $3, $4)
                        """,
                        player_profile['id'], -candle_cost_difference, reason, used_for
                    )

            # 3. Update RSVP record (using the effective values)
            await conn.execute(
                """
                UPDATE rsvps SET attendance_status = $1, ticket_xp = COALESCE($2, ticket_xp),
                candle_xp = COALESCE($3, candle_xp), notes = COALESCE($4, notes),
                processed_by_user_id = $5, attendance_processed_at = CURRENT_TIMESTAMP
                WHERE id = $6
                """,
                update_data.attendance_status, update_data.ticket_xp, update_data.candle_xp,
                update_data.notes, user.sub, rsvp_id
            )
            # --- END OF FIX ---

            # This complex XP logic is a candidate for a stored procedure in PostgreSQL
            # For now, it remains in the application layer. Re-running this endpoint should be idempotent.
            # We will clear old transactions and create new ones based on the final state.

            event = await conn.fetchrow("SELECT title FROM events WHERE id = $1", rsvp_row['event_id'])
            
            # Clear previous XP transaction for this event/character to ensure idempotency
            if rsvp_row['character_id']:
                await conn.execute(
                    "DELETE FROM xp_transactions WHERE character_id = $1 AND transaction_type = 'event_reward' AND reason LIKE $2",
                    rsvp_row['character_id'], f"%{event['title']}%"
                )

            if update_data.attendance_status == 'attended' and rsvp_row['character_id']:
                # Get character's current events attended count to calculate bonus XP
                events_attended = await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM rsvps r 
                    JOIN events e ON r.event_id = e.id 
                    WHERE r.character_id = $1 
                    AND r.attendance_status = 'attended'
                    """,
                    rsvp_row['character_id']
                ) or 0
                
                # Calculate attendance bonus XP based on events attended scale
                # Events 1-10: +6 XP, 11-20: +5 XP, 21-30: +4 XP, 31+: +3 XP
                if events_attended <= 10:
                    bonus_xp = 6
                elif events_attended <= 20:
                    bonus_xp = 5
                elif events_attended <= 30:
                    bonus_xp = 4
                else:
                    bonus_xp = 3
                
                # Fix: Use explicit None check instead of 'or' to allow 0 values
                effective_ticket_xp = update_data.ticket_xp if update_data.ticket_xp is not None else rsvp_row['ticket_xp']
                effective_candle_xp = update_data.candle_xp if update_data.candle_xp is not None else rsvp_row['candle_xp']
                
                event_xp = effective_ticket_xp + effective_candle_xp
                total_xp_reward = event_xp + bonus_xp
                
                
                await conn.execute(
                    "UPDATE characters SET xp_total = xp_total + $1, xp_available = xp_available + $1 WHERE id = $2",
                    total_xp_reward, rsvp_row['character_id']
                )
                await conn.execute(
                    """
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES ($1, $2, 'event_reward', $3)
                    """,
                    rsvp_row['character_id'], total_xp_reward, f"{event['title']}: {event_xp} event XP + {bonus_xp} attendance bonus"
                )
            # Re-calculate character's total XP after all operations
            if rsvp_row['character_id']:
                await recalculate_character_xp(conn, rsvp_row['character_id'])

            # Add audit log
            await log_admin_action(
                performed_by_user_id=user.sub,
                action_type="event",
                action="update_attendance",
                entity_type="rsvp",
                entity_id=str(rsvp_id),
                details={"status": update_data.attendance_status, "event_id": str(rsvp_row['event_id'])}
            )
        
        return {"success": True, "message": f"Attendance for RSVP {rsvp_id} updated to '{update_data.attendance_status}'"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating attendance status: {e}")
        raise HTTPException(status_code=500, detail="Failed to update attendance") from e
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.post("/events/{event_id}/manual-rsvp", response_model=ManualRSVPResponse)
async def add_manual_rsvp(event_id: UUID, rsvp_data: ManualRSVPRequest, user: AuthorizedUser):
    """Manually add an RSVP for a character (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_db_connection()
        async with conn.transaction():
            # MODIFIED: Fetch title for logging
            event = await conn.fetchrow("SELECT id, title FROM events WHERE id = $1", event_id)
            if not event:
                raise HTTPException(status_code=404, detail="Event not found")
            
            # MODIFIED: Fetch player_profile_id for transaction
            character_info = await conn.fetchrow("SELECT user_id, pp.id as player_profile_id FROM characters c JOIN player_profiles pp ON c.player_profile_id = pp.id WHERE c.id = $1", rsvp_data.character_id)
            if not character_info:
                raise HTTPException(status_code=404, detail="Character not found")
            
            if await conn.fetchrow("SELECT id FROM rsvps WHERE event_id = $1 AND character_id = $2", event_id, rsvp_data.character_id):
                raise HTTPException(status_code=400, detail="RSVP already exists for this character")

            # ADDED: Logic to deduct candles and log transaction
            if rsvp_data.candle_xp > 0:
                candle_cost = rsvp_data.candle_xp * 10
                player_profile_id = character_info['player_profile_id']
                
                # Deduct candles
                await conn.execute(
                    "UPDATE player_profiles SET candles_available = candles_available - $1 WHERE id = $2",
                    candle_cost, player_profile_id
                )
                
                # Log transaction
                reason = f"Admin manual RSVP: XP purchase for event '{event['title']}' ({rsvp_data.candle_xp} XP)"
                used_for = "Event RSVP XP purchase (Admin)"

                await conn.execute(
                    """
                    INSERT INTO candle_transactions (player_profile_id, amount, reason, used_for, granted_by_user_id)
                    VALUES ($1, $2, $3, $4, $5)
                    """,
                    player_profile_id, -candle_cost, reason, used_for, user.sub
                )
            rsvp_id = await conn.fetchval(
                """
                INSERT INTO rsvps (event_id, user_id, character_id, attendance_status, ticket_xp, candle_xp, notes, processed_by_user_id)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id
                """,
                event_id, character_info['user_id'], rsvp_data.character_id, rsvp_data.attendance_status,
                rsvp_data.ticket_xp, rsvp_data.candle_xp, rsvp_data.notes, user.sub
            )
            
            # Process XP if attendance status is 'attended'
            if rsvp_data.attendance_status == 'attended' and rsvp_data.character_id:
                # Get event title for transaction reason
                event = await conn.fetchrow("SELECT title FROM events WHERE id = $1", event_id)
                
                # Get character's current events attended count to calculate bonus XP
                events_attended = await conn.fetchval(
                    """
                    SELECT COUNT(*) FROM rsvps r 
                    JOIN events e ON r.event_id = e.id 
                    WHERE r.character_id = $1 
                    AND r.attendance_status = 'attended'
                    """,
                    rsvp_data.character_id
                ) or 0
                
                # Calculate attendance bonus XP based on events attended scale
                # Events 1-10: +6 XP, 11-20: +5 XP, 21-30: +4 XP, 31+: +3 XP
                if events_attended <= 10:
                    bonus_xp = 6
                elif events_attended <= 20:
                    bonus_xp = 5
                elif events_attended <= 30:
                    bonus_xp = 4
                else:
                    bonus_xp = 3
                
                # Fix: Use explicit None check instead of 'or' to allow 0 values
                ticket_xp = rsvp_data.ticket_xp if rsvp_data.ticket_xp is not None else 0
                candle_xp = rsvp_data.candle_xp if rsvp_data.candle_xp is not None else 0
                
                event_xp = ticket_xp + candle_xp
                total_xp_reward = event_xp + bonus_xp
                
                # Award XP to character
                await conn.execute(
                    "UPDATE characters SET xp_total = xp_total + $1, xp_available = xp_available + $1 WHERE id = $2",
                    total_xp_reward, rsvp_data.character_id
                )
                await conn.execute(
                    """
                    INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
                    VALUES ($1, $2, 'event_reward', $3)
                    """,
                    rsvp_data.character_id, total_xp_reward, f"{event['title']}: {event_xp} event XP + {bonus_xp} attendance bonus"
                )
                
                # Recalculate character XP totals
                await recalculate_character_xp(conn, rsvp_data.character_id)

            # Add audit log
            await log_admin_action(
                performed_by_user_id=user.sub,
                action_type="event",
                action="manual_rsvp",
                entity_type="rsvp",
                entity_id=str(rsvp_id),
                details={
                    "event_id": str(event_id),
                    "character_id": str(rsvp_data.character_id),
                    "status": rsvp_data.attendance_status,
                    "ticket_xp": rsvp_data.ticket_xp,
                    "candle_xp": rsvp_data.candle_xp
                }
            )
            
            return ManualRSVPResponse(id=rsvp_id, message="Manual RSVP added successfully")
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error adding manual RSVP: {e}")
        raise HTTPException(status_code=500, detail="Failed to add manual RSVP")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- Character Endpoints ---

@router.get("/characters")
async def list_all_characters(user: AuthorizedUser) -> AdminCharacterListResponse:
    """Get all characters for comprehensive admin management (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_db_connection()
        query = """
            SELECT c.*, h.name as heritage_name, cu.name as culture_name, a.name as archetype_name,
                   sa.name as secondary_archetype_name, ta.name as tertiary_archetype_name,
                   pp.first_name || ' ' || pp.last_name as player_name, pp.player_number,
                   pp.chapter_id,
                   (
                       SELECT COUNT(*) FROM rsvps r 
                       WHERE r.character_id = c.id 
                       AND r.attendance_status = 'attended'
                   ) as events_attended,
                   (
                       SELECT r.event_id 
                       FROM rsvps r
                       JOIN events e ON r.event_id = e.id
                       WHERE r.character_id = c.id 
                       AND r.attendance_status = 'attended'
                       ORDER BY e.starts_at DESC
                       LIMIT 1
                   ) as last_attended_event_id,
                   (
                       SELECT COALESCE(SUM(amount) FILTER (WHERE amount > 0 
                        AND transaction_type NOT LIKE '%refund%' 
                        AND (transaction_type IN ('initial', 'event_reward') 
                             OR (transaction_type = 'admin_adjustment' AND reason NOT ILIKE '%refund%'))), 0)
                       FROM xp_transactions WHERE character_id = c.id
                   ) as real_xp_total,
                   (
                       SELECT COALESCE(SUM(amount), 0)
                       FROM xp_transactions WHERE character_id = c.id
                   ) as real_xp_available
            FROM characters c
            JOIN player_profiles pp ON c.player_profile_id = pp.id
            LEFT JOIN heritages h ON c.heritage_id = h.id
            LEFT JOIN cultures cu ON c.culture_id = cu.id
            LEFT JOIN archetypes a ON c.archetype_id = a.id
            LEFT JOIN archetypes sa ON c.secondary_archetype_id = sa.id
            LEFT JOIN archetypes ta ON c.tertiary_archetype_id = ta.id
            ORDER BY pp.last_name, pp.first_name, c.name
        """
        rows = await conn.fetch(query)
        
        # Calculate XP from transaction history for each character
        characters = []
        for row in rows:
            character = dict(row)
            
            # Convert UUID fields to strings for Pydantic validation
            uuid_fields = ['id', 'heritage_id', 'culture_id', 'archetype_id', 
                          'secondary_archetype_id', 'tertiary_archetype_id', 
                          'player_profile_id', 'chapter_id', 'last_attended_event_id']
            for field in uuid_fields:
                if character.get(field) is not None:
                    character[field] = str(character[field])
            
            # Use calculated XP values instead of stored columns
            character['xp_total'] = row['real_xp_total']
            character['xp_available'] = row['real_xp_available']
            character['xp_spent'] = row['real_xp_total'] - row['real_xp_available']
            character_id = character['id']
            
            # Calculate skill count from selected_skills JSONB field
            skill_count = 0
            if character.get('selected_skills'):
                skills_data = character['selected_skills']
                # asyncpg returns JSONB as string, need to parse it
                if isinstance(skills_data, str):
                    import json
                    skills_data = json.loads(skills_data)
                skill_count = len(skills_data) if isinstance(skills_data, list) else 0
            
            character['skill_count'] = skill_count
            
            characters.append(character)
            
        return AdminCharacterListResponse(characters=characters)
    except Exception as e:
        print(f"Error listing characters: {e}")
        raise HTTPException(status_code=500, detail="Failed to list characters")
    finally:
        if conn and not conn.is_closed():
            await conn.close()


@router.get("/characters/{character_id}")
async def get_admin_character(character_id: UUID, user: AuthorizedUser) -> dict:
    """Get detailed character data for admin editing (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        # This function combines fetching and transforming skill data
        return await get_character_full_data(conn, character_id)
    except Exception as e:
        print(f"Error getting admin character: {e}")
        raise HTTPException(status_code=500, detail="Failed to get character")
    finally:
        if conn and not conn.is_closed():
            await conn.close()


@router.put("/characters/{character_id}")
async def update_admin_character(character_id: UUID, character_data: AdminCharacterUpdate, user: AuthorizedUser) -> dict:
    """Update character data (admin only), recalculating and reconciling XP."""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        async with conn.transaction():
            # Get original character state
            original_state = await get_character_full_data(conn, character_id)
            if not original_state:
                raise HTTPException(status_code=404, detail="Character not found")
            
            # Build update dict with ONLY fields that were actually sent by the client
            updates_to_apply = character_data.dict(exclude_unset=True)
            
            # Special handling for selected_skills to normalize format before comparison
            if 'selected_skills' in updates_to_apply:
                new_value = updates_to_apply['selected_skills']
                original_value = original_state.get('selected_skills')
                
                # Parse original_value if it's a JSON string (Bug #2 fix)
                original_parsed = []
                if isinstance(original_value, str) and original_value:
                    original_parsed = json.loads(original_value)
                elif isinstance(original_value, list):
                    original_parsed = original_value
                
                # Normalize both to skill_id -> quantity maps for comparison
                original_skill_map = {}
                for skill in (original_parsed or []):
                    skill_id = skill.get('skill_id') or skill.get('id')
                    if skill_id:
                        original_skill_map[skill_id] = original_skill_map.get(skill_id, 0) + 1
                
                new_skill_map = {}
                for skill in (new_value or []):
                    skill_id = skill.get('skill_id') or skill.get('id')
                    if skill_id:
                        quantity = skill.get('quantity', 1)
                        new_skill_map[skill_id] = new_skill_map.get(skill_id, 0) + quantity
                
                # If the maps are the same, remove it from updates
                if original_skill_map == new_skill_map:
                    del updates_to_apply['selected_skills']

           # Debug: Log what we're about to update
            print(f"DEBUG: Updates to apply: {list(updates_to_apply.keys())}")
            print(f"DEBUG: player_notes in updates: {'player_notes' in updates_to_apply}")
            if 'player_notes' in updates_to_apply:
               print(f"DEBUG: player_notes value: {updates_to_apply['player_notes']}")

            if not updates_to_apply:
                # Nothing changed, just return success
                return {"message": "No changes detected", "id": str(character_id)}

            # Build and execute the UPDATE statement
            update_fields = []
            update_values = []
            for field, value in updates_to_apply.items():
                if field == 'selected_skills':
                    value = json.dumps(value)
                update_fields.append(f"{field} = ${len(update_values) + 2}")
                update_values.append(value)
                
            # Step 1: Update the character fields WITHOUT XP fields first
            query = f"UPDATE characters SET {', '.join(update_fields)} WHERE id = $1"
            await conn.execute(query, character_id, *update_values)
            
            # Step 2: Create XP transactions based on the changes
            await create_complete_xp_transactions(conn, character_id, original_state, updates_to_apply)
            
            # Step 3: Calculate what the new XP totals should be
            # FIX: Use SUM(amount) for xp_available to correctly account for refunds
            totals_query = """
            SELECT
                COALESCE(SUM(amount) FILTER (WHERE 
                    transaction_type IN ('initial', 'event_reward') 
                    OR (transaction_type = 'admin_adjustment' AND reason NOT ILIKE '%refund%')
                ), 0) as total_earned,
                COALESCE(SUM(amount), 0) as xp_available
            FROM xp_transactions
            WHERE character_id = $1
            """
            totals = await conn.fetchrow(totals_query, character_id)
            xp_total = int(totals['total_earned'])
            xp_available = int(totals['xp_available'])
            xp_spent = xp_total - xp_available

            # DEBUG: Show XP calculation details
            print(f"DEBUG XP CALCULATION:")
            print(f"  Character ID: {character_id}")
            print(f"  XP Total (earned): {xp_total}")
            print(f"  XP Spent: {xp_spent}")
            print(f"  XP Available: {xp_available}")
            
            # Step 4: Validate BEFORE updating
            if xp_available < 0:
                raise HTTPException(status_code=400, detail=f"Insufficient XP. These changes would result in {xp_available} XP available (character would be overspent by {abs(xp_available)} XP).")
            
            # Step 5: Update XP fields (this satisfies the constraint because xp_available >= 0)
            update_xp_query = "UPDATE characters SET xp_total = $1, xp_spent = $2, xp_available = $3 WHERE id = $4"
            await conn.execute(update_xp_query, xp_total, xp_spent, xp_available, character_id)

            # Add audit log
            await log_admin_action(
                performed_by_user_id=user.sub,
                action_type="character",
                action="update",
                entity_type="character",
                entity_id=str(character_id),
                details={
                    "updates": list(updates_to_apply.keys())
                }
            )
        
        return {"message": "Character updated successfully", "id": str(character_id)}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error updating admin character: {e}")
        raise HTTPException(status_code=500, detail="Failed to update character")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.delete("/characters/{character_id}")
async def delete_admin_character(character_id: UUID, user: AuthorizedUser) -> dict:
    """Delete a character (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_db_connection()
        
        # Check if character exists
        char_result = await conn.fetchrow("SELECT name FROM characters WHERE id = $1", character_id)
        if not char_result:
            raise HTTPException(status_code=404, detail="Character not found")
        
        char_name = char_result['name']
        
        # Delete the character (cascade will handle related xp_transactions, rsvps, etc.)
        await conn.execute("DELETE FROM characters WHERE id = $1", character_id)

        # Add audit log
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="character",
            action="delete",
            entity_type="character",
            entity_id=str(character_id),
            details={"character_name": char_name}
        )
        
        return {"message": f"Character '{char_name}' deleted successfully"}
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting admin character: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete character")
    finally:
        if conn and not conn.is_closed():
            await conn.close()


class XPTransactionResponse(BaseModel):
    id: str
    amount: int
    transaction_type: str
    reason: str
    skill_id: Optional[str] = None
    body_points: Optional[int] = None
    stamina_points: Optional[int] = None
    created_at: str

class CharacterXPHistoryResponse(BaseModel):
    character_name: str
    transactions: List[XPTransactionResponse]

@router.get("/characters/{character_id}/xp-history")
async def get_admin_character_xp_history(character_id: UUID, user: AuthorizedUser) -> CharacterXPHistoryResponse:
    """Get XP transaction history for a character (admin only)."""
    await check_admin_permission(user)
    
    conn = None
    try:
        conn = await get_db_connection()
        
        # Get character name
        char_result = await conn.fetchrow("SELECT name FROM characters WHERE id = $1", character_id)
        if not char_result:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Get XP transactions
        xp_query = """
        SELECT * FROM xp_transactions 
        WHERE character_id = $1 
        ORDER BY created_at DESC
        """
        xp_rows = await conn.fetch(xp_query, character_id)
        
        transactions = [
            XPTransactionResponse(
                id=str(row['id']),
                amount=row['amount'],
                transaction_type=row['transaction_type'],
                reason=row['reason'],
                skill_id=str(row['skill_id']) if row['skill_id'] else None,
                body_points=row.get('body_points'),
                stamina_points=row.get('stamina_points'),
                created_at=row['created_at'].isoformat()
            )
            for row in xp_rows
        ]
        
        return CharacterXPHistoryResponse(
            character_name=char_result['name'],
            transactions=transactions
        )
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error getting character XP history: {e}")
        raise HTTPException(status_code=500, detail="Failed to get XP history")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.post("/characters/{character_id}/xp-transactions")
async def add_admin_xp_transaction(
    character_id: str, 
    transaction: AdminXPTransactionCreate,
    user: AuthorizedUser,
    force: bool = False  # Add force parameter to allow negative XP
) -> dict:
    """Add a manual XP transaction to a character (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Verify character exists
        char_result = await conn.fetchrow("SELECT id FROM characters WHERE id = $1", character_id)
        if not char_result:
            raise HTTPException(status_code=404, detail="Character not found")
        
        # Check if transaction would result in negative XP (unless forced)
        if not force:
            current_xp = await conn.fetchrow(
                "SELECT xp_total, xp_spent, xp_available FROM characters WHERE id = $1",
                character_id
            )
            projected_available = current_xp['xp_available'] + transaction.amount
            
            if projected_available < 0:
                return {
                    "success": False,
                    "would_cause_negative_xp": True,
                    "current_available": current_xp['xp_available'],
                    "transaction_amount": transaction.amount,
                    "projected_available": projected_available,
                    "message": f"This transaction would result in negative XP ({projected_available}). Use force=true to proceed anyway."
                }
        
        # Insert XP transaction
        await conn.execute(
            """
            INSERT INTO xp_transactions (character_id, amount, transaction_type, reason)
            VALUES ($1, $2, $3, $4)
            """,
            character_id, transaction.amount, transaction.transaction_type, transaction.reason
        )
        
        # If force=true, we perform a direct relative update and bypass recalculation
        if force:
            await conn.execute(
                "UPDATE characters SET xp_available = xp_available + $1 WHERE id = $2",
                transaction.amount,
                character_id
            )
        else:
            # Recalculate character XP totals safely
            await recalculate_character_xp(conn, character_id)

        # Add audit log
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="character",
            action="add_xp",
            entity_type="xp_transaction",
            entity_id=str(character_id), # Using character_id as reference since we didn't capture the ID above easily without another query or change
            details={
                "amount": transaction.amount,
                "type": transaction.transaction_type,
                "reason": transaction.reason,
                "force": force
            }
        )
        
        return {"success": True, "message": "XP transaction added successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error adding XP transaction: {e}")
        raise HTTPException(status_code=500, detail="Failed to add XP transaction")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

@router.delete("/xp-transactions/{transaction_id}")
async def delete_admin_xp_transaction(
    transaction_id: str, 
    user: AuthorizedUser,
    force: bool = False  # Add force parameter
) -> dict:
    """Delete an XP transaction (admin only)"""
    await check_admin_permission(user)
    
    conn = await get_database_connection()
    try:
        # Get transaction and character_id before deleting
        # MODIFIED: Fetch amount and reason as well for logging
        transaction_row = await conn.fetchrow(
            "SELECT character_id, amount, reason FROM xp_transactions WHERE id = $1", 
            transaction_id
        )
        
        if not transaction_row:
            raise HTTPException(status_code=404, detail="Transaction not found")

        character_id = transaction_row['character_id']
        
        # Check if deletion would result in negative XP (unless forced)
        if not force:
            transaction_to_delete = await conn.fetchrow(
                "SELECT amount FROM xp_transactions WHERE id = $1",
                transaction_id
            )
            current_xp = await conn.fetchrow(
                "SELECT xp_available FROM characters WHERE id = $1",
                character_id
            )
            # Deleting reverses the transaction
            projected_available = current_xp['xp_available'] - transaction_to_delete['amount']
            
            if projected_available < 0:
                return {
                    "success": False,
                    "would_cause_negative_xp": True,
                    "current_available": current_xp['xp_available'],
                    "transaction_amount": transaction_to_delete['amount'],
                    "projected_available": projected_available,
                    "message": f"Deleting this transaction would result in negative XP ({projected_available}). Use force=true to proceed anyway."
                }
        
        # Delete the transaction
        await conn.execute("DELETE FROM xp_transactions WHERE id = $1", transaction_id)
        
        # Recalculate character XP totals
        await recalculate_character_xp(conn, character_id)

        # Add audit log
        await log_admin_action(
            performed_by_user_id=user.sub,
            action_type="character",
            action="delete_xp",
            entity_type="xp_transaction",
            entity_id=str(transaction_id),
            details={
                "character_id": str(character_id),
                "amount": transaction_row['amount'],
                "reason": transaction_row['reason'],
                "force": force
            }
        )
        
        return {"success": True, "message": "XP transaction deleted successfully"}
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error deleting XP transaction: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete XP transaction")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- PDF Export Endpoints ---

@router.post("/characters/export-pdf")
async def bulk_export_character_sheets(character_ids: List[UUID], user: AuthorizedUser) -> StreamingResponse:
    """Export multiple character sheets as a single multi-page PDF (admin only)"""
    await check_admin_permission(user)
    conn = None
    try:
        conn = await get_database_connection()
        characters_data = [await get_character_full_data(conn, char_id) for char_id in character_ids]
        characters_data = [data for data in characters_data if data] # Filter out None
        if not characters_data:
            raise HTTPException(status_code=404, detail="No valid characters found for export")

        pdf_buffer = generate_bulk_character_sheets(characters_data)
        pdf_buffer.seek(0)
        filename = f"character_sheets_{datetime.now().strftime('%Y-%m-%d')}.pdf"
        return StreamingResponse(pdf_buffer, media_type="application/pdf", headers={"Content-Disposition": f"attachment; filename={filename}"})
    except Exception as e:
        print(f"Error exporting character sheets: {e}")
        raise HTTPException(status_code=500, detail="Failed to export character sheets")
    finally:
        if conn and not conn.is_closed():
            await conn.close()

# --- XP and Transaction Helpers & Endpoints ---

async def recalculate_character_xp(conn, character_id: uuid.UUID):
    """Recalculate character's XP totals based on their transaction history."""
    xp_query = """
    SELECT
        COALESCE(SUM(amount) FILTER (WHERE amount > 0 
            AND transaction_type NOT LIKE '%refund%' 
            AND (transaction_type IN ('initial', 'event_reward') 
                 OR (transaction_type = 'admin_adjustment' AND reason NOT ILIKE '%refund%'))), 0) as total_earned,
        COALESCE(SUM(amount), 0) as xp_available
    FROM xp_transactions
    WHERE character_id = $1
    """
    totals = await conn.fetchrow(xp_query, character_id)
    
    xp_total = int(totals['total_earned'])
    xp_available = int(totals['xp_available'])
    xp_spent = xp_total - xp_available
    
    update_query = "UPDATE characters SET xp_total = $1, xp_spent = $2, xp_available = $3 WHERE id = $4"
    await conn.execute(update_query, xp_total, xp_spent, xp_available, character_id)
    
async def create_complete_xp_transactions(conn, character_id: uuid.UUID, original_state: dict, updates: dict):
    """Orchestrator to create all necessary XP transactions after a character update."""
    print(f"INFO: Creating XP transactions for character {character_id} based on updates.")
    
    # Only process skill changes if skills were actually updated
    if 'selected_skills' in updates:
        original_skills = original_state.get('selected_skills', [])
        new_skills = updates.get('selected_skills', [])
        await create_skill_xp_transactions(conn, character_id, original_skills, new_skills)
    
    # Get heritage info to determine base stats
    old_heritage_base_body = original_state.get('base_body', 1)
    old_heritage_base_stamina = original_state.get('base_stamina', 1)
    
    new_heritage_id = updates.get('heritage_id')
    new_heritage_base_body = old_heritage_base_body
    new_heritage_base_stamina = old_heritage_base_stamina
    
    # If heritage changed, fetch new base stats
    if new_heritage_id and str(new_heritage_id) != str(original_state.get('heritage_id')):
        heritage_row = await conn.fetchrow("SELECT base_body, base_stamina FROM heritages WHERE id = $1", new_heritage_id)
        if heritage_row:
            new_heritage_base_body = heritage_row['base_body']
            new_heritage_base_stamina = heritage_row['base_stamina']
    # Extract body and stamina values
    original_body = original_state.get('body', 1)
    new_body = updates.get('body', original_body)
    original_stamina = original_state.get('stamina', 1)
    new_stamina = updates.get('stamina', original_stamina)

    # Check if body, stamina OR heritage changed (as heritage affects the cost basis)
    if original_body != new_body or original_stamina != new_stamina or new_heritage_base_body != old_heritage_base_body or new_heritage_base_stamina != old_heritage_base_stamina:
        await create_body_stamina_xp_transactions(
            conn, character_id, 
            original_body, new_body, 
            original_stamina, new_stamina, 
            old_heritage_base_body, new_heritage_base_body,
            old_heritage_base_stamina, new_heritage_base_stamina
        )
        
    original_archetype = original_state.get('archetype_id')
    new_archetype = updates.get('archetype_id', original_archetype)
    original_secondary = original_state.get('secondary_archetype_id')
    new_secondary = updates.get('secondary_archetype_id', original_secondary)
    original_tertiary = original_state.get('tertiary_archetype_id')
    new_tertiary = updates.get('tertiary_archetype_id', original_tertiary)
    
    # Only create transactions if secondary or tertiary changed (primary is free)
    # BUT we also need to reconcile skill costs if ANY archetype changed
    if original_secondary != new_secondary or original_tertiary != new_tertiary or original_archetype != new_archetype:
        # Use ORIGINAL skills for cost adjustment, not final skills. 
        # We only want to adjust costs for skills the character already had.
        # New skills are purchased at the new rate automatically.
        skills_to_adjust = original_state.get('selected_skills', [])
        heritage_id = updates.get('heritage_id', original_state.get('heritage_id'))
        
        await create_archetype_xp_transactions(
            conn, 
            character_id, 
            original_archetype, 
            new_archetype,
            original_secondary,
            new_secondary,
            original_tertiary,
            new_tertiary,
            skills_to_adjust,
            heritage_id
        )

async def create_skill_xp_transactions(conn, character_id: uuid.UUID, original_skills: list, new_skills: list):
    """Create XP transactions for skill purchase differences."""
    # Filter out any skills that don't have a valid ID
    # Build skill maps - handle enriched format (from DB) vs simple format (from frontend)
    original_skill_map = {}
    for skill in original_skills:
        skill_id = skill.get('skill_id') or skill.get('id')
        if skill_id:
            # Enriched format expands each purchase, so count occurrences
            original_skill_map[skill_id] = original_skill_map.get(skill_id, 0) + 1
     
    new_skill_map = {}
    for skill in new_skills:
        skill_id = skill.get('skill_id') or skill.get('id')
        if skill_id:
            # Handle both formats: enriched (no quantity field) and frontend (has quantity field)
            quantity = skill.get('quantity', 1)
            new_skill_map[skill_id] = new_skill_map.get(skill_id, 0) + quantity

    # Get all unique skill IDs
    all_skill_ids = set(original_skill_map.keys()) | set(new_skill_map.keys())
    
    for skill_id in all_skill_ids:
        original_qty = original_skill_map.get(skill_id, 0)
        new_qty = new_skill_map.get(skill_id, 0)
        qty_diff = new_qty - original_qty
        
        if qty_diff != 0:
            # Get skill XP cost
            skill_cost = await calculate_skill_xp_cost(conn, skill_id, character_id)
            
            # Get skill name
            skill_row = await conn.fetchrow("SELECT name FROM skills WHERE id = $1", uuid.UUID(skill_id))
            skill_name = skill_row['name'] if skill_row else "Unknown Skill"
                
            if qty_diff > 0:
                    # Purchased skills
                    for i in range(qty_diff):
                        await conn.execute(
                            "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, skill_id) VALUES ($1, $2, $3, $4, $5)",
                            character_id, -skill_cost, 'skill_purchase', f'Admin update: purchased {skill_name}', uuid.UUID(skill_id)
                        )
            else:
                    # Refunded skills
                    for i in range(abs(qty_diff)):
                        await conn.execute(
                            "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, skill_id) VALUES ($1, $2, $3, $4, $5)",
                            character_id, skill_cost, 'skill_refund', f'Admin update: refunded {skill_name}', uuid.UUID(skill_id)
                        )

async def create_body_stamina_xp_transactions(conn, character_id: uuid.UUID, original_body: int, new_body: int, original_stamina: int, new_stamina: int, old_base_body: int, new_base_body: int, old_base_stamina: int, new_base_stamina: int):
    """Create XP transactions for body/stamina changes."""
    
    # 1. Calculate Body XP Cost Difference
    if new_body > original_body:
        # Purchase: Calculate cost of NEW points using NEW base
        cost_of_new_points = calculate_body_stamina_xp_cost(new_base_body, new_body) - calculate_body_stamina_xp_cost(new_base_body, original_body)
        
        if cost_of_new_points > 0:  # <--- Added check
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points) VALUES ($1, $2, $3, $4, $5)",
                character_id, -cost_of_new_points, 'body_purchase', 'Admin update: body cost adjustment', new_body
            )
    elif new_body < original_body:
        # Refund: Calculate value of LOST points using OLD base
        refund_amount = calculate_body_stamina_xp_cost(old_base_body, original_body) - calculate_body_stamina_xp_cost(old_base_body, new_body)
        
        if refund_amount > 0:
            await conn.execute(
                 "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, body_points) VALUES ($1, $2, $3, $4, $5)",
                 character_id, refund_amount, 'body_refund', 'Admin update: body cost adjustment', new_body
             )
    
    # 2. Calculate Stamina XP Cost Difference
    if new_stamina > original_stamina:
        # Purchase
        cost_of_new_points = calculate_body_stamina_xp_cost(new_base_stamina, new_stamina) - calculate_body_stamina_xp_cost(new_base_stamina, original_stamina)
        
        if cost_of_new_points > 0:  # <--- Added check
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, stamina_points) VALUES ($1, $2, $3, $4, $5)",
                character_id, -cost_of_new_points, 'stamina_purchase', 'Admin update: stamina cost adjustment', new_stamina
            )
    elif new_stamina < original_stamina:
        # Refund
        refund_amount = calculate_body_stamina_xp_cost(old_base_stamina, original_stamina) - calculate_body_stamina_xp_cost(old_base_stamina, new_stamina)
        
        if refund_amount > 0:
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason, stamina_points) VALUES ($1, $2, $3, $4, $5)",
                character_id, refund_amount, 'stamina_refund', 'Admin update: stamina cost adjustment', new_stamina
            )
        
async def create_archetype_xp_transactions(
    conn, 
    character_id: uuid.UUID, 
    original_archetype: str, 
    new_archetype: str,
    original_secondary: str,
    new_secondary: str,
    original_tertiary: str,
    new_tertiary: str,
    skills: list,
    heritage_id: str
):
    """Create XP transactions for archetype changes. PRIMARY archetype is FREE and should not generate transactions."""
    
    # Handle SECONDARY archetype changes (costs 50 XP)
    if original_secondary != new_secondary:
        if original_secondary:
            # Refund removed secondary archetype (50 XP)
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
                character_id, 50, 'archetype_refund', 'Admin update: removed secondary archetype'
            )
        
        if new_secondary:
            # Purchase new secondary archetype (50 XP)
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
                character_id, -50, 'archetype_purchase', 'Admin update: selected secondary archetype'
            )
    
    # Handle TERTIARY archetype changes (costs 50 XP)
    if original_tertiary != new_tertiary:
        if original_tertiary:
            # Refund removed tertiary archetype (50 XP)
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
                character_id, 50, 'archetype_refund', 'Admin update: removed tertiary archetype'
            )
        
        if new_tertiary:
            # Purchase new tertiary archetype (50 XP)
            await conn.execute(
                "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
                character_id, -50, 'archetype_purchase', 'Admin update: selected tertiary archetype'
            )

    # --- RECONCILE SKILL COSTS ---
    # Calculate if the archetype changes affect the cost of existing skills
    
    # Helper to calculate cost for a single skill ID given specific archetypes
    async def get_contextual_cost(s_id, a1, a2, a3, h_id):
        query = """
            SELECT CASE
                WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN 5
                WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
                ELSE 20
            END as xp_cost
            FROM skills s
            LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = $2
            LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = $2
            LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = $3
            LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = $3
            LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = $4
            LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = $4
            LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = $5
            WHERE s.id = $1
        """
        row = await conn.fetchrow(query, s_id, a1, a2, a3, h_id)
        return row['xp_cost'] if row else 20

    # Aggregate skills to process (handle both enriched and flat format)
    skill_counts = {}
    for skill in skills:
        s_id = skill.get('skill_id') or skill.get('id')
        if s_id:
            qty = skill.get('quantity', 1)
            # If it's an enriched list where each item is a purchase, count them.
            # If it's a list with quantity, use that.
            # Usually 'selected_skills' from DB is enriched (list of objects), updates is likely list with quantity.
            # We'll assume if 'quantity' is present use it, else count as 1.
            # But wait, original_state['selected_skills'] is usually list of objects (one per purchase).
            # So we sum them up.
            if 'quantity' in skill:
                skill_counts[s_id] = skill_counts.get(s_id, 0) + qty
            else:
                skill_counts[s_id] = skill_counts.get(s_id, 0) + 1
    
    total_diff = 0
    
    for s_id, qty in skill_counts.items():
        if not s_id: continue
        
        # Calculate old cost
        old_unit_cost = await get_contextual_cost(s_id, original_archetype, original_secondary, original_tertiary, heritage_id)
        old_total = old_unit_cost * qty
        
        # Calculate new cost
        new_unit_cost = await get_contextual_cost(s_id, new_archetype, new_secondary, new_tertiary, heritage_id)
        new_total = new_unit_cost * qty
        
        total_diff += (new_total - old_total)

    if total_diff > 0:
        # Cost increased -> Charge the player
        await conn.execute(
            "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
            character_id, -total_diff, 'skill_purchase', 'Admin update: skill cost adjustment due to archetype change'
        )
    elif total_diff < 0:
        # Cost decreased -> Refund the player
        await conn.execute(
            "INSERT INTO xp_transactions (character_id, amount, transaction_type, reason) VALUES ($1, $2, $3, $4)",
            character_id, abs(total_diff), 'skill_refund', 'Admin update: skill cost adjustment due to archetype change'
        )

async def calculate_skill_xp_cost(conn, skill_id: str, character_id: uuid.UUID) -> int:
    """Helper to get XP cost for a skill based on character's archetypes and heritage."""
    # Get character's archetype and heritage IDs
    char_result = await conn.fetchrow(
        "SELECT archetype_id, secondary_archetype_id, tertiary_archetype_id, heritage_id FROM characters WHERE id = $1",
        character_id
    )
    if not char_result:
        return 20  # Default cost
    
    # Query using CASE logic to determine cost (5 for primary, 10 for secondary, 20 for other)
    cost_query = """
        SELECT CASE
            -- Check if primary skill in ANY archetype (primary, secondary, or tertiary)
            WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN 5
            -- Check if secondary skill in ANY archetype or heritage
            WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
            ELSE 20
        END as xp_cost
        FROM skills s
        -- Primary archetype
        LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = $2
        LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = $2
        -- Secondary archetype
        LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = $3
        LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = $3
        -- Tertiary archetype
        LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = $4
        LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = $4
        -- Heritage secondary skills
        LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = $5
        WHERE s.id = $1
    """
    cost_result = await conn.fetchrow(
        cost_query,
        skill_id,
        char_result['archetype_id'],
        char_result['secondary_archetype_id'],
        char_result['tertiary_archetype_id'],
        char_result['heritage_id']
    )
    return cost_result['xp_cost'] if cost_result else 20

async def get_character_full_data(conn, character_id: UUID) -> Optional[dict]:
    """Helper function to get complete character data for various endpoints."""
    query = """
        SELECT c.*, pp.first_name, pp.last_name, pp.player_number, 
               h.name as heritage_name, h.base_body, h.base_stamina, h.benefit_name as heritage_benefit_name, h.weakness_name as heritage_flaw_name,
               h.benefit as heritage_benefit, h.weakness as heritage_weakness,
               cu.name as culture_name, cu.benefit_name as culture_benefit_name, cu.benefit as culture_benefit,
               a.name as archetype_name,
               sa.name as secondary_archetype_name,
               ta.name as tertiary_archetype_name
        FROM characters c
        LEFT JOIN player_profiles pp ON c.player_profile_id = pp.id
        LEFT JOIN heritages h ON c.heritage_id = h.id
        LEFT JOIN cultures cu ON c.culture_id = cu.id
        LEFT JOIN archetypes a ON c.archetype_id = a.id
        LEFT JOIN archetypes sa ON c.secondary_archetype_id = sa.id
        LEFT JOIN archetypes ta ON c.tertiary_archetype_id = ta.id
        WHERE c.id = $1
    """
    row = await conn.fetchrow(query, character_id)
    if not row:
          return None
    
    character_data = dict(row)

    # Structure heritage and culture data for frontend
    character_data['heritage'] = {
        'name': character_data.get('heritage_name'),
        'benefit_name': character_data.get('heritage_benefit_name'),
        'benefit': character_data.get('heritage_benefit'),
        'weakness_name': character_data.get('heritage_flaw_name'),
        'weakness': character_data.get('heritage_weakness'),
    }
    
    character_data['culture'] = {
        'name': character_data.get('culture_name'),
        'benefit_name': character_data.get('culture_benefit_name'),
        'benefit': character_data.get('culture_benefit'),
    }

    # Get events attended count
    events_attended = await conn.fetchval(
        "SELECT COUNT(*) FROM rsvps WHERE character_id = $1 AND attendance_status = 'attended'",
        character_id
    )
    character_data['events_attended'] = events_attended or 0
    
    # Fetch full skill details including names and XP costs
    enriched_skills = []
    # Parse selected_skills from JSON stored in database
    import json
    skills_list = json.loads(character_data.get('selected_skills', '[]')) if character_data.get('selected_skills') else []
    for skill_entry in skills_list:
        skill_id = skill_entry.get('skill_id')
        quantity = skill_entry.get('quantity', 1)
        
        # Get skill details from database
        skill_row = await conn.fetchrow(
            "SELECT name FROM skills WHERE id = $1",
            skill_id
        )
        
        # Calculate XP cost based on character's heritage and archetypes
        # Build query to check if skill is primary/secondary in ANY of the archetypes or heritage
        skill_cost_query = """
        SELECT 
            CASE 
                -- Check if primary skill in ANY archetype (primary, secondary, or tertiary)
                WHEN aps.skill_id IS NOT NULL OR aps2.skill_id IS NOT NULL OR aps3.skill_id IS NOT NULL THEN 5
                -- Check if secondary skill in ANY archetype or heritage
                WHEN ass.skill_id IS NOT NULL OR ass2.skill_id IS NOT NULL OR ass3.skill_id IS NOT NULL OR hss.skill_id IS NOT NULL THEN 10
                ELSE 20
            END as xp_cost
        FROM skills s
        -- Primary archetype
        LEFT JOIN archetype_primary_skills aps ON aps.skill_id = s.id AND aps.archetype_id = $1
        LEFT JOIN archetype_secondary_skills ass ON ass.skill_id = s.id AND ass.archetype_id = $1
        -- Secondary archetype
        LEFT JOIN archetype_primary_skills aps2 ON aps2.skill_id = s.id AND aps2.archetype_id = $2
        LEFT JOIN archetype_secondary_skills ass2 ON ass2.skill_id = s.id AND ass2.archetype_id = $2
        -- Tertiary archetype
        LEFT JOIN archetype_primary_skills aps3 ON aps3.skill_id = s.id AND aps3.archetype_id = $3
        LEFT JOIN archetype_secondary_skills ass3 ON ass3.skill_id = s.id AND ass3.archetype_id = $3
        -- Heritage
        LEFT JOIN heritage_secondary_skills hss ON hss.skill_id = s.id AND hss.heritage_id = $4
        WHERE s.id = $5
        """
        
        # Get character's archetype IDs
        primary_archetype_id = character_data.get('archetype_id')
        secondary_archetype_id = character_data.get('secondary_archetype_id') or primary_archetype_id
        tertiary_archetype_id = character_data.get('tertiary_archetype_id') or primary_archetype_id
        heritage_id = character_data.get('heritage_id')
        
        # Calculate cost for this specific skill based on character's archetypes
        cost_row = await conn.fetchrow(
            skill_cost_query,
            primary_archetype_id,
            secondary_archetype_id,
            tertiary_archetype_id,
            heritage_id,
            skill_id
        )
        
        xp_cost = cost_row['xp_cost'] if cost_row else 20  # Default to 20 if calculation fails
        
        if skill_row:
            # Add skill multiple times based on quantity
            for _ in range(quantity):
                enriched_skills.append({
                    'skill_id': str(skill_id),
                    'name': skill_row['name'],
                    'xp_cost': xp_cost
                })
    
    character_data['selected_skills'] = enriched_skills

    # Calculate XP from transaction history - derive spent from earned minus available
    xp_query = """
        SELECT
            COALESCE(SUM(amount) FILTER (WHERE amount > 0 
                AND transaction_type NOT LIKE '%refund%' 
                AND (transaction_type IN ('initial', 'event_reward') 
                     OR (transaction_type = 'admin_adjustment' AND reason NOT ILIKE '%refund%'))), 0) as xp_total,
            COALESCE(SUM(amount), 0) as xp_available
        FROM xp_transactions
        WHERE character_id = $1
    """
    xp_row = await conn.fetchrow(xp_query, character_id)
    
    # Update character with calculated XP values from transactions
    xp_total = int(xp_row['xp_total'])
    xp_available = int(xp_row['xp_available'])
    xp_spent = xp_total - xp_available  # Derive spent as earned - available
    
    character_data['xp_total'] = xp_total
    character_data['xp_spent'] = xp_spent
    character_data['xp_available'] = xp_available
    
    return character_data
