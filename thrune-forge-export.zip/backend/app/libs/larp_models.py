"""LARP Database Models

Python models representing the database schema for Thrune's Forge LARP management.
Use these as reference when building APIs that interact with the database.

Database Schema:
- chapters: LARP chapters/organizations  
- events: LARP events organized by chapters
- rsvps: User RSVPs to events (linked by Stack Auth user_id)
"""

from typing import Optional, Literal
from datetime import datetime
from uuid import UUID


class Chapter:
    """LARP Chapter/Organization
    
    Table: public.chapters
    """
    id: UUID  # Primary key, auto-generated
    name: str  # Chapter name (max 255 chars)
    description: Optional[str]  # Optional description
    created_at: datetime  # Auto-generated timestamp


class Event:
    """LARP Event
    
    Table: public.events
    """
    id: UUID  # Primary key, auto-generated
    chapter_id: UUID  # Foreign key to chapters.id
    title: str  # Event title (max 255 chars)
    description: Optional[str]  # Optional event description
    location: Optional[str]  # Event location (max 255 chars)
    starts_at: datetime  # Event start time (with timezone)
    ends_at: datetime  # Event end time (with timezone)
    status: Literal['scheduled', 'completed', 'cancelled']  # Event status
    created_at: datetime  # Auto-generated timestamp


class RSVP:
    """User RSVP to Event
    
    Table: public.rsvps
    """
    id: UUID  # Primary key, auto-generated
    event_id: UUID  # Foreign key to events.id
    user_id: str  # User ID from Stack Auth token.sub
    status: Literal['going', 'maybe', 'not_attending']  # RSVP status
    created_at: datetime  # Auto-generated timestamp


# Database constraints and indexes:
# - rsvps has unique constraint on (event_id, user_id)
# - Foreign keys have CASCADE DELETE
# - Indexes on: events.starts_at, events.chapter_id, rsvps.user_id, rsvps.event_id

# Usage in APIs:
# - Use asyncpg for database integration
# - Always get user_id from AuthorizedUser.sub in protected endpoints
# - Remember there's no users table - user data comes from Stack Auth
