from uuid import UUID
from datetime import datetime

async def calculate_chronological_bonus_xp(conn, character_id: UUID, current_event_id: UUID) -> int:
    """
    Calculates bonus XP based on the purchase order (RSVP creation) of the event attendance.
    
    Events 1-10: +6 XP
    Events 11-20: +5 XP
    Events 21-30: +4 XP
    Events 31+: +3 XP
    
    This ensures that the bonus is deterministic based on when the RSVP was made.
    """
    
    # Get all attended events ordered by RSVP creation date (purchase order)
    # We include the current event in this list if it's marked as attended
    # The query fetches all events that ARE attended for this character
    query = """
        SELECT e.id
        FROM rsvps r
        JOIN events e ON r.event_id = e.id
        WHERE r.character_id = $1
        AND r.attendance_status = 'attended'
        ORDER BY r.created_at ASC
    """
    
    rows = await conn.fetch(query, character_id)
    attended_event_ids = [row['id'] for row in rows]
    
    try:
        # Find the rank (0-based index)
        # Note: In the calling context, the current event might trigger this calculation
        # AFTER being marked 'attended' in the DB (which is the case in update_attendance_status).
        # So it SHOULD be in the list.
        index = attended_event_ids.index(current_event_id)
        rank = index + 1
    except ValueError:
        # If for some reason the current event is not in the list (e.g. transaction isolation or logic error),
        # we fall back to appending it as the last one (assuming it's being added now).
        # However, since we update the status BEFORE calling this, it should be there.
        # But if we call this during a "preview" calculation, it might not be.
        # For now, we assume it's in the list or we return a default based on count + 1.
        rank = len(attended_event_ids) + 1

    if rank <= 10:
        return 6
    elif rank <= 20:
        return 5
    elif rank <= 30:
        return 4
    else:
        return 3
