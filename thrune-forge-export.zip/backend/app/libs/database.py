import asyncpg
import os
from app.env import mode, Mode

async def get_db_connection():
    """Get admin database connection based on current environment."""
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_ADMIN_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_ADMIN_DEV")
    
    conn = await asyncpg.connect(db_url)
    return conn

async def get_database_connection():
    """Get regular database connection based on current environment."""
    if mode == Mode.PROD:
        db_url = os.environ.get("DATABASE_URL_PROD")
    else:
        db_url = os.environ.get("DATABASE_URL_DEV")
    
    conn = await asyncpg.connect(db_url)
    return conn
