import os
from datetime import datetime
from typing import Optional, Any, Dict
import json
from app.libs.database import get_database_connection

async def log_admin_action(
    performed_by_user_id: str,
    action_type: str,
    action: str,
    entity_id: Optional[str] = None,
    entity_type: Optional[str] = None,
    details: Optional[Dict[str, Any]] = None
):
    """
    Logs an administrative action to the audit_logs table.
    
    Args:
        performed_by_user_id: The ID of the user (admin) performing the action.
        action_type: Category of action (e.g., 'candle', 'xp', 'character').
        action: Specific action name (e.g., 'update', 'grant', 'delete').
        entity_id: UUID of the entity being affected.
        entity_type: Type of the entity (e.g., 'character', 'event').
        details: Dictionary of extra details to store as JSON.
    """
    conn = None
    try:
        conn = await get_database_connection()
        query = """
            INSERT INTO audit_logs 
            (performed_by_user_id, action_type, action, entity_id, entity_type, details)
            VALUES ($1, $2, $3, $4, $5, $6)
        """
        
        # Ensure details is valid JSON-serializable dict
        details_json = json.dumps(details) if details else '{}'
        
        await conn.execute(
            query,
            performed_by_user_id,
            action_type,
            action,
            entity_id,
            entity_type,
            details_json
        )
    except Exception as e:
        print(f"FAILED TO LOG ACTION: {e}")
        # We generally don't want to crash the main request if logging fails, 
        # but we should definitely log the error to the console.
    finally:
        if conn and not conn.is_closed():
            await conn.close()# Here you can write code for reusable functions and variables that you want to use