import requests
import os
from app.env import Mode, mode
from typing import Dict, Any, List
import json

async def sync_player_profiles_to_dev():
    """
    Sync all player profiles from production to development.
    Only runs in production environment.
    Returns True if successful, False if failed.
    """
    # Only sync when running in production
    if mode != Mode.PROD:
        print("Sync skipped: not running in production environment")
        return True
    
    try:
        # Import database connection here to avoid circular imports
        from app.libs.database import get_database_connection
        
        conn = await get_database_connection()
        
        try:
            # Get all player profiles from production
            player_profiles = await conn.fetch(
                """
                SELECT 
                    pp.id,
                    pp.user_id,
                    pp.first_name,
                    pp.last_name,
                    pp.phone_number,
                    pp.emergency_contact_name,
                    pp.emergency_contact_phone,
                    pp.chapter_id,
                    pp.player_number,
                    pp.candles_available,
                    pp.is_admin,
                    pp.email,
                    pp.created_at,
                    pp.updated_at
                FROM public.player_profiles pp
                ORDER BY pp.created_at
                """
            )
            
            # Convert to list of dictionaries with proper serialization
            player_data = []
            for row in player_profiles:
                row_dict = dict(row)
                # Convert UUID and datetime objects to strings
                for key, value in row_dict.items():
                    if hasattr(value, 'isoformat'):  # datetime objects
                        row_dict[key] = value.isoformat()
                    elif hasattr(value, 'hex'):  # UUID objects
                        row_dict[key] = str(value)
                player_data.append(row_dict)
            
            # Make HTTP request to development sync API
            dev_api_url = "https://riff.new/_projects/e1ccddac-de04-4a52-bbf7-5dcd0ee50a6e/dbtn/devx/app/routes"
            sync_endpoint = f"{dev_api_url}/dev/sync-player-profiles"
            
            # Get admin token for the request
            # Use a service account token from secrets for production-to-dev sync
            admin_token = os.environ.get("ADMIN_SYNC_TOKEN")
            if not admin_token:
                print("Warning: ADMIN_SYNC_TOKEN not configured, sync will fail")
                return False
            
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {admin_token}"
            }
            
            payload = {
                "player_profiles": player_data
            }
            
            # Make the sync request with timeout
            response = requests.post(
                sync_endpoint,
                json=payload,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                print(f"Successfully synced {len(player_data)} player profiles to development")
                return True
            else:
                print(f"Sync failed with status {response.status_code}: {response.text}")
                return False
                
        finally:
            await conn.close()
            
    except Exception as e:
        print(f"Error during player profile sync: {e}")
        return False

def log_sync_attempt(endpoint_name: str, player_id: str, success: bool, error: str = None):
    """
    Log sync attempts for debugging and monitoring.
    """
    status = "SUCCESS" if success else "FAILED"
    log_message = f"Sync from {endpoint_name} for player {player_id}: {status}"
    
    if error:
        log_message += f" - Error: {error}"
    
    print(log_message)
