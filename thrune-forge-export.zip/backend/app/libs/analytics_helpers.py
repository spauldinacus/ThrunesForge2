"""
Analytics helper utilities for shared query functions and date calculations.

Provides common utilities for analytics across the application.
"""

from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional
import asyncpg


class DateRange:
    """Helper for calculating common date ranges."""
    
    @staticmethod
    def last_n_days(days: int) -> tuple[datetime, datetime]:
        """Get start and end datetime for last N days."""
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=days)
        return start, end
    
    @staticmethod
    def next_n_days(days: int) -> tuple[datetime, datetime]:
        """Get start and end datetime for next N days."""
        start = datetime.now(timezone.utc)
        end = start + timedelta(days=days)
        return start, end


async def get_active_players_count(
    conn: asyncpg.Connection,
    days_back: int = 90
) -> int:
    """Get count of players who attended an event in the last N days.
    
    Args:
        conn: Database connection
        days_back: Number of days to look back (default 90)
        
    Returns:
        Count of active players
    """
    start_date, _ = DateRange.last_n_days(days_back)
    
    query = """
        SELECT COUNT(DISTINCT pp.id)
        FROM player_profiles pp
        JOIN rsvps r ON r.user_id = pp.user_id
        JOIN events e ON e.id = r.event_id
        WHERE r.attendance_status = 'attended'
        AND e.starts_at >= $1
    """
    
    count = await conn.fetchval(query, start_date)
    return count or 0


async def get_total_characters_count(
    conn: asyncpg.Connection,
    active_only: bool = True
) -> int:
    """Get count of total characters.
    
    Args:
        conn: Database connection
        active_only: If True, only count non-retired characters
        
    Returns:
        Count of characters
    """
    query = "SELECT COUNT(*) FROM characters WHERE retired = false" if active_only else "SELECT COUNT(*) FROM characters"
    count = await conn.fetchval(query)
    return count or 0


async def get_upcoming_events_count(
    conn: asyncpg.Connection,
    days_ahead: int = 30
) -> int:
    """Get count of upcoming events in next N days.
    
    Args:
        conn: Database connection
        days_ahead: Number of days to look ahead (default 30)
        
    Returns:
        Count of upcoming events
    """
    start_date, end_date = DateRange.next_n_days(days_ahead)
    
    query = """
        SELECT COUNT(*)
        FROM events
        WHERE starts_at >= $1
        AND starts_at <= $2
        AND status NOT IN ('cancelled')
    """
    
    count = await conn.fetchval(query, start_date, end_date)
    return count or 0


async def get_recent_attendance_rate(
    conn: asyncpg.Connection,
    event_count: int = 5
) -> float:
    """Calculate average attendance rate for last N events.
    
    Args:
        conn: Database connection
        event_count: Number of recent events to analyze
        
    Returns:
        Attendance rate as percentage (0-100)
    """
    query = """
        WITH recent_events AS (
            SELECT id
            FROM events
            WHERE (status = 'completed' OR (status = 'scheduled' AND starts_at < NOW()))
            ORDER BY starts_at DESC
            LIMIT $1
        ),
        event_stats AS (
            SELECT
                e.id,
                COUNT(r.id) FILTER (WHERE r.attendance_status = 'attended') as attended
            FROM recent_events e
            LEFT JOIN rsvps r ON r.event_id = e.id
            GROUP BY e.id
        )
        SELECT 
            COALESCE(AVG(attended), 0) as avg_attendance
        FROM event_stats
    """
    
    rate = await conn.fetchval(query, event_count)
    return round(rate or 0.0, 1)


async def get_total_xp_distributed(
    conn: asyncpg.Connection
) -> int:
    """Get total XP distributed across all characters (all time).
    
    Returns:
        Total XP distributed
    """
    query = """
        SELECT COALESCE(SUM(xp_total), 0) as total_xp
        FROM characters
        WHERE retired = false
    """
    
    total = await conn.fetchval(query)
    return total or 0


async def get_active_chapters_count(
    conn: asyncpg.Connection
) -> int:
    """Get count of active chapters (chapters with at least one player).
    
    Returns:
        Count of active chapters
    """
    query = """
        SELECT COUNT(DISTINCT chapter_id)
        FROM player_profiles
    """
    
    count = await conn.fetchval(query)
    return count or 0
