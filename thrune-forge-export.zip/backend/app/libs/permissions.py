from fastapi import HTTPException
from app.libs.database import get_database_connection
from typing import Optional, List
from uuid import UUID

async def check_permission(
    user_id: str,
    permission_name: str,
    target_chapter_id: Optional[str] = None,
    raise_exception: bool = True
) -> bool:
    """
    Check if a user has a specific permission, optionally scoped to a chapter.
    
    Args:
        user_id: The Stack Auth user ID
        permission_name: Name of the permission to check
        target_chapter_id: ID of the chapter to check permission for (optional)
        raise_exception: Whether to raise HTTPException if permission denied
        
    Returns:
        bool: True if user has permission, False otherwise
    """
    conn = await get_database_connection()
    try:
        # Query to check permissions
        # User has permission if:
        # 1. They have a role with the permission AND the role is global (chapter_id is NULL)
        # 2. OR they have a role with the permission AND the role is for the target chapter
        
        query = """
        SELECT EXISTS(
            SELECT 1 FROM player_profiles pp
            JOIN player_roles pr ON pp.id = pr.player_profile_id
            JOIN role_permissions rp ON pr.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE pp.user_id = $1 
            AND p.name = $2
            AND (
                pr.chapter_id IS NULL  -- Global permission
                OR 
                ($3::uuid IS NOT NULL AND pr.chapter_id = $3::uuid) -- Chapter specific permission
            )
        )
        """
        
        has_perm = await conn.fetchval(query, user_id, permission_name, target_chapter_id)
        
        if not has_perm and raise_exception:
            detail = f"Permission denied: '{permission_name}'"
            if target_chapter_id:
                detail += f" for chapter {target_chapter_id}"
            raise HTTPException(status_code=403, detail=detail)
            
        return has_perm
    finally:
        await conn.close()

async def get_user_chapters_with_permission(
    user_id: str,
    permission_name: str
) -> List[Optional[str]]:
    """
    Get list of chapter IDs where the user has the specified permission.
    Returns [None] if user has global permission.
    Returns [] if user has no permission.
    Returns list of UUID strings for specific chapters.
    """
    conn = await get_database_connection()
    try:
        # Check for global permission first
        global_perm = await conn.fetchval(
            """
            SELECT EXISTS(
                SELECT 1 FROM player_profiles pp
                JOIN player_roles pr ON pp.id = pr.player_profile_id
                JOIN role_permissions rp ON pr.role_id = rp.role_id
                JOIN permissions p ON rp.permission_id = p.id
                WHERE pp.user_id = $1 
                AND p.name = $2
                AND pr.chapter_id IS NULL
            )
            """,
            user_id, permission_name
        )
        
        if global_perm:
            return [None] # Represents all chapters/global
            
        # Get specific chapters
        chapters = await conn.fetch(
            """
            SELECT DISTINCT pr.chapter_id
            FROM player_profiles pp
            JOIN player_roles pr ON pp.id = pr.player_profile_id
            JOIN role_permissions rp ON pr.role_id = rp.role_id
            JOIN permissions p ON rp.permission_id = p.id
            WHERE pp.user_id = $1 
            AND p.name = $2
            AND pr.chapter_id IS NOT NULL
            """,
            user_id, permission_name
        )
        
        return [str(row['chapter_id']) for row in chapters]
    finally:
        await conn.close()
