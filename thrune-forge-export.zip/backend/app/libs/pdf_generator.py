

"""PDF Generation Module for Character Sheets"""

from io import BytesIO
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
from typing import Dict, List, Any
import zipfile


def generate_character_sheet_pdf(character_data: Dict[str, Any]) -> BytesIO:
    """Generate a single character sheet PDF"""
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter, 
                          rightMargin=72, leftMargin=72, 
                          topMargin=72, bottomMargin=18)
    
    # Build story
    story = []
    styles = getSampleStyleSheet()
    
    # Custom styles
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        spaceAfter=30,
        alignment=1,  # Center
        textColor=colors.darkblue
    )
    
    header_style = ParagraphStyle(
        'CustomHeader',
        parent=styles['Heading2'],
        fontSize=14,
        spaceAfter=12,
        textColor=colors.darkred
    )
    
    # Title
    story.append(Paragraph("Thrune's Forge - Character Sheet", title_style))
    story.append(Spacer(1, 20))
    
    # Character Name
    story.append(Paragraph(f"<b>Character Name:</b> {character_data.get('name', 'N/A')}", styles['Normal']))
    story.append(Spacer(1, 12))
    
    # Basic Info Table
    basic_info = [
        ['Player Name', character_data.get('player_name', 'N/A')],
        ['Heritage', character_data.get('heritage_name', 'N/A')],
        ['Culture', character_data.get('culture_name', 'N/A')],
        ['Primary Archetype', character_data.get('archetype_name', 'N/A')],
        ['Secondary Archetype', character_data.get('secondary_archetype_name', 'N/A') or 'None'],
        ['Tertiary Archetype', character_data.get('tertiary_archetype_name', 'N/A') or 'None']
    ]
    
    basic_table = Table(basic_info, colWidths=[2*inch, 3*inch])
    basic_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(Paragraph("Basic Information", header_style))
    story.append(basic_table)
    story.append(Spacer(1, 20))
    
    # Stats Table
    stats_info = [
        ['Body', str(character_data.get('body', 0))],
        ['Stamina', str(character_data.get('stamina', 0))],
        ['XP Available', str(character_data.get('xp_available', 0))],
        ['Total XP Earned', str(character_data.get('xp_total', 0))],
        ['Events Attended', str(character_data.get('events_attended', 0))],
        ['Deaths', str(character_data.get('death_count', 0))],
        ['Status', 'Retired' if character_data.get('retired') else 'Active']
    ]
    
    stats_table = Table(stats_info, colWidths=[2*inch, 1.5*inch])
    stats_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightblue),
        ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, -1), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.black)
    ]))
    
    story.append(Paragraph("Character Stats", header_style))
    story.append(stats_table)
    story.append(Spacer(1, 20))
    
    # Admin Notes (if any)
    if character_data.get('player_notes'):
        story.append(Paragraph("Player Notes", header_style))
        story.append(Paragraph(character_data.get('player_notes', ''), styles['Normal']))
        story.append(Spacer(1, 12))
    
    if character_data.get('addictions_diseases'):
        story.append(Paragraph("Addictions & Diseases", header_style))
        story.append(Paragraph(character_data.get('addictions_diseases', ''), styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Death Status
    if character_data.get('deaths', 0) > 0:
        story.append(Paragraph("Death Information", header_style))
        deaths = character_data.get('deaths', 0)
        story.append(Paragraph(f"• Deaths: {deaths}", styles['Normal']))
        story.append(Spacer(1, 12))
    
    # Footer
    story.append(Spacer(1, 30))
    story.append(Paragraph(f"Generated on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
    
    # Build PDF
    doc.build(story)
    buffer.seek(0)
    return buffer


def generate_bulk_character_sheets(characters: List[Dict[str, Any]]) -> BytesIO:
    """Generate a ZIP file containing multiple character sheet PDFs"""
    zip_buffer = BytesIO()
    
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for character in characters:
            # Generate PDF for this character
            pdf_buffer = generate_character_sheet_pdf(character)
            
            # Create filename: CharacterName_YYYY-MM-DD.pdf
            char_name = character.get('name', 'Unknown').replace(' ', '_')
            date_str = datetime.now().strftime('%Y-%m-%d')
            filename = f"{char_name}_{date_str}.pdf"
            
            # Add to ZIP
            zip_file.writestr(filename, pdf_buffer.getvalue())
    
    zip_buffer.seek(0)
    return zip_buffer
