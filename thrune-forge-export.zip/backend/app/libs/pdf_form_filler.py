"""PDF Form Filling Module for Character Sheets"""

import fitz  # PyMuPDF
from datetime import datetime, timedelta
from typing import Dict, Any, List
from io import BytesIO
import io
import requests

# Static asset URL for the PDF template
PDF_TEMPLATE_URL = "https://static.riff.new/public/e1ccddac-de04-4a52-bbf7-5dcd0ee50a6e/character-sheet-f.pdf"


def clean_benefit_text(text):
    """Clean benefit text by removing underscores and capitalizing properly"""
    if not text:
        return ""
    return text.replace("_", " ").title()


def clean_skill_name(skill_name):
    """Clean up skill names by removing magic path prefixes and adding ** to specific skills"""
    if not skill_name:
        return ""
    
    # Remove magic path prefixes (case insensitive)
    skill_name_lower = skill_name.lower()
    
    # Remove "magic path of the " prefix
    if skill_name_lower.startswith("magic path of the "):
        skill_name = skill_name[17:].strip()  # Remove first 17 characters and trim whitespace
    # Remove "magic path of " prefix
    elif skill_name_lower.startswith("magic path of "):
        skill_name = skill_name[14:].strip()  # Remove first 14 characters and trim whitespace
    # Remove magic path prefix with colon (e.g., "Earth: Entangle" -> "Entangle")
    elif ": " in skill_name:
        skill_name = skill_name.split(": ", 1)[1].strip()
    
    # Add ** prefix to specific skills (case insensitive check)
    skills_with_prefix = {
        "farming", "herbalism", "hunting", "lumberjack", 
        "mercantile", "mining", "scavenging", "trader", "wealth"
    }
    
    if skill_name.lower() in skills_with_prefix:
        return f"**{skill_name}"
    
    return skill_name


def map_character_to_new_form_fields(character_data):
    """Map character data to the new character_sheet_f.pdf form fields"""
    # Create EST timezone-aware timestamp (subtract 4 hours as requested)
    current_time = datetime.utcnow() - timedelta(hours=4)
    pdf_timestamp = current_time.strftime("%Y-%m-%d %I:%M %p EST")
    
    # Calculate derived values with correct field names
    total_xp = character_data.get("xp_total", 0)  # Use correct database column
    spent_xp = character_data.get("xp_spent", 0)  # Use actual spent XP from DB
    remaining_xp = character_data.get("xp_available", 0)  # Use actual available XP
    
    # Health calculations with correct field names
    base_body = character_data.get("base_body", 0)
    total_body = character_data.get("body", 0)
    purchased_body = max(0, total_body - base_body)
    
    base_stamina = character_data.get("base_stamina", 0)
    total_stamina = character_data.get("stamina", 0)
    purchased_stamina = max(0, total_stamina - base_stamina)
    
    # Clean up benefit/flaw text (remove prefixes)
    def clean_benefit_text(text):
        if not text:
            return ""
        # Remove common prefixes
        for prefix in ["Benefit - ", "Weakness - ", "Flaw - ", "Benefit: ", "Flaw: "]:
            if text.startswith(prefix):
                return text[len(prefix):]
        return text
    
    # Build player name
    player_name = f"{character_data.get('first_name', '')} {character_data.get('last_name', '')}".strip()
    
    # Map to actual form fields based on PDF analysis
    form_data = {
        # Basic Character Information
        "text_1svos": character_data.get("name", ""),  # Field #1 - Character Name
        "text_7dkcn": player_name,  # Field #2 - Player Name
        "text_2ezqs": character_data.get("heritage_name", ""),  # Field #3 - Heritage Name
        "text_8pmxq": str(character_data.get("player_number", "")),  # Field #4 - Player ID
        "text_3bsgy": character_data.get("culture_name", ""),  # Field #8 - Culture
        "text_4oypl": character_data.get("archetype_name", ""),  # Field #12 - Primary archetype
        "text_5bsq": character_data.get("secondary_archetype_name", ""),  # Field #14 - Secondary archetype
        "text_6ptlu": character_data.get("tertiary_archetype_name", ""),  # Field #17 - Tertiary archetype
        
        # XP Tracking
        "text_9cqkh": str(total_xp),  # Field #13 - Total XP earned
        "text_10bqpw": str(spent_xp),  # Field #15 - XP spent
        "text_11tzfx": str(remaining_xp),  # Field #18 - XP remaining
        
        # Health System
        "text_12rpum": str(base_body),  # Field #5 - Base heritage body
        "text_14fois": str(purchased_body),  # Field #6 - Purchased body
        "text_16sxan": str(total_body),  # Field #7 - Total body
        "text_13vg": str(base_stamina),  # Field #9 - Base heritage stamina
        "text_15dvbl": str(purchased_stamina),  # Field #10 - Purchased stamina
        "text_17izaz": str(total_stamina),  # Field #11 - Total stamina
        
        # Progress Tracking
        "text_18cbri": str(character_data.get("events_attended", 0)),  # Field #16 - Events attended
        "text_19kc": str(character_data.get("deaths", 0)),  # Field #19 - Deaths
        "text_20wtca": str(character_data.get("corruption", 0)),  # Field #20 - Corruption
        
        # Special Features
        "text_21mmty": clean_benefit_text(character_data.get("heritage_benefit_name", "")),  # Field #25 - Heritage benefit
        "text_22hxoy": clean_benefit_text(character_data.get("heritage_flaw_name", "")),  # Field #30 - Heritage flaw
        "text_23woai": clean_benefit_text(character_data.get("culture_benefit_name", "")),  # Field #35 - Culture benefit
        
        # Notes
        "textarea_25qska": character_data.get("addictions_diseases", ""),  # Field #48 - Addictions/diseases
        "textarea_26xehj": character_data.get("player_notes", ""),  # Field #81 - Player notes
        
        # Meta
        "text_28pdde": pdf_timestamp,  # Field #106 - PDF timestamp
    }
    
    # Process skills - get first 40 skills with names and costs
    # Get skills data from character - FIXED: Use correct field name
    skills_data = character_data.get("selected_skills", [])
    print(f"Found {len(skills_data)} skills in selected_skills")
    
    # Skills - All 40 skill pairs with exact field names
    skill_fields = [
        # Skill pairs: (skill_name_field, skill_cost_field)
        ("text_29ffia", "text_49kqgx"),    # 1st skill - Field #21, #22
        ("text_30cx", "text_50wpko"),      # 2nd skill - Field #26, #27  
        ("text_31dgmr", "text_51kjtz"),    # 3rd skill - Field #31, #32
        ("text_32ayht", "text_52wcmo"),    # 4th skill - Field #36, #37
        ("text_33thut", "text_53cwsa"),    # 5th skill - Field #40, #41
        ("text_34apzk", "text_54wcim"),    # 6th skill - Field #44, #45
        ("text_35pfni", "text_55mucq"),    # 7th skill - Field #49, #50
        ("text_36vfhz", "text_56xlvp"),    # 8th skill - Field #53, #54
        ("text_37vomg", "text_57jvju"),    # 9th skill - Field #57, #58
        ("text_38gvpg", "text_58imhf"),    # 10th skill - Field #61, #62
        ("text_39pqpr", "text_59tjrk"),    # 11th skill - Field #65, #66
        ("text_40efoe", "text_60gmln"),    # 12th skill - Field #69, #70
        ("text_41rvcz", "text_61qfs"),     # 13th skill - Field #73, #74
        ("text_42ofnd", "text_62qmjp"),    # 14th skill - Field #77, #78
        ("text_43qdeu", "text_63sjwp"),    # 15th skill - Field #82, #83
        ("text_44sal", "text_64glpr"),     # 16th skill - Field #86, #87
        ("text_45ejxc", "text_65sdo"),     # 17th skill - Field #90, #91
        ("text_46yhqg", "text_66trlr"),    # 18th skill - Field #94, #95
        ("text_47etsa", "text_67gooe"),    # 19th skill - Field #98, #99
        ("text_48dizx", "text_68hexh"),    # 20th skill - Field #102, #103
        ("text_69qyoz", "text_89qvvj"),    # 21st skill - Field #23, #24
        ("text_70xzeu", "text_90xrdm"),    # 22nd skill - Field #28, #29
        ("text_71vviw", "text_91phfr"),    # 23rd skill - Field #33, #34
        ("text_72cmse", "text_92woyo"),    # 24th skill - Field #38, #39
        ("text_73lwkn", "text_93weei"),    # 25th skill - Field #42, #43
        ("text_74dpcf", "text_94rpyp"),    # 26th skill - Field #46, #47
        ("text_75mrdm", "text_95izsn"),    # 27th skill - Field #51, #52
        ("text_76qdfu", "text_96dskt"),    # 28th skill - Field #55, #56
        ("text_77rfum", "text_97unqg"),    # 29th skill - Field #59, #60
        ("text_78mcir", "text_98rqhh"),    # 30th skill - Field #63, #64
        ("text_79elsh", "text_99wgda"),    # 31st skill - Field #67, #68
        ("text_80rewy", "text_100kpbz"),   # 32nd skill - Field #71, #72
        ("text_81znio", "text_101ltqz"),   # 33rd skill - Field #75, #76
        ("text_82jzoj", "text_102rsfg"),   # 34th skill - Field #79, #80
        ("text_83myfv", "text_103aehh"),   # 35th skill - Field #84, #85
        ("text_84nbda", "text_104ujvx"),   # 36th skill - Field #88, #89
        ("text_85pplh", "text_105oxka"),   # 37th skill - Field #92, #93
        ("text_86nzqj", "text_106hbjf"),   # 38th skill - Field #96, #97
        ("text_87uugg", "text_107xrac"),   # 39th skill - Field #100, #101
        ("text_88uzyk", "text_108mtyc"),   # 40th skill - Field #104, #105
    ]
    
    # Group skills by name and count duplicates
    from collections import defaultdict
    skill_groups = defaultdict(lambda: {'count': 0, 'xp_cost': 0})
    
    for skill in skills_data:
        skill_name = clean_skill_name(skill.get("name", ""))
        skill_groups[skill_name]['count'] += 1
        skill_groups[skill_name]['xp_cost'] = skill.get("xp_cost", 0)
    
    # Convert to list with formatted names
    consolidated_skills = []
    for skill_name, data in skill_groups.items():
        if data['count'] > 1:
            # Add multiplier for skills purchased multiple times
            formatted_name = f"{skill_name} x{data['count']}"
            # Calculate total cost (single cost × count)
            total_cost = data['xp_cost'] * data['count']
            formatted_cost = f"{data['xp_cost']} ({total_cost})"
        else:
            formatted_name = skill_name
            formatted_cost = str(data['xp_cost'])
        
        consolidated_skills.append({
            'name': formatted_name,
            'xp_cost': formatted_cost
        })
    
    # Custom sorting function for skills
    def sort_skill_key(skill):
        name = skill['name']
        
        # Check if it's a magic path skill (looking for "magic path of" case-insensitive)
        name_lower = name.lower()
        
        if 'magic path of' in name_lower:
            # Extract the path type and tier
            # Format is usually "Magic Path of the Earth: Apprentice" or "Earth: Apprentice" after cleaning
            if ':' in name:
                parts = name.split(':', 1)
                path_name = parts[0].strip()
                tier = parts[1].strip().lower()
                
                # Remove "x2", "x3" etc from tier if present
                tier_clean = tier.split(' x')[0].strip()
                
                # Define tier order
                tier_order = {'apprentice': 1, 'journeyman': 2, 'master': 3}
                tier_num = tier_order.get(tier_clean, 99)
                
                # Return tuple: (is_magic, path_name, tier_number, full_name)
                return (True, path_name.lower(), tier_num, name)
            else:
                # Magic path but no tier, sort it normally
                return (True, name.lower(), 0, name)
        else:
            # Not a magic path skill, sort alphabetically
            # Return tuple: (is_magic, name, 0, name)
            return (False, name.lower(), 0, name)
    
    # Sort the consolidated skills
    consolidated_skills.sort(key=sort_skill_key)
    
    print(f"Consolidated {len(skills_data)} skills into {len(consolidated_skills)} unique entries")
    
    # Fill skill pairs
    for i, (skill_name_field, skill_cost_field) in enumerate(skill_fields):
        if i < len(consolidated_skills):
            skill = consolidated_skills[i]
            form_data[skill_name_field] = skill['name']
            form_data[skill_cost_field] = str(skill['xp_cost'])
        else:
            # Empty fields for unused skill slots
            form_data[skill_name_field] = ""
            form_data[skill_cost_field] = ""
    
    # Remove empty fields to avoid overwriting form defaults
    return {k: v for k, v in form_data.items() if v}

def generate_character_sheet_pdf(character_data: Dict[str, Any]) -> BytesIO:
    """Generate a filled PDF character sheet using template from static assets"""
    
    try:
        print(f"Generating PDF for character: {character_data.get('name', 'Unknown')}")
        
        # Fetch the template PDF from static assets
        try:
            print(f"Fetching PDF template from static assets: {PDF_TEMPLATE_URL}")
            
            # Check if template URL is configured
            if "TEMPLATE_ASSET_ID" in PDF_TEMPLATE_URL:
                print("WARNING: PDF template URL not configured yet. Using fallback PDF generation.")
                print("Please upload character_sheet_f.pdf to static assets and update PDF_TEMPLATE_URL")
                return create_fallback_pdf(character_data)
            
            response = requests.get(PDF_TEMPLATE_URL, timeout=10)
            response.raise_for_status()
            template_pdf = response.content
            print(f"Successfully fetched PDF template: {len(template_pdf)} bytes")
            
        except requests.RequestException as e:
            print(f"Error fetching PDF template from static assets: {e}")
            print("Falling back to ReportLab PDF generation")
            return create_fallback_pdf(character_data)
        
        # Open the template PDF
        doc = fitz.open("pdf", template_pdf)
        
        # Get the form fields mapping
        form_data = map_character_to_new_form_fields(character_data)
        
        # Fill the form fields using PyMuPDF's method
        page = doc[0]  # Assuming single-page form
        
        # Get all form fields on the page
        widgets = page.widgets()
        filled_count = 0
        
        for widget in widgets:
            field_name = widget.field_name
            if field_name in form_data:
                try:
                    widget.field_value = str(form_data[field_name])
                    widget.update()
                    filled_count += 1
                except Exception as e:
                    print(f"Warning: Could not fill field {field_name}: {e}")
                    continue
        
        print(f"Filled {filled_count}/{len(form_data)} form fields")
        
        # Save to buffer
        buffer = BytesIO()
        doc.save(buffer)
        doc.close()
        
        buffer.seek(0)
        print(f"Generated form-filled PDF: {len(buffer.getvalue())} bytes")
        return buffer
            
    except Exception as e:
        print(f"Error generating PDF: {e}")
        # Create a simple reportlab PDF as ultimate fallback
        return create_fallback_pdf(character_data)

def create_fallback_pdf(character_data: Dict[str, Any]) -> BytesIO:
    """Create a simple PDF using reportlab as fallback"""
    
    try:
        from reportlab.pdfgen import canvas
        from reportlab.lib.pagesizes import letter
        
        print("Creating fallback PDF with reportlab")
        
        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=letter)
        
        # Basic character information
        y_position = 750
        line_height = 20
        
        c.drawString(50, y_position, f"Character Name: {character_data.get('name', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Heritage: {character_data.get('heritage_name', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Culture: {character_data.get('culture_name', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Primary Archetype: {character_data.get('primary_archetype_name', '')}")
        y_position -= line_height * 2
        
        # Stats
        c.drawString(50, y_position, f"Body: {character_data.get('body', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Stamina: {character_data.get('stamina', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Corruption: {character_data.get('corruption', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Deaths: {character_data.get('deaths', '')}")
        y_position -= line_height * 2
        
        # XP
        c.drawString(50, y_position, f"Total XP: {character_data.get('xp_total', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Spent XP: {character_data.get('xp_spent', '')}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Available XP: {character_data.get('xp_available', '')}")
        y_position -= line_height * 2
        
        # Player info
        player_name = f"{character_data.get('first_name', '')} {character_data.get('last_name', '')}".strip()
        c.drawString(50, y_position, f"Player: {player_name}")
        y_position -= line_height
        
        c.drawString(50, y_position, f"Player Number: {character_data.get('player_number', '')}")
        
        c.save()
        buffer.seek(0)
        
        print(f"Created fallback PDF: {len(buffer.getvalue())} bytes")
        return buffer
        
    except Exception as e:
        print(f"Error creating fallback PDF: {e}")
        raise

def generate_bulk_character_sheets(characters_data: List[dict]) -> io.BytesIO:
    """Generate a single multi-page PDF with multiple character sheets using simple concatenation"""
    
    try:
        print(f"Generating bulk PDF with {len(characters_data)} character sheets using simple concatenation")
        
        # Create a new PDF document
        combined_doc = fitz.open()
        
        for i, character_data in enumerate(characters_data):
            try:
                print(f"Processing character {i+1}/{len(characters_data)}: {character_data.get('name', 'Unknown')}")
                
                # Generate individual form-filled PDF for this character
                char_pdf_buffer = generate_character_sheet_pdf(character_data)
                
                # Open the character PDF with PyMuPDF
                char_doc = fitz.open("pdf", char_pdf_buffer.getvalue())
                
                # Simply insert all pages from this character's PDF
                combined_doc.insert_pdf(char_doc)
                
                # Close the character document
                char_doc.close()
                    
                print(f"Added character sheet for {character_data.get('name', 'Unknown')}")
                
            except Exception as e:
                print(f"Error processing character {i+1}: {e}")
                continue
        
        # Save combined document to buffer
        output_buffer = io.BytesIO()
        combined_doc.save(output_buffer)
        combined_doc.close()
        
        output_buffer.seek(0)
        print(f"Generated bulk PDF with size: {len(output_buffer.getvalue())} bytes")
        return output_buffer
        
    except Exception as e:
        print(f"Error generating bulk PDF: {e}")
        raise
