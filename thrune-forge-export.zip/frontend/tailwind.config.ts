export * from "./tailwind.config.js";
