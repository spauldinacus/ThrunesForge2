import { useUser } from '@stackframe/react';
import { useState, useEffect, useCallback } from 'react';
import { apiClient } from 'app';

interface UserPermissions {
  hasProfile: boolean;
  isAdmin: boolean;
  permissions: string[];
  roles: Array<{
    id: string;
    name: string;
    description: string | null;
    is_system_role: boolean;
    permissions: string[];
  }>;
}

// Cache for permissions to avoid excessive API calls
let permissionsCache: UserPermissions | null = null;
let cacheUserId: string | null = null;
let cacheTimestamp: number = 0;
const CACHE_DURATION = 5 * 60 * 1000; // 5 minutes

// Function to clear cache (useful for forcing refresh after admin status changes)
export function clearPermissionsCache() {
  permissionsCache = null;
  cacheUserId = null;
  cacheTimestamp = 0;
}

export function usePermissions() {
  const user = useUser();
  const [permissions, setPermissions] = useState<string[]>([]);
  const [roles, setRoles] = useState<UserPermissions['roles']>([]);
  const [hasProfile, setHasProfile] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchPermissions() {
      if (!user?.id) {
        // User not logged in - reset everything
        setPermissions([]);
        setRoles([]);
        setHasProfile(false);
        setIsAdmin(false);
        setLoading(false);
        return;
      }

      try {
        const now = Date.now();
        const isCacheValid = 
          permissionsCache && 
          cacheUserId === user.id && 
          (now - cacheTimestamp) < CACHE_DURATION;

        let data: UserPermissions;
        
        if (isCacheValid) {
          data = permissionsCache!;
        } else {
          // Get user's permissions from new endpoint
          const response = await apiClient.get_my_permissions();
          data = await response.json();
          
          // Update cache
          permissionsCache = data;
          cacheUserId = user.id;
          cacheTimestamp = now;
        }
        
        // Update state
        setPermissions(data.permissions || []);
        setRoles(data.roles || []);
        setHasProfile(data.hasProfile || false);
        setIsAdmin(data.isAdmin || false);
      } catch (error) {
        console.error('Error fetching permissions:', error);
        
        // Fallback: try to get basic admin status
        try {
          const userInfoResponse = await apiClient.get_current_user_info();
          const userInfo = await userInfoResponse.json();
          
          setPermissions([]);
          setRoles([]);
          setHasProfile(userInfo.has_profile || false);
          setIsAdmin(userInfo.is_admin || false);
        } catch (fallbackError) {
          console.error('Error in fallback permission check:', fallbackError);
          
          // Complete fallback - no permissions
          setPermissions([]);
          setRoles([]);
          setHasProfile(false);
          setIsAdmin(false);
        }
      } finally {
        setLoading(false);
      }
    }

    fetchPermissions();
  }, [user?.id]);

  // Helper functions
  const hasPermission = useCallback((permission: string): boolean => {
    return permissions.includes(permission);
  }, [permissions]);

  const hasAnyPermission = useCallback((permissionList: string[]): boolean => {
    return permissionList.some(permission => permissions.includes(permission));
  }, [permissions]);

  const hasRole = useCallback((roleName: string): boolean => {
    return roles.some(role => role.name === roleName);
  }, [roles]);

  const hasAnyRole = useCallback((roleNames: string[]): boolean => {
    return roleNames.some(roleName => hasRole(roleName));
  }, [hasRole]);

  return {
    permissions,
    roles,
    hasProfile,
    isAdmin,
    loading,
    hasPermission,
    hasAnyPermission,
    hasRole,
    hasAnyRole,
    // Alias for legacy compatibility
    hasAdminAccess: isAdmin
  };
}

// Export PERMISSIONS from the separate file
export { PERMISSIONS } from 'utils/permissions';

// Export type for external use
export type { UserPermissions };

// Default export
export default usePermissions;
