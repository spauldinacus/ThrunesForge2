interface CapturedError {
  type: 'error' | 'warn' | 'log';
  message: string;
  timestamp: string;
  stack?: string;
}

class ErrorCapture {
  private errors: CapturedError[] = [];
  private maxErrors = 50;
  private originalConsole = {
    error: console.error,
    warn: console.warn,
    log: console.log,
  };

  initialize() {
    // Intercept console.error
    console.error = (...args: any[]) => {
      this.captureError('error', args);
      this.originalConsole.error(...args);
    };

    // Intercept console.warn
    console.warn = (...args: any[]) => {
      this.captureError('warn', args);
      this.originalConsole.warn(...args);
    };

    // Intercept unhandled errors
    window.addEventListener('error', (event) => {
      this.captureError('error', [event.message], event.error?.stack);
    });

    // Intercept unhandled promise rejections
    window.addEventListener('unhandledrejection', (event) => {
      this.captureError('error', [event.reason]);
    });
  }

  private captureError(type: 'error' | 'warn' | 'log', args: any[], stack?: string) {
    const message = args.map(arg => 
      typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
    ).join(' ');

    this.errors.push({
      type,
      message,
      timestamp: new Date().toISOString(),
      stack,
    });

    // Keep only last maxErrors
    if (this.errors.length > this.maxErrors) {
      this.errors.shift();
    }
  }

  getErrors(): CapturedError[] {
    return [...this.errors];
  }

  clearErrors() {
    this.errors = [];
  }
}

export const errorCapture = new ErrorCapture();

/**
 * Initialize global error handlers for deployment issues
 */
export function initializeDeploymentErrorHandlers() {
  // Handle unsupported build version errors
  window.addEventListener('error', (event) => {
    const errorMessage = event.message || event.error?.message || '';
    
    if (errorMessage.includes('unsupported build version') || 
        errorMessage.includes('Received unsupported build version')) {
      console.error('🔄 Unsupported build version detected. Forcing hard reload...');
      
      // Clear any cached resources
      if ('caches' in window) {
        caches.keys().then(names => {
          names.forEach(name => caches.delete(name));
        });
      }
      
      // Force a hard reload with cache bypass
      setTimeout(() => {
        window.location.reload();
      }, 100);
      
      event.preventDefault();
      return false;
    }
  });

  // Handle unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const errorMessage = event.reason?.message || String(event.reason) || '';
    
    if (errorMessage.includes('unsupported build version') || 
        errorMessage.includes('Received unsupported build version')) {
      console.error('🔄 Unsupported build version detected in promise. Forcing hard reload...');
      
      // Clear any cached resources
      if ('caches' in window) {
        caches.keys().then(names => {
          names.forEach(name => caches.delete(name));
        });
      }
      
      // Force a hard reload with cache bypass
      setTimeout(() => {
        window.location.reload();
      }, 100);
      
      event.preventDefault();
    }
  });
}
