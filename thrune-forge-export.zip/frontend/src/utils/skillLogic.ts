


import { SkillResponse, ArchetypeResponse, HeritageResponse } from 'types';

export interface SkillWithState extends SkillResponse {
  xp_cost?: number;
  is_primary?: boolean;
  is_secondary?: boolean;
  is_locked?: boolean;
  missing_prerequisites?: string[];
}

/**
 * Calculate the XP cost for a skill based on archetype and heritage
 */
export const calculateSkillXPCost = (
  skill: SkillResponse,
  archetype: ArchetypeResponse | null,
  heritage: HeritageResponse | null,
  secondaryArchetype?: ArchetypeResponse | null,
  tertiaryArchetype?: ArchetypeResponse | null
): number => {
  // Check if it's a primary skill from ANY archetype (5 XP)
  const isPrimaryInPrimary = archetype && (archetype.primary_skills || []).some(s => s.id === skill.id);
  const isPrimaryInSecondary = secondaryArchetype && (secondaryArchetype.primary_skills || []).some(s => s.id === skill.id);
  const isPrimaryInTertiary = tertiaryArchetype && (tertiaryArchetype.primary_skills || []).some(s => s.id === skill.id);
  
  if (isPrimaryInPrimary || isPrimaryInSecondary || isPrimaryInTertiary) return 5;

  // Check if it's a secondary skill from ANY archetype OR heritage (10 XP)
  const isSecondaryInPrimary = archetype && (archetype.secondary_skills || []).some(s => s.id === skill.id);
  const isSecondaryInSecondary = secondaryArchetype && (secondaryArchetype.secondary_skills || []).some(s => s.id === skill.id);
  const isSecondaryInTertiary = tertiaryArchetype && (tertiaryArchetype.secondary_skills || []).some(s => s.id === skill.id);
  const isSecondaryInHeritage = heritage && (heritage.secondary_skills || []).some(s => s.id === skill.id);
  
  if (isSecondaryInPrimary || isSecondaryInSecondary || isSecondaryInTertiary || isSecondaryInHeritage) return 10;

  // Default cost
  return 20;
};

/**
 * Find all skills that depend on a given skill as a prerequisite
 */
export const findDependentSkills = (
  skillId: string,
  allSkills: SkillResponse[],
  selectedSkills: Record<string, number>
): SkillResponse[] => {
  // Add null safety checks
  if (!skillId || !allSkills || !selectedSkills) {
    return [];
  }

  const selectedSkillIds = Object.keys(selectedSkills);
  const dependentSkills: SkillResponse[] = [];
  const visited = new Set<string>();

  // Recursive function to find all dependent skills in the dependency tree
  const findDependentsRecursive = (targetSkillId: string) => {
    if (visited.has(targetSkillId)) return;
    visited.add(targetSkillId);

    for (const skillId of selectedSkillIds) {
      const skill = (allSkills || []).find(s => s.id === skillId);
      if (!skill || !skill.prerequisites) continue;

      // Check if this skill depends on the target skill
      const dependsOnTarget = skill.prerequisites.some(prereq => prereq?.id === targetSkillId);
      if (dependsOnTarget) {
        if (!dependentSkills.find(s => s.id === skill.id)) {
          dependentSkills.push(skill);
        }
        // Recursively find skills that depend on this skill
        findDependentsRecursive(skill.id);
      }
    }
  };

  findDependentsRecursive(skillId);
  return dependentSkills;
};

/**
 * Validate if a skill's prerequisites are met
 */
export const validateSkillPrerequisites = (
  skill: SkillResponse,
  selectedSkills: Record<string, number>
): { isValid: boolean; missingPrereqs: string[] } => {
  if (!skill.prerequisites || skill.prerequisites.length === 0) {
    return { isValid: true, missingPrereqs: [] };
  }

  // Count how many prerequisites are actually met
  let metCount = 0;
  const missingPrereqs: string[] = [];
  
  for (const prereq of skill.prerequisites) {
    const isPrereqMet = (selectedSkills[prereq.id] || 0) > 0;
    if (isPrereqMet) {
      metCount++;
    } else {
      missingPrereqs.push(prereq.name);
    }
  }

  // Determine how many prerequisites are required
  // If prerequisite_count is 0, treat as "all required" (backward compatibility)
  // Otherwise, use the specified count
  const requiredCount = skill.prerequisite_count > 0 
    ? skill.prerequisite_count 
    : skill.prerequisites.length;

  // Valid if we have enough prerequisites met
  const isValid = metCount >= requiredCount;

  // If valid, clear missing prereqs (requirement is fulfilled)
  // If not valid, return the unmet prerequisites as options
  return {
    isValid,
    missingPrereqs: isValid ? [] : missingPrereqs
  };
};

/**
 * Process skills with state information (costs, locks, prerequisites)
 */
export const processSkillsWithState = (
  allSkills: SkillResponse[],
  selectedSkills: Record<string, number>,
  archetype: ArchetypeResponse | null,
  heritage: HeritageResponse | null,
  secondaryArchetype?: ArchetypeResponse | null,
  tertiaryArchetype?: ArchetypeResponse | null,
  showHidden: boolean = false
): SkillWithState[] => {
  // Root cause fix: Add comprehensive null safety at function entry
  if (!allSkills || !Array.isArray(allSkills)) {
    return [];
  }

  // Filter skills based on showHidden parameter AND admin_only
  const visibleSkills = allSkills.filter(skill => {
    // ADMIN MODE: Show everything
    if (showHidden) return true;
    
    // CHARACTER CREATOR MODE: Hide admin-only skills
    if (skill.admin_only) return false;
    
    // CHARACTER CREATOR MODE: Hide hidden skills completely
    if (skill.hidden) return false;
    
    // Show all non-hidden, non-admin-only skills
    return true;
  });

  // Allow skills to display even without archetype - show with default costs
  return visibleSkills.map(skill => {
    const isSelected = (selectedSkills && selectedSkills[skill.id] || 0) > 0;
    
    // Check if primary in ANY archetype
    const isPrimary = (Array.isArray(archetype?.primary_skills) && archetype.primary_skills.some(s => s.id === skill.id)) ||
                     (Array.isArray(secondaryArchetype?.primary_skills) && secondaryArchetype.primary_skills.some(s => s.id === skill.id)) ||
                     (Array.isArray(tertiaryArchetype?.primary_skills) && tertiaryArchetype.primary_skills.some(s => s.id === skill.id));
    
    // Check if secondary in ANY archetype OR heritage
    const isSecondary = (Array.isArray(archetype?.secondary_skills) && archetype.secondary_skills.some(s => s.id === skill.id)) ||
                       (Array.isArray(secondaryArchetype?.secondary_skills) && secondaryArchetype.secondary_skills.some(s => s.id === skill.id)) ||
                       (Array.isArray(tertiaryArchetype?.secondary_skills) && tertiaryArchetype.secondary_skills.some(s => s.id === skill.id)) ||
                       (Array.isArray(heritage?.secondary_skills) && heritage.secondary_skills.some(s => s.id === skill.id));
    
    const xpCost = calculateSkillXPCost(skill, archetype, heritage, secondaryArchetype, tertiaryArchetype);
    const { isValid: hasAllPrerequisites, missingPrereqs } = validateSkillPrerequisites(skill, selectedSkills || {});

    // A skill is locked if it doesn't have all prerequisites AND isn't already selected
    const isLocked = !hasAllPrerequisites && !isSelected;

    return {
      ...skill,
      xp_cost: xpCost,
      is_primary: isPrimary,
      is_secondary: isSecondary,
      is_locked: isLocked,
      missing_prerequisites: missingPrereqs
    };
  });
};

/**
 * Sort skills by category (primary, secondary, other) and then alphabetically
 */
export const sortSkillsByCategory = (skills: SkillWithState[]): SkillWithState[] => {
  return [...skills].sort((a, b) => {
    // Assign category order: primary=0, secondary=1, other=2
    const getCategoryOrder = (skill: SkillWithState) => {
      if (skill.is_primary) return 0;
      if (skill.is_secondary) return 1;
      return 2;
    };
    
    const categoryA = getCategoryOrder(a);
    const categoryB = getCategoryOrder(b);
    
    // First sort by category
    if (categoryA !== categoryB) {
      return categoryA - categoryB;
    }
    
    // Then sort alphabetically by name within the same category
    return a.name.localeCompare(b.name);
  });
};
