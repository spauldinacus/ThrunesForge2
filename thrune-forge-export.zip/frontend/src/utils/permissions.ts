// Permission constants for role-based access control
export const PERMISSIONS = {
  // Core admin permissions
  VIEW_ADMIN_PANEL: 'view_admin_panel',
  
  // Player management
  MANAGE_PLAYERS: 'manage_players',
  
  // Event management
  MANAGE_EVENTS: 'manage_events',
  
  // Character management
  MANAGE_CHARACTERS: 'manage_characters',
  
  // Content management
  MANAGE_CHAPTERS: 'manage_chapters',
  MANAGE_ARCHETYPES: 'manage_archetypes',
  MANAGE_HERITAGES: 'manage_heritages',
  MANAGE_CULTURES: 'manage_cultures',
  MANAGE_SKILLS: 'manage_skills',
  MANAGE_LORE_SUBMISSIONS: 'manage_lore_submissions',
  MANAGE_PHOTO_GALLERIES: 'manage_photo_galleries',
  
  // Milestones and journals
  VIEW_SHARED_MILESTONES: 'view_shared_milestones',
  
  // Analytics
  VIEW_ANALYTICS: 'view_analytics',
    
  // Role and permission management
  MANAGE_ROLES: 'manage_roles',
  
  // Character reassignment
  CHARACTER_REASSIGNMENT: 'character_reassignment',

  // Audit Logs
  VIEW_AUDIT_LOGS: 'view_audit_logs'
} as const;

// Type for permission values
export type Permission = typeof PERMISSIONS[keyof typeof PERMISSIONS];

// Helper to check if a string is a valid permission
export function isValidPermission(permission: string): permission is Permission {
  return Object.values(PERMISSIONS).includes(permission as Permission);
}
