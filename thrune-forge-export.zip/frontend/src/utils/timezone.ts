/**
 * Timezone utility functions for handling datetime conversions
 * All times are handled in Eastern Time (EST/EDT) for consistency
 */

const EST_TIMEZONE = 'America/New_York';

/**
 * Converts a datetime-local input value (YYYY-MM-DDTHH:mm) to UTC ISO string
 * This assumes the input is in Eastern Time and converts to UTC for backend storage
 * 
 * @param datetimeLocalValue - Value from datetime-local input in EST (e.g., "2024-09-28T22:00")
 * @returns ISO string in UTC for backend storage
 */
export function convertLocalDatetimeToUTC(datetimeLocalValue: string): string {
  if (!datetimeLocalValue) {
    throw new Error('Datetime value is required');
  }
  
  // The input is in format "YYYY-MM-DDTHH:mm" and represents EST/EDT time
  // We need to convert this to UTC ISO string
  
  // Split into components
  const [datePart, timePart] = datetimeLocalValue.split('T');
  const [year, month, day] = datePart.split('-');
  const [hour, minute] = timePart.split(':');
  
  // Create a formatter that will help us parse this as EST
  const dateInEST = new Date(`${year}-${month}-${day}T${hour}:${minute}:00`);
  
  // Get the EST string representation
  const estFormatter = new Intl.DateTimeFormat('sv-SE', {
    timeZone: EST_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false
  });
  
  // Find what UTC time gives us the desired EST time
  // We'll use a different approach: create the date components directly
  const targetESTString = `${year}-${month}-${day} ${hour}:${minute}:00`;
  
  // Try different UTC times until we find one that formats to our target EST time
  // Start with a reasonable guess
  let guessUTC = new Date(Date.UTC(
    parseInt(year),
    parseInt(month) - 1,
    parseInt(day),
    parseInt(hour) + 5, // Initial guess: add 5 hours for EST
    parseInt(minute)
  ));
  
  // Check the formatted result
  const formattedEST = estFormatter.format(guessUTC).replace('T', ' ');
  
  // If it doesn't match, adjust for DST (try +4 instead of +5)
  if (!formattedEST.startsWith(targetESTString.slice(0, -3))) {
    guessUTC = new Date(Date.UTC(
      parseInt(year),
      parseInt(month) - 1,
      parseInt(day),
      parseInt(hour) + 4, // DST: add 4 hours for EDT
      parseInt(minute)
    ));
  }
  
  return guessUTC.toISOString();
}
/**
 * Converts a UTC ISO string back to datetime-local format for input fields
 * This converts UTC time to Eastern Time for display in datetime-local inputs
 * 
 * @param utcIsoString - UTC ISO string from backend
 * @returns datetime-local format in EST (e.g., "2024-09-28T22:00")
 */
export function convertUTCToLocalDatetime(utcIsoString: string): string {
  if (!utcIsoString) {
    return '';
  }
  
  const utcDate = new Date(utcIsoString);
  
  // Convert UTC to EST using Intl API
  const estDateString = utcDate.toLocaleString('sv-SE', { 
    timeZone: EST_TIMEZONE,
    year: 'numeric',
    month: '2-digit', 
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });
  
  // Convert from "YYYY-MM-DD HH:mm:ss" to "YYYY-MM-DDTHH:mm"
  return estDateString.replace(' ', 'T').slice(0, 16);
}

/**
 * Formats a UTC datetime string for display in Eastern Time
 * 
 * @param utcIsoString - UTC ISO string from backend
 * @param options - Intl.DateTimeFormatOptions for customizing the display
 * @returns Formatted date string in Eastern Time
 */
export function formatDateTimeForDisplay(
  utcIsoString: string,
  options: Intl.DateTimeFormatOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: EST_TIMEZONE
  }
): string {
  if (!utcIsoString) {
    return '';
  }
  
  const date = new Date(utcIsoString);
  return date.toLocaleDateString('en-US', {
    ...options,
    timeZone: EST_TIMEZONE
  });
}

/**
 * Formats just the time portion for display in Eastern Time
 * 
 * @param utcIsoString - UTC ISO string from backend
 * @returns Time string in Eastern Time (e.g., "10:00 PM EST")
 */
export function formatTimeForDisplay(utcIsoString: string): string {
  if (!utcIsoString) {
    return '';
  }
  
  const date = new Date(utcIsoString);
  return date.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    timeZone: EST_TIMEZONE
  }) + ' EST';
}

/**
 * Formats just the date portion for display in Eastern Time
 * 
 * @param utcIsoString - UTC ISO string from backend
 * @returns Date string in Eastern Time (e.g., "Sep 28, 2024")
 */
export function formatDateForDisplay(utcIsoString: string): string {
  if (!utcIsoString) {
    return '';
  }
  
  const date = new Date(utcIsoString);
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    timeZone: EST_TIMEZONE
  });
}

/**
 * Validates that a datetime-local value is in the future (assuming EST input)
 * 
 * @param datetimeLocalValue - Value from datetime-local input in EST
 * @returns true if the datetime is in the future
 */
export function isDatetimeInFuture(datetimeLocalValue: string): boolean {
  if (!datetimeLocalValue) {
    return false;
  }
  
  // Convert the EST input to UTC for comparison
  const utcString = convertLocalDatetimeToUTC(datetimeLocalValue);
  const inputDate = new Date(utcString);
  const now = new Date();
  
  return inputDate > now;
}

/**
 * Helper function to determine if a date is in Daylight Saving Time
 * 
 * @param date - Date to check
 * @returns true if date is in DST period
 */
function isDaylightSavingTime(date: Date): boolean {
  // DST in US typically runs from second Sunday in March to first Sunday in November
  const year = date.getFullYear();
  
  // Get second Sunday in March
  const march = new Date(year, 2, 1); // March 1st
  const dstStart = new Date(year, 2, 14 - march.getDay()); // Second Sunday
  
  // Get first Sunday in November  
  const november = new Date(year, 10, 1); // November 1st
  const dstEnd = new Date(year, 10, 7 - november.getDay()); // First Sunday
  
  return date >= dstStart && date < dstEnd;
}
