import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { HeritageResponse, CultureResponse, ArchetypeResponse, SkillResponse } from 'types';

interface CharacterReferenceStore {
  // Data
  heritages: HeritageResponse[];
  cultures: CultureResponse[];
  archetypes: ArchetypeResponse[];
  skills: SkillResponse[];
  characterNames: string[];
  
  // Metadata
  lastUpdated: number;
  isLoaded: boolean;
  
  // Loading states
  heritagesLoaded: boolean;
  culturesLoaded: boolean;
  archetypesLoaded: boolean;
  skillsLoaded: boolean;
  characterNamesLoaded: boolean;
  
  // Actions
  setHeritages: (heritages: HeritageResponse[]) => void;
  setCultures: (cultures: CultureResponse[]) => void;
  setArchetypes: (archetypes: ArchetypeResponse[]) => void;
  setSkills: (skills: SkillResponse[]) => void;
  setCharacterNames: (names: string[]) => void;
  
  setHeritagesLoaded: (loaded: boolean) => void;
  setCulturesLoaded: (loaded: boolean) => void;
  setArchetypesLoaded: (loaded: boolean) => void;
  setSkillsLoaded: (loaded: boolean) => void;
  setCharacterNamesLoaded: (loaded: boolean) => void;
  
  clearCache: () => void;
  isDataFresh: () => boolean;
}

const CACHE_DURATION = 10 * 60 * 1000; // 10 minutes in milliseconds

export const useCharacterReferenceStore = create<CharacterReferenceStore>()(  
  persist(
    (set, get) => ({
      // Initial state
      heritages: [],
      cultures: [],
      archetypes: [],
      skills: [],
      characterNames: [],
      
      lastUpdated: 0,
      isLoaded: false,
      
      heritagesLoaded: false,
      culturesLoaded: false,
      archetypesLoaded: false,
      skillsLoaded: false,
      characterNamesLoaded: false,
      
      // Actions
      setHeritages: (heritages) => {
        set({ 
          heritages, 
          lastUpdated: Date.now(),
          heritagesLoaded: true
        });
      },
      
      setCultures: (cultures) => {
        set({ 
          cultures, 
          lastUpdated: Date.now(),
          culturesLoaded: true
        });
      },
      
      setArchetypes: (archetypes) => {
        set({ 
          archetypes, 
          lastUpdated: Date.now(),
          archetypesLoaded: true
        });
      },
      
      setSkills: (skills) => {
        set({ 
          skills, 
          lastUpdated: Date.now(),
          skillsLoaded: true
        });
      },
      
      setCharacterNames: (characterNames) => {
        set({ 
          characterNames, 
          lastUpdated: Date.now(),
          characterNamesLoaded: true
        });
      },
      
      setHeritagesLoaded: (loaded) => set({ heritagesLoaded: loaded }),
      setCulturesLoaded: (loaded) => set({ culturesLoaded: loaded }),
      setArchetypesLoaded: (loaded) => set({ archetypesLoaded: loaded }),
      setSkillsLoaded: (loaded) => set({ skillsLoaded: loaded }),
      setCharacterNamesLoaded: (loaded) => set({ characterNamesLoaded: loaded }),
      
      clearCache: () => {
        set({
          heritages: [],
          cultures: [],
          archetypes: [],
          skills: [],
          characterNames: [],
          lastUpdated: 0,
          isLoaded: false,
          heritagesLoaded: false,
          culturesLoaded: false,
          archetypesLoaded: false,
          skillsLoaded: false,
          characterNamesLoaded: false,
        });
      },
      
      isDataFresh: () => {
        const now = Date.now();
        const lastUpdated = get().lastUpdated;
        return now - lastUpdated < CACHE_DURATION;
      },
    }),
    {
      name: 'character-reference-store',
      version: 1,
      // Only persist the data, not the loading states
      partialize: (state) => ({
        heritages: state.heritages,
        cultures: state.cultures,
        archetypes: state.archetypes,
        skills: state.skills,
        characterNames: state.characterNames,
        lastUpdated: state.lastUpdated,
        isLoaded: state.isLoaded,
      }),
    }
  )
);

// Hook for easy access to frequently used computed values
export const useCharacterReferenceData = () => {
  const store = useCharacterReferenceStore();
  
  return {
    ...store,
    allDataLoaded: store.heritagesLoaded && store.culturesLoaded && store.archetypesLoaded && store.skillsLoaded,
    basicDataLoaded: store.heritagesLoaded && store.culturesLoaded && store.archetypesLoaded,
  };
};
