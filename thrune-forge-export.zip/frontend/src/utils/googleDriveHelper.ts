// ui/src/utils/googleDriveHelper.ts
// Lines 1-35 (Complete new file)

/**
 * Converts a Google Drive share link to a direct image URL
 * @param url - Google Drive share URL or file ID
 * @returns Direct image URL that can be used in <img> src
 */
export const convertGoogleDriveUrl = (url: string): string | null => {
  // Extract file ID from various Google Drive URL formats
  const patterns = [
    /\/file\/d\/([a-zA-Z0-9_-]+)/,           // /file/d/FILE_ID/view
    /id=([a-zA-Z0-9_-]+)/,                   // ?id=FILE_ID
    /^([a-zA-Z0-9_-]{25,})$/,                // Just the ID
  ];

  let fileId: string | null = null;

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      fileId = match[1];
      break;
    }
  }

  if (!fileId) {
    return null;
  }

  // Return direct image URL
  return `https://drive.google.com/uc?export=view&id=${fileId}`;
};

/**
 * Extract folder ID from Google Drive folder URL
 */
export const extractFolderId = (url: string): string | null => {
  const patterns = [
    /\/folders\/([a-zA-Z0-9_-]+)/,           // /folders/FOLDER_ID
    /^([a-zA-Z0-9_-]{25,})$/,                // Just the ID
  ];

  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      return match[1];
    }
  }

  return null;
};

/**
 * Determine if URL is a folder or file
 */
export const isGoogleDriveFolder = (url: string): boolean => {
  return url.includes('/folders/') || url.includes('drive/folders');
};

/**
 * Validates if a string is a valid Google Drive URL or file ID
 */
export const isValidGoogleDriveUrl = (url: string): boolean => {
  return convertGoogleDriveUrl(url) !== null;
};