import { SkillResponse, ArchetypeResponse, HeritageResponse } from 'types';
import { SkillWithState, calculateSkillXPCost } from './skillLogic';

export interface CharacterData {
  name: string;
  heritage_id: string;
  culture_id: string;
  archetype_id: string;
  secondary_archetype_id?: string;
  tertiary_archetype_id?: string;
  body: number;
  stamina: number;
  selected_skills: Record<string, number>;
}

// Helper type to handle both CharacterData and CharacterDetail
type CharacterForXPCalculation = {
  body: number;
  stamina: number;
  selected_skills: Record<string, number>;
};

// Type guard to ensure we have the required properties
const isValidCharacterData = (character: any): character is CharacterForXPCalculation => {
  return character && 
    typeof character.body === 'number' && 
    typeof character.stamina === 'number' && 
    character.selected_skills && 
    typeof character.selected_skills === 'object';
};

/**
 * Calculate XP cost for Body or Stamina increases using tiered system
 * Tier 1 (1-20): 1 XP each
 * Tier 2 (21-40): 2 XP each
 * Tier 3 (41-60): 3 XP each
 * Pattern: Tier N = Points ((N-1)*20+1) to (N*20) = N XP each
 * CAPS AT 10 XP per point for stats above 200
 * Heritage base values cost 0 XP
 */
export const calculateBodyStaminaXPCost = (current: number, target: number, heritageBase: number): number => {
  if (target <= current) return 0;
  
  let totalCost = 0;
  
  // Calculate cost for each point using absolute stat values for tier determination
  for (let absoluteValue = current + 1; absoluteValue <= target; absoluteValue++) {
    // Only charge XP for points above heritage base
    if (absoluteValue > heritageBase) {
      // Determine tier based on absolute stat value (not heritage-relative)
      // Tier 1 (1-20): 1 XP, Tier 2 (21-40): 2 XP, etc.
      // Caps at Tier 10 (10 XP per point) for stats 181+
      const tier = Math.min(Math.floor((absoluteValue - 1) / 20) + 1, 10);
      totalCost += tier;
    }
  }
  
  return totalCost;
};

/**
 * Calculate total XP spent on skills
 */
export const calculateSkillsXPCost = (
  selectedSkills: Record<string, number> | undefined | null,
  allSkills: SkillResponse[],
  archetype: ArchetypeResponse | null,
  heritage: HeritageResponse | null,
  secondaryArchetype?: ArchetypeResponse | null,
  tertiaryArchetype?: ArchetypeResponse | null
): number => {
  // Add null safety checks
  if (!selectedSkills || !allSkills) {
    return 0;
  }

  let totalCost = 0;
  
  for (const [skillId, purchases] of Object.entries(selectedSkills)) {
    if (!skillId || typeof purchases !== 'number' || purchases <= 0) continue;
    
    const skill = (allSkills || []).find(s => s?.id === skillId);
    if (!skill) continue;
    
    const costPerPurchase = calculateSkillXPCost(skill, archetype, heritage, secondaryArchetype, tertiaryArchetype);
    totalCost += costPerPurchase * purchases;
  }
  
  return totalCost;
};

/**
 * Calculate XP cost for purchasing additional archetypes
 * Secondary and Tertiary archetypes each cost 50 XP
 */
export const calculateArchetypeXPCost = (
  secondaryArchetypeId?: string,
  tertiaryArchetypeId?: string
): number => {
  let archetypeXP = 0;
  if (secondaryArchetypeId && secondaryArchetypeId.trim() !== '') archetypeXP += 50;
  if (tertiaryArchetypeId && tertiaryArchetypeId.trim() !== '') archetypeXP += 50;
  return archetypeXP;
};

/**
 * Calculate total XP spent across all character aspects
 */
export const calculateTotalXPSpent = (
  characterData: CharacterData | any, // Accept both types
  allSkills: SkillResponse[],
  archetype: ArchetypeResponse | null,
  heritage: HeritageResponse | null,
  secondaryArchetype?: ArchetypeResponse | null,
  tertiaryArchetype?: ArchetypeResponse | null
): { bodyXP: number; staminaXP: number; skillsXP: number; archetypeXP: number; totalXP: number } => {
  // Validate input data
  if (!isValidCharacterData(characterData)) {
    return { bodyXP: 0, staminaXP: 0, skillsXP: 0, archetypeXP: 0, totalXP: 0 };
  }

  // Get heritage base values or default to 10
  const baseBody = heritage?.base_body || 10;
  const baseStamina = heritage?.base_stamina || 10;

  // Calculate XP costs using heritage base values
  const bodyXP = calculateBodyStaminaXPCost(baseBody, characterData.body, baseBody);
  const staminaXP = calculateBodyStaminaXPCost(baseStamina, characterData.stamina, baseStamina);
  const skillsXP = calculateSkillsXPCost(characterData.selected_skills, allSkills, archetype, heritage, secondaryArchetype, tertiaryArchetype);
  const archetypeXP = calculateArchetypeXPCost(
    characterData.secondary_archetype_id,
    characterData.tertiary_archetype_id
  );
  
  return {
    bodyXP,
    staminaXP,
    skillsXP,
    archetypeXP,
    totalXP: bodyXP + staminaXP + skillsXP + archetypeXP
  };
};

/**
 * Check if character has enough XP for current selections
 */
export const validateXPBudget = (
  characterData: CharacterData,
  allSkills: SkillResponse[],
  archetype: ArchetypeResponse | null,
  heritage: HeritageResponse | null,
  secondaryArchetype?: ArchetypeResponse | null,
  tertiaryArchetype?: ArchetypeResponse | null,
  maxXP: number = 25
): { isValid: boolean; totalSpent: number; remaining: number } => {
  const { totalXP } = calculateTotalXPSpent(characterData, allSkills, archetype, heritage, secondaryArchetype, tertiaryArchetype);
  
  return {
    isValid: totalXP <= maxXP,
    totalSpent: totalXP,
    remaining: maxXP - totalXP
  };
};
