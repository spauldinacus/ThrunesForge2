import { SkillResponse } from 'types';

export interface CharacterData {
  id?: string;
  player_profile_id?: string;
  name: string;
  heritage_id: string;
  culture_id: string;
  archetype_id: string;
  secondary_archetype_id?: string;
  tertiary_archetype_id?: string;
  body: number;
  stamina: number;
  selected_skills: Record<string, number>;
  corruption?: number;
  deaths?: number;
  status?: string;
  xp_total?: number;
}

export interface SkillWithState extends SkillResponse {
  xp_cost?: number;
  is_primary?: boolean;
  is_secondary?: boolean;
  is_locked?: boolean;
  missing_prerequisites?: string[];
}

export type SkillSortMode = 'category' | 'alphabetical';
