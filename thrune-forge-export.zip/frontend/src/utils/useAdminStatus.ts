import { useEffect } from 'react';
import { useUser } from '@stackframe/react';
import { useProfileStatusStore } from 'utils/profileStatusStore';

interface UseAdminStatusReturn {
  isAdmin: boolean;
  adminStatusLoading: boolean;
  hasProfile: boolean;
  refetchAdminStatus: () => Promise<void>;
}

export function useAdminStatus(): UseAdminStatusReturn {
  const user = useUser();
  const {
    isAdmin,
    hasProfile,
    adminStatusLoading,
    fetchProfileStatus,
    refetchProfileStatus,
    clearProfileStatus
  } = useProfileStatusStore();

  // Fetch profile status when user changes
  useEffect(() => {
    if (user) {
      fetchProfileStatus(user.id);
    } else {
      clearProfileStatus();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  return {
    isAdmin,
    adminStatusLoading,
    hasProfile,
    refetchAdminStatus: refetchProfileStatus
  };
}

// Keep the legacy cache clearing function for backwards compatibility
// but make it clear the new store instead
export function clearAdminStatusCache() {
  useProfileStatusStore.getState().clearProfileStatus();
}
