import { create } from 'zustand';
import { devtools } from 'zustand/middleware';
import { apiClient } from 'app';

interface AdminStatusResponse {
  is_admin: boolean;
  has_profile: boolean;
  user_id: string;
}

interface ProfileStatusState {
  // Core state
  isAdmin: boolean;
  hasProfile: boolean;
  adminStatusLoading: boolean;
  lastFetchTime: number;
  
  // Actions
  fetchProfileStatus: (userId?: string) => Promise<void>;
  updateProfileStatus: (hasProfile: boolean, isAdmin?: boolean) => void;
  clearProfileStatus: () => void;
  refetchProfileStatus: () => Promise<void>;
}

const INITIAL_STATE = {
  isAdmin: false,
  hasProfile: false,
  adminStatusLoading: false,
  lastFetchTime: 0,
};

export const useProfileStatusStore = create<ProfileStatusState>()(
  devtools(
    (set, get) => ({
      // Initial state
      ...INITIAL_STATE,
      
      // Fetch profile status from API
      fetchProfileStatus: async (userId?: string) => {
        const state = get();
        const now = Date.now();
        
        // Prevent concurrent requests
        if (state.adminStatusLoading) {
          console.log('Profile status fetch already in progress, skipping');
          return;
        }
        
        try {
            set({ adminStatusLoading: true });
          
          const response = await apiClient.get_current_user_info();
          const data: AdminStatusResponse = await response.json();
          
          set({
            isAdmin: data.is_admin || false,
            hasProfile: data.has_profile || false,
            adminStatusLoading: false,
            lastFetchTime: now,
          });
        } catch (error) {
          console.error('Failed to fetch profile status:', error);
          set({
            isAdmin: false,
            hasProfile: false,
            adminStatusLoading: false,
            lastFetchTime: now,
          });
        }
      },
      
      // Update profile status (for immediate state sync after profile creation)
      updateProfileStatus: (hasProfile: boolean, isAdmin?: boolean) => {
        const state = get();
        set({
          hasProfile,
          isAdmin: isAdmin !== undefined ? isAdmin : state.isAdmin,
          lastFetchTime: Date.now(), // Update timestamp since we have fresh data
        });
      },
      
      // Clear profile status (for logout)
      clearProfileStatus: () => {
        set(INITIAL_STATE);
      },
              
      // Refetch profile status (force refresh)
      refetchProfileStatus: async () => {
        await get().fetchProfileStatus();
      },
        
    }),
    {
      name: 'profile-status-store',
    }
  )
);

// Export convenience hooks for specific state slices
export const useHasProfile = () => useProfileStatusStore((state) => state.hasProfile);
export const useIsAdmin = () => useProfileStatusStore((state) => state.isAdmin);
export const useProfileStatusLoading = () => useProfileStatusStore((state) => state.adminStatusLoading);
