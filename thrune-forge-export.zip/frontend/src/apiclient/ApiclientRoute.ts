import {
  AcknowledgeReferralData,
  AcknowledgeReferralRequest,
  AddAdminXpTransactionData,
  AddManualRsvpData,
  AddPhotoToGalleryData,
  AdminCharacterUpdate,
  AdminXPTransactionCreate,
  AppApisAdminPlayersUpdatePlayerProfileRequest,
  AppApisPlayersUpdatePlayerProfileRequest,
  ArchetypeCreate,
  ArchetypeUpdate,
  AssignSystemMilestoneData,
  BackfillAuditLogsData,
  BugReportRequest,
  BulkAddPhotosToGalleryData,
  BulkExportCharacterSheetsData,
  BulkExportCharacterSheetsPayload,
  BulkPhotoUploadRequest,
  CalculateXpCostData,
  ChapterCreate,
  ChapterUpdate,
  CharacterCreate,
  CharacterUpdateRequest,
  CheckHealthData,
  CreateArchetypeData,
  CreateCandleTransactionData,
  CreateCandleTransactionRequest,
  CreateChapterData,
  CreateCharacterData,
  CreateCultureData,
  CreateCustomMilestoneData,
  CreateEventData,
  CreateEventRequest,
  CreateGalleryData,
  CreateHeritageData,
  CreateJournalEntryData,
  CreateLoreSubmissionData,
  CreateOrUpdateRsvpData,
  CreatePhotoTagData,
  CreatePhotoTagRequest,
  CreatePlayerProfileData,
  CreatePlayerProfileRequest,
  CreateRSVPRequest,
  CreateRoleData,
  CreateSkillData,
  CreateSystemMilestoneData,
  CreateTestCharacterData,
  CultureCreate,
  CultureUpdate,
  CustomMilestoneCreate,
  CustomMilestoneUpdate,
  DeleteAdminCharacterData,
  DeleteAdminXpTransactionData,
  DeleteArchetypeData,
  DeleteCandleTransactionData,
  DeleteChapterData,
  DeleteCultureData,
  DeleteCustomMilestoneData,
  DeleteEventData,
  DeleteGalleryData,
  DeleteGalleryPhotoData,
  DeleteHeritageData,
  DeleteJournalEntryData,
  DeleteLoreSubmissionData,
  DeleteMyCharacterData,
  DeletePhotoTagData,
  DeletePlayerData,
  DeleteRoleData,
  DeleteSkillData,
  DeleteSystemMilestoneData,
  DeleteTestCharacterData,
  DownloadCompletePackageData,
  FolderPhotosRequest,
  GalleryCreate,
  GalleryUpdate,
  GetAdminCharacterData,
  GetAdminCharacterXpHistoryData,
  GetAdminLoreSubmissionsData,
  GetAllCharactersForTaggingData,
  GetAllMigrationsData,
  GetAllPhotoTagsData,
  GetAnalyticsOverviewData,
  GetArchetypeData,
  GetAuditLogsData,
  GetChapterHealthAnalyticsData,
  GetCharacterBuildsAnalyticsData,
  GetCharacterCustomMilestonesData,
  GetCharacterJournalEntriesData,
  GetCharacterPhotosData,
  GetCharacterSystemMilestonesData,
  GetCultureData,
  GetCurrentUserInfoData,
  GetEventAttendeesData,
  GetEventDetailData,
  GetEventPerformanceAnalyticsData,
  GetExportStatusData,
  GetHeritageData,
  GetMyCandleHistoryData,
  GetMyCharacterData,
  GetMyCharacterNamesData,
  GetMyCharactersForTaggingData,
  GetMyLoreSubmissionsData,
  GetMyPermissionsData,
  GetMyPlayerProfileData,
  GetMyRsvpsData,
  GetPhotoTagsData,
  GetPlayerCandleHistoryData,
  GetPlayerCharacterEventsData,
  GetPlayerDetailData,
  GetPlayerEngagementAnalyticsData,
  GetPlayersByChapterData,
  GetReassignmentHistoryData,
  GetReferralStatsData,
  GetSharedJournalsData,
  GetSharedMilestonesData,
  GetSkillData,
  GetXpEconomyAnalyticsData,
  HeritageCreate,
  HeritageUpdate,
  JournalEntryCreate,
  JournalEntryUpdate,
  ListAdminEventsData,
  ListAllCharactersData,
  ListAllCharactersForReassignmentData,
  ListAllCharactersWithPhotosData,
  ListAllPlayersData,
  ListAllRolesData,
  ListArchetypesData,
  ListChaptersData,
  ListCharactersForAssignmentData,
  ListCulturesData,
  ListEventsData,
  ListFolderPhotosData,
  ListGalleriesData,
  ListGalleryPhotosData,
  ListHeritagesData,
  ListMyCharactersData,
  ListMyTestCharactersData,
  ListPermissionsData,
  ListPlayerCharactersData,
  ListPlayersForReferralData,
  ListPublicChaptersData,
  ListPublicGalleriesData,
  ListPublicGalleryPhotosData,
  ListPublicPhotosData,
  ListReferralsData,
  ListScopedChaptersData,
  ListScopedCharactersData,
  ListScopedEventsData,
  ListSkillsData,
  ListSystemMilestonesData,
  LoreSubmissionCreate,
  LoreSubmissionUpdate,
  ManualRSVPRequest,
  MarkSystemMilestoneCompleteData,
  MilestoneAssignmentRequest,
  OptimizeBuildData,
  OptimizeBuildRequest,
  PhotoCreate,
  PhotoReorderRequest,
  PhotoUpdate,
  ReassignCharacterData,
  ReassignmentRequest,
  RebuildCharacterData,
  ReorderGalleryPhotosData,
  RoleCreate,
  RoleUpdate,
  SkillCreate,
  SkillUpdate,
  StackUserWebhookData,
  SubmitBugReportData,
  SyncPlayerProfilesFromProductionData,
  SyncPlayerProfilesRequest,
  SystemMilestoneCreate,
  SystemMilestoneUpdate,
  TestCharacterCreate,
  TestCharacterUpdate,
  UpdateAdminCharacterData,
  UpdateArchetypeData,
  UpdateAttendanceRequest,
  UpdateAttendanceStatusData,
  UpdateCandleTransactionData,
  UpdateCandleTransactionRequest,
  UpdateChapterData,
  UpdateCultureData,
  UpdateCustomMilestoneData,
  UpdateEventData,
  UpdateEventRequest,
  UpdateGalleryData,
  UpdateGalleryPhotoData,
  UpdateHeritageData,
  UpdateJournalEntryData,
  UpdateLoreSubmissionData,
  UpdateMyCharacterData,
  UpdateMyPlayerProfileData,
  UpdatePlayerNumberData,
  UpdatePlayerNumberRequest,
  UpdatePlayerProfileData,
  UpdatePlayerRolesData,
  UpdatePlayerRolesRequest,
  UpdateRoleData,
  UpdateSkillData,
  UpdateSystemMilestoneData,
  UpdateSystemMilestoneNotesData,
  UpdateTestCharacterData,
  User,
} from "./data-contracts";

export namespace Apiclient {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description Create a new lore submission (admin only).
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name create_lore_submission
   * @summary Create Lore Submission
   * @request POST:/routes/lore-submissions/create
   */
  export namespace create_lore_submission {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = LoreSubmissionCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateLoreSubmissionData;
  }

  /**
   * @description Get all lore submissions with optional filters (admin only).
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name get_admin_lore_submissions
   * @summary Get Admin Lore Submissions
   * @request GET:/routes/lore-submissions/admin
   */
  export namespace get_admin_lore_submissions {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Chapter Id */
      chapter_id?: string | null;
      /** Event Id */
      event_id?: string | null;
      /** Character Id */
      character_id?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminLoreSubmissionsData;
  }

  /**
   * @description Get lore submissions for characters owned by the authenticated player.
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name get_my_lore_submissions
   * @summary Get My Lore Submissions
   * @request GET:/routes/lore-submissions/my-submissions
   */
  export namespace get_my_lore_submissions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyLoreSubmissionsData;
  }

  /**
   * @description Update an existing lore submission (admin only).
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name update_lore_submission
   * @summary Update Lore Submission
   * @request PUT:/routes/lore-submissions/{submission_id}
   */
  export namespace update_lore_submission {
    export type RequestParams = {
      /** Submission Id */
      submissionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = LoreSubmissionUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateLoreSubmissionData;
  }

  /**
   * @description Delete a lore submission (admin only).
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name delete_lore_submission
   * @summary Delete Lore Submission
   * @request DELETE:/routes/lore-submissions/{submission_id}
   */
  export namespace delete_lore_submission {
    export type RequestParams = {
      /** Submission Id */
      submissionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteLoreSubmissionData;
  }

  /**
   * @description Resets a character to a clean state for rebuilding: - Removes all skills - Removes secondary/tertiary archetypes - Resets body/stamina to heritage base - Resets XP spent
   * @tags dbtn/module:admin_rebuild_character, dbtn/hasAuth
   * @name rebuild_character
   * @summary Rebuild Character
   * @request POST:/routes/admin/characters/{character_id}/rebuild
   */
  export namespace rebuild_character {
    export type RequestParams = {
      /**
       * Character Id
       * @format uuid
       */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = RebuildCharacterData;
  }

  /**
   * @description Get audit logs with filtering
   * @tags dbtn/module:admin_audit_logs, dbtn/hasAuth
   * @name get_audit_logs
   * @summary Get Audit Logs
   * @request GET:/routes/admin/audit-logs
   */
  export namespace get_audit_logs {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Limit
       * @default 50
       */
      limit?: number;
      /**
       * Offset
       * @default 0
       */
      offset?: number;
      /** Action Type */
      action_type?: string | null;
      /** User Id */
      user_id?: string | null;
      /** Start Date */
      start_date?: string | null;
      /** End Date */
      end_date?: string | null;
      /** Action */
      action?: string | null;
      /** Entity Type */
      entity_type?: string | null;
      /**
       * Sort By
       * @default "created_at"
       */
      sort_by?: string;
      /**
       * Sort Direction
       * @default "desc"
       */
      sort_direction?: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAuditLogsData;
  }

  /**
   * @description Backfill audit logs from existing transactions
   * @tags dbtn/module:admin_audit_logs, dbtn/hasAuth
   * @name backfill_audit_logs
   * @summary Backfill Audit Logs
   * @request POST:/routes/admin/audit-logs/backfill
   */
  export namespace backfill_audit_logs {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = BackfillAuditLogsData;
  }

  /**
   * @description Get export readiness status
   * @tags dbtn/module:export_system
   * @name get_export_status
   * @summary Get Export Status
   * @request GET:/routes/export/status
   */
  export namespace get_export_status {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetExportStatusData;
  }

  /**
   * @description Extract all migrations from database
   * @tags dbtn/module:export_system
   * @name get_all_migrations
   * @summary Get All Migrations
   * @request GET:/routes/export/migrations
   */
  export namespace get_all_migrations {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllMigrationsData;
  }

  /**
   * @description Download complete app package as ZIP
   * @tags dbtn/module:export_system
   * @name download_complete_package
   * @summary Download Complete Package
   * @request GET:/routes/export/download-package
   */
  export namespace download_complete_package {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DownloadCompletePackageData;
  }

  /**
   * @description Get all system milestones with progress for a character
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_system_milestones
   * @summary Get Character System Milestones
   * @request GET:/routes/player-milestones/character/{character_id}/system-milestones
   */
  export namespace get_character_system_milestones {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCharacterSystemMilestonesData;
  }

  /**
   * @description Update notes and sharing settings for a system milestone
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_system_milestone_notes
   * @summary Update System Milestone Notes
   * @request POST:/routes/player-milestones/character/{character_id}/system-milestones/{system_milestone_id}/notes
   */
  export namespace update_system_milestone_notes {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
      /** System Milestone Id */
      systemMilestoneId: string;
    };
    export type RequestQuery = {
      /** Notes */
      notes?: string | null;
      /**
       * Shared With Staff
       * @default false
       */
      shared_with_staff?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSystemMilestoneNotesData;
  }

  /**
   * @description Mark an 'other' type system milestone as completed
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name mark_system_milestone_complete
   * @summary Mark System Milestone Complete
   * @request POST:/routes/player-milestones/character/{character_id}/system-milestones/{system_milestone_id}/mark-complete
   */
  export namespace mark_system_milestone_complete {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
      /** System Milestone Id */
      systemMilestoneId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = MarkSystemMilestoneCompleteData;
  }

  /**
   * @description Get all custom milestones for a character
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_custom_milestones
   * @summary Get Character Custom Milestones
   * @request GET:/routes/player-milestones/character/{character_id}/custom-milestones
   */
  export namespace get_character_custom_milestones {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCharacterCustomMilestonesData;
  }

  /**
   * @description Create a new custom milestone
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name create_custom_milestone
   * @summary Create Custom Milestone
   * @request POST:/routes/player-milestones/custom-milestones
   */
  export namespace create_custom_milestone {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CustomMilestoneCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCustomMilestoneData;
  }

  /**
   * @description Update a custom milestone
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_custom_milestone
   * @summary Update Custom Milestone
   * @request PUT:/routes/player-milestones/custom-milestones/{milestone_id}
   */
  export namespace update_custom_milestone {
    export type RequestParams = {
      /** Milestone Id */
      milestoneId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = CustomMilestoneUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCustomMilestoneData;
  }

  /**
   * @description Delete a custom milestone
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name delete_custom_milestone
   * @summary Delete Custom Milestone
   * @request DELETE:/routes/player-milestones/custom-milestones/{milestone_id}
   */
  export namespace delete_custom_milestone {
    export type RequestParams = {
      /** Milestone Id */
      milestoneId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCustomMilestoneData;
  }

  /**
   * @description Get all journal entries for a character
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_journal_entries
   * @summary Get Character Journal Entries
   * @request GET:/routes/player-milestones/character/{character_id}/journal
   */
  export namespace get_character_journal_entries {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCharacterJournalEntriesData;
  }

  /**
   * @description Create a new journal entry
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name create_journal_entry
   * @summary Create Journal Entry
   * @request POST:/routes/player-milestones/journal
   */
  export namespace create_journal_entry {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = JournalEntryCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateJournalEntryData;
  }

  /**
   * @description Update a journal entry
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_journal_entry
   * @summary Update Journal Entry
   * @request PUT:/routes/player-milestones/journal/{entry_id}
   */
  export namespace update_journal_entry {
    export type RequestParams = {
      /** Entry Id */
      entryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = JournalEntryUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateJournalEntryData;
  }

  /**
   * @description Delete a journal entry
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name delete_journal_entry
   * @summary Delete Journal Entry
   * @request DELETE:/routes/player-milestones/journal/{entry_id}
   */
  export namespace delete_journal_entry {
    export type RequestParams = {
      /** Entry Id */
      entryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteJournalEntryData;
  }

  /**
   * @description Get all test characters for the authenticated user (max 3).
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name list_my_test_characters
   * @summary List My Test Characters
   * @request GET:/routes/test-characters/my-test-characters
   */
  export namespace list_my_test_characters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListMyTestCharactersData;
  }

  /**
   * @description Create a new test character. Limited to 3 per user.
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name create_test_character
   * @summary Create Test Character
   * @request POST:/routes/test-characters/create
   */
  export namespace create_test_character {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = TestCharacterCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateTestCharacterData;
  }

  /**
   * @description Update a test character. Recalculates XP cost.
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name update_test_character
   * @summary Update Test Character
   * @request PUT:/routes/test-characters/{test_character_id}
   */
  export namespace update_test_character {
    export type RequestParams = {
      /** Test Character Id */
      testCharacterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = TestCharacterUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateTestCharacterData;
  }

  /**
   * @description Delete a test character.
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name delete_test_character
   * @summary Delete Test Character
   * @request DELETE:/routes/test-characters/{test_character_id}
   */
  export namespace delete_test_character {
    export type RequestParams = {
      /** Test Character Id */
      testCharacterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteTestCharacterData;
  }

  /**
   * @description Get all events with admin data, filtered by user's chapter permissions
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_events
   * @summary List Scoped Events
   * @request GET:/routes/admin-scoped/events
   */
  export namespace list_scoped_events {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListScopedEventsData;
  }

  /**
   * @description Get all characters for admin management, filtered by user's chapter permissions
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_characters
   * @summary List Scoped Characters
   * @request GET:/routes/admin-scoped/characters
   */
  export namespace list_scoped_characters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListScopedCharactersData;
  }

  /**
   * @description Get all chapters filtered by user's chapter permissions
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_chapters
   * @summary List Scoped Chapters
   * @request GET:/routes/admin-scoped/chapters
   */
  export namespace list_scoped_chapters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListScopedChaptersData;
  }

  /**
   * @description List all galleries with photo counts (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_galleries
   * @summary List Galleries
   * @request GET:/routes/admin-galleries/galleries
   */
  export namespace list_galleries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListGalleriesData;
  }

  /**
   * @description Create a new photo gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name create_gallery
   * @summary Create Gallery
   * @request POST:/routes/admin-galleries/galleries
   */
  export namespace create_gallery {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = GalleryCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateGalleryData;
  }

  /**
   * @description Update a gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name update_gallery
   * @summary Update Gallery
   * @request PUT:/routes/admin-galleries/galleries/{gallery_id}
   */
  export namespace update_gallery {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = GalleryUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateGalleryData;
  }

  /**
   * @description Delete a gallery and all its photos (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name delete_gallery
   * @summary Delete Gallery
   * @request DELETE:/routes/admin-galleries/galleries/{gallery_id}
   */
  export namespace delete_gallery {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteGalleryData;
  }

  /**
   * @description Get all galleries with photo counts (public endpoint for PhotoGallery page)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_galleries
   * @summary List Public Galleries
   * @request GET:/routes/admin-galleries/public/galleries
   */
  export namespace list_public_galleries {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPublicGalleriesData;
  }

  /**
   * @description Get all photos from a specific gallery with their tags (public endpoint)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_gallery_photos
   * @summary List Public Gallery Photos
   * @request GET:/routes/admin-galleries/public/galleries/{gallery_id}/photos
   */
  export namespace list_public_gallery_photos {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPublicGalleryPhotosData;
  }

  /**
   * @description Get all photos from all galleries (public endpoint for PhotoGallery page)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_photos
   * @summary List Public Photos
   * @request GET:/routes/admin-galleries/public/photos
   */
  export namespace list_public_photos {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPublicPhotosData;
  }

  /**
   * @description Add a photo to a gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name add_photo_to_gallery
   * @summary Add Photo To Gallery
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos
   */
  export namespace add_photo_to_gallery {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = PhotoCreate;
    export type RequestHeaders = {};
    export type ResponseBody = AddPhotoToGalleryData;
  }

  /**
   * @description List all photos in a gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_gallery_photos
   * @summary List Gallery Photos
   * @request GET:/routes/admin-galleries/galleries/{gallery_id}/photos
   */
  export namespace list_gallery_photos {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListGalleryPhotosData;
  }

  /**
   * @description Bulk add photos to a gallery with duplicate detection (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name bulk_add_photos_to_gallery
   * @summary Bulk Add Photos To Gallery
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos/bulk
   */
  export namespace bulk_add_photos_to_gallery {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = BulkPhotoUploadRequest;
    export type RequestHeaders = {};
    export type ResponseBody = BulkAddPhotosToGalleryData;
  }

  /**
   * @description Update a photo in gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name update_gallery_photo
   * @summary Update Gallery Photo
   * @request PUT:/routes/admin-galleries/galleries/{gallery_id}/photos/{photo_id}
   */
  export namespace update_gallery_photo {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
      /** Photo Id */
      photoId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = PhotoUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateGalleryPhotoData;
  }

  /**
   * @description Delete a photo from gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name delete_gallery_photo
   * @summary Delete Gallery Photo
   * @request DELETE:/routes/admin-galleries/galleries/{gallery_id}/photos/{photo_id}
   */
  export namespace delete_gallery_photo {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
      /** Photo Id */
      photoId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteGalleryPhotoData;
  }

  /**
   * @description Reorder photos in a gallery (admin only)
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name reorder_gallery_photos
   * @summary Reorder Gallery Photos
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos/reorder
   */
  export namespace reorder_gallery_photos {
    export type RequestParams = {
      /** Gallery Id */
      galleryId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = PhotoReorderRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReorderGalleryPhotosData;
  }

  /**
   * @description Update the current user's player profile
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name update_my_player_profile
   * @summary Update My Player Profile
   * @request PUT:/routes/players/profile
   */
  export namespace update_my_player_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AppApisPlayersUpdatePlayerProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateMyPlayerProfileData;
  }

  /**
   * @description Create a new player profile for the authenticated user
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name create_player_profile
   * @summary Create Player Profile
   * @request POST:/routes/players/profile
   */
  export namespace create_player_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreatePlayerProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreatePlayerProfileData;
  }

  /**
   * @description Get the current user's player profile
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_player_profile
   * @summary Get My Player Profile
   * @request GET:/routes/my-player-profile
   */
  export namespace get_my_player_profile {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyPlayerProfileData;
  }

  /**
   * @description Get the current user's candle transaction history
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_candle_history
   * @summary Get My Candle History
   * @request GET:/routes/players/candle-history
   */
  export namespace get_my_candle_history {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyCandleHistoryData;
  }

  /**
   * @description Update a player's number (admin only)
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name update_player_number
   * @summary Update Player Number
   * @request PUT:/routes/admin/players/{player_id}/player-number
   */
  export namespace update_player_number {
    export type RequestParams = {
      /**
       * Player Id
       * @format uuid
       */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdatePlayerNumberRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdatePlayerNumberData;
  }

  /**
   * @description Debug endpoint to check current user ID and admin status
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_current_user_info
   * @summary Get Current User Info
   * @request GET:/routes/debug/user-info
   */
  export namespace get_current_user_info {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCurrentUserInfoData;
  }

  /**
   * @description Get current user's roles and permissions
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_permissions
   * @summary Get My Permissions
   * @request GET:/routes/my/permissions
   */
  export namespace get_my_permissions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyPermissionsData;
  }

  /**
   * @description List all referrals with optional filtering (admin only)
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name list_referrals
   * @summary List Referrals
   * @request GET:/routes/referrals/list
   */
  export namespace list_referrals {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Filter Type
       * @default "all"
       */
      filter_type?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListReferralsData;
  }

  /**
   * @description Acknowledge and lock a referral (admin only)
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name acknowledge_referral
   * @summary Acknowledge Referral
   * @request POST:/routes/referrals/acknowledge
   */
  export namespace acknowledge_referral {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = AcknowledgeReferralRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AcknowledgeReferralData;
  }

  /**
   * @description Get referral statistics and top referrers (admin only)
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name get_referral_stats
   * @summary Get Referral Stats
   * @request GET:/routes/referrals/stats
   */
  export namespace get_referral_stats {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetReferralStatsData;
  }

  /**
   * @description Get all players grouped by chapter for referral selection
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name list_players_for_referral
   * @summary List Players For Referral
   * @request GET:/routes/referrals/players-for-referral
   */
  export namespace list_players_for_referral {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPlayersForReferralData;
  }

  /**
   * @description Get all milestones shared with staff (filterable)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name get_shared_milestones
   * @summary Get Shared Milestones
   * @request GET:/routes/admin-milestones/shared-milestones
   */
  export namespace get_shared_milestones {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Chapter Id */
      chapter_id?: string | null;
      /** Character Id */
      character_id?: string | null;
      /** Player Id */
      player_id?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSharedMilestonesData;
  }

  /**
   * @description Get all journal entries shared with staff (filterable)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name get_shared_journals
   * @summary Get Shared Journals
   * @request GET:/routes/admin-milestones/shared-journals
   */
  export namespace get_shared_journals {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Chapter Id */
      chapter_id?: string | null;
      /** Character Id */
      character_id?: string | null;
      /** Player Id */
      player_id?: string | null;
      /** Event Id */
      event_id?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSharedJournalsData;
  }

  /**
   * @description List all system milestone definitions (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name list_system_milestones
   * @summary List System Milestones
   * @request GET:/routes/admin-milestones/system-milestones
   */
  export namespace list_system_milestones {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Include Disabled
       * @default false
       */
      include_disabled?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSystemMilestonesData;
  }

  /**
   * @description Create a new system milestone definition (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name create_system_milestone
   * @summary Create System Milestone
   * @request POST:/routes/admin-milestones/system-milestones
   */
  export namespace create_system_milestone {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SystemMilestoneCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSystemMilestoneData;
  }

  /**
   * @description Update a system milestone definition (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name update_system_milestone
   * @summary Update System Milestone
   * @request PUT:/routes/admin-milestones/system-milestones/{milestone_id}
   */
  export namespace update_system_milestone {
    export type RequestParams = {
      /** Milestone Id */
      milestoneId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SystemMilestoneUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSystemMilestoneData;
  }

  /**
   * @description Delete a system milestone definition (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name delete_system_milestone
   * @summary Delete System Milestone
   * @request DELETE:/routes/admin-milestones/system-milestones/{milestone_id}
   */
  export namespace delete_system_milestone {
    export type RequestParams = {
      /** Milestone Id */
      milestoneId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSystemMilestoneData;
  }

  /**
   * @description List all characters for milestone assignment (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name list_characters_for_assignment
   * @summary List Characters For Assignment
   * @request GET:/routes/admin-milestones/characters
   */
  export namespace list_characters_for_assignment {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCharactersForAssignmentData;
  }

  /**
   * @description Assign a system milestone to a character (admin only)
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name assign_system_milestone
   * @summary Assign System Milestone
   * @request POST:/routes/admin-milestones/assign
   */
  export namespace assign_system_milestone {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = MilestoneAssignmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AssignSystemMilestoneData;
  }

  /**
   * @description List all image files from a Google Drive folder Requires GOOGLE_DRIVE_API_KEY secret
   * @tags dbtn/module:google_drive, dbtn/hasAuth
   * @name list_folder_photos
   * @summary List Folder Photos
   * @request POST:/routes/google-drive/list-folder-photos
   */
  export namespace list_folder_photos {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = FolderPhotosRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ListFolderPhotosData;
  }

  /**
   * @description Calculate XP cost for body/stamina changes.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name calculate_xp_cost
   * @summary Calculate Xp Cost
   * @request POST:/routes/characters/calculate-xp-cost
   */
  export namespace calculate_xp_cost {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Body */
      body: number;
      /** Stamina */
      stamina: number;
      /** Character Id */
      character_id: string;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CalculateXpCostData;
  }

  /**
   * @description Get list of characters for the authenticated user.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name list_my_characters
   * @summary List My Characters
   * @request GET:/routes/characters/my-characters
   */
  export namespace list_my_characters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListMyCharactersData;
  }

  /**
   * @description Get detailed character information including skills and XP history.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name get_my_character
   * @summary Get My Character
   * @request GET:/routes/characters/my-characters/{character_id}
   */
  export namespace get_my_character {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyCharacterData;
  }

  /**
   * @description Update a character.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name update_my_character
   * @summary Update My Character
   * @request PUT:/routes/characters/my-characters/{character_id}
   */
  export namespace update_my_character {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = CharacterUpdateRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateMyCharacterData;
  }

  /**
   * @description Delete a character.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name delete_my_character
   * @summary Delete My Character
   * @request DELETE:/routes/characters/my-characters/{character_id}
   */
  export namespace delete_my_character {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteMyCharacterData;
  }

  /**
   * @description Create a new character.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name create_character
   * @summary Create Character
   * @request POST:/routes/characters/create
   */
  export namespace create_character {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CharacterCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCharacterData;
  }

  /**
   * @description Get list of character names for the current player.
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name get_my_character_names
   * @summary Get My Character Names
   * @request GET:/routes/characters/my-character-names
   */
  export namespace get_my_character_names {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyCharacterNamesData;
  }

  /**
   * @description Get all characters with heritage, culture, player, chapter, and photo count
   * @tags dbtn/module:face_to_name, dbtn/hasAuth
   * @name list_all_characters_with_photos
   * @summary List All Characters With Photos
   * @request GET:/routes/characters
   */
  export namespace list_all_characters_with_photos {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllCharactersWithPhotosData;
  }

  /**
   * @description Get all photos where a character is tagged
   * @tags dbtn/module:face_to_name, dbtn/hasAuth
   * @name get_character_photos
   * @summary Get Character Photos
   * @request GET:/routes/characters/{character_id}/photos
   */
  export namespace get_character_photos {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCharacterPhotosData;
  }

  /**
   * @description List all chapters (public endpoint)
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name list_public_chapters
   * @summary List Public Chapters
   * @request GET:/routes/chapters
   */
  export namespace list_public_chapters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPublicChaptersData;
  }

  /**
   * @description List events with optional filtering.
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name list_events
   * @summary List Events
   * @request GET:/routes/events
   */
  export namespace list_events {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Chapter Id */
      chapter_id?: string | null;
      /** Status */
      status?: "scheduled" | "completed" | "cancelled" | null;
      /** From Date */
      from_date?: string | null;
      /** To Date */
      to_date?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListEventsData;
  }

  /**
   * @description Get detailed information about a specific event.
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name get_event_detail
   * @summary Get Event Detail
   * @request GET:/routes/events/{event_id}
   */
  export namespace get_event_detail {
    export type RequestParams = {
      /**
       * Event Id
       * @format uuid
       */
      eventId: string;
    };
    export type RequestQuery = {
      /** User */
      user?: User | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEventDetailData;
  }

  /**
   * @description Create or update user's RSVP for an event with enhanced features.
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name create_or_update_rsvp
   * @summary Create Or Update Rsvp
   * @request POST:/routes/events/{event_id}/rsvp
   */
  export namespace create_or_update_rsvp {
    export type RequestParams = {
      /**
       * Event Id
       * @format uuid
       */
      eventId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = CreateRSVPRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateOrUpdateRsvpData;
  }

  /**
   * @description Get all of the current user's RSVPs with event details.
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name get_my_rsvps
   * @summary Get My Rsvps
   * @request GET:/routes/my/rsvps
   */
  export namespace get_my_rsvps {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyRsvpsData;
  }

  /**
   * @description Sync player_profiles data from production to development. This endpoint receives complete player_profiles table data from production and updates the development database to maintain OAuth consistency. Only available in development environment and requires admin permissions.
   * @tags dbtn/module:dev_sync, dbtn/hasAuth
   * @name sync_player_profiles_from_production
   * @summary Sync Player Profiles From Production
   * @request POST:/routes/dev/sync-player-profiles
   */
  export namespace sync_player_profiles_from_production {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SyncPlayerProfilesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SyncPlayerProfilesFromProductionData;
  }

  /**
   * @description List all available roles with permissions (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_all_roles
   * @summary List All Roles
   * @request GET:/routes/admin/players/roles
   */
  export namespace list_all_roles {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllRolesData;
  }

  /**
   * @description Create a new role
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name create_role
   * @summary Create Role
   * @request POST:/routes/admin/players/roles
   */
  export namespace create_role {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = RoleCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateRoleData;
  }

  /**
   * @description List all available permissions
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_permissions
   * @summary List Permissions
   * @request GET:/routes/admin/players/permissions
   */
  export namespace list_permissions {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPermissionsData;
  }

  /**
   * @description Update an existing role
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_role
   * @summary Update Role
   * @request PUT:/routes/admin/players/roles/{role_id}
   */
  export namespace update_role {
    export type RequestParams = {
      /** Role Id */
      roleId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = RoleUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateRoleData;
  }

  /**
   * @description Delete a role (only if not assigned to any users and not a system role)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_role
   * @summary Delete Role
   * @request DELETE:/routes/admin/players/roles/{role_id}
   */
  export namespace delete_role {
    export type RequestParams = {
      /** Role Id */
      roleId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteRoleData;
  }

  /**
   * @description Get detailed player information for editing (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_detail
   * @summary Get Player Detail
   * @request GET:/routes/admin/players/{player_id}
   */
  export namespace get_player_detail {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPlayerDetailData;
  }

  /**
   * @description Delete a player and all associated data (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_player
   * @summary Delete Player
   * @request DELETE:/routes/admin/players/{player_id}
   */
  export namespace delete_player {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeletePlayerData;
  }

  /**
   * @description List all characters for a specific player (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_player_characters
   * @summary List Player Characters
   * @request GET:/routes/admin/players/{player_id}/characters
   */
  export namespace list_player_characters {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListPlayerCharactersData;
  }

  /**
   * @description List all players with management information (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_all_players
   * @summary List All Players
   * @request GET:/routes/admin/players/
   */
  export namespace list_all_players {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllPlayersData;
  }

  /**
   * @description Update player roles (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_player_roles
   * @summary Update Player Roles
   * @request PUT:/routes/admin/players/{player_id}/roles
   */
  export namespace update_player_roles {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdatePlayerRolesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdatePlayerRolesData;
  }

  /**
   * @description Update player profile information (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_player_profile
   * @summary Update Player Profile
   * @request PUT:/routes/admin/players/{player_id}/profile
   */
  export namespace update_player_profile {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = AppApisAdminPlayersUpdatePlayerProfileRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdatePlayerProfileData;
  }

  /**
   * @description Get candle transaction history for a specific player (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_candle_history
   * @summary Get Player Candle History
   * @request GET:/routes/admin/players/{player_id}/candle-history
   */
  export namespace get_player_candle_history {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPlayerCandleHistoryData;
  }

  /**
   * @description Create a new candle transaction for a player (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name create_candle_transaction
   * @summary Create Candle Transaction
   * @request POST:/routes/admin/players/{player_id}/candles
   */
  export namespace create_candle_transaction {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
    };
    export type RequestQuery = {
      /**
       * Force
       * Force the transaction even if it results in a negative balance
       * @default false
       */
      force?: boolean;
    };
    export type RequestBody = CreateCandleTransactionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCandleTransactionData;
  }

  /**
   * @description Update an existing candle transaction (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_candle_transaction
   * @summary Update Candle Transaction
   * @request PUT:/routes/admin/players/{player_id}/candles/{transaction_id}
   */
  export namespace update_candle_transaction {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
      /** Transaction Id */
      transactionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateCandleTransactionRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCandleTransactionData;
  }

  /**
   * @description Delete a candle transaction (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_candle_transaction
   * @summary Delete Candle Transaction
   * @request DELETE:/routes/admin/players/{player_id}/candles/{transaction_id}
   */
  export namespace delete_candle_transaction {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
      /** Transaction Id */
      transactionId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCandleTransactionData;
  }

  /**
   * @description Get all events a character has RSVP'd to or attended (admin only)
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_character_events
   * @summary Get Player Character Events
   * @request GET:/routes/admin/players/{player_id}/characters/{character_id}/events
   */
  export namespace get_player_character_events {
    export type RequestParams = {
      /** Player Id */
      playerId: string;
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPlayerCharacterEventsData;
  }

  /**
   * @description Tag a character in a photo. Players can only tag their own characters. Admins can tag any character.
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name create_photo_tag
   * @summary Create Photo Tag
   * @request POST:/routes/photo-gallery/tags
   */
  export namespace create_photo_tag {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreatePhotoTagRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreatePhotoTagData;
  }

  /**
   * @description Get all tags for a specific photo
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_photo_tags
   * @summary Get Photo Tags
   * @request GET:/routes/photo-gallery/photos/{photo_id}/tags
   */
  export namespace get_photo_tags {
    export type RequestParams = {
      /** Photo Id */
      photoId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPhotoTagsData;
  }

  /**
   * @description Delete a photo tag. Only the creator or admin can delete.
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name delete_photo_tag
   * @summary Delete Photo Tag
   * @request DELETE:/routes/photo-gallery/tags/{tag_id}
   */
  export namespace delete_photo_tag {
    export type RequestParams = {
      /** Tag Id */
      tagId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeletePhotoTagData;
  }

  /**
   * @description Get all photo tags in one query for efficient loading
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_all_photo_tags
   * @summary Get All Photo Tags
   * @request GET:/routes/photo-gallery/tags/all
   */
  export namespace get_all_photo_tags {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllPhotoTagsData;
  }

  /**
   * @description Get user's characters for tagging dropdown
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_my_characters_for_tagging
   * @summary Get My Characters For Tagging
   * @request GET:/routes/photo-gallery/my-characters
   */
  export namespace get_my_characters_for_tagging {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetMyCharactersForTaggingData;
  }

  /**
   * @description Get all characters for admin tagging (admin only)
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_all_characters_for_tagging
   * @summary Get All Characters For Tagging
   * @request GET:/routes/photo-gallery/all-characters
   */
  export namespace get_all_characters_for_tagging {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAllCharactersForTaggingData;
  }

  /**
   * @description List all heritages with their secondary skills
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name list_heritages
   * @summary List Heritages
   * @request GET:/routes/heritages/
   */
  export namespace list_heritages {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListHeritagesData;
  }

  /**
   * @description Create a new heritage with secondary skills
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name create_heritage
   * @summary Create Heritage
   * @request POST:/routes/heritages/
   */
  export namespace create_heritage {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = HeritageCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateHeritageData;
  }

  /**
   * @description Get a specific heritage with its secondary skills
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name get_heritage
   * @summary Get Heritage
   * @request GET:/routes/heritages/{heritage_id}
   */
  export namespace get_heritage {
    export type RequestParams = {
      /** Heritage Id */
      heritageId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetHeritageData;
  }

  /**
   * @description Update a heritage and its secondary skills
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name update_heritage
   * @summary Update Heritage
   * @request PUT:/routes/heritages/{heritage_id}
   */
  export namespace update_heritage {
    export type RequestParams = {
      /** Heritage Id */
      heritageId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = HeritageUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateHeritageData;
  }

  /**
   * @description Delete a heritage and all its relationships
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name delete_heritage
   * @summary Delete Heritage
   * @request DELETE:/routes/heritages/{heritage_id}
   */
  export namespace delete_heritage {
    export type RequestParams = {
      /** Heritage Id */
      heritageId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteHeritageData;
  }

  /**
   * @description Webhook endpoint for Stack Auth user events. Syncs user data to neon_auth.users_sync table. This endpoint is UNPROTECTED (no auth required) as it receives webhooks from Stack Auth. Security is handled via webhook signature verification.
   * @tags dbtn/module:stack_webhook, dbtn/hasAuth
   * @name stack_user_webhook
   * @summary Stack User Webhook
   * @request POST:/routes/webhooks/stack/users
   */
  export namespace stack_user_webhook {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {
      /** X-Stack-Signature */
      "x-stack-signature"?: string | null;
    };
    export type ResponseBody = StackUserWebhookData;
  }

  /**
   * @description Get high-level KPI metrics for the analytics hub page. Returns: AnalyticsOverview with current system metrics
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_analytics_overview
   * @summary Get Analytics Overview
   * @request GET:/routes/analytics/overview
   */
  export namespace get_analytics_overview {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAnalyticsOverviewData;
  }

  /**
   * @description Get comprehensive character build analytics including popularity, combinations, and patterns. Args: active_only: Filter to only active characters start_date: Optional start date for filtering end_date: Optional end date for filtering Returns: CharacterBuildsAnalytics with all build metrics
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_character_builds_analytics
   * @summary Get Character Builds Analytics
   * @request GET:/routes/analytics/character-builds
   */
  export namespace get_character_builds_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Active Only
       * Only include active (non-retired) characters
       * @default true
       */
      active_only?: boolean;
      /**
       * Start Date
       * Start date for character creation filter
       */
      start_date?: string | null;
      /**
       * End Date
       * End date for character creation filter
       */
      end_date?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCharacterBuildsAnalyticsData;
  }

  /**
   * @description Get comprehensive XP economy analytics including distribution, spending patterns, earning trends, and candle purchase metrics. Args: start_date: Optional start date for filtering transactions end_date: Optional end date for filtering transactions Returns: XPEconomyAnalytics with all XP economy metrics
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_xp_economy_analytics
   * @summary Get Xp Economy Analytics
   * @request GET:/routes/analytics/xp-economy
   */
  export namespace get_xp_economy_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Start Date
       * Start date for filtering
       */
      start_date?: string | null;
      /**
       * End Date
       * End date for filtering
       */
      end_date?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetXpEconomyAnalyticsData;
  }

  /**
   * @description Get comprehensive event performance analytics including attendance trends, RSVP accuracy, event rankings, and chapter comparisons. Args: start_date: Optional start date for filtering events end_date: Optional end date for filtering events chapter_id: Optional chapter ID to filter by Returns: EventPerformanceAnalytics with all event performance metrics
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_event_performance_analytics
   * @summary Get Event Performance Analytics
   * @request GET:/routes/analytics/event-performance
   */
  export namespace get_event_performance_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Start Date
       * Start date for filtering
       */
      start_date?: string | null;
      /**
       * End Date
       * End date for filtering
       */
      end_date?: string | null;
      /**
       * Chapter Id
       * Filter by specific chapter
       */
      chapter_id?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEventPerformanceAnalyticsData;
  }

  /**
   * @description Get comprehensive player engagement analytics including activity status, retention analysis, engagement patterns, and character ownership. Args: active_days: Number of days to consider a player active (default 90) Returns: PlayerEngagementAnalytics with all player engagement metrics
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_player_engagement_analytics
   * @summary Get Player Engagement Analytics
   * @request GET:/routes/analytics/player-engagement
   */
  export namespace get_player_engagement_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Active Days
       * Days to consider a player active
       * @default 90
       */
      active_days?: number;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPlayerEngagementAnalyticsData;
  }

  /**
   * @description Get comprehensive chapter health analytics.
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_chapter_health_analytics
   * @summary Get Chapter Health Analytics
   * @request GET:/routes/analytics/chapter-health
   */
  export namespace get_chapter_health_analytics {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Chapter Id
       * Filter by specific chapter
       */
      chapter_id?: string | null;
      /**
       * Start Date
       * Start date for filtering
       */
      start_date?: string | null;
      /**
       * End Date
       * End date for filtering
       */
      end_date?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetChapterHealthAnalyticsData;
  }

  /**
   * @description List all archetypes with their associated skills
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name list_archetypes
   * @summary List Archetypes
   * @request GET:/routes/archetypes/
   */
  export namespace list_archetypes {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListArchetypesData;
  }

  /**
   * @description Create a new archetype (admin only)
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name create_archetype
   * @summary Create Archetype
   * @request POST:/routes/archetypes/
   */
  export namespace create_archetype {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ArchetypeCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateArchetypeData;
  }

  /**
   * @description Get a specific archetype by ID
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name get_archetype
   * @summary Get Archetype
   * @request GET:/routes/archetypes/{archetype_id}
   */
  export namespace get_archetype {
    export type RequestParams = {
      /** Archetype Id */
      archetypeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetArchetypeData;
  }

  /**
   * @description Update an archetype (admin only)
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name update_archetype
   * @summary Update Archetype
   * @request PUT:/routes/archetypes/{archetype_id}
   */
  export namespace update_archetype {
    export type RequestParams = {
      /** Archetype Id */
      archetypeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ArchetypeUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateArchetypeData;
  }

  /**
   * @description Delete an archetype (admin only)
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name delete_archetype
   * @summary Delete Archetype
   * @request DELETE:/routes/archetypes/{archetype_id}
   */
  export namespace delete_archetype {
    export type RequestParams = {
      /** Archetype Id */
      archetypeId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteArchetypeData;
  }

  /**
   * @description List all cultures, optionally filtered by heritage
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name list_cultures
   * @summary List Cultures
   * @request GET:/routes/cultures/cultures/
   */
  export namespace list_cultures {
    export type RequestParams = {};
    export type RequestQuery = {
      /** Heritage Id */
      heritage_id?: string | null;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListCulturesData;
  }

  /**
   * @description Create a new culture (admin only)
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name create_culture
   * @summary Create Culture
   * @request POST:/routes/cultures/cultures/
   */
  export namespace create_culture {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CultureCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateCultureData;
  }

  /**
   * @description Get a specific culture by ID
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name get_culture
   * @summary Get Culture
   * @request GET:/routes/cultures/cultures/{culture_id}
   */
  export namespace get_culture {
    export type RequestParams = {
      /** Culture Id */
      cultureId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetCultureData;
  }

  /**
   * @description Update an existing culture (admin only)
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name update_culture
   * @summary Update Culture
   * @request PUT:/routes/cultures/cultures/{culture_id}
   */
  export namespace update_culture {
    export type RequestParams = {
      /** Culture Id */
      cultureId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = CultureUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateCultureData;
  }

  /**
   * @description Delete a culture (admin only)
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name delete_culture
   * @summary Delete Culture
   * @request DELETE:/routes/cultures/cultures/{culture_id}
   */
  export namespace delete_culture {
    export type RequestParams = {
      /** Culture Id */
      cultureId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteCultureData;
  }

  /**
   * @description List all characters with heritage, culture, archetype, and current player assignment
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name list_all_characters_for_reassignment
   * @summary List All Characters For Reassignment
   * @request GET:/routes/character-reassignment/characters
   */
  export namespace list_all_characters_for_reassignment {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllCharactersForReassignmentData;
  }

  /**
   * @description Get all players filtered by chapter
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name get_players_by_chapter
   * @summary Get Players By Chapter
   * @request GET:/routes/character-reassignment/players-by-chapter/{chapter_id}
   */
  export namespace get_players_by_chapter {
    export type RequestParams = {
      /** Chapter Id */
      chapterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetPlayersByChapterData;
  }

  /**
   * @description Reassign a character to a different player
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name reassign_character
   * @summary Reassign Character
   * @request POST:/routes/character-reassignment/reassign
   */
  export namespace reassign_character {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ReassignmentRequest;
    export type RequestHeaders = {};
    export type ResponseBody = ReassignCharacterData;
  }

  /**
   * @description Get reassignment history for a character
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name get_reassignment_history
   * @summary Get Reassignment History
   * @request GET:/routes/character-reassignment/history/{character_id}
   */
  export namespace get_reassignment_history {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetReassignmentHistoryData;
  }

  /**
   * @description Submit a bug report via email. Rate limited to 3 submissions per hour per email address.
   * @tags dbtn/module:bug_reports, dbtn/hasAuth
   * @name submit_bug_report
   * @summary Submit Bug Report
   * @request POST:/routes/submit
   */
  export namespace submit_bug_report {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BugReportRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SubmitBugReportData;
  }

  /**
   * @description Analyzes selected skills and suggests optimal archetype combinations. Streams progress updates and returns top 5 combinations ranked by XP cost.
   * @tags stream, dbtn/module:build_optimizer, dbtn/hasAuth
   * @name optimize_build
   * @summary Optimize Build
   * @request POST:/routes/optimize
   */
  export namespace optimize_build {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = OptimizeBuildRequest;
    export type RequestHeaders = {};
    export type ResponseBody = OptimizeBuildData;
  }

  /**
   * @description List all chapters
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_chapters
   * @summary List Chapters
   * @request GET:/routes/admin/chapters
   */
  export namespace list_chapters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListChaptersData;
  }

  /**
   * @description Create a new chapter (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name create_chapter
   * @summary Create Chapter
   * @request POST:/routes/admin/chapters
   */
  export namespace create_chapter {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = ChapterCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateChapterData;
  }

  /**
   * @description Update an existing chapter (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_chapter
   * @summary Update Chapter
   * @request PUT:/routes/admin/chapters/{chapter_id}
   */
  export namespace update_chapter {
    export type RequestParams = {
      /** Chapter Id */
      chapterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ChapterUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateChapterData;
  }

  /**
   * @description Delete a chapter (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_chapter
   * @summary Delete Chapter
   * @request DELETE:/routes/admin/chapters/{chapter_id}
   */
  export namespace delete_chapter {
    export type RequestParams = {
      /** Chapter Id */
      chapterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteChapterData;
  }

  /**
   * @description Get all events with admin data (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_admin_events
   * @summary List Admin Events
   * @request GET:/routes/admin/events
   */
  export namespace list_admin_events {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAdminEventsData;
  }

  /**
   * @description Create a new event (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name create_event
   * @summary Create Event
   * @request POST:/routes/admin/events
   */
  export namespace create_event {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = CreateEventRequest;
    export type RequestHeaders = {};
    export type ResponseBody = CreateEventData;
  }

  /**
   * @description Update an existing event (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_event
   * @summary Update Event
   * @request PUT:/routes/admin/events/{event_id}
   */
  export namespace update_event {
    export type RequestParams = {
      /** Event Id */
      eventId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateEventRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateEventData;
  }

  /**
   * @description Delete an event and all related data (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_event
   * @summary Delete Event
   * @request DELETE:/routes/admin/events/{event_id}
   */
  export namespace delete_event {
    export type RequestParams = {
      /** Event Id */
      eventId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteEventData;
  }

  /**
   * @description Get all attendees for an event with attendance management data
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_event_attendees
   * @summary Get Event Attendees
   * @request GET:/routes/admin/events/{event_id}/attendees
   */
  export namespace get_event_attendees {
    export type RequestParams = {
      /** Event Id */
      eventId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetEventAttendeesData;
  }

  /**
   * @description Update attendance status and process XP rewards
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_attendance_status
   * @summary Update Attendance Status
   * @request PUT:/routes/admin/events/rsvp/{rsvp_id}/attendance
   */
  export namespace update_attendance_status {
    export type RequestParams = {
      /** Rsvp Id */
      rsvpId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = UpdateAttendanceRequest;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAttendanceStatusData;
  }

  /**
   * @description Manually add an RSVP for a character (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name add_manual_rsvp
   * @summary Add Manual Rsvp
   * @request POST:/routes/admin/events/{event_id}/manual-rsvp
   */
  export namespace add_manual_rsvp {
    export type RequestParams = {
      /**
       * Event Id
       * @format uuid
       */
      eventId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = ManualRSVPRequest;
    export type RequestHeaders = {};
    export type ResponseBody = AddManualRsvpData;
  }

  /**
   * @description Get all characters for comprehensive admin management (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_all_characters
   * @summary List All Characters
   * @request GET:/routes/admin/characters
   */
  export namespace list_all_characters {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListAllCharactersData;
  }

  /**
   * @description Get detailed character data for admin editing (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_admin_character
   * @summary Get Admin Character
   * @request GET:/routes/admin/characters/{character_id}
   */
  export namespace get_admin_character {
    export type RequestParams = {
      /**
       * Character Id
       * @format uuid
       */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminCharacterData;
  }

  /**
   * @description Update character data (admin only), recalculating and reconciling XP.
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_admin_character
   * @summary Update Admin Character
   * @request PUT:/routes/admin/characters/{character_id}
   */
  export namespace update_admin_character {
    export type RequestParams = {
      /**
       * Character Id
       * @format uuid
       */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = AdminCharacterUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateAdminCharacterData;
  }

  /**
   * @description Delete a character (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_admin_character
   * @summary Delete Admin Character
   * @request DELETE:/routes/admin/characters/{character_id}
   */
  export namespace delete_admin_character {
    export type RequestParams = {
      /**
       * Character Id
       * @format uuid
       */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAdminCharacterData;
  }

  /**
   * @description Get XP transaction history for a character (admin only).
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_admin_character_xp_history
   * @summary Get Admin Character Xp History
   * @request GET:/routes/admin/characters/{character_id}/xp-history
   */
  export namespace get_admin_character_xp_history {
    export type RequestParams = {
      /**
       * Character Id
       * @format uuid
       */
      characterId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetAdminCharacterXpHistoryData;
  }

  /**
   * @description Add a manual XP transaction to a character (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name add_admin_xp_transaction
   * @summary Add Admin Xp Transaction
   * @request POST:/routes/admin/characters/{character_id}/xp-transactions
   */
  export namespace add_admin_xp_transaction {
    export type RequestParams = {
      /** Character Id */
      characterId: string;
    };
    export type RequestQuery = {
      /**
       * Force
       * @default false
       */
      force?: boolean;
    };
    export type RequestBody = AdminXPTransactionCreate;
    export type RequestHeaders = {};
    export type ResponseBody = AddAdminXpTransactionData;
  }

  /**
   * @description Delete an XP transaction (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_admin_xp_transaction
   * @summary Delete Admin Xp Transaction
   * @request DELETE:/routes/admin/xp-transactions/{transaction_id}
   */
  export namespace delete_admin_xp_transaction {
    export type RequestParams = {
      /** Transaction Id */
      transactionId: string;
    };
    export type RequestQuery = {
      /**
       * Force
       * @default false
       */
      force?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteAdminXpTransactionData;
  }

  /**
   * @description Export multiple character sheets as a single multi-page PDF (admin only)
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name bulk_export_character_sheets
   * @summary Bulk Export Character Sheets
   * @request POST:/routes/admin/characters/export-pdf
   */
  export namespace bulk_export_character_sheets {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = BulkExportCharacterSheetsPayload;
    export type RequestHeaders = {};
    export type ResponseBody = BulkExportCharacterSheetsData;
  }

  /**
   * @description List all skills with their prerequisite counts
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name list_skills
   * @summary List Skills
   * @request GET:/routes/skills/
   */
  export namespace list_skills {
    export type RequestParams = {};
    export type RequestQuery = {
      /**
       * Show Hidden
       * @default false
       */
      show_hidden?: boolean;
    };
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListSkillsData;
  }

  /**
   * @description Create a new skill with prerequisites
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name create_skill
   * @summary Create Skill
   * @request POST:/routes/skills/
   */
  export namespace create_skill {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SkillCreate;
    export type RequestHeaders = {};
    export type ResponseBody = CreateSkillData;
  }

  /**
   * @description Get a specific skill with its prerequisites
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name get_skill
   * @summary Get Skill
   * @request GET:/routes/skills/{skill_id}
   */
  export namespace get_skill {
    export type RequestParams = {
      /** Skill Id */
      skillId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = GetSkillData;
  }

  /**
   * @description Update a skill and its prerequisites
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name update_skill
   * @summary Update Skill
   * @request PUT:/routes/skills/{skill_id}
   */
  export namespace update_skill {
    export type RequestParams = {
      /** Skill Id */
      skillId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = SkillUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateSkillData;
  }

  /**
   * @description Delete a skill and all its relationships with cascade cleanup and XP refunds
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name delete_skill
   * @summary Delete Skill
   * @request DELETE:/routes/skills/{skill_id}
   */
  export namespace delete_skill {
    export type RequestParams = {
      /** Skill Id */
      skillId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteSkillData;
  }
}
