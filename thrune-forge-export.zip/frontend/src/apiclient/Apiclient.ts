import {
  AcknowledgeReferralData,
  AcknowledgeReferralError,
  AcknowledgeReferralRequest,
  AddAdminXpTransactionData,
  AddAdminXpTransactionError,
  AddAdminXpTransactionParams,
  AddManualRsvpData,
  AddManualRsvpError,
  AddManualRsvpParams,
  AddPhotoToGalleryData,
  AddPhotoToGalleryError,
  AddPhotoToGalleryParams,
  AdminCharacterUpdate,
  AdminXPTransactionCreate,
  AppApisAdminPlayersUpdatePlayerProfileRequest,
  AppApisPlayersUpdatePlayerProfileRequest,
  ArchetypeCreate,
  ArchetypeUpdate,
  AssignSystemMilestoneData,
  AssignSystemMilestoneError,
  BackfillAuditLogsData,
  BugReportRequest,
  BulkAddPhotosToGalleryData,
  BulkAddPhotosToGalleryError,
  BulkAddPhotosToGalleryParams,
  BulkExportCharacterSheetsData,
  BulkExportCharacterSheetsError,
  BulkExportCharacterSheetsPayload,
  BulkPhotoUploadRequest,
  CalculateXpCostData,
  CalculateXpCostError,
  CalculateXpCostParams,
  ChapterCreate,
  ChapterUpdate,
  CharacterCreate,
  CharacterUpdateRequest,
  CheckHealthData,
  CreateArchetypeData,
  CreateArchetypeError,
  CreateCandleTransactionData,
  CreateCandleTransactionError,
  CreateCandleTransactionParams,
  CreateCandleTransactionRequest,
  CreateChapterData,
  CreateChapterError,
  CreateCharacterData,
  CreateCharacterError,
  CreateCultureData,
  CreateCultureError,
  CreateCustomMilestoneData,
  CreateCustomMilestoneError,
  CreateEventData,
  CreateEventError,
  CreateEventRequest,
  CreateGalleryData,
  CreateGalleryError,
  CreateHeritageData,
  CreateHeritageError,
  CreateJournalEntryData,
  CreateJournalEntryError,
  CreateLoreSubmissionData,
  CreateLoreSubmissionError,
  CreateOrUpdateRsvpData,
  CreateOrUpdateRsvpError,
  CreateOrUpdateRsvpParams,
  CreatePhotoTagData,
  CreatePhotoTagError,
  CreatePhotoTagRequest,
  CreatePlayerProfileData,
  CreatePlayerProfileError,
  CreatePlayerProfileRequest,
  CreateRSVPRequest,
  CreateRoleData,
  CreateRoleError,
  CreateSkillData,
  CreateSkillError,
  CreateSystemMilestoneData,
  CreateSystemMilestoneError,
  CreateTestCharacterData,
  CreateTestCharacterError,
  CultureCreate,
  CultureUpdate,
  CustomMilestoneCreate,
  CustomMilestoneUpdate,
  DeleteAdminCharacterData,
  DeleteAdminCharacterError,
  DeleteAdminCharacterParams,
  DeleteAdminXpTransactionData,
  DeleteAdminXpTransactionError,
  DeleteAdminXpTransactionParams,
  DeleteArchetypeData,
  DeleteArchetypeError,
  DeleteArchetypeParams,
  DeleteCandleTransactionData,
  DeleteCandleTransactionError,
  DeleteCandleTransactionParams,
  DeleteChapterData,
  DeleteChapterError,
  DeleteChapterParams,
  DeleteCultureData,
  DeleteCultureError,
  DeleteCultureParams,
  DeleteCustomMilestoneData,
  DeleteCustomMilestoneError,
  DeleteCustomMilestoneParams,
  DeleteEventData,
  DeleteEventError,
  DeleteEventParams,
  DeleteGalleryData,
  DeleteGalleryError,
  DeleteGalleryParams,
  DeleteGalleryPhotoData,
  DeleteGalleryPhotoError,
  DeleteGalleryPhotoParams,
  DeleteHeritageData,
  DeleteHeritageError,
  DeleteHeritageParams,
  DeleteJournalEntryData,
  DeleteJournalEntryError,
  DeleteJournalEntryParams,
  DeleteLoreSubmissionData,
  DeleteLoreSubmissionError,
  DeleteLoreSubmissionParams,
  DeleteMyCharacterData,
  DeleteMyCharacterError,
  DeleteMyCharacterParams,
  DeletePhotoTagData,
  DeletePhotoTagError,
  DeletePhotoTagParams,
  DeletePlayerData,
  DeletePlayerError,
  DeletePlayerParams,
  DeleteRoleData,
  DeleteRoleError,
  DeleteRoleParams,
  DeleteSkillData,
  DeleteSkillError,
  DeleteSkillParams,
  DeleteSystemMilestoneData,
  DeleteSystemMilestoneError,
  DeleteSystemMilestoneParams,
  DeleteTestCharacterData,
  DeleteTestCharacterError,
  DeleteTestCharacterParams,
  DownloadCompletePackageData,
  FolderPhotosRequest,
  GalleryCreate,
  GalleryUpdate,
  GetAdminCharacterData,
  GetAdminCharacterError,
  GetAdminCharacterParams,
  GetAdminCharacterXpHistoryData,
  GetAdminCharacterXpHistoryError,
  GetAdminCharacterXpHistoryParams,
  GetAdminLoreSubmissionsData,
  GetAdminLoreSubmissionsError,
  GetAdminLoreSubmissionsParams,
  GetAllCharactersForTaggingData,
  GetAllMigrationsData,
  GetAllPhotoTagsData,
  GetAnalyticsOverviewData,
  GetArchetypeData,
  GetArchetypeError,
  GetArchetypeParams,
  GetAuditLogsData,
  GetAuditLogsError,
  GetAuditLogsParams,
  GetChapterHealthAnalyticsData,
  GetChapterHealthAnalyticsError,
  GetChapterHealthAnalyticsParams,
  GetCharacterBuildsAnalyticsData,
  GetCharacterBuildsAnalyticsError,
  GetCharacterBuildsAnalyticsParams,
  GetCharacterCustomMilestonesData,
  GetCharacterCustomMilestonesError,
  GetCharacterCustomMilestonesParams,
  GetCharacterJournalEntriesData,
  GetCharacterJournalEntriesError,
  GetCharacterJournalEntriesParams,
  GetCharacterPhotosData,
  GetCharacterPhotosError,
  GetCharacterPhotosParams,
  GetCharacterSystemMilestonesData,
  GetCharacterSystemMilestonesError,
  GetCharacterSystemMilestonesParams,
  GetCultureData,
  GetCultureError,
  GetCultureParams,
  GetCurrentUserInfoData,
  GetEventAttendeesData,
  GetEventAttendeesError,
  GetEventAttendeesParams,
  GetEventDetailData,
  GetEventDetailError,
  GetEventDetailParams,
  GetEventPerformanceAnalyticsData,
  GetEventPerformanceAnalyticsError,
  GetEventPerformanceAnalyticsParams,
  GetExportStatusData,
  GetHeritageData,
  GetHeritageError,
  GetHeritageParams,
  GetMyCandleHistoryData,
  GetMyCharacterData,
  GetMyCharacterError,
  GetMyCharacterNamesData,
  GetMyCharacterParams,
  GetMyCharactersForTaggingData,
  GetMyLoreSubmissionsData,
  GetMyPermissionsData,
  GetMyPlayerProfileData,
  GetMyRsvpsData,
  GetPhotoTagsData,
  GetPhotoTagsError,
  GetPhotoTagsParams,
  GetPlayerCandleHistoryData,
  GetPlayerCandleHistoryError,
  GetPlayerCandleHistoryParams,
  GetPlayerCharacterEventsData,
  GetPlayerCharacterEventsError,
  GetPlayerCharacterEventsParams,
  GetPlayerDetailData,
  GetPlayerDetailError,
  GetPlayerDetailParams,
  GetPlayerEngagementAnalyticsData,
  GetPlayerEngagementAnalyticsError,
  GetPlayerEngagementAnalyticsParams,
  GetPlayersByChapterData,
  GetPlayersByChapterError,
  GetPlayersByChapterParams,
  GetReassignmentHistoryData,
  GetReassignmentHistoryError,
  GetReassignmentHistoryParams,
  GetReferralStatsData,
  GetSharedJournalsData,
  GetSharedJournalsError,
  GetSharedJournalsParams,
  GetSharedMilestonesData,
  GetSharedMilestonesError,
  GetSharedMilestonesParams,
  GetSkillData,
  GetSkillError,
  GetSkillParams,
  GetXpEconomyAnalyticsData,
  GetXpEconomyAnalyticsError,
  GetXpEconomyAnalyticsParams,
  HeritageCreate,
  HeritageUpdate,
  JournalEntryCreate,
  JournalEntryUpdate,
  ListAdminEventsData,
  ListAllCharactersData,
  ListAllCharactersForReassignmentData,
  ListAllCharactersWithPhotosData,
  ListAllPlayersData,
  ListAllRolesData,
  ListArchetypesData,
  ListChaptersData,
  ListCharactersForAssignmentData,
  ListCulturesData,
  ListCulturesError,
  ListCulturesParams,
  ListEventsData,
  ListEventsError,
  ListEventsParams,
  ListFolderPhotosData,
  ListFolderPhotosError,
  ListGalleriesData,
  ListGalleryPhotosData,
  ListGalleryPhotosError,
  ListGalleryPhotosParams,
  ListHeritagesData,
  ListMyCharactersData,
  ListMyTestCharactersData,
  ListPermissionsData,
  ListPlayerCharactersData,
  ListPlayerCharactersError,
  ListPlayerCharactersParams,
  ListPlayersForReferralData,
  ListPublicChaptersData,
  ListPublicGalleriesData,
  ListPublicGalleryPhotosData,
  ListPublicGalleryPhotosError,
  ListPublicGalleryPhotosParams,
  ListPublicPhotosData,
  ListReferralsData,
  ListReferralsError,
  ListReferralsParams,
  ListScopedChaptersData,
  ListScopedCharactersData,
  ListScopedEventsData,
  ListSkillsData,
  ListSkillsError,
  ListSkillsParams,
  ListSystemMilestonesData,
  ListSystemMilestonesError,
  ListSystemMilestonesParams,
  LoreSubmissionCreate,
  LoreSubmissionUpdate,
  ManualRSVPRequest,
  MarkSystemMilestoneCompleteData,
  MarkSystemMilestoneCompleteError,
  MarkSystemMilestoneCompleteParams,
  MilestoneAssignmentRequest,
  OptimizeBuildData,
  OptimizeBuildError,
  OptimizeBuildRequest,
  PhotoCreate,
  PhotoReorderRequest,
  PhotoUpdate,
  ReassignCharacterData,
  ReassignCharacterError,
  ReassignmentRequest,
  RebuildCharacterData,
  RebuildCharacterError,
  RebuildCharacterParams,
  ReorderGalleryPhotosData,
  ReorderGalleryPhotosError,
  ReorderGalleryPhotosParams,
  RoleCreate,
  RoleUpdate,
  SkillCreate,
  SkillUpdate,
  StackUserWebhookData,
  StackUserWebhookError,
  SubmitBugReportData,
  SubmitBugReportError,
  SyncPlayerProfilesFromProductionData,
  SyncPlayerProfilesFromProductionError,
  SyncPlayerProfilesRequest,
  SystemMilestoneCreate,
  SystemMilestoneUpdate,
  TestCharacterCreate,
  TestCharacterUpdate,
  UpdateAdminCharacterData,
  UpdateAdminCharacterError,
  UpdateAdminCharacterParams,
  UpdateArchetypeData,
  UpdateArchetypeError,
  UpdateArchetypeParams,
  UpdateAttendanceRequest,
  UpdateAttendanceStatusData,
  UpdateAttendanceStatusError,
  UpdateAttendanceStatusParams,
  UpdateCandleTransactionData,
  UpdateCandleTransactionError,
  UpdateCandleTransactionParams,
  UpdateCandleTransactionRequest,
  UpdateChapterData,
  UpdateChapterError,
  UpdateChapterParams,
  UpdateCultureData,
  UpdateCultureError,
  UpdateCultureParams,
  UpdateCustomMilestoneData,
  UpdateCustomMilestoneError,
  UpdateCustomMilestoneParams,
  UpdateEventData,
  UpdateEventError,
  UpdateEventParams,
  UpdateEventRequest,
  UpdateGalleryData,
  UpdateGalleryError,
  UpdateGalleryParams,
  UpdateGalleryPhotoData,
  UpdateGalleryPhotoError,
  UpdateGalleryPhotoParams,
  UpdateHeritageData,
  UpdateHeritageError,
  UpdateHeritageParams,
  UpdateJournalEntryData,
  UpdateJournalEntryError,
  UpdateJournalEntryParams,
  UpdateLoreSubmissionData,
  UpdateLoreSubmissionError,
  UpdateLoreSubmissionParams,
  UpdateMyCharacterData,
  UpdateMyCharacterError,
  UpdateMyCharacterParams,
  UpdateMyPlayerProfileData,
  UpdateMyPlayerProfileError,
  UpdatePlayerNumberData,
  UpdatePlayerNumberError,
  UpdatePlayerNumberParams,
  UpdatePlayerNumberRequest,
  UpdatePlayerProfileData,
  UpdatePlayerProfileError,
  UpdatePlayerProfileParams,
  UpdatePlayerRolesData,
  UpdatePlayerRolesError,
  UpdatePlayerRolesParams,
  UpdatePlayerRolesRequest,
  UpdateRoleData,
  UpdateRoleError,
  UpdateRoleParams,
  UpdateSkillData,
  UpdateSkillError,
  UpdateSkillParams,
  UpdateSystemMilestoneData,
  UpdateSystemMilestoneError,
  UpdateSystemMilestoneNotesData,
  UpdateSystemMilestoneNotesError,
  UpdateSystemMilestoneNotesParams,
  UpdateSystemMilestoneParams,
  UpdateTestCharacterData,
  UpdateTestCharacterError,
  UpdateTestCharacterParams,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Apiclient<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new lore submission (admin only).
   *
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name create_lore_submission
   * @summary Create Lore Submission
   * @request POST:/routes/lore-submissions/create
   */
  create_lore_submission = (data: LoreSubmissionCreate, params: RequestParams = {}) =>
    this.request<CreateLoreSubmissionData, CreateLoreSubmissionError>({
      path: `/routes/lore-submissions/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all lore submissions with optional filters (admin only).
   *
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name get_admin_lore_submissions
   * @summary Get Admin Lore Submissions
   * @request GET:/routes/lore-submissions/admin
   */
  get_admin_lore_submissions = (query: GetAdminLoreSubmissionsParams, params: RequestParams = {}) =>
    this.request<GetAdminLoreSubmissionsData, GetAdminLoreSubmissionsError>({
      path: `/routes/lore-submissions/admin`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get lore submissions for characters owned by the authenticated player.
   *
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name get_my_lore_submissions
   * @summary Get My Lore Submissions
   * @request GET:/routes/lore-submissions/my-submissions
   */
  get_my_lore_submissions = (params: RequestParams = {}) =>
    this.request<GetMyLoreSubmissionsData, any>({
      path: `/routes/lore-submissions/my-submissions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an existing lore submission (admin only).
   *
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name update_lore_submission
   * @summary Update Lore Submission
   * @request PUT:/routes/lore-submissions/{submission_id}
   */
  update_lore_submission = (
    { submissionId, ...query }: UpdateLoreSubmissionParams,
    data: LoreSubmissionUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateLoreSubmissionData, UpdateLoreSubmissionError>({
      path: `/routes/lore-submissions/${submissionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a lore submission (admin only).
   *
   * @tags dbtn/module:lore_submissions, dbtn/hasAuth
   * @name delete_lore_submission
   * @summary Delete Lore Submission
   * @request DELETE:/routes/lore-submissions/{submission_id}
   */
  delete_lore_submission = ({ submissionId, ...query }: DeleteLoreSubmissionParams, params: RequestParams = {}) =>
    this.request<DeleteLoreSubmissionData, DeleteLoreSubmissionError>({
      path: `/routes/lore-submissions/${submissionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Resets a character to a clean state for rebuilding: - Removes all skills - Removes secondary/tertiary archetypes - Resets body/stamina to heritage base - Resets XP spent
   *
   * @tags dbtn/module:admin_rebuild_character, dbtn/hasAuth
   * @name rebuild_character
   * @summary Rebuild Character
   * @request POST:/routes/admin/characters/{character_id}/rebuild
   */
  rebuild_character = ({ characterId, ...query }: RebuildCharacterParams, params: RequestParams = {}) =>
    this.request<RebuildCharacterData, RebuildCharacterError>({
      path: `/routes/admin/characters/${characterId}/rebuild`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get audit logs with filtering
   *
   * @tags dbtn/module:admin_audit_logs, dbtn/hasAuth
   * @name get_audit_logs
   * @summary Get Audit Logs
   * @request GET:/routes/admin/audit-logs
   */
  get_audit_logs = (query: GetAuditLogsParams, params: RequestParams = {}) =>
    this.request<GetAuditLogsData, GetAuditLogsError>({
      path: `/routes/admin/audit-logs`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Backfill audit logs from existing transactions
   *
   * @tags dbtn/module:admin_audit_logs, dbtn/hasAuth
   * @name backfill_audit_logs
   * @summary Backfill Audit Logs
   * @request POST:/routes/admin/audit-logs/backfill
   */
  backfill_audit_logs = (params: RequestParams = {}) =>
    this.request<BackfillAuditLogsData, any>({
      path: `/routes/admin/audit-logs/backfill`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get export readiness status
   *
   * @tags dbtn/module:export_system
   * @name get_export_status
   * @summary Get Export Status
   * @request GET:/routes/export/status
   */
  get_export_status = (params: RequestParams = {}) =>
    this.request<GetExportStatusData, any>({
      path: `/routes/export/status`,
      method: "GET",
      ...params,
    });

  /**
   * @description Extract all migrations from database
   *
   * @tags dbtn/module:export_system
   * @name get_all_migrations
   * @summary Get All Migrations
   * @request GET:/routes/export/migrations
   */
  get_all_migrations = (params: RequestParams = {}) =>
    this.request<GetAllMigrationsData, any>({
      path: `/routes/export/migrations`,
      method: "GET",
      ...params,
    });

  /**
   * @description Download complete app package as ZIP
   *
   * @tags dbtn/module:export_system
   * @name download_complete_package
   * @summary Download Complete Package
   * @request GET:/routes/export/download-package
   */
  download_complete_package = (params: RequestParams = {}) =>
    this.request<DownloadCompletePackageData, any>({
      path: `/routes/export/download-package`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all system milestones with progress for a character
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_system_milestones
   * @summary Get Character System Milestones
   * @request GET:/routes/player-milestones/character/{character_id}/system-milestones
   */
  get_character_system_milestones = (
    { characterId, ...query }: GetCharacterSystemMilestonesParams,
    params: RequestParams = {},
  ) =>
    this.request<GetCharacterSystemMilestonesData, GetCharacterSystemMilestonesError>({
      path: `/routes/player-milestones/character/${characterId}/system-milestones`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update notes and sharing settings for a system milestone
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_system_milestone_notes
   * @summary Update System Milestone Notes
   * @request POST:/routes/player-milestones/character/{character_id}/system-milestones/{system_milestone_id}/notes
   */
  update_system_milestone_notes = (
    { characterId, systemMilestoneId, ...query }: UpdateSystemMilestoneNotesParams,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSystemMilestoneNotesData, UpdateSystemMilestoneNotesError>({
      path: `/routes/player-milestones/character/${characterId}/system-milestones/${systemMilestoneId}/notes`,
      method: "POST",
      query: query,
      ...params,
    });

  /**
   * @description Mark an 'other' type system milestone as completed
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name mark_system_milestone_complete
   * @summary Mark System Milestone Complete
   * @request POST:/routes/player-milestones/character/{character_id}/system-milestones/{system_milestone_id}/mark-complete
   */
  mark_system_milestone_complete = (
    { characterId, systemMilestoneId, ...query }: MarkSystemMilestoneCompleteParams,
    params: RequestParams = {},
  ) =>
    this.request<MarkSystemMilestoneCompleteData, MarkSystemMilestoneCompleteError>({
      path: `/routes/player-milestones/character/${characterId}/system-milestones/${systemMilestoneId}/mark-complete`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get all custom milestones for a character
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_custom_milestones
   * @summary Get Character Custom Milestones
   * @request GET:/routes/player-milestones/character/{character_id}/custom-milestones
   */
  get_character_custom_milestones = (
    { characterId, ...query }: GetCharacterCustomMilestonesParams,
    params: RequestParams = {},
  ) =>
    this.request<GetCharacterCustomMilestonesData, GetCharacterCustomMilestonesError>({
      path: `/routes/player-milestones/character/${characterId}/custom-milestones`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new custom milestone
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name create_custom_milestone
   * @summary Create Custom Milestone
   * @request POST:/routes/player-milestones/custom-milestones
   */
  create_custom_milestone = (data: CustomMilestoneCreate, params: RequestParams = {}) =>
    this.request<CreateCustomMilestoneData, CreateCustomMilestoneError>({
      path: `/routes/player-milestones/custom-milestones`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a custom milestone
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_custom_milestone
   * @summary Update Custom Milestone
   * @request PUT:/routes/player-milestones/custom-milestones/{milestone_id}
   */
  update_custom_milestone = (
    { milestoneId, ...query }: UpdateCustomMilestoneParams,
    data: CustomMilestoneUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCustomMilestoneData, UpdateCustomMilestoneError>({
      path: `/routes/player-milestones/custom-milestones/${milestoneId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a custom milestone
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name delete_custom_milestone
   * @summary Delete Custom Milestone
   * @request DELETE:/routes/player-milestones/custom-milestones/{milestone_id}
   */
  delete_custom_milestone = ({ milestoneId, ...query }: DeleteCustomMilestoneParams, params: RequestParams = {}) =>
    this.request<DeleteCustomMilestoneData, DeleteCustomMilestoneError>({
      path: `/routes/player-milestones/custom-milestones/${milestoneId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all journal entries for a character
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name get_character_journal_entries
   * @summary Get Character Journal Entries
   * @request GET:/routes/player-milestones/character/{character_id}/journal
   */
  get_character_journal_entries = (
    { characterId, ...query }: GetCharacterJournalEntriesParams,
    params: RequestParams = {},
  ) =>
    this.request<GetCharacterJournalEntriesData, GetCharacterJournalEntriesError>({
      path: `/routes/player-milestones/character/${characterId}/journal`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new journal entry
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name create_journal_entry
   * @summary Create Journal Entry
   * @request POST:/routes/player-milestones/journal
   */
  create_journal_entry = (data: JournalEntryCreate, params: RequestParams = {}) =>
    this.request<CreateJournalEntryData, CreateJournalEntryError>({
      path: `/routes/player-milestones/journal`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a journal entry
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name update_journal_entry
   * @summary Update Journal Entry
   * @request PUT:/routes/player-milestones/journal/{entry_id}
   */
  update_journal_entry = (
    { entryId, ...query }: UpdateJournalEntryParams,
    data: JournalEntryUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateJournalEntryData, UpdateJournalEntryError>({
      path: `/routes/player-milestones/journal/${entryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a journal entry
   *
   * @tags dbtn/module:player_milestones, dbtn/hasAuth
   * @name delete_journal_entry
   * @summary Delete Journal Entry
   * @request DELETE:/routes/player-milestones/journal/{entry_id}
   */
  delete_journal_entry = ({ entryId, ...query }: DeleteJournalEntryParams, params: RequestParams = {}) =>
    this.request<DeleteJournalEntryData, DeleteJournalEntryError>({
      path: `/routes/player-milestones/journal/${entryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all test characters for the authenticated user (max 3).
   *
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name list_my_test_characters
   * @summary List My Test Characters
   * @request GET:/routes/test-characters/my-test-characters
   */
  list_my_test_characters = (params: RequestParams = {}) =>
    this.request<ListMyTestCharactersData, any>({
      path: `/routes/test-characters/my-test-characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new test character. Limited to 3 per user.
   *
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name create_test_character
   * @summary Create Test Character
   * @request POST:/routes/test-characters/create
   */
  create_test_character = (data: TestCharacterCreate, params: RequestParams = {}) =>
    this.request<CreateTestCharacterData, CreateTestCharacterError>({
      path: `/routes/test-characters/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a test character. Recalculates XP cost.
   *
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name update_test_character
   * @summary Update Test Character
   * @request PUT:/routes/test-characters/{test_character_id}
   */
  update_test_character = (
    { testCharacterId, ...query }: UpdateTestCharacterParams,
    data: TestCharacterUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateTestCharacterData, UpdateTestCharacterError>({
      path: `/routes/test-characters/${testCharacterId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a test character.
   *
   * @tags dbtn/module:test_characters, dbtn/hasAuth
   * @name delete_test_character
   * @summary Delete Test Character
   * @request DELETE:/routes/test-characters/{test_character_id}
   */
  delete_test_character = ({ testCharacterId, ...query }: DeleteTestCharacterParams, params: RequestParams = {}) =>
    this.request<DeleteTestCharacterData, DeleteTestCharacterError>({
      path: `/routes/test-characters/${testCharacterId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all events with admin data, filtered by user's chapter permissions
   *
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_events
   * @summary List Scoped Events
   * @request GET:/routes/admin-scoped/events
   */
  list_scoped_events = (params: RequestParams = {}) =>
    this.request<ListScopedEventsData, any>({
      path: `/routes/admin-scoped/events`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all characters for admin management, filtered by user's chapter permissions
   *
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_characters
   * @summary List Scoped Characters
   * @request GET:/routes/admin-scoped/characters
   */
  list_scoped_characters = (params: RequestParams = {}) =>
    this.request<ListScopedCharactersData, any>({
      path: `/routes/admin-scoped/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all chapters filtered by user's chapter permissions
   *
   * @tags dbtn/module:admin_scoped, dbtn/hasAuth
   * @name list_scoped_chapters
   * @summary List Scoped Chapters
   * @request GET:/routes/admin-scoped/chapters
   */
  list_scoped_chapters = (params: RequestParams = {}) =>
    this.request<ListScopedChaptersData, any>({
      path: `/routes/admin-scoped/chapters`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all galleries with photo counts (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_galleries
   * @summary List Galleries
   * @request GET:/routes/admin-galleries/galleries
   */
  list_galleries = (params: RequestParams = {}) =>
    this.request<ListGalleriesData, any>({
      path: `/routes/admin-galleries/galleries`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new photo gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name create_gallery
   * @summary Create Gallery
   * @request POST:/routes/admin-galleries/galleries
   */
  create_gallery = (data: GalleryCreate, params: RequestParams = {}) =>
    this.request<CreateGalleryData, CreateGalleryError>({
      path: `/routes/admin-galleries/galleries`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name update_gallery
   * @summary Update Gallery
   * @request PUT:/routes/admin-galleries/galleries/{gallery_id}
   */
  update_gallery = ({ galleryId, ...query }: UpdateGalleryParams, data: GalleryUpdate, params: RequestParams = {}) =>
    this.request<UpdateGalleryData, UpdateGalleryError>({
      path: `/routes/admin-galleries/galleries/${galleryId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a gallery and all its photos (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name delete_gallery
   * @summary Delete Gallery
   * @request DELETE:/routes/admin-galleries/galleries/{gallery_id}
   */
  delete_gallery = ({ galleryId, ...query }: DeleteGalleryParams, params: RequestParams = {}) =>
    this.request<DeleteGalleryData, DeleteGalleryError>({
      path: `/routes/admin-galleries/galleries/${galleryId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all galleries with photo counts (public endpoint for PhotoGallery page)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_galleries
   * @summary List Public Galleries
   * @request GET:/routes/admin-galleries/public/galleries
   */
  list_public_galleries = (params: RequestParams = {}) =>
    this.request<ListPublicGalleriesData, any>({
      path: `/routes/admin-galleries/public/galleries`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all photos from a specific gallery with their tags (public endpoint)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_gallery_photos
   * @summary List Public Gallery Photos
   * @request GET:/routes/admin-galleries/public/galleries/{gallery_id}/photos
   */
  list_public_gallery_photos = ({ galleryId, ...query }: ListPublicGalleryPhotosParams, params: RequestParams = {}) =>
    this.request<ListPublicGalleryPhotosData, ListPublicGalleryPhotosError>({
      path: `/routes/admin-galleries/public/galleries/${galleryId}/photos`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all photos from all galleries (public endpoint for PhotoGallery page)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_public_photos
   * @summary List Public Photos
   * @request GET:/routes/admin-galleries/public/photos
   */
  list_public_photos = (params: RequestParams = {}) =>
    this.request<ListPublicPhotosData, any>({
      path: `/routes/admin-galleries/public/photos`,
      method: "GET",
      ...params,
    });

  /**
   * @description Add a photo to a gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name add_photo_to_gallery
   * @summary Add Photo To Gallery
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos
   */
  add_photo_to_gallery = (
    { galleryId, ...query }: AddPhotoToGalleryParams,
    data: PhotoCreate,
    params: RequestParams = {},
  ) =>
    this.request<AddPhotoToGalleryData, AddPhotoToGalleryError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all photos in a gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name list_gallery_photos
   * @summary List Gallery Photos
   * @request GET:/routes/admin-galleries/galleries/{gallery_id}/photos
   */
  list_gallery_photos = ({ galleryId, ...query }: ListGalleryPhotosParams, params: RequestParams = {}) =>
    this.request<ListGalleryPhotosData, ListGalleryPhotosError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos`,
      method: "GET",
      ...params,
    });

  /**
   * @description Bulk add photos to a gallery with duplicate detection (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name bulk_add_photos_to_gallery
   * @summary Bulk Add Photos To Gallery
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos/bulk
   */
  bulk_add_photos_to_gallery = (
    { galleryId, ...query }: BulkAddPhotosToGalleryParams,
    data: BulkPhotoUploadRequest,
    params: RequestParams = {},
  ) =>
    this.request<BulkAddPhotosToGalleryData, BulkAddPhotosToGalleryError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos/bulk`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a photo in gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name update_gallery_photo
   * @summary Update Gallery Photo
   * @request PUT:/routes/admin-galleries/galleries/{gallery_id}/photos/{photo_id}
   */
  update_gallery_photo = (
    { galleryId, photoId, ...query }: UpdateGalleryPhotoParams,
    data: PhotoUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateGalleryPhotoData, UpdateGalleryPhotoError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos/${photoId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a photo from gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name delete_gallery_photo
   * @summary Delete Gallery Photo
   * @request DELETE:/routes/admin-galleries/galleries/{gallery_id}/photos/{photo_id}
   */
  delete_gallery_photo = ({ galleryId, photoId, ...query }: DeleteGalleryPhotoParams, params: RequestParams = {}) =>
    this.request<DeleteGalleryPhotoData, DeleteGalleryPhotoError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos/${photoId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Reorder photos in a gallery (admin only)
   *
   * @tags dbtn/module:admin_galleries, dbtn/hasAuth
   * @name reorder_gallery_photos
   * @summary Reorder Gallery Photos
   * @request POST:/routes/admin-galleries/galleries/{gallery_id}/photos/reorder
   */
  reorder_gallery_photos = (
    { galleryId, ...query }: ReorderGalleryPhotosParams,
    data: PhotoReorderRequest,
    params: RequestParams = {},
  ) =>
    this.request<ReorderGalleryPhotosData, ReorderGalleryPhotosError>({
      path: `/routes/admin-galleries/galleries/${galleryId}/photos/reorder`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update the current user's player profile
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name update_my_player_profile
   * @summary Update My Player Profile
   * @request PUT:/routes/players/profile
   */
  update_my_player_profile = (data: AppApisPlayersUpdatePlayerProfileRequest, params: RequestParams = {}) =>
    this.request<UpdateMyPlayerProfileData, UpdateMyPlayerProfileError>({
      path: `/routes/players/profile`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Create a new player profile for the authenticated user
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name create_player_profile
   * @summary Create Player Profile
   * @request POST:/routes/players/profile
   */
  create_player_profile = (data: CreatePlayerProfileRequest, params: RequestParams = {}) =>
    this.request<CreatePlayerProfileData, CreatePlayerProfileError>({
      path: `/routes/players/profile`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get the current user's player profile
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_player_profile
   * @summary Get My Player Profile
   * @request GET:/routes/my-player-profile
   */
  get_my_player_profile = (params: RequestParams = {}) =>
    this.request<GetMyPlayerProfileData, any>({
      path: `/routes/my-player-profile`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get the current user's candle transaction history
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_candle_history
   * @summary Get My Candle History
   * @request GET:/routes/players/candle-history
   */
  get_my_candle_history = (params: RequestParams = {}) =>
    this.request<GetMyCandleHistoryData, any>({
      path: `/routes/players/candle-history`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a player's number (admin only)
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name update_player_number
   * @summary Update Player Number
   * @request PUT:/routes/admin/players/{player_id}/player-number
   */
  update_player_number = (
    { playerId, ...query }: UpdatePlayerNumberParams,
    data: UpdatePlayerNumberRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdatePlayerNumberData, UpdatePlayerNumberError>({
      path: `/routes/admin/players/${playerId}/player-number`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Debug endpoint to check current user ID and admin status
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_current_user_info
   * @summary Get Current User Info
   * @request GET:/routes/debug/user-info
   */
  get_current_user_info = (params: RequestParams = {}) =>
    this.request<GetCurrentUserInfoData, any>({
      path: `/routes/debug/user-info`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get current user's roles and permissions
   *
   * @tags dbtn/module:players, dbtn/hasAuth
   * @name get_my_permissions
   * @summary Get My Permissions
   * @request GET:/routes/my/permissions
   */
  get_my_permissions = (params: RequestParams = {}) =>
    this.request<GetMyPermissionsData, any>({
      path: `/routes/my/permissions`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all referrals with optional filtering (admin only)
   *
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name list_referrals
   * @summary List Referrals
   * @request GET:/routes/referrals/list
   */
  list_referrals = (query: ListReferralsParams, params: RequestParams = {}) =>
    this.request<ListReferralsData, ListReferralsError>({
      path: `/routes/referrals/list`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Acknowledge and lock a referral (admin only)
   *
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name acknowledge_referral
   * @summary Acknowledge Referral
   * @request POST:/routes/referrals/acknowledge
   */
  acknowledge_referral = (data: AcknowledgeReferralRequest, params: RequestParams = {}) =>
    this.request<AcknowledgeReferralData, AcknowledgeReferralError>({
      path: `/routes/referrals/acknowledge`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get referral statistics and top referrers (admin only)
   *
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name get_referral_stats
   * @summary Get Referral Stats
   * @request GET:/routes/referrals/stats
   */
  get_referral_stats = (params: RequestParams = {}) =>
    this.request<GetReferralStatsData, any>({
      path: `/routes/referrals/stats`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all players grouped by chapter for referral selection
   *
   * @tags dbtn/module:referrals, dbtn/hasAuth
   * @name list_players_for_referral
   * @summary List Players For Referral
   * @request GET:/routes/referrals/players-for-referral
   */
  list_players_for_referral = (params: RequestParams = {}) =>
    this.request<ListPlayersForReferralData, any>({
      path: `/routes/referrals/players-for-referral`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all milestones shared with staff (filterable)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name get_shared_milestones
   * @summary Get Shared Milestones
   * @request GET:/routes/admin-milestones/shared-milestones
   */
  get_shared_milestones = (query: GetSharedMilestonesParams, params: RequestParams = {}) =>
    this.request<GetSharedMilestonesData, GetSharedMilestonesError>({
      path: `/routes/admin-milestones/shared-milestones`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get all journal entries shared with staff (filterable)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name get_shared_journals
   * @summary Get Shared Journals
   * @request GET:/routes/admin-milestones/shared-journals
   */
  get_shared_journals = (query: GetSharedJournalsParams, params: RequestParams = {}) =>
    this.request<GetSharedJournalsData, GetSharedJournalsError>({
      path: `/routes/admin-milestones/shared-journals`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description List all system milestone definitions (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name list_system_milestones
   * @summary List System Milestones
   * @request GET:/routes/admin-milestones/system-milestones
   */
  list_system_milestones = (query: ListSystemMilestonesParams, params: RequestParams = {}) =>
    this.request<ListSystemMilestonesData, ListSystemMilestonesError>({
      path: `/routes/admin-milestones/system-milestones`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new system milestone definition (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name create_system_milestone
   * @summary Create System Milestone
   * @request POST:/routes/admin-milestones/system-milestones
   */
  create_system_milestone = (data: SystemMilestoneCreate, params: RequestParams = {}) =>
    this.request<CreateSystemMilestoneData, CreateSystemMilestoneError>({
      path: `/routes/admin-milestones/system-milestones`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update a system milestone definition (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name update_system_milestone
   * @summary Update System Milestone
   * @request PUT:/routes/admin-milestones/system-milestones/{milestone_id}
   */
  update_system_milestone = (
    { milestoneId, ...query }: UpdateSystemMilestoneParams,
    data: SystemMilestoneUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateSystemMilestoneData, UpdateSystemMilestoneError>({
      path: `/routes/admin-milestones/system-milestones/${milestoneId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a system milestone definition (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name delete_system_milestone
   * @summary Delete System Milestone
   * @request DELETE:/routes/admin-milestones/system-milestones/{milestone_id}
   */
  delete_system_milestone = ({ milestoneId, ...query }: DeleteSystemMilestoneParams, params: RequestParams = {}) =>
    this.request<DeleteSystemMilestoneData, DeleteSystemMilestoneError>({
      path: `/routes/admin-milestones/system-milestones/${milestoneId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all characters for milestone assignment (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name list_characters_for_assignment
   * @summary List Characters For Assignment
   * @request GET:/routes/admin-milestones/characters
   */
  list_characters_for_assignment = (params: RequestParams = {}) =>
    this.request<ListCharactersForAssignmentData, any>({
      path: `/routes/admin-milestones/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Assign a system milestone to a character (admin only)
   *
   * @tags dbtn/module:admin_milestones, dbtn/hasAuth
   * @name assign_system_milestone
   * @summary Assign System Milestone
   * @request POST:/routes/admin-milestones/assign
   */
  assign_system_milestone = (data: MilestoneAssignmentRequest, params: RequestParams = {}) =>
    this.request<AssignSystemMilestoneData, AssignSystemMilestoneError>({
      path: `/routes/admin-milestones/assign`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all image files from a Google Drive folder Requires GOOGLE_DRIVE_API_KEY secret
   *
   * @tags dbtn/module:google_drive, dbtn/hasAuth
   * @name list_folder_photos
   * @summary List Folder Photos
   * @request POST:/routes/google-drive/list-folder-photos
   */
  list_folder_photos = (data: FolderPhotosRequest, params: RequestParams = {}) =>
    this.request<ListFolderPhotosData, ListFolderPhotosError>({
      path: `/routes/google-drive/list-folder-photos`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Calculate XP cost for body/stamina changes.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name calculate_xp_cost
   * @summary Calculate Xp Cost
   * @request POST:/routes/characters/calculate-xp-cost
   */
  calculate_xp_cost = (query: CalculateXpCostParams, params: RequestParams = {}) =>
    this.request<CalculateXpCostData, CalculateXpCostError>({
      path: `/routes/characters/calculate-xp-cost`,
      method: "POST",
      query: query,
      ...params,
    });

  /**
   * @description Get list of characters for the authenticated user.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name list_my_characters
   * @summary List My Characters
   * @request GET:/routes/characters/my-characters
   */
  list_my_characters = (params: RequestParams = {}) =>
    this.request<ListMyCharactersData, any>({
      path: `/routes/characters/my-characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get detailed character information including skills and XP history.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name get_my_character
   * @summary Get My Character
   * @request GET:/routes/characters/my-characters/{character_id}
   */
  get_my_character = ({ characterId, ...query }: GetMyCharacterParams, params: RequestParams = {}) =>
    this.request<GetMyCharacterData, GetMyCharacterError>({
      path: `/routes/characters/my-characters/${characterId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a character.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name update_my_character
   * @summary Update My Character
   * @request PUT:/routes/characters/my-characters/{character_id}
   */
  update_my_character = (
    { characterId, ...query }: UpdateMyCharacterParams,
    data: CharacterUpdateRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateMyCharacterData, UpdateMyCharacterError>({
      path: `/routes/characters/my-characters/${characterId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a character.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name delete_my_character
   * @summary Delete My Character
   * @request DELETE:/routes/characters/my-characters/{character_id}
   */
  delete_my_character = ({ characterId, ...query }: DeleteMyCharacterParams, params: RequestParams = {}) =>
    this.request<DeleteMyCharacterData, DeleteMyCharacterError>({
      path: `/routes/characters/my-characters/${characterId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Create a new character.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name create_character
   * @summary Create Character
   * @request POST:/routes/characters/create
   */
  create_character = (data: CharacterCreate, params: RequestParams = {}) =>
    this.request<CreateCharacterData, CreateCharacterError>({
      path: `/routes/characters/create`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get list of character names for the current player.
   *
   * @tags dbtn/module:characters, dbtn/hasAuth
   * @name get_my_character_names
   * @summary Get My Character Names
   * @request GET:/routes/characters/my-character-names
   */
  get_my_character_names = (params: RequestParams = {}) =>
    this.request<GetMyCharacterNamesData, any>({
      path: `/routes/characters/my-character-names`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all characters with heritage, culture, player, chapter, and photo count
   *
   * @tags dbtn/module:face_to_name, dbtn/hasAuth
   * @name list_all_characters_with_photos
   * @summary List All Characters With Photos
   * @request GET:/routes/characters
   */
  list_all_characters_with_photos = (params: RequestParams = {}) =>
    this.request<ListAllCharactersWithPhotosData, any>({
      path: `/routes/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all photos where a character is tagged
   *
   * @tags dbtn/module:face_to_name, dbtn/hasAuth
   * @name get_character_photos
   * @summary Get Character Photos
   * @request GET:/routes/characters/{character_id}/photos
   */
  get_character_photos = ({ characterId, ...query }: GetCharacterPhotosParams, params: RequestParams = {}) =>
    this.request<GetCharacterPhotosData, GetCharacterPhotosError>({
      path: `/routes/characters/${characterId}/photos`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all chapters (public endpoint)
   *
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name list_public_chapters
   * @summary List Public Chapters
   * @request GET:/routes/chapters
   */
  list_public_chapters = (params: RequestParams = {}) =>
    this.request<ListPublicChaptersData, any>({
      path: `/routes/chapters`,
      method: "GET",
      ...params,
    });

  /**
   * @description List events with optional filtering.
   *
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name list_events
   * @summary List Events
   * @request GET:/routes/events
   */
  list_events = (query: ListEventsParams, params: RequestParams = {}) =>
    this.request<ListEventsData, ListEventsError>({
      path: `/routes/events`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get detailed information about a specific event.
   *
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name get_event_detail
   * @summary Get Event Detail
   * @request GET:/routes/events/{event_id}
   */
  get_event_detail = ({ eventId, ...query }: GetEventDetailParams, params: RequestParams = {}) =>
    this.request<GetEventDetailData, GetEventDetailError>({
      path: `/routes/events/${eventId}`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create or update user's RSVP for an event with enhanced features.
   *
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name create_or_update_rsvp
   * @summary Create Or Update Rsvp
   * @request POST:/routes/events/{event_id}/rsvp
   */
  create_or_update_rsvp = (
    { eventId, ...query }: CreateOrUpdateRsvpParams,
    data: CreateRSVPRequest,
    params: RequestParams = {},
  ) =>
    this.request<CreateOrUpdateRsvpData, CreateOrUpdateRsvpError>({
      path: `/routes/events/${eventId}/rsvp`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all of the current user's RSVPs with event details.
   *
   * @tags dbtn/module:events, dbtn/hasAuth
   * @name get_my_rsvps
   * @summary Get My Rsvps
   * @request GET:/routes/my/rsvps
   */
  get_my_rsvps = (params: RequestParams = {}) =>
    this.request<GetMyRsvpsData, any>({
      path: `/routes/my/rsvps`,
      method: "GET",
      ...params,
    });

  /**
   * @description Sync player_profiles data from production to development. This endpoint receives complete player_profiles table data from production and updates the development database to maintain OAuth consistency. Only available in development environment and requires admin permissions.
   *
   * @tags dbtn/module:dev_sync, dbtn/hasAuth
   * @name sync_player_profiles_from_production
   * @summary Sync Player Profiles From Production
   * @request POST:/routes/dev/sync-player-profiles
   */
  sync_player_profiles_from_production = (data: SyncPlayerProfilesRequest, params: RequestParams = {}) =>
    this.request<SyncPlayerProfilesFromProductionData, SyncPlayerProfilesFromProductionError>({
      path: `/routes/dev/sync-player-profiles`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all available roles with permissions (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_all_roles
   * @summary List All Roles
   * @request GET:/routes/admin/players/roles
   */
  list_all_roles = (params: RequestParams = {}) =>
    this.request<ListAllRolesData, any>({
      path: `/routes/admin/players/roles`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new role
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name create_role
   * @summary Create Role
   * @request POST:/routes/admin/players/roles
   */
  create_role = (data: RoleCreate, params: RequestParams = {}) =>
    this.request<CreateRoleData, CreateRoleError>({
      path: `/routes/admin/players/roles`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all available permissions
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_permissions
   * @summary List Permissions
   * @request GET:/routes/admin/players/permissions
   */
  list_permissions = (params: RequestParams = {}) =>
    this.request<ListPermissionsData, any>({
      path: `/routes/admin/players/permissions`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an existing role
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_role
   * @summary Update Role
   * @request PUT:/routes/admin/players/roles/{role_id}
   */
  update_role = ({ roleId, ...query }: UpdateRoleParams, data: RoleUpdate, params: RequestParams = {}) =>
    this.request<UpdateRoleData, UpdateRoleError>({
      path: `/routes/admin/players/roles/${roleId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a role (only if not assigned to any users and not a system role)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_role
   * @summary Delete Role
   * @request DELETE:/routes/admin/players/roles/{role_id}
   */
  delete_role = ({ roleId, ...query }: DeleteRoleParams, params: RequestParams = {}) =>
    this.request<DeleteRoleData, DeleteRoleError>({
      path: `/routes/admin/players/roles/${roleId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get detailed player information for editing (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_detail
   * @summary Get Player Detail
   * @request GET:/routes/admin/players/{player_id}
   */
  get_player_detail = ({ playerId, ...query }: GetPlayerDetailParams, params: RequestParams = {}) =>
    this.request<GetPlayerDetailData, GetPlayerDetailError>({
      path: `/routes/admin/players/${playerId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete a player and all associated data (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_player
   * @summary Delete Player
   * @request DELETE:/routes/admin/players/{player_id}
   */
  delete_player = ({ playerId, ...query }: DeletePlayerParams, params: RequestParams = {}) =>
    this.request<DeletePlayerData, DeletePlayerError>({
      path: `/routes/admin/players/${playerId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all characters for a specific player (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_player_characters
   * @summary List Player Characters
   * @request GET:/routes/admin/players/{player_id}/characters
   */
  list_player_characters = ({ playerId, ...query }: ListPlayerCharactersParams, params: RequestParams = {}) =>
    this.request<ListPlayerCharactersData, ListPlayerCharactersError>({
      path: `/routes/admin/players/${playerId}/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all players with management information (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name list_all_players
   * @summary List All Players
   * @request GET:/routes/admin/players/
   */
  list_all_players = (params: RequestParams = {}) =>
    this.request<ListAllPlayersData, any>({
      path: `/routes/admin/players/`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update player roles (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_player_roles
   * @summary Update Player Roles
   * @request PUT:/routes/admin/players/{player_id}/roles
   */
  update_player_roles = (
    { playerId, ...query }: UpdatePlayerRolesParams,
    data: UpdatePlayerRolesRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdatePlayerRolesData, UpdatePlayerRolesError>({
      path: `/routes/admin/players/${playerId}/roles`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update player profile information (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_player_profile
   * @summary Update Player Profile
   * @request PUT:/routes/admin/players/{player_id}/profile
   */
  update_player_profile = (
    { playerId, ...query }: UpdatePlayerProfileParams,
    data: AppApisAdminPlayersUpdatePlayerProfileRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdatePlayerProfileData, UpdatePlayerProfileError>({
      path: `/routes/admin/players/${playerId}/profile`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get candle transaction history for a specific player (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_candle_history
   * @summary Get Player Candle History
   * @request GET:/routes/admin/players/{player_id}/candle-history
   */
  get_player_candle_history = ({ playerId, ...query }: GetPlayerCandleHistoryParams, params: RequestParams = {}) =>
    this.request<GetPlayerCandleHistoryData, GetPlayerCandleHistoryError>({
      path: `/routes/admin/players/${playerId}/candle-history`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new candle transaction for a player (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name create_candle_transaction
   * @summary Create Candle Transaction
   * @request POST:/routes/admin/players/{player_id}/candles
   */
  create_candle_transaction = (
    { playerId, ...query }: CreateCandleTransactionParams,
    data: CreateCandleTransactionRequest,
    params: RequestParams = {},
  ) =>
    this.request<CreateCandleTransactionData, CreateCandleTransactionError>({
      path: `/routes/admin/players/${playerId}/candles`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing candle transaction (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name update_candle_transaction
   * @summary Update Candle Transaction
   * @request PUT:/routes/admin/players/{player_id}/candles/{transaction_id}
   */
  update_candle_transaction = (
    { playerId, transactionId, ...query }: UpdateCandleTransactionParams,
    data: UpdateCandleTransactionRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateCandleTransactionData, UpdateCandleTransactionError>({
      path: `/routes/admin/players/${playerId}/candles/${transactionId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a candle transaction (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name delete_candle_transaction
   * @summary Delete Candle Transaction
   * @request DELETE:/routes/admin/players/{player_id}/candles/{transaction_id}
   */
  delete_candle_transaction = (
    { playerId, transactionId, ...query }: DeleteCandleTransactionParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteCandleTransactionData, DeleteCandleTransactionError>({
      path: `/routes/admin/players/${playerId}/candles/${transactionId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all events a character has RSVP'd to or attended (admin only)
   *
   * @tags dbtn/module:admin_players, dbtn/hasAuth
   * @name get_player_character_events
   * @summary Get Player Character Events
   * @request GET:/routes/admin/players/{player_id}/characters/{character_id}/events
   */
  get_player_character_events = (
    { playerId, characterId, ...query }: GetPlayerCharacterEventsParams,
    params: RequestParams = {},
  ) =>
    this.request<GetPlayerCharacterEventsData, GetPlayerCharacterEventsError>({
      path: `/routes/admin/players/${playerId}/characters/${characterId}/events`,
      method: "GET",
      ...params,
    });

  /**
   * @description Tag a character in a photo. Players can only tag their own characters. Admins can tag any character.
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name create_photo_tag
   * @summary Create Photo Tag
   * @request POST:/routes/photo-gallery/tags
   */
  create_photo_tag = (data: CreatePhotoTagRequest, params: RequestParams = {}) =>
    this.request<CreatePhotoTagData, CreatePhotoTagError>({
      path: `/routes/photo-gallery/tags`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all tags for a specific photo
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_photo_tags
   * @summary Get Photo Tags
   * @request GET:/routes/photo-gallery/photos/{photo_id}/tags
   */
  get_photo_tags = ({ photoId, ...query }: GetPhotoTagsParams, params: RequestParams = {}) =>
    this.request<GetPhotoTagsData, GetPhotoTagsError>({
      path: `/routes/photo-gallery/photos/${photoId}/tags`,
      method: "GET",
      ...params,
    });

  /**
   * @description Delete a photo tag. Only the creator or admin can delete.
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name delete_photo_tag
   * @summary Delete Photo Tag
   * @request DELETE:/routes/photo-gallery/tags/{tag_id}
   */
  delete_photo_tag = ({ tagId, ...query }: DeletePhotoTagParams, params: RequestParams = {}) =>
    this.request<DeletePhotoTagData, DeletePhotoTagError>({
      path: `/routes/photo-gallery/tags/${tagId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all photo tags in one query for efficient loading
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_all_photo_tags
   * @summary Get All Photo Tags
   * @request GET:/routes/photo-gallery/tags/all
   */
  get_all_photo_tags = (params: RequestParams = {}) =>
    this.request<GetAllPhotoTagsData, any>({
      path: `/routes/photo-gallery/tags/all`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get user's characters for tagging dropdown
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_my_characters_for_tagging
   * @summary Get My Characters For Tagging
   * @request GET:/routes/photo-gallery/my-characters
   */
  get_my_characters_for_tagging = (params: RequestParams = {}) =>
    this.request<GetMyCharactersForTaggingData, any>({
      path: `/routes/photo-gallery/my-characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all characters for admin tagging (admin only)
   *
   * @tags dbtn/module:photo_gallery, dbtn/hasAuth
   * @name get_all_characters_for_tagging
   * @summary Get All Characters For Tagging
   * @request GET:/routes/photo-gallery/all-characters
   */
  get_all_characters_for_tagging = (params: RequestParams = {}) =>
    this.request<GetAllCharactersForTaggingData, any>({
      path: `/routes/photo-gallery/all-characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all heritages with their secondary skills
   *
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name list_heritages
   * @summary List Heritages
   * @request GET:/routes/heritages/
   */
  list_heritages = (params: RequestParams = {}) =>
    this.request<ListHeritagesData, any>({
      path: `/routes/heritages/`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new heritage with secondary skills
   *
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name create_heritage
   * @summary Create Heritage
   * @request POST:/routes/heritages/
   */
  create_heritage = (data: HeritageCreate, params: RequestParams = {}) =>
    this.request<CreateHeritageData, CreateHeritageError>({
      path: `/routes/heritages/`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific heritage with its secondary skills
   *
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name get_heritage
   * @summary Get Heritage
   * @request GET:/routes/heritages/{heritage_id}
   */
  get_heritage = ({ heritageId, ...query }: GetHeritageParams, params: RequestParams = {}) =>
    this.request<GetHeritageData, GetHeritageError>({
      path: `/routes/heritages/${heritageId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a heritage and its secondary skills
   *
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name update_heritage
   * @summary Update Heritage
   * @request PUT:/routes/heritages/{heritage_id}
   */
  update_heritage = (
    { heritageId, ...query }: UpdateHeritageParams,
    data: HeritageUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateHeritageData, UpdateHeritageError>({
      path: `/routes/heritages/${heritageId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a heritage and all its relationships
   *
   * @tags dbtn/module:heritages, dbtn/hasAuth
   * @name delete_heritage
   * @summary Delete Heritage
   * @request DELETE:/routes/heritages/{heritage_id}
   */
  delete_heritage = ({ heritageId, ...query }: DeleteHeritageParams, params: RequestParams = {}) =>
    this.request<DeleteHeritageData, DeleteHeritageError>({
      path: `/routes/heritages/${heritageId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Webhook endpoint for Stack Auth user events. Syncs user data to neon_auth.users_sync table. This endpoint is UNPROTECTED (no auth required) as it receives webhooks from Stack Auth. Security is handled via webhook signature verification.
   *
   * @tags dbtn/module:stack_webhook, dbtn/hasAuth
   * @name stack_user_webhook
   * @summary Stack User Webhook
   * @request POST:/routes/webhooks/stack/users
   */
  stack_user_webhook = (params: RequestParams = {}) =>
    this.request<StackUserWebhookData, StackUserWebhookError>({
      path: `/routes/webhooks/stack/users`,
      method: "POST",
      ...params,
    });

  /**
   * @description Get high-level KPI metrics for the analytics hub page. Returns: AnalyticsOverview with current system metrics
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_analytics_overview
   * @summary Get Analytics Overview
   * @request GET:/routes/analytics/overview
   */
  get_analytics_overview = (params: RequestParams = {}) =>
    this.request<GetAnalyticsOverviewData, any>({
      path: `/routes/analytics/overview`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get comprehensive character build analytics including popularity, combinations, and patterns. Args: active_only: Filter to only active characters start_date: Optional start date for filtering end_date: Optional end date for filtering Returns: CharacterBuildsAnalytics with all build metrics
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_character_builds_analytics
   * @summary Get Character Builds Analytics
   * @request GET:/routes/analytics/character-builds
   */
  get_character_builds_analytics = (query: GetCharacterBuildsAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetCharacterBuildsAnalyticsData, GetCharacterBuildsAnalyticsError>({
      path: `/routes/analytics/character-builds`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive XP economy analytics including distribution, spending patterns, earning trends, and candle purchase metrics. Args: start_date: Optional start date for filtering transactions end_date: Optional end date for filtering transactions Returns: XPEconomyAnalytics with all XP economy metrics
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_xp_economy_analytics
   * @summary Get Xp Economy Analytics
   * @request GET:/routes/analytics/xp-economy
   */
  get_xp_economy_analytics = (query: GetXpEconomyAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetXpEconomyAnalyticsData, GetXpEconomyAnalyticsError>({
      path: `/routes/analytics/xp-economy`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive event performance analytics including attendance trends, RSVP accuracy, event rankings, and chapter comparisons. Args: start_date: Optional start date for filtering events end_date: Optional end date for filtering events chapter_id: Optional chapter ID to filter by Returns: EventPerformanceAnalytics with all event performance metrics
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_event_performance_analytics
   * @summary Get Event Performance Analytics
   * @request GET:/routes/analytics/event-performance
   */
  get_event_performance_analytics = (query: GetEventPerformanceAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetEventPerformanceAnalyticsData, GetEventPerformanceAnalyticsError>({
      path: `/routes/analytics/event-performance`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive player engagement analytics including activity status, retention analysis, engagement patterns, and character ownership. Args: active_days: Number of days to consider a player active (default 90) Returns: PlayerEngagementAnalytics with all player engagement metrics
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_player_engagement_analytics
   * @summary Get Player Engagement Analytics
   * @request GET:/routes/analytics/player-engagement
   */
  get_player_engagement_analytics = (query: GetPlayerEngagementAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetPlayerEngagementAnalyticsData, GetPlayerEngagementAnalyticsError>({
      path: `/routes/analytics/player-engagement`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Get comprehensive chapter health analytics.
   *
   * @tags dbtn/module:analytics, dbtn/hasAuth
   * @name get_chapter_health_analytics
   * @summary Get Chapter Health Analytics
   * @request GET:/routes/analytics/chapter-health
   */
  get_chapter_health_analytics = (query: GetChapterHealthAnalyticsParams, params: RequestParams = {}) =>
    this.request<GetChapterHealthAnalyticsData, GetChapterHealthAnalyticsError>({
      path: `/routes/analytics/chapter-health`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description List all archetypes with their associated skills
   *
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name list_archetypes
   * @summary List Archetypes
   * @request GET:/routes/archetypes/
   */
  list_archetypes = (params: RequestParams = {}) =>
    this.request<ListArchetypesData, any>({
      path: `/routes/archetypes/`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new archetype (admin only)
   *
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name create_archetype
   * @summary Create Archetype
   * @request POST:/routes/archetypes/
   */
  create_archetype = (data: ArchetypeCreate, params: RequestParams = {}) =>
    this.request<CreateArchetypeData, CreateArchetypeError>({
      path: `/routes/archetypes/`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific archetype by ID
   *
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name get_archetype
   * @summary Get Archetype
   * @request GET:/routes/archetypes/{archetype_id}
   */
  get_archetype = ({ archetypeId, ...query }: GetArchetypeParams, params: RequestParams = {}) =>
    this.request<GetArchetypeData, GetArchetypeError>({
      path: `/routes/archetypes/${archetypeId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an archetype (admin only)
   *
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name update_archetype
   * @summary Update Archetype
   * @request PUT:/routes/archetypes/{archetype_id}
   */
  update_archetype = (
    { archetypeId, ...query }: UpdateArchetypeParams,
    data: ArchetypeUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateArchetypeData, UpdateArchetypeError>({
      path: `/routes/archetypes/${archetypeId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an archetype (admin only)
   *
   * @tags dbtn/module:archetypes, dbtn/hasAuth
   * @name delete_archetype
   * @summary Delete Archetype
   * @request DELETE:/routes/archetypes/{archetype_id}
   */
  delete_archetype = ({ archetypeId, ...query }: DeleteArchetypeParams, params: RequestParams = {}) =>
    this.request<DeleteArchetypeData, DeleteArchetypeError>({
      path: `/routes/archetypes/${archetypeId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all cultures, optionally filtered by heritage
   *
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name list_cultures
   * @summary List Cultures
   * @request GET:/routes/cultures/cultures/
   */
  list_cultures = (query: ListCulturesParams, params: RequestParams = {}) =>
    this.request<ListCulturesData, ListCulturesError>({
      path: `/routes/cultures/cultures/`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new culture (admin only)
   *
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name create_culture
   * @summary Create Culture
   * @request POST:/routes/cultures/cultures/
   */
  create_culture = (data: CultureCreate, params: RequestParams = {}) =>
    this.request<CreateCultureData, CreateCultureError>({
      path: `/routes/cultures/cultures/`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific culture by ID
   *
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name get_culture
   * @summary Get Culture
   * @request GET:/routes/cultures/cultures/{culture_id}
   */
  get_culture = ({ cultureId, ...query }: GetCultureParams, params: RequestParams = {}) =>
    this.request<GetCultureData, GetCultureError>({
      path: `/routes/cultures/cultures/${cultureId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update an existing culture (admin only)
   *
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name update_culture
   * @summary Update Culture
   * @request PUT:/routes/cultures/cultures/{culture_id}
   */
  update_culture = ({ cultureId, ...query }: UpdateCultureParams, data: CultureUpdate, params: RequestParams = {}) =>
    this.request<UpdateCultureData, UpdateCultureError>({
      path: `/routes/cultures/cultures/${cultureId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a culture (admin only)
   *
   * @tags dbtn/module:cultures, dbtn/hasAuth
   * @name delete_culture
   * @summary Delete Culture
   * @request DELETE:/routes/cultures/cultures/{culture_id}
   */
  delete_culture = ({ cultureId, ...query }: DeleteCultureParams, params: RequestParams = {}) =>
    this.request<DeleteCultureData, DeleteCultureError>({
      path: `/routes/cultures/cultures/${cultureId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description List all characters with heritage, culture, archetype, and current player assignment
   *
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name list_all_characters_for_reassignment
   * @summary List All Characters For Reassignment
   * @request GET:/routes/character-reassignment/characters
   */
  list_all_characters_for_reassignment = (params: RequestParams = {}) =>
    this.request<ListAllCharactersForReassignmentData, any>({
      path: `/routes/character-reassignment/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get all players filtered by chapter
   *
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name get_players_by_chapter
   * @summary Get Players By Chapter
   * @request GET:/routes/character-reassignment/players-by-chapter/{chapter_id}
   */
  get_players_by_chapter = ({ chapterId, ...query }: GetPlayersByChapterParams, params: RequestParams = {}) =>
    this.request<GetPlayersByChapterData, GetPlayersByChapterError>({
      path: `/routes/character-reassignment/players-by-chapter/${chapterId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Reassign a character to a different player
   *
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name reassign_character
   * @summary Reassign Character
   * @request POST:/routes/character-reassignment/reassign
   */
  reassign_character = (data: ReassignmentRequest, params: RequestParams = {}) =>
    this.request<ReassignCharacterData, ReassignCharacterError>({
      path: `/routes/character-reassignment/reassign`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get reassignment history for a character
   *
   * @tags dbtn/module:character_reassignment, dbtn/hasAuth
   * @name get_reassignment_history
   * @summary Get Reassignment History
   * @request GET:/routes/character-reassignment/history/{character_id}
   */
  get_reassignment_history = ({ characterId, ...query }: GetReassignmentHistoryParams, params: RequestParams = {}) =>
    this.request<GetReassignmentHistoryData, GetReassignmentHistoryError>({
      path: `/routes/character-reassignment/history/${characterId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Submit a bug report via email. Rate limited to 3 submissions per hour per email address.
   *
   * @tags dbtn/module:bug_reports, dbtn/hasAuth
   * @name submit_bug_report
   * @summary Submit Bug Report
   * @request POST:/routes/submit
   */
  submit_bug_report = (data: BugReportRequest, params: RequestParams = {}) =>
    this.request<SubmitBugReportData, SubmitBugReportError>({
      path: `/routes/submit`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Analyzes selected skills and suggests optimal archetype combinations. Streams progress updates and returns top 5 combinations ranked by XP cost.
   *
   * @tags stream, dbtn/module:build_optimizer, dbtn/hasAuth
   * @name optimize_build
   * @summary Optimize Build
   * @request POST:/routes/optimize
   */
  optimize_build = (data: OptimizeBuildRequest, params: RequestParams = {}) =>
    this.requestStream<OptimizeBuildData, OptimizeBuildError>({
      path: `/routes/optimize`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all chapters
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_chapters
   * @summary List Chapters
   * @request GET:/routes/admin/chapters
   */
  list_chapters = (params: RequestParams = {}) =>
    this.request<ListChaptersData, any>({
      path: `/routes/admin/chapters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new chapter (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name create_chapter
   * @summary Create Chapter
   * @request POST:/routes/admin/chapters
   */
  create_chapter = (data: ChapterCreate, params: RequestParams = {}) =>
    this.request<CreateChapterData, CreateChapterError>({
      path: `/routes/admin/chapters`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing chapter (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_chapter
   * @summary Update Chapter
   * @request PUT:/routes/admin/chapters/{chapter_id}
   */
  update_chapter = ({ chapterId, ...query }: UpdateChapterParams, data: ChapterUpdate, params: RequestParams = {}) =>
    this.request<UpdateChapterData, UpdateChapterError>({
      path: `/routes/admin/chapters/${chapterId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a chapter (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_chapter
   * @summary Delete Chapter
   * @request DELETE:/routes/admin/chapters/{chapter_id}
   */
  delete_chapter = ({ chapterId, ...query }: DeleteChapterParams, params: RequestParams = {}) =>
    this.request<DeleteChapterData, DeleteChapterError>({
      path: `/routes/admin/chapters/${chapterId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all events with admin data (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_admin_events
   * @summary List Admin Events
   * @request GET:/routes/admin/events
   */
  list_admin_events = (params: RequestParams = {}) =>
    this.request<ListAdminEventsData, any>({
      path: `/routes/admin/events`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new event (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name create_event
   * @summary Create Event
   * @request POST:/routes/admin/events
   */
  create_event = (data: CreateEventRequest, params: RequestParams = {}) =>
    this.request<CreateEventData, CreateEventError>({
      path: `/routes/admin/events`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing event (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_event
   * @summary Update Event
   * @request PUT:/routes/admin/events/{event_id}
   */
  update_event = ({ eventId, ...query }: UpdateEventParams, data: UpdateEventRequest, params: RequestParams = {}) =>
    this.request<UpdateEventData, UpdateEventError>({
      path: `/routes/admin/events/${eventId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an event and all related data (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_event
   * @summary Delete Event
   * @request DELETE:/routes/admin/events/{event_id}
   */
  delete_event = ({ eventId, ...query }: DeleteEventParams, params: RequestParams = {}) =>
    this.request<DeleteEventData, DeleteEventError>({
      path: `/routes/admin/events/${eventId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get all attendees for an event with attendance management data
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_event_attendees
   * @summary Get Event Attendees
   * @request GET:/routes/admin/events/{event_id}/attendees
   */
  get_event_attendees = ({ eventId, ...query }: GetEventAttendeesParams, params: RequestParams = {}) =>
    this.request<GetEventAttendeesData, GetEventAttendeesError>({
      path: `/routes/admin/events/${eventId}/attendees`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update attendance status and process XP rewards
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_attendance_status
   * @summary Update Attendance Status
   * @request PUT:/routes/admin/events/rsvp/{rsvp_id}/attendance
   */
  update_attendance_status = (
    { rsvpId, ...query }: UpdateAttendanceStatusParams,
    data: UpdateAttendanceRequest,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAttendanceStatusData, UpdateAttendanceStatusError>({
      path: `/routes/admin/events/rsvp/${rsvpId}/attendance`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Manually add an RSVP for a character (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name add_manual_rsvp
   * @summary Add Manual Rsvp
   * @request POST:/routes/admin/events/{event_id}/manual-rsvp
   */
  add_manual_rsvp = ({ eventId, ...query }: AddManualRsvpParams, data: ManualRSVPRequest, params: RequestParams = {}) =>
    this.request<AddManualRsvpData, AddManualRsvpError>({
      path: `/routes/admin/events/${eventId}/manual-rsvp`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get all characters for comprehensive admin management (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name list_all_characters
   * @summary List All Characters
   * @request GET:/routes/admin/characters
   */
  list_all_characters = (params: RequestParams = {}) =>
    this.request<ListAllCharactersData, any>({
      path: `/routes/admin/characters`,
      method: "GET",
      ...params,
    });

  /**
   * @description Get detailed character data for admin editing (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_admin_character
   * @summary Get Admin Character
   * @request GET:/routes/admin/characters/{character_id}
   */
  get_admin_character = ({ characterId, ...query }: GetAdminCharacterParams, params: RequestParams = {}) =>
    this.request<GetAdminCharacterData, GetAdminCharacterError>({
      path: `/routes/admin/characters/${characterId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update character data (admin only), recalculating and reconciling XP.
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name update_admin_character
   * @summary Update Admin Character
   * @request PUT:/routes/admin/characters/{character_id}
   */
  update_admin_character = (
    { characterId, ...query }: UpdateAdminCharacterParams,
    data: AdminCharacterUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateAdminCharacterData, UpdateAdminCharacterError>({
      path: `/routes/admin/characters/${characterId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a character (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_admin_character
   * @summary Delete Admin Character
   * @request DELETE:/routes/admin/characters/{character_id}
   */
  delete_admin_character = ({ characterId, ...query }: DeleteAdminCharacterParams, params: RequestParams = {}) =>
    this.request<DeleteAdminCharacterData, DeleteAdminCharacterError>({
      path: `/routes/admin/characters/${characterId}`,
      method: "DELETE",
      ...params,
    });

  /**
   * @description Get XP transaction history for a character (admin only).
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name get_admin_character_xp_history
   * @summary Get Admin Character Xp History
   * @request GET:/routes/admin/characters/{character_id}/xp-history
   */
  get_admin_character_xp_history = (
    { characterId, ...query }: GetAdminCharacterXpHistoryParams,
    params: RequestParams = {},
  ) =>
    this.request<GetAdminCharacterXpHistoryData, GetAdminCharacterXpHistoryError>({
      path: `/routes/admin/characters/${characterId}/xp-history`,
      method: "GET",
      ...params,
    });

  /**
   * @description Add a manual XP transaction to a character (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name add_admin_xp_transaction
   * @summary Add Admin Xp Transaction
   * @request POST:/routes/admin/characters/{character_id}/xp-transactions
   */
  add_admin_xp_transaction = (
    { characterId, ...query }: AddAdminXpTransactionParams,
    data: AdminXPTransactionCreate,
    params: RequestParams = {},
  ) =>
    this.request<AddAdminXpTransactionData, AddAdminXpTransactionError>({
      path: `/routes/admin/characters/${characterId}/xp-transactions`,
      method: "POST",
      query: query,
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an XP transaction (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name delete_admin_xp_transaction
   * @summary Delete Admin Xp Transaction
   * @request DELETE:/routes/admin/xp-transactions/{transaction_id}
   */
  delete_admin_xp_transaction = (
    { transactionId, ...query }: DeleteAdminXpTransactionParams,
    params: RequestParams = {},
  ) =>
    this.request<DeleteAdminXpTransactionData, DeleteAdminXpTransactionError>({
      path: `/routes/admin/xp-transactions/${transactionId}`,
      method: "DELETE",
      query: query,
      ...params,
    });

  /**
   * @description Export multiple character sheets as a single multi-page PDF (admin only)
   *
   * @tags dbtn/module:admin, dbtn/hasAuth
   * @name bulk_export_character_sheets
   * @summary Bulk Export Character Sheets
   * @request POST:/routes/admin/characters/export-pdf
   */
  bulk_export_character_sheets = (data: BulkExportCharacterSheetsPayload, params: RequestParams = {}) =>
    this.request<BulkExportCharacterSheetsData, BulkExportCharacterSheetsError>({
      path: `/routes/admin/characters/export-pdf`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description List all skills with their prerequisite counts
   *
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name list_skills
   * @summary List Skills
   * @request GET:/routes/skills/
   */
  list_skills = (query: ListSkillsParams, params: RequestParams = {}) =>
    this.request<ListSkillsData, ListSkillsError>({
      path: `/routes/skills/`,
      method: "GET",
      query: query,
      ...params,
    });

  /**
   * @description Create a new skill with prerequisites
   *
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name create_skill
   * @summary Create Skill
   * @request POST:/routes/skills/
   */
  create_skill = (data: SkillCreate, params: RequestParams = {}) =>
    this.request<CreateSkillData, CreateSkillError>({
      path: `/routes/skills/`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Get a specific skill with its prerequisites
   *
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name get_skill
   * @summary Get Skill
   * @request GET:/routes/skills/{skill_id}
   */
  get_skill = ({ skillId, ...query }: GetSkillParams, params: RequestParams = {}) =>
    this.request<GetSkillData, GetSkillError>({
      path: `/routes/skills/${skillId}`,
      method: "GET",
      ...params,
    });

  /**
   * @description Update a skill and its prerequisites
   *
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name update_skill
   * @summary Update Skill
   * @request PUT:/routes/skills/{skill_id}
   */
  update_skill = ({ skillId, ...query }: UpdateSkillParams, data: SkillUpdate, params: RequestParams = {}) =>
    this.request<UpdateSkillData, UpdateSkillError>({
      path: `/routes/skills/${skillId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete a skill and all its relationships with cascade cleanup and XP refunds
   *
   * @tags dbtn/module:skills, dbtn/hasAuth
   * @name delete_skill
   * @summary Delete Skill
   * @request DELETE:/routes/skills/{skill_id}
   */
  delete_skill = ({ skillId, ...query }: DeleteSkillParams, params: RequestParams = {}) =>
    this.request<DeleteSkillData, DeleteSkillError>({
      path: `/routes/skills/${skillId}`,
      method: "DELETE",
      ...params,
    });
}
