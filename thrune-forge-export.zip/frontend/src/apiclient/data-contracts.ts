/**
 * AcknowledgeReferralRequest
 * Request to acknowledge a referral
 */
export interface AcknowledgeReferralRequest {
  /**
   * Player Id
   * @format uuid
   */
  player_id: string;
}

/**
 * AcknowledgeReferralResponse
 * Response after acknowledging a referral
 */
export interface AcknowledgeReferralResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
}

/**
 * ActivityStatusBreakdown
 * Player activity status by time period.
 */
export interface ActivityStatusBreakdown {
  /** Period */
  period: string;
  /** Active Count */
  active_count: number;
  /** Percentage */
  percentage: number;
}

/**
 * AdminCharacterListItem
 * Response model for character list items in admin view
 */
export interface AdminCharacterListItem {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Heritage Name */
  heritage_name?: string | null;
  /** Culture Id */
  culture_id: string;
  /** Culture Name */
  culture_name?: string | null;
  /** Archetype Id */
  archetype_id: string;
  /** Archetype Name */
  archetype_name?: string | null;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Secondary Archetype Name */
  secondary_archetype_name?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Tertiary Archetype Name */
  tertiary_archetype_name?: string | null;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /** Player Profile Id */
  player_profile_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Chapter Id */
  chapter_id: string;
  /** Deaths */
  deaths: number;
  /** Corruption */
  corruption: number;
  /** Retired */
  retired: boolean;
  /** Events Attended */
  events_attended: number;
  /** Last Attended Event Id */
  last_attended_event_id?: string | null;
  /** Xp Total */
  xp_total: number;
  /** Xp Available */
  xp_available: number;
  /** Xp Spent */
  xp_spent: number;
  /** Skill Count */
  skill_count: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * AdminCharacterListResponse
 * Response model for list of characters
 */
export interface AdminCharacterListResponse {
  /** Characters */
  characters: AdminCharacterListItem[];
}

/** AdminCharacterUpdate */
export interface AdminCharacterUpdate {
  /** Name */
  name?: string | null;
  /** Body */
  body?: number | null;
  /** Stamina */
  stamina?: number | null;
  /** Heritage Id */
  heritage_id?: string | null;
  /** Culture Id */
  culture_id?: string | null;
  /** Archetype Id */
  archetype_id?: string | null;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Selected Skills */
  selected_skills?: Record<string, any>[] | null;
  /** Player Notes */
  player_notes?: string | null;
  /** Addictions Diseases */
  addictions_diseases?: string | null;
  /** Deaths */
  deaths?: number | null;
  /** Corruption */
  corruption?: number | null;
  /** Retired */
  retired?: boolean | null;
}

/** AdminEventListResponse */
export interface AdminEventListResponse {
  /** Events */
  events: AdminEventResponse[];
}

/** AdminEventResponse */
export interface AdminEventResponse {
  /** Id */
  id: string;
  /** Chapter Id */
  chapter_id: string;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Chapter Name */
  chapter_name: string;
  /** Total Rsvps */
  total_rsvps: number;
  /** Attended Count */
  attended_count: number;
  /** No Show Count */
  no_show_count: number;
}

/** AdminXPTransactionCreate */
export interface AdminXPTransactionCreate {
  /** Amount */
  amount: number;
  /** Transaction Type */
  transaction_type: string;
  /** Reason */
  reason: string;
}

/**
 * AnalyticsOverview
 * High-level KPI metrics for analytics hub page.
 */
export interface AnalyticsOverview {
  /** Total Corruption */
  total_corruption: number;
  /** Total Characters */
  total_characters: number;
  /** Total Deaths */
  total_deaths: number;
  /** Attendance Rate */
  attendance_rate: number;
  /** Total Xp Distributed */
  total_xp_distributed: number;
  /** Total Events */
  total_events: number;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/** ArchetypeCreate */
export interface ArchetypeCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /**
   * Primary Skill Ids
   * List of primary skill UUIDs
   * @default []
   */
  primary_skill_ids?: string[];
  /**
   * Secondary Skill Ids
   * List of secondary skill UUIDs
   * @default []
   */
  secondary_skill_ids?: string[];
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** ArchetypeResponse */
export interface ArchetypeResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /**
   * Primary Skills
   * @default []
   */
  primary_skills?: AppApisArchetypesSkillSummary[];
  /**
   * Secondary Skills
   * @default []
   */
  secondary_skills?: AppApisArchetypesSkillSummary[];
  /** Created At */
  created_at: string;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** ArchetypeUpdate */
export interface ArchetypeUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Primary Skill Ids */
  primary_skill_ids?: string[] | null;
  /** Secondary Skill Ids */
  secondary_skill_ids?: string[] | null;
  /** Candle Cost */
  candle_cost?: number | null;
}

/**
 * AtRiskPlayer
 * At-risk player with declining attendance.
 */
export interface AtRiskPlayer {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /**
   * Last Event Date
   * @format date-time
   */
  last_event_date: string;
  /** Days Since Last Event */
  days_since_last_event: number;
  /** Events Last 3Mo */
  events_last_3mo: number;
  /** Events Previous 3Mo */
  events_previous_3mo: number;
  /** Trend */
  trend: string;
}

/**
 * AttendanceTrend
 * Monthly attendance trend.
 */
export interface AttendanceTrend {
  /** Month */
  month: string;
  /** Year */
  year: number;
  /** Event Count */
  event_count: number;
  /** Total Attendance */
  total_attendance: number;
  /** Avg Attendance */
  avg_attendance: number;
}

/** AttendeeInfo */
export interface AttendeeInfo {
  /** Id */
  id: string;
  /** Character Id */
  character_id?: string | null;
  /** Character Name */
  character_name?: string | null;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Ticket Xp */
  ticket_xp: number;
  /** Candle Xp */
  candle_xp: number;
  /** Rsvp Status */
  rsvp_status: string;
  /** Attendance Status */
  attendance_status: string;
  /** Notes */
  notes?: string | null;
  /** Processed By User Id */
  processed_by_user_id?: string | null;
  /** Attendance Processed At */
  attendance_processed_at?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** AuditLogEntry */
export interface AuditLogEntry {
  /** Id */
  id: string;
  /** Performed By User Id */
  performed_by_user_id: string | null;
  /** Performed By Name */
  performed_by_name: string | null;
  /** Action Type */
  action_type: string;
  /** Action */
  action: string;
  /** Entity Id */
  entity_id: string | null;
  /** Entity Name */
  entity_name?: string | null;
  /** Entity Type */
  entity_type: string | null;
  /** Details */
  details: any;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** BugReportRequest */
export interface BugReportRequest {
  /**
   * Email
   * @format email
   */
  email: string;
  /** Description */
  description: string;
  /** Page Url */
  page_url?: string | null;
  /** Player Name */
  player_name?: string | null;
  /** Console Errors */
  console_errors?: ConsoleError[] | null;
}

/**
 * BuildCombination
 * Combination of build options.
 */
export interface BuildCombination {
  /** Combination */
  combination: string;
  /** Count */
  count: number;
  /** Percentage */
  percentage: number;
  /** Details */
  details: Record<string, any>;
}

/** BulkPhotoResult */
export interface BulkPhotoResult {
  /** Photo Url */
  photo_url: string;
  /** Status */
  status: string;
  /** Photo Id */
  photo_id?: string | null;
  /** Error Message */
  error_message?: string | null;
}

/** BulkPhotoUploadRequest */
export interface BulkPhotoUploadRequest {
  /** Photos */
  photos: PhotoCreate[];
}

/** BulkPhotoUploadResponse */
export interface BulkPhotoUploadResponse {
  /** Results */
  results: BulkPhotoResult[];
  /** Success Count */
  success_count: number;
  /** Duplicate Count */
  duplicate_count: number;
  /** Error Count */
  error_count: number;
}

/**
 * CandleMetrics
 * Candle purchase metrics.
 */
export interface CandleMetrics {
  /** Total Candles Purchased */
  total_candles_purchased: number;
  /** Purchase Count */
  purchase_count: number;
  /** Avg Candles Per Purchase */
  avg_candles_per_purchase: number;
  /** Players Who Purchased */
  players_who_purchased: number;
  /** Total Players */
  total_players: number;
  /** Purchase Percentage */
  purchase_percentage: number;
}

/**
 * ChapterComparison
 * Chapter performance comparison.
 */
export interface ChapterComparison {
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Event Count */
  event_count: number;
  /** Avg Attendance */
  avg_attendance: number;
  /** Rsvp Accuracy */
  rsvp_accuracy: number;
}

/**
 * ChapterComparisonMetric
 * Chapter comparison metrics.
 */
export interface ChapterComparisonMetric {
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Total Events */
  total_events: number;
  /** Avg Attendance */
  avg_attendance: number;
  /** Unique Players */
  unique_players: number;
  /** Xp Distributed */
  xp_distributed: number;
  /** Rsvp Accuracy */
  rsvp_accuracy: number;
}

/**
 * ChapterConsistencyMetric
 * Chapter event consistency metrics.
 */
export interface ChapterConsistencyMetric {
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Events Per Month */
  events_per_month: number;
  /** Consistency Score */
  consistency_score: number;
  /** Longest Gap Days */
  longest_gap_days: number;
}

/** ChapterCreate */
export interface ChapterCreate {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Chapter Code */
  chapter_code: string;
  /** Location */
  location?: string | null;
  /** Contact Email */
  contact_email?: string | null;
  /** Website */
  website?: string | null;
}

/**
 * ChapterGrowthTrend
 * Chapter growth trend over time.
 */
export interface ChapterGrowthTrend {
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Month */
  month: string;
  /** Year */
  year: number;
  /** Player Count */
  player_count: number;
  /** Trend Status */
  trend_status: string;
}

/**
 * ChapterHealthAnalytics
 * Chapter health analytics response.
 */
export interface ChapterHealthAnalytics {
  /** Total Chapters */
  total_chapters: number;
  /** Active Chapters */
  active_chapters: number;
  /** Inactive Chapters */
  inactive_chapters: number;
  /** Chapter List */
  chapter_list: ChapterOverview[];
  /** Growth Trends */
  growth_trends: ChapterGrowthTrend[];
  /** Chapter Comparisons */
  chapter_comparisons: ChapterComparisonMetric[];
  /** Total Cross Chapter Players */
  total_cross_chapter_players: number;
  /** Cross Chapter Percentage */
  cross_chapter_percentage: number;
  /** Cross Chapter Players */
  cross_chapter_players: CrossChapterPlayer[];
  /** Chapter Overlap Flows */
  chapter_overlap_flows: ChapterOverlapFlow[];
  /** Consistency Metrics */
  consistency_metrics: ChapterConsistencyMetric[];
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/**
 * ChapterOverlapFlow
 * Chapter to chapter attendance flow.
 */
export interface ChapterOverlapFlow {
  /** From Chapter Id */
  from_chapter_id: string;
  /** From Chapter Name */
  from_chapter_name: string;
  /** To Chapter Id */
  to_chapter_id: string;
  /** To Chapter Name */
  to_chapter_name: string;
  /** Player Count */
  player_count: number;
}

/**
 * ChapterOverview
 * Individual chapter overview statistics.
 */
export interface ChapterOverview {
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Events Hosted */
  events_hosted: number;
  /** Avg Attendance */
  avg_attendance: number;
  /** Last Event Date */
  last_event_date: string | null;
  /** Status */
  status: string;
  /** Unique Players */
  unique_players: number;
}

/**
 * ChapterPlayersGroup
 * Players grouped by chapter
 */
export interface ChapterPlayersGroup {
  /**
   * Chapter Id
   * @format uuid
   */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Players */
  players: PlayerListItem[];
}

/** ChapterUpdate */
export interface ChapterUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Chapter Code */
  chapter_code?: string | null;
  /** Location */
  location?: string | null;
  /** Contact Email */
  contact_email?: string | null;
  /** Website */
  website?: string | null;
}

/**
 * CharacterBuildsAnalytics
 * Character builds analytics response.
 */
export interface CharacterBuildsAnalytics {
  /** Top Skills */
  top_skills: SkillPopularity[];
  /** Least Popular Skills */
  least_popular_skills: SkillPopularity[];
  /** All Skills */
  all_skills: SkillPopularity[];
  /** Archetype Distribution */
  archetype_distribution: OptionDistribution[];
  /** Heritage Distribution */
  heritage_distribution: OptionDistribution[];
  /** Culture Distribution */
  culture_distribution: OptionDistribution[];
  /** Orphaned Options */
  orphaned_options: OrphanedOption[];
  /** Top Archetype Heritage Combos */
  top_archetype_heritage_combos: BuildCombination[];
  /** Top Archetype Culture Combos */
  top_archetype_culture_combos: BuildCombination[];
  /** Top Heritage Culture Combos */
  top_heritage_culture_combos: BuildCombination[];
  /** Top Trifecta Combos */
  top_trifecta_combos: BuildCombination[];
  /** Skill Distribution */
  skill_distribution: Record<string, any>;
  /** Skill Synergies */
  skill_synergies: SkillSynergy[];
  /** Total Characters Analyzed */
  total_characters_analyzed: number;
  /** Average Body */
  average_body: number;
  /** Average Stamina */
  average_stamina: number;
  /** Body Distribution */
  body_distribution: StatDistribution[];
  /** Stamina Distribution */
  stamina_distribution: StatDistribution[];
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/**
 * CharacterCountDistribution
 * Distribution of characters per player.
 */
export interface CharacterCountDistribution {
  /** Character Count */
  character_count: number;
  /** Player Count */
  player_count: number;
  /** Percentage */
  percentage: number;
}

/** CharacterCreate */
export interface CharacterCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Culture Id */
  culture_id: string;
  /** Archetype Id */
  archetype_id: string;
  /**
   * Body
   * @min 1
   * @max 200
   */
  body: number;
  /**
   * Stamina
   * @min 1
   * @max 200
   */
  stamina: number;
  /** Selected Skills */
  selected_skills?: Record<string, any>[];
  /** Player Notes */
  player_notes?: string | null;
  /** Addictions Diseases */
  addictions_diseases?: string | null;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
}

/** CharacterDetail */
export interface CharacterDetail {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Culture Id */
  culture_id: string;
  /** Archetype Id */
  archetype_id: string;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /** Xp Total */
  xp_total: number;
  /** Xp Spent */
  xp_spent: number;
  /** Xp Available */
  xp_available: number;
  /** Player Notes */
  player_notes?: string | null;
  /** Addictions Diseases */
  addictions_diseases?: string | null;
  /** Retired */
  retired: boolean;
  /**
   * Deaths
   * @default 0
   */
  deaths?: number;
  /**
   * Corruption
   * @default 0
   */
  corruption?: number;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /** Heritage Name */
  heritage_name: string;
  /** Culture Name */
  culture_name: string;
  heritage: HeritageInfo;
  culture: CultureInfo;
  /** Archetype Name */
  archetype_name: string;
  /** Secondary Archetype Name */
  secondary_archetype_name?: string | null;
  /** Tertiary Archetype Name */
  tertiary_archetype_name?: string | null;
  /** Skills */
  skills: SkillInfo[];
  /** Events Attended */
  events_attended: number;
  /** Xp Transactions */
  xp_transactions: XPTransaction[];
}

/** CharacterPhoto */
export interface CharacterPhoto {
  /** Tag Id */
  tag_id: string;
  /** Photo Id */
  photo_id: string;
  /** Photo Url */
  photo_url: string;
  /** Thumbnail Url */
  thumbnail_url: string | null;
  /** Tagged At */
  tagged_at: string;
  /** X Position */
  x_position: number;
  /** Y Position */
  y_position: number;
  /** Player Profile Id */
  player_profile_id: string;
}

/**
 * CharacterSelectionResponse
 * Character info for selection
 */
export interface CharacterSelectionResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
}

/** CharacterUpdateRequest */
export interface CharacterUpdateRequest {
  /** Name */
  name?: string | null;
  /** Heritage Id */
  heritage_id?: string | null;
  /** Culture Id */
  culture_id?: string | null;
  /** Archetype Id */
  archetype_id?: string | null;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Body */
  body?: number | null;
  /** Stamina */
  stamina?: number | null;
  /** Selected Skills */
  selected_skills?: Record<string, any>[] | null;
  /** Player Notes */
  player_notes?: string | null;
  /** Addictions Diseases */
  addictions_diseases?: string | null;
  /** Retired */
  retired?: boolean | null;
  /** Deaths */
  deaths?: number | null;
  /** Corruption */
  corruption?: number | null;
}

/** CharacterXPHistoryResponse */
export interface CharacterXPHistoryResponse {
  /** Character Name */
  character_name: string;
  /** Transactions */
  transactions: XPTransactionResponse[];
}

/** ConsoleError */
export interface ConsoleError {
  /** Message */
  message: string;
  /** Type */
  type: string;
  /** Timestamp */
  timestamp: string;
  /** Stack */
  stack?: string | null;
}

/**
 * CreateCandleTransactionRequest
 * Request to create a new candle transaction
 */
export interface CreateCandleTransactionRequest {
  /**
   * Amount
   * Amount of candles (positive or negative)
   */
  amount: number;
  /**
   * Reason
   * Reason for candle transaction
   * @minLength 1
   * @maxLength 500
   */
  reason: string;
  /**
   * Transaction Type
   * Type of transaction: manual_adjustment, event_attendance, character_creation, referral_bonus
   * @default "manual_adjustment"
   */
  transaction_type?: string;
  /**
   * Character Id
   * Character ID for character_creation transactions
   */
  character_id?: string | null;
  /**
   * Event Id
   * Event ID for event_attendance transactions
   */
  event_id?: string | null;
}

/** CreateEventRequest */
export interface CreateEventRequest {
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /** Chapter Id */
  chapter_id: string;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /**
   * Status
   * @default "scheduled"
   */
  status?: string;
}

/**
 * CreatePhotoTagRequest
 * Request to tag a character in a photo
 */
export interface CreatePhotoTagRequest {
  /**
   * Photo Url
   * Full URL of the photo
   */
  photo_url: string;
  /**
   * Photo Id
   * Google Photos ID
   */
  photo_id: string;
  /**
   * Character Id
   * Character UUID to tag
   */
  character_id: string;
  /**
   * X Position
   * X position percentage
   * @min 0
   * @max 100
   */
  x_position: number;
  /**
   * Y Position
   * Y position percentage
   * @min 0
   * @max 100
   */
  y_position: number;
}

/**
 * CreatePlayerProfileRequest
 * Request model for creating a new player profile
 */
export interface CreatePlayerProfileRequest {
  /**
   * First Name
   * @minLength 1
   * @maxLength 100
   */
  first_name: string;
  /**
   * Last Name
   * @minLength 1
   * @maxLength 100
   */
  last_name: string;
  /** Phone Number */
  phone_number?: string | null;
  /** Emergency Contact Name */
  emergency_contact_name?: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone?: string | null;
  /**
   * Chapter Id
   * Chapter the player belongs to
   * @format uuid
   */
  chapter_id: string;
}

/**
 * CreateRSVPRequest
 * Request to create/update an RSVP
 */
export interface CreateRSVPRequest {
  /** Status */
  status: "going" | "maybe" | "not_attending";
  /**
   * Character Id
   * Character ID for this RSVP (optional)
   */
  character_id?: string | null;
  /**
   * Notes
   * Player notes for this RSVP
   */
  notes?: string | null;
  /**
   * Ticket Xp
   * XP purchased with ticket (0-2)
   * @min 0
   * @max 2
   * @default 0
   */
  ticket_xp?: number;
  /**
   * Candle Xp
   * XP purchased with candles (0-2, costs 10 candles per XP)
   * @min 0
   * @max 2
   * @default 0
   */
  candle_xp?: number;
}

/**
 * CrossChapterPlayer
 * Player who attends multiple chapters.
 */
export interface CrossChapterPlayer {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Chapters Attended */
  chapters_attended: number;
  /** Chapter Names */
  chapter_names: string[];
  /** Total Events */
  total_events: number;
}

/** CultureCreate */
export interface CultureCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Heritage Id
   * UUID of the heritage this culture belongs to
   */
  heritage_id: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /** Costuming Requirements */
  costuming_requirements?: string | null;
  /**
   * Benefit
   * @minLength 1
   */
  benefit: string;
  /** Benefit Name */
  benefit_name?: string | null;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** CultureInfo */
export interface CultureInfo {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Description */
  description: string;
  /** Costuming Requirements */
  costuming_requirements?: string | null;
  /** Benefit */
  benefit: string;
  /** Benefit Name */
  benefit_name?: string | null;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** CultureResponse */
export interface CultureResponse {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Heritage Id
   * UUID of the heritage this culture belongs to
   */
  heritage_id: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /** Costuming Requirements */
  costuming_requirements?: string | null;
  /**
   * Benefit
   * @minLength 1
   */
  benefit: string;
  /** Benefit Name */
  benefit_name?: string | null;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
  /** Id */
  id: string;
  /**
   * Heritage Name
   * Name of the heritage this culture belongs to
   */
  heritage_name: string;
  /** Created At */
  created_at: string;
}

/** CultureUpdate */
export interface CultureUpdate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Heritage Id
   * UUID of the heritage this culture belongs to
   */
  heritage_id: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /** Costuming Requirements */
  costuming_requirements?: string | null;
  /**
   * Benefit
   * @minLength 1
   */
  benefit: string;
  /** Benefit Name */
  benefit_name?: string | null;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/**
 * CustomMilestoneCreate
 * Create a custom player milestone
 */
export interface CustomMilestoneCreate {
  /** Character Id */
  character_id: string;
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /**
   * Category
   * @maxLength 100
   */
  category: string;
  /** Target Progress */
  target_progress?: number | null;
  /** Notes */
  notes?: string | null;
  /**
   * Shared With Staff
   * @default false
   */
  shared_with_staff?: boolean;
}

/**
 * CustomMilestoneResponse
 * Custom milestone response
 */
export interface CustomMilestoneResponse {
  /** Id */
  id: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Current Progress */
  current_progress: number;
  /** Target Progress */
  target_progress: number | null;
  /** Completed */
  completed: boolean;
  /** Notes */
  notes: string | null;
  /** Shared With Staff */
  shared_with_staff: boolean;
  /** Completed At */
  completed_at: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * CustomMilestoneUpdate
 * Update a custom milestone
 */
export interface CustomMilestoneUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Category */
  category?: string | null;
  /** Current Progress */
  current_progress?: number | null;
  /** Target Progress */
  target_progress?: number | null;
  /** Notes */
  notes?: string | null;
  /** Shared With Staff */
  shared_with_staff?: boolean | null;
  /** Completed At */
  completed_at?: string | null;
}

/**
 * EngagedPlayer
 * Top engaged player.
 */
export interface EngagedPlayer {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Events Attended */
  events_attended: number;
  /** Character Count */
  character_count: number;
}

/** EventAttendanceResponse */
export interface EventAttendanceResponse {
  event: EventResponse;
  /** Attendees */
  attendees: AttendeeInfo[];
  /** Total Attendees */
  total_attendees: number;
}

/** EventCreated */
export interface EventCreated {
  /** Id */
  id: string;
  /** Title */
  title: string;
  /** Chapter Id */
  chapter_id: string;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * EventDetail
 * Detailed event information
 */
export interface EventDetail {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Chapter Id
   * @format uuid
   */
  chapter_id: string;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: "scheduled" | "upcoming" | "completed" | "cancelled";
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  chapter: AppApisEventsChapter;
  /**
   * My Rsvps
   * User's RSVPs for this event
   * @default []
   */
  my_rsvps?: RSVPStatus[];
  /**
   * Rsvp Count
   * Total number of RSVPs
   */
  rsvp_count: number;
}

/**
 * EventPerformanceAnalytics
 * Event performance analytics response.
 */
export interface EventPerformanceAnalytics {
  /** Total Events */
  total_events: number;
  /** Total Past Events */
  total_past_events: number;
  /** Monthly Trends */
  monthly_trends: AttendanceTrend[];
  /** Avg Attendance Per Event */
  avg_attendance_per_event: number;
  /** Attendance Trend */
  attendance_trend: string;
  /** Upcoming Events */
  upcoming_events: UpcomingEventRSVP[];
  /** Overall Rsvp Accuracy */
  overall_rsvp_accuracy: number;
  /** No Show Rate */
  no_show_rate: number;
  /** Surprise Attendance Rate */
  surprise_attendance_rate: number;
  /** Rsvp Accuracy By Event */
  rsvp_accuracy_by_event: RSVPAccuracyByEvent[];
  /** Most Attended Events */
  most_attended_events: EventRanking[];
  /** Least Attended Events */
  least_attended_events: EventRanking[];
  /** Chapter Comparisons */
  chapter_comparisons: ChapterComparison[];
  /** XP purchase statistics. */
  xp_purchase_metrics: XPPurchaseMetrics;
  /** Monthly Xp Purchase Trend */
  monthly_xp_purchase_trend: MonthlyXPPurchaseTrend[];
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/**
 * EventRanking
 * Event ranking by attendance.
 */
export interface EventRanking {
  /** Event Id */
  event_id: string;
  /** Title */
  title: string;
  /**
   * Event Date
   * @format date-time
   */
  event_date: string;
  /** Chapter Name */
  chapter_name: string;
  /** Attendance Count */
  attendance_count: number;
}

/** EventResponse */
export interface EventResponse {
  /** Id */
  id: string;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: string;
  /** Rsvp Count */
  rsvp_count: number;
  /** Attended Count */
  attended_count: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * EventSummary
 * Event summary for list views
 */
export interface EventSummary {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Chapter Id
   * @format uuid
   */
  chapter_id: string;
  /** Title */
  title: string;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: "scheduled" | "upcoming" | "completed" | "cancelled";
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  chapter: AppApisEventsChapter;
  /**
   * My Rsvps
   * User's RSVPs for this event
   * @default []
   */
  my_rsvps?: RSVPStatus[];
  /**
   * Rsvp Count
   * Total number of RSVPs
   */
  rsvp_count: number;
}

/** EventUpdated */
export interface EventUpdated {
  /** Id */
  id: string;
  /** Title */
  title: string;
  /** Description */
  description: string | null;
  /** Location */
  location: string | null;
  /** Chapter Id */
  chapter_id: string;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /**
   * Ends At
   * @format date-time
   */
  ends_at: string;
  /** Status */
  status: string;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * EventsAttendedDistribution
 * Distribution of events attended.
 */
export interface EventsAttendedDistribution {
  /** Bracket */
  bracket: string;
  /** Player Count */
  player_count: number;
  /** Percentage */
  percentage: number;
}

/**
 * EventsListResponse
 * Response for events list endpoint
 */
export interface EventsListResponse {
  /** Events */
  events: EventSummary[];
  /** Total */
  total: number;
}

/** ExportStatus */
export interface ExportStatus {
  /** Total Files */
  total_files: number;
  /** Total Migrations */
  total_migrations: number;
  /** Total Size Bytes */
  total_size_bytes: number;
  /** Ready */
  ready: boolean;
}

/** FolderPhotosRequest */
export interface FolderPhotosRequest {
  /** Folder Id */
  folder_id: string;
}

/** FolderPhotosResponse */
export interface FolderPhotosResponse {
  /** Photos */
  photos: GoogleDrivePhoto[];
  /** Folder Name */
  folder_name: string;
  /** Total Count */
  total_count: number;
}

/**
 * GalleryCreate
 * Request to create a new gallery
 */
export interface GalleryCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /** Description */
  description?: string | null;
  /** Event Date */
  event_date?: string | null;
}

/**
 * GalleryResponse
 * Response for a gallery
 */
export interface GalleryResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /** Event Date */
  event_date: string | null;
  /** Created By User Id */
  created_by_user_id: string;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
  /**
   * Photo Count
   * @default 0
   */
  photo_count?: number;
}

/**
 * GalleryUpdate
 * Request to update a gallery
 */
export interface GalleryUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Event Date */
  event_date?: string | null;
}

/** GoogleDrivePhoto */
export interface GoogleDrivePhoto {
  /** File Id */
  file_id: string;
  /** Name */
  name: string;
  /** Thumbnail Url */
  thumbnail_url: string;
  /** Web View Link */
  web_view_link: string;
  /** Direct Link */
  direct_link: string;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** HeritageCreate */
export interface HeritageCreate {
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Costuming Requirements */
  costuming_requirements: string;
  /** Base Body */
  base_body: number;
  /** Base Stamina */
  base_stamina: number;
  /** Benefit */
  benefit: string;
  /** Benefit Name */
  benefit_name: string;
  /** Weakness */
  weakness: string;
  /** Weakness Name */
  weakness_name: string;
  /**
   * Secondary Skill Ids
   * @default []
   */
  secondary_skill_ids?: string[];
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** HeritageInfo */
export interface HeritageInfo {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Costuming Requirements */
  costuming_requirements: string;
  /** Base Body */
  base_body: number;
  /** Base Stamina */
  base_stamina: number;
  /** Benefit */
  benefit: string;
  /** Benefit Name */
  benefit_name: string;
  /** Weakness */
  weakness: string;
  /** Weakness Name */
  weakness_name: string;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** HeritageListResponse */
export interface HeritageListResponse {
  /** Heritages */
  heritages: HeritageResponse[];
  /** Total */
  total: number;
}

/** HeritageResponse */
export interface HeritageResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Costuming Requirements */
  costuming_requirements: string;
  /** Base Body */
  base_body: number;
  /** Base Stamina */
  base_stamina: number;
  /** Benefit */
  benefit: string;
  /** Benefit Name */
  benefit_name: string;
  /** Weakness */
  weakness: string;
  /** Weakness Name */
  weakness_name: string;
  /** Created At */
  created_at: string;
  /**
   * Secondary Skills
   * @default []
   */
  secondary_skills?: AppApisHeritagesSkillSummary[];
  /**
   * Secondary Skill Count
   * @default 0
   */
  secondary_skill_count?: number;
  /**
   * Candle Cost
   * @default 0
   */
  candle_cost?: number;
}

/** HeritageUpdate */
export interface HeritageUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Costuming Requirements */
  costuming_requirements?: string | null;
  /** Base Body */
  base_body?: number | null;
  /** Base Stamina */
  base_stamina?: number | null;
  /** Benefit */
  benefit?: string | null;
  /** Benefit Name */
  benefit_name?: string | null;
  /** Weakness */
  weakness?: string | null;
  /** Weakness Name */
  weakness_name?: string | null;
  /** Secondary Skill Ids */
  secondary_skill_ids?: string[] | null;
  /** Candle Cost */
  candle_cost?: number | null;
}

/**
 * JournalEntryCreate
 * Create a journal entry
 */
export interface JournalEntryCreate {
  /** Character Id */
  character_id: string;
  /**
   * Title
   * @minLength 1
   * @maxLength 255
   */
  title: string;
  /**
   * Content
   * @minLength 1
   */
  content: string;
  /**
   * Tags
   * @default []
   */
  tags?: string[];
  /** Event Id */
  event_id?: string | null;
  /**
   * Shared With Staff
   * @default false
   */
  shared_with_staff?: boolean;
}

/**
 * JournalEntryResponse
 * Journal entry response
 */
export interface JournalEntryResponse {
  /** Id */
  id: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
  /** Tags */
  tags: string[];
  /** Event Id */
  event_id: string | null;
  /** Event Title */
  event_title: string | null;
  /** Shared With Staff */
  shared_with_staff: boolean;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * JournalEntryUpdate
 * Update a journal entry
 */
export interface JournalEntryUpdate {
  /** Title */
  title?: string | null;
  /** Content */
  content?: string | null;
  /** Tags */
  tags?: string[] | null;
  /** Event Id */
  event_id?: string | null;
  /** Shared With Staff */
  shared_with_staff?: boolean | null;
}

/** LoreSubmissionCreate */
export interface LoreSubmissionCreate {
  /** Event Id */
  event_id: string;
  /** Chapter Id */
  chapter_id: string;
  /** Character Id */
  character_id: string;
  /** Lores Used */
  lores_used?: string | null;
  /** Items Used */
  items_used?: string | null;
  /** Outcome */
  outcome: string;
  /** Link */
  link?: string | null;
}

/** LoreSubmissionResponse */
export interface LoreSubmissionResponse {
  /** Id */
  id: string;
  /** Event Id */
  event_id: string;
  /** Event Name */
  event_name: string;
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Lores Used */
  lores_used: string;
  /** Outcome */
  outcome: string;
  /** Items Used */
  items_used: string | null;
  /** Link */
  link: string | null;
  /** Created At */
  created_at: string;
  /** Created By */
  created_by: string;
}

/** LoreSubmissionUpdate */
export interface LoreSubmissionUpdate {
  /** Event Id */
  event_id?: string | null;
  /** Chapter Id */
  chapter_id?: string | null;
  /** Character Id */
  character_id?: string | null;
  /** Lores Used */
  lores_used?: string | null;
  /** Items Used */
  items_used?: string | null;
  /** Outcome */
  outcome?: string | null;
  /** Link */
  link?: string | null;
}

/** ManualRSVPRequest */
export interface ManualRSVPRequest {
  /**
   * Character Id
   * @format uuid
   */
  character_id: string;
  /**
   * Ticket Xp
   * @default 0
   */
  ticket_xp?: number;
  /**
   * Candle Xp
   * @default 0
   */
  candle_xp?: number;
  /** Notes */
  notes?: string | null;
  /**
   * Attendance Status
   * @default "rsvp"
   */
  attendance_status?: "rsvp" | "attended" | "no_show";
}

/** ManualRSVPResponse */
export interface ManualRSVPResponse {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Message */
  message: string;
}

/** MigrationFile */
export interface MigrationFile {
  /** Name */
  name: string;
  /** Order */
  order: number;
  /** Sql */
  sql: string;
  /** Executed At */
  executed_at: string;
}

/**
 * MilestoneAssignmentRequest
 * Request to assign milestone to character
 */
export interface MilestoneAssignmentRequest {
  /** System Milestone Id */
  system_milestone_id: string;
  /** Character Id */
  character_id: string;
  /** Notes */
  notes?: string | null;
}

/**
 * MonthlyXPPurchaseTrend
 * Monthly XP purchase trend.
 */
export interface MonthlyXPPurchaseTrend {
  /** Month */
  month: string;
  /** Year */
  year: number;
  /** Ticket Xp */
  ticket_xp: number;
  /** Candle Xp */
  candle_xp: number;
  /** Total Xp Purchased */
  total_xp_purchased: number;
}

/**
 * MonthlyXPTrend
 * Monthly XP distribution trend.
 */
export interface MonthlyXPTrend {
  /** Month */
  month: string;
  /** Year */
  year: number;
  /** Total Xp */
  total_xp: number;
  /** Candle Xp */
  candle_xp: number;
  /** Event Xp */
  event_xp: number;
}

/**
 * MostPlayedCharacter
 * Most played character.
 */
export interface MostPlayedCharacter {
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Player Name */
  player_name: string;
  /** Events Attended */
  events_attended: number;
}

/**
 * MyRSVP
 * User's RSVP with event summary
 */
export interface MyRSVP {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Status */
  status: "going" | "maybe" | "not_attending";
  /** Character Id */
  character_id?: string | null;
  /** Character Name */
  character_name?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Ticket Xp
   * @default 0
   */
  ticket_xp?: number;
  /**
   * Candle Xp
   * @default 0
   */
  candle_xp?: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Event summary for list views */
  event: EventSummary;
}

/**
 * MyRSVPsResponse
 * Response for user's RSVPs endpoint
 */
export interface MyRSVPsResponse {
  /** Rsvps */
  rsvps: MyRSVP[];
  /** Total */
  total: number;
}

/**
 * NegativeBalanceError
 * Error response for transactions causing negative balance
 */
export interface NegativeBalanceError {
  /** Would Cause Negative */
  would_cause_negative: boolean;
  /** Current Balance */
  current_balance: number;
  /** Requested Amount */
  requested_amount: number;
}

/** OptimizeBuildRequest */
export interface OptimizeBuildRequest {
  /** Selected Skills */
  selected_skills: AppApisBuildOptimizerSelectedSkillRequest[];
  /** Heritage Id */
  heritage_id: string;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /**
   * Include Three Archetypes
   * @default false
   */
  include_three_archetypes?: boolean;
}

/**
 * OptionDistribution
 * Distribution of archetype/heritage/culture.
 */
export interface OptionDistribution {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Count */
  count: number;
  /** Percentage */
  percentage: number;
}

/**
 * OrphanedOption
 * Unused option.
 */
export interface OrphanedOption {
  /** Type */
  type: string;
  /** Id */
  id: string;
  /** Name */
  name: string;
}

/**
 * Permission
 * Permission model
 */
export interface Permission {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
}

/**
 * PhotoCreate
 * Request to create a new photo
 *
 * For Google Drive photos, use the direct image URL format:
 * https://drive.google.com/uc?export=view&id=FILE_ID
 */
export interface PhotoCreate {
  /**
   * Photo Url
   * URL to the photo (e.g., Google Drive direct link)
   */
  photo_url: string;
  /** Thumbnail Url */
  thumbnail_url?: string | null;
  /** Description */
  description?: string | null;
  /**
   * Display Order
   * @min 0
   * @default 0
   */
  display_order?: number;
}

/** PhotoReorderRequest */
export interface PhotoReorderRequest {
  /** Photo Ids */
  photo_ids: string[];
}

/**
 * PhotoResponse
 * Response for a photo
 */
export interface PhotoResponse {
  /** Gallery Id */
  gallery_id: string;
  /** Photo Url */
  photo_url: string;
  /** Thumbnail Url */
  thumbnail_url: string | null;
  /** Photo Id */
  photo_id: string;
  /** Description */
  description: string | null;
  /** Display Order */
  display_order: number;
}

/**
 * PhotoTagResponse
 * Response for a photo tag
 */
export interface PhotoTagResponse {
  /** Id */
  id: string;
  /** Photo Url */
  photo_url: string;
  /** Photo Id */
  photo_id: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Player Name */
  player_name: string;
  /** Tagged By User Id */
  tagged_by_user_id: string;
  /** Tagged By Name */
  tagged_by_name: string;
  /** X Position */
  x_position: number;
  /** Y Position */
  y_position: number;
  /** Created At */
  created_at: string;
}

/**
 * PhotoUpdate
 * Request to update a photo
 */
export interface PhotoUpdate {
  /** Photo Url */
  photo_url?: string | null;
  /** Thumbnail Url */
  thumbnail_url?: string | null;
  /** Description */
  description?: string | null;
  /** Display Order */
  display_order?: number | null;
}

/**
 * PlayerAssignedRole
 * Role assigned to a player, optionally scoped to a chapter
 */
export interface PlayerAssignedRole {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string | null;
  /**
   * Permissions
   * @default []
   */
  permissions?: Permission[];
  /** Chapter Id */
  chapter_id?: string | null;
  /** Chapter Name */
  chapter_name?: string | null;
}

/**
 * PlayerDetailResponse
 * Detailed player information for editing
 */
export interface PlayerDetailResponse {
  /** Id */
  id: string;
  /** User Id */
  user_id: string;
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /** Phone Number */
  phone_number: string | null;
  /** Emergency Contact Name */
  emergency_contact_name: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone: string | null;
  /** Chapter Id */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Player Number */
  player_number: string;
  /** Candles Available */
  candles_available: number;
  /**
   * Roles
   * @default []
   */
  roles?: PlayerAssignedRole[];
  /**
   * Is Admin
   * @default false
   */
  is_admin?: boolean;
  /** Email */
  email?: string | null;
  /** Referred By Player Id */
  referred_by_player_id?: string | null;
  /** Referred By Player Name */
  referred_by_player_name?: string | null;
  /** Referred By Player Number */
  referred_by_player_number?: string | null;
  /**
   * Referral Acknowledged
   * @default false
   */
  referral_acknowledged?: boolean;
  /** Referral Acknowledged At */
  referral_acknowledged_at?: string | null;
  /** Referral Acknowledged By User Id */
  referral_acknowledged_by_user_id?: string | null;
  /** Referral Acknowledged By Name */
  referral_acknowledged_by_name?: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * PlayerEngagementAnalytics
 * Player engagement analytics response.
 */
export interface PlayerEngagementAnalytics {
  /** Total Players */
  total_players: number;
  /** Active Players */
  active_players: number;
  /** Inactive Players */
  inactive_players: number;
  /** Active Rate */
  active_rate: number;
  /** Activity Breakdown */
  activity_breakdown: ActivityStatusBreakdown[];
  /** Retention Cohorts */
  retention_cohorts: RetentionCohort[];
  /** Overall Churn Rate */
  overall_churn_rate: number;
  /** New Player Conversion Rate */
  new_player_conversion_rate: number;
  /** Avg Events Per Player */
  avg_events_per_player: number;
  /** Events Distribution */
  events_distribution: EventsAttendedDistribution[];
  /** Top Engaged Players */
  top_engaged_players: EngagedPlayer[];
  /** At Risk Players */
  at_risk_players: AtRiskPlayer[];
  /** Avg Characters Per Player */
  avg_characters_per_player: number;
  /** Character Distribution */
  character_distribution: CharacterCountDistribution[];
  /** Most Played Characters */
  most_played_characters: MostPlayedCharacter[];
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/**
 * PlayerListItem
 * Individual player for referral selection
 */
export interface PlayerListItem {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Name */
  name: string;
  /** Player Number */
  player_number: string;
  /**
   * Chapter Id
   * @format uuid
   */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
}

/**
 * PlayerProfile
 * Player profile response model
 */
export interface PlayerProfile {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** User Id */
  user_id: string;
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /** Phone Number */
  phone_number: string | null;
  /** Emergency Contact Name */
  emergency_contact_name: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone: string | null;
  /**
   * Chapter Id
   * @format uuid
   */
  chapter_id: string;
  /** Chapter Name */
  chapter_name: string;
  /** Player Number */
  player_number: string;
  /** Candles Available */
  candles_available: number;
  /** Email */
  email: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Updated At
   * @format date-time
   */
  updated_at: string;
  /** Referred By Player Id */
  referred_by_player_id?: string | null;
  /** Referred By Player Name */
  referred_by_player_name?: string | null;
  /** Referred By Player Number */
  referred_by_player_number?: string | null;
  /**
   * Referral Acknowledged
   * @default false
   */
  referral_acknowledged?: boolean;
  /** Referral Acknowledged At */
  referral_acknowledged_at?: string | null;
  /** Referral Acknowledged By User Id */
  referral_acknowledged_by_user_id?: string | null;
  /** Referral Acknowledged By Name */
  referral_acknowledged_by_name?: string | null;
}

/**
 * PlayerProfileSync
 * Player profile data for sync from production to development
 */
export interface PlayerProfileSync {
  /** User Id */
  user_id: string;
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /** Phone Number */
  phone_number?: string | null;
  /** Emergency Contact Name */
  emergency_contact_name?: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone?: string | null;
  /** Player Number */
  player_number?: string | null;
  /** Chapter Id */
  chapter_id?: string | null;
  /**
   * Candles Available
   * @default 0
   */
  candles_available?: number | null;
  /**
   * Is Admin
   * @default false
   */
  is_admin?: boolean | null;
  /** Email */
  email?: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * PublicPhotoResponse
 * Public response for photos (for PhotoGallery page)
 */
export interface PublicPhotoResponse {
  /** Photo Id */
  photo_id: string;
  /** Photo Url */
  photo_url: string;
  /** Thumbnail Url */
  thumbnail_url: string | null;
  /** Description */
  description: string | null;
  /** Gallery Name */
  gallery_name: string;
  /** Event Date */
  event_date: string | null;
  /**
   * Tags
   * @default []
   */
  tags?: Record<string, any>[];
}

/**
 * RSVPAccuracyByEvent
 * RSVP accuracy for a specific event.
 */
export interface RSVPAccuracyByEvent {
  /** Event Id */
  event_id: string;
  /** Title */
  title: string;
  /**
   * Event Date
   * @format date-time
   */
  event_date: string;
  /** Rsvp Yes Count */
  rsvp_yes_count: number;
  /** Actual Attended */
  actual_attended: number;
  /** Accuracy Rate */
  accuracy_rate: number;
}

/**
 * RSVPResponse
 * RSVP creation/update response
 */
export interface RSVPResponse {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Event Id
   * @format uuid
   */
  event_id: string;
  /** User Id */
  user_id: string;
  /** Status */
  status: "going" | "maybe" | "not_attending";
  /** Character Id */
  character_id?: string | null;
  /** Character Name */
  character_name?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Ticket Xp
   * @default 0
   */
  ticket_xp?: number;
  /**
   * Candle Xp
   * @default 0
   */
  candle_xp?: number;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * RSVPStatus
 * RSVP status information
 */
export interface RSVPStatus {
  /** Status */
  status: "going" | "maybe" | "not_attending";
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /** Character Id */
  character_id?: string | null;
  /** Character Name */
  character_name?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Ticket Xp
   * @default 0
   */
  ticket_xp?: number;
  /**
   * Candle Xp
   * @default 0
   */
  candle_xp?: number;
  /**
   * Attendance Status
   * @default "rsvp"
   */
  attendance_status?: string | null;
}

/** ReassignmentHistoryRecord */
export interface ReassignmentHistoryRecord {
  /** Id */
  id: string;
  /** Character Id */
  character_id: string;
  /** From Player Name */
  from_player_name: string | null;
  /** To Player Name */
  to_player_name: string;
  /** Reassigned By Name */
  reassigned_by_name: string;
  /** Notes */
  notes: string | null;
  /** Reassigned At */
  reassigned_at: string;
}

/** ReassignmentRequest */
export interface ReassignmentRequest {
  /** Character Id */
  character_id: string;
  /** To Player Id */
  to_player_id: string;
  /** Notes */
  notes?: string | null;
}

/**
 * ReferralListResponse
 * Response for referral list
 */
export interface ReferralListResponse {
  /** Referrals */
  referrals: ReferralRecord[];
  /** Total Count */
  total_count: number;
}

/**
 * ReferralRecord
 * Individual referral record
 */
export interface ReferralRecord {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /**
   * Player Id
   * @format uuid
   */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /**
   * Referred By Id
   * @format uuid
   */
  referred_by_id: string;
  /** Referred By Name */
  referred_by_name: string;
  /** Referred By Number */
  referred_by_number: string;
  /** Referral Acknowledged */
  referral_acknowledged: boolean;
  /** Referral Acknowledged At */
  referral_acknowledged_at: string | null;
  /** Referral Acknowledged By User Id */
  referral_acknowledged_by_user_id: string | null;
  /** Referral Acknowledged By Name */
  referral_acknowledged_by_name: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * ReferralStatsResponse
 * Statistics about referrals
 */
export interface ReferralStatsResponse {
  /** Total Referrals */
  total_referrals: number;
  /** Pending Referrals */
  pending_referrals: number;
  /** Acknowledged Referrals */
  acknowledged_referrals: number;
  /** Top Referrers */
  top_referrers: TopReferrer[];
}

/**
 * RetentionCohort
 * Player retention by cohort.
 */
export interface RetentionCohort {
  /** Month */
  month: string;
  /** Year */
  year: number;
  /** New Players */
  new_players: number;
  /** Retained 1Mo */
  retained_1mo: number;
  /** Retained 3Mo */
  retained_3mo: number;
  /** Retained 6Mo */
  retained_6mo: number;
  /** Retained 1Yr */
  retained_1yr: number;
  /** Retention 1Mo Rate */
  retention_1mo_rate: number;
  /** Retention 3Mo Rate */
  retention_3mo_rate: number;
  /** Retention 6Mo Rate */
  retention_6mo_rate: number;
  /** Retention 1Yr Rate */
  retention_1yr_rate: number;
}

/**
 * Role
 * Role model with permissions
 */
export interface Role {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Permissions */
  permissions?: Permission[];
  /**
   * Is System Role
   * @default false
   */
  is_system_role?: boolean;
  /**
   * User Count
   * @default 0
   */
  user_count?: number;
}

/**
 * RoleAssignment
 * Input model for assigning a role
 */
export interface RoleAssignment {
  /** Role Id */
  role_id: string;
  /** Chapter Id */
  chapter_id?: string | null;
}

/**
 * RoleCreate
 * Role creation model
 */
export interface RoleCreate {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Permission Ids
   * @default []
   */
  permission_ids?: string[];
}

/**
 * RoleUpdate
 * Role update model
 */
export interface RoleUpdate {
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /**
   * Permission Ids
   * @default []
   */
  permission_ids?: string[];
}

/**
 * SharedJournalResponse
 * Shared journal entry with player/character info
 */
export interface SharedJournalResponse {
  /** Id */
  id: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Chapter Name */
  chapter_name: string;
  /** Title */
  title: string;
  /** Content */
  content: string;
  /** Tags */
  tags: string[];
  /** Event Id */
  event_id: string | null;
  /** Event Title */
  event_title: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * SharedMilestoneResponse
 * Shared milestone with player/character info
 */
export interface SharedMilestoneResponse {
  /** Id */
  id: string;
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Chapter Name */
  chapter_name: string;
  /** Is Custom */
  is_custom: boolean;
  /** Milestone Name */
  milestone_name: string;
  /** Milestone Description */
  milestone_description: string;
  /** Category */
  category: string;
  /** Current Progress */
  current_progress: number;
  /** Target Progress */
  target_progress: number | null;
  /** Completed */
  completed: boolean;
  /** Notes */
  notes: string | null;
  /** Completed At */
  completed_at: string | null;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/** SkillCreate */
export interface SkillCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 100
   */
  name: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /**
   * Hidden
   * @default false
   */
  hidden?: boolean;
  /**
   * Admin Only
   * @default false
   */
  admin_only?: boolean;
  /**
   * Prerequisite Skill Ids
   * @default []
   */
  prerequisite_skill_ids?: string[];
  /**
   * Prerequisite Count
   * @min 0
   * @default 0
   */
  prerequisite_count?: number;
  /**
   * Max Purchases
   * @min 1
   * @max 10
   * @default 1
   */
  max_purchases?: number;
}

/** SkillInfo */
export interface SkillInfo {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Is Primary */
  is_primary: boolean;
  /** Is Secondary */
  is_secondary: boolean;
  /** Xp Cost */
  xp_cost: number;
}

/** SkillListResponse */
export interface SkillListResponse {
  /** Skills */
  skills: SkillResponse[];
  /** Total */
  total: number;
}

/**
 * SkillPopularity
 * Skill popularity metrics.
 */
export interface SkillPopularity {
  /** Skill Id */
  skill_id: string;
  /** Skill Name */
  skill_name: string;
  /** Character Count */
  character_count: number;
  /** Percentage */
  percentage: number;
}

/** SkillResponse */
export interface SkillResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Hidden */
  hidden: boolean;
  /** Admin Only */
  admin_only: boolean;
  /** Prerequisite Count */
  prerequisite_count: number;
  /** Max Purchases */
  max_purchases: number;
  /** Prerequisites */
  prerequisites?: SkillResponse[];
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * SkillSynergy
 * Skill pair synergy.
 */
export interface SkillSynergy {
  /** Skill1 Id */
  skill1_id: string;
  /** Skill1 Name */
  skill1_name: string;
  /** Skill2 Id */
  skill2_id: string;
  /** Skill2 Name */
  skill2_name: string;
  /** Pair Count */
  pair_count: number;
}

/** SkillUpdate */
export interface SkillUpdate {
  /**
   * Name
   * @minLength 1
   * @maxLength 100
   */
  name: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /**
   * Hidden
   * @default false
   */
  hidden?: boolean;
  /**
   * Admin Only
   * @default false
   */
  admin_only?: boolean;
  /**
   * Prerequisite Skill Ids
   * @default []
   */
  prerequisite_skill_ids?: string[];
  /**
   * Prerequisite Count
   * @min 0
   * @default 0
   */
  prerequisite_count?: number;
  /**
   * Max Purchases
   * @min 1
   * @max 10
   * @default 1
   */
  max_purchases?: number;
}

/**
 * StatDistribution
 * Distribution of a stat value.
 */
export interface StatDistribution {
  /** Value */
  value: number;
  /** Count */
  count: number;
}

/**
 * SyncPlayerProfilesRequest
 * Request body for syncing player profiles from production
 */
export interface SyncPlayerProfilesRequest {
  /** Player Profiles */
  player_profiles: PlayerProfileSync[];
}

/**
 * SyncResponse
 * Response for sync operations
 */
export interface SyncResponse {
  /** Success */
  success: boolean;
  /** Message */
  message: string;
  /** Synced Count */
  synced_count: number;
}

/**
 * SystemMilestoneCreate
 * Create a new system milestone definition
 */
export interface SystemMilestoneCreate {
  /**
   * Name
   * @minLength 1
   * @maxLength 255
   */
  name: string;
  /**
   * Description
   * @minLength 1
   */
  description: string;
  /**
   * Category
   * @maxLength 100
   */
  category: string;
  /**
   * Milestone Type
   * event_count, xp_total, skill_count, candle_total, character_age_days
   */
  milestone_type: string;
  /**
   * Threshold Value
   * @exclusiveMin 0
   */
  threshold_value: number;
  /**
   * Enabled
   * @default true
   */
  enabled?: boolean;
}

/**
 * SystemMilestoneProgress
 * System milestone with calculated progress
 */
export interface SystemMilestoneProgress {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Milestone Type */
  milestone_type: string;
  /** Threshold Value */
  threshold_value: number;
  /** Current Progress */
  current_progress: number;
  /** Completed */
  completed: boolean;
  /** Player Milestone Id */
  player_milestone_id?: string | null;
  /** Notes */
  notes?: string | null;
  /**
   * Shared With Staff
   * @default false
   */
  shared_with_staff?: boolean;
  /** Completed At */
  completed_at?: string | null;
  /** Awarded By */
  awarded_by?: string | null;
  /** Awarded By User Name */
  awarded_by_user_name?: string | null;
}

/**
 * SystemMilestoneResponse
 * System milestone definition
 */
export interface SystemMilestoneResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
  /** Category */
  category: string;
  /** Milestone Type */
  milestone_type: string;
  /** Threshold Value */
  threshold_value: number;
  /** Enabled */
  enabled: boolean;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * SystemMilestoneUpdate
 * Update a system milestone definition
 */
export interface SystemMilestoneUpdate {
  /** Name */
  name?: string | null;
  /** Description */
  description?: string | null;
  /** Category */
  category?: string | null;
  /** Milestone Type */
  milestone_type?: string | null;
  /** Threshold Value */
  threshold_value?: number | null;
  /** Enabled */
  enabled?: boolean | null;
}

/**
 * TestCharacterCreate
 * Request model for creating a test character.
 */
export interface TestCharacterCreate {
  /** Name */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Culture Id */
  culture_id: string;
  /** Archetype Id */
  archetype_id: string;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /**
   * Corruption
   * @default 0
   */
  corruption?: number;
  /**
   * Deaths
   * @default 0
   */
  deaths?: number;
  /** Selected Skills */
  selected_skills: AppApisTestCharactersSelectedSkillRequest[];
}

/**
 * TestCharacterListResponse
 * Response model for listing test characters.
 */
export interface TestCharacterListResponse {
  /** Test Characters */
  test_characters: TestCharacterResponse[];
  /** Count */
  count: number;
  /**
   * Max Allowed
   * @default 3
   */
  max_allowed?: number;
}

/**
 * TestCharacterResponse
 * Response model for a test character.
 */
export interface TestCharacterResponse {
  /** Id */
  id: string;
  /** User Id */
  user_id: string;
  /** Name */
  name: string;
  /** Heritage Id */
  heritage_id: string;
  /** Culture Id */
  culture_id: string;
  /** Archetype Id */
  archetype_id: string;
  /** Secondary Archetype Id */
  secondary_archetype_id: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id: string | null;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /** Corruption */
  corruption: number;
  /** Deaths */
  deaths: number;
  /** Selected Skills */
  selected_skills: Record<string, any>[];
  /** Xp Cost */
  xp_cost: number;
  /** Created At */
  created_at: string;
  /** Updated At */
  updated_at: string;
}

/**
 * TestCharacterUpdate
 * Request model for updating a test character.
 */
export interface TestCharacterUpdate {
  /** Name */
  name?: string | null;
  /** Heritage Id */
  heritage_id?: string | null;
  /** Culture Id */
  culture_id?: string | null;
  /** Archetype Id */
  archetype_id?: string | null;
  /** Secondary Archetype Id */
  secondary_archetype_id?: string | null;
  /** Tertiary Archetype Id */
  tertiary_archetype_id?: string | null;
  /** Body */
  body?: number | null;
  /** Stamina */
  stamina?: number | null;
  /** Corruption */
  corruption?: number | null;
  /** Deaths */
  deaths?: number | null;
  /** Selected Skills */
  selected_skills?: AppApisTestCharactersSelectedSkillRequest[] | null;
}

/**
 * TopReferrer
 * Top referrer statistics
 */
export interface TopReferrer {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Referral Count */
  referral_count: number;
}

/**
 * TopXPEarner
 * Top XP earner.
 */
export interface TopXPEarner {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Player Number */
  player_number: string;
  /** Total Xp */
  total_xp: number;
}

/**
 * UpcomingEventRSVP
 * Upcoming event with RSVP counts.
 */
export interface UpcomingEventRSVP {
  /** Event Id */
  event_id: string;
  /** Title */
  title: string;
  /**
   * Starts At
   * @format date-time
   */
  starts_at: string;
  /** Chapter Name */
  chapter_name: string;
  /** Rsvp Count */
  rsvp_count: number;
  /** Going Count */
  going_count: number;
}

/** UpdateAttendanceRequest */
export interface UpdateAttendanceRequest {
  /** Rsvp Id */
  rsvp_id: string;
  /** Attendance Status */
  attendance_status: "rsvp" | "attended" | "no_show";
  /** Ticket Xp */
  ticket_xp?: number | null;
  /** Candle Xp */
  candle_xp?: number | null;
  /** Notes */
  notes?: string | null;
}

/**
 * UpdateCandleTransactionRequest
 * Request to update an existing candle transaction
 */
export interface UpdateCandleTransactionRequest {
  /**
   * Amount
   * New amount
   */
  amount: number;
  /**
   * Reason
   * Updated reason
   * @minLength 1
   * @maxLength 500
   */
  reason: string;
  /**
   * Transaction Type
   * Type of transaction
   * @default "manual_adjustment"
   */
  transaction_type?: string;
  /**
   * Character Id
   * Character ID for character_creation transactions
   */
  character_id?: string | null;
  /**
   * Event Id
   * Event ID for event_attendance transactions
   */
  event_id?: string | null;
}

/** UpdateEventRequest */
export interface UpdateEventRequest {
  /** Title */
  title?: string | null;
  /** Description */
  description?: string | null;
  /** Location */
  location?: string | null;
  /** Chapter Id */
  chapter_id?: string | null;
  /** Starts At */
  starts_at?: string | null;
  /** Ends At */
  ends_at?: string | null;
  /** Status */
  status?: "scheduled" | "completed" | "cancelled" | "upcoming" | null;
}

/**
 * UpdatePlayerNumberRequest
 * Request model for updating player number (admin only)
 */
export interface UpdatePlayerNumberRequest {
  /**
   * Player Number
   * @minLength 9
   * @maxLength 9
   * @pattern ^[A-Z]{2}\d{7}$
   */
  player_number: string;
  /**
   * Reason
   * Reason for changing player number
   * @minLength 1
   * @maxLength 500
   */
  reason: string;
}

/**
 * UpdatePlayerRolesRequest
 * Request to update player roles
 */
export interface UpdatePlayerRolesRequest {
  /**
   * Assignments
   * List of roles to assign to player
   */
  assignments: RoleAssignment[];
  /**
   * Reason
   * Reason for role change
   * @minLength 1
   * @maxLength 500
   */
  reason: string;
}

/** User */
export interface User {
  /** Sub */
  sub: string;
  /** User Id */
  user_id?: string | null;
  /** Name */
  name?: string | null;
  /** Picture */
  picture?: string | null;
  /** Email */
  email?: string | null;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/**
 * XPBracketDistribution
 * Player count by XP bracket.
 */
export interface XPBracketDistribution {
  /** Bracket */
  bracket: string;
  /** Player Count */
  player_count: number;
  /** Percentage */
  percentage: number;
}

/** XPCostCalculation */
export interface XPCostCalculation {
  /** Body Cost */
  body_cost: number;
  /** Stamina Cost */
  stamina_cost: number;
  /** Total Cost */
  total_cost: number;
}

/**
 * XPEconomyAnalytics
 * XP economy analytics response.
 */
export interface XPEconomyAnalytics {
  /** Xp Brackets */
  xp_brackets: XPBracketDistribution[];
  /** Average Xp Per Player */
  average_xp_per_player: number;
  /** Median Xp Per Player */
  median_xp_per_player: number;
  /** Top Earners */
  top_earners: TopXPEarner[];
  /** Spending By Category */
  spending_by_category: XPSpendingCategory[];
  /** Avg Xp Spent Per Character */
  avg_xp_spent_per_character: number;
  /** Skill Type Spending */
  skill_type_spending: Record<string, any>;
  /** Monthly Xp Trend */
  monthly_xp_trend: MonthlyXPTrend[];
  /** Avg Xp Per Event */
  avg_xp_per_event: number;
  /** Candle purchase metrics. */
  candle_metrics: CandleMetrics;
  /** Total Characters Analyzed */
  total_characters_analyzed: number;
  /**
   * Last Updated
   * @format date-time
   */
  last_updated: string;
}

/**
 * XPPurchaseMetrics
 * XP purchase statistics.
 */
export interface XPPurchaseMetrics {
  /** Total Ticket Xp Purchased */
  total_ticket_xp_purchased: number;
  /** Total Candle Xp Purchased */
  total_candle_xp_purchased: number;
  /** Total Xp Purchased */
  total_xp_purchased: number;
  /** Avg Ticket Xp Per Event */
  avg_ticket_xp_per_event: number;
  /** Avg Candle Xp Per Event */
  avg_candle_xp_per_event: number;
  /** Players Purchasing Ticket Xp */
  players_purchasing_ticket_xp: number;
  /** Players Purchasing Candle Xp */
  players_purchasing_candle_xp: number;
  /** Candles Spent On Xp */
  candles_spent_on_xp: number;
}

/**
 * XPSpendingCategory
 * XP spending by category.
 */
export interface XPSpendingCategory {
  /** Category */
  category: string;
  /** Total Xp */
  total_xp: number;
  /** Percentage */
  percentage: number;
}

/** XPTransaction */
export interface XPTransaction {
  /** Id */
  id: string;
  /** Amount */
  amount: number;
  /** Transaction Type */
  transaction_type: string;
  /** Reason */
  reason: string;
  /** Skill Id */
  skill_id?: string | null;
  /** Body Points */
  body_points?: number | null;
  /** Stamina Points */
  stamina_points?: number | null;
  /** Created At */
  created_at: string;
}

/** XPTransactionResponse */
export interface XPTransactionResponse {
  /** Id */
  id: string;
  /** Amount */
  amount: number;
  /** Transaction Type */
  transaction_type: string;
  /** Reason */
  reason: string;
  /** Skill Id */
  skill_id?: string | null;
  /** Body Points */
  body_points?: number | null;
  /** Stamina Points */
  stamina_points?: number | null;
  /** Created At */
  created_at: string;
}

/** Chapter */
export interface AppApisAdminChapter {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Chapter Code */
  chapter_code?: string | null;
  /** Location */
  location?: string | null;
  /** Contact Email */
  contact_email?: string | null;
  /** Website */
  website?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/** ChapterListResponse */
export interface AppApisAdminChapterListResponse {
  /** Chapters */
  chapters: AppApisAdminChapterResponse[];
}

/** ChapterResponse */
export interface AppApisAdminChapterResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Chapter Code */
  chapter_code?: string | null;
  /** Location */
  location?: string | null;
  /** Contact Email */
  contact_email?: string | null;
  /** Website */
  website?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * CandleHistoryResponse
 * Response with player candle info and transaction history
 */
export interface AppApisAdminPlayersCandleHistoryResponse {
  /** Player Id */
  player_id: string;
  /** Player Name */
  player_name: string;
  /** Current Balance */
  current_balance: number;
  /** Transactions */
  transactions: AppApisAdminPlayersCandleTransaction[];
}

/**
 * CandleTransaction
 * Candle transaction history entry
 */
export interface AppApisAdminPlayersCandleTransaction {
  /** Id */
  id: string;
  /** Player Profile Id */
  player_profile_id: string;
  /** Amount */
  amount: number;
  /** Reason */
  reason: string;
  /** Transaction Type */
  transaction_type?: string | null;
  /** Character Id */
  character_id?: string | null;
  /** Character Name */
  character_name?: string | null;
  /** Event Id */
  event_id?: string | null;
  /** Event Name */
  event_name?: string | null;
  /** Granted By User Id */
  granted_by_user_id: string | null;
  /** Granted By Name */
  granted_by_name: string | null;
  /** Created At */
  created_at: string;
}

/**
 * CharacterSummary
 * Summary of character info for player list
 */
export interface AppApisAdminPlayersCharacterSummary {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Name */
  heritage_name: string;
  /** Culture Name */
  culture_name: string;
  /** Archetype Name */
  archetype_name: string;
  /**
   * Status
   * @default "Active"
   */
  status?: string;
}

/**
 * PlayerSummary
 * Player summary for management table
 */
export interface AppApisAdminPlayersPlayerSummary {
  /** Id */
  id: string;
  /** User Id */
  user_id: string;
  /** First Name */
  first_name: string;
  /** Last Name */
  last_name: string;
  /** Player Number */
  player_number: string;
  /** Email */
  email?: string | null;
  /** Chapter Name */
  chapter_name: string;
  /** Character Count */
  character_count: number;
  /**
   * Roles
   * @default []
   */
  roles?: string[];
  /**
   * Is Admin
   * @default false
   */
  is_admin?: boolean;
  /** Created At */
  created_at: string;
}

/**
 * UpdatePlayerProfileRequest
 * Request to update player profile (admin)
 */
export interface AppApisAdminPlayersUpdatePlayerProfileRequest {
  /** First Name */
  first_name?: string | null;
  /** Last Name */
  last_name?: string | null;
  /** Phone Number */
  phone_number?: string | null;
  /** Emergency Contact Name */
  emergency_contact_name?: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone?: string | null;
  /** Chapter Id */
  chapter_id?: string | null;
  /** Player Number */
  player_number?: string | null;
  /** Referred By Player Id */
  referred_by_player_id?: string | null;
  /**
   * Reason
   * Reason for changes
   * @minLength 1
   * @maxLength 500
   */
  reason: string;
}

/** ChapterListResponse */
export interface AppApisAdminScopedChapterListResponse {
  /** Chapters */
  chapters: AppApisAdminScopedChapterResponse[];
}

/** ChapterResponse */
export interface AppApisAdminScopedChapterResponse {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
}

/** SkillSummary */
export interface AppApisArchetypesSkillSummary {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description: string;
}

/** SelectedSkillRequest */
export interface AppApisBuildOptimizerSelectedSkillRequest {
  /** Skill Id */
  skill_id: string;
  /** Quantity */
  quantity: number;
}

/** CharacterSummary */
export interface AppApisCharacterReassignmentCharacterSummary {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Name */
  heritage_name: string;
  /** Culture Name */
  culture_name: string;
  /** Archetype Name */
  archetype_name: string;
  /** Player Id */
  player_id: string | null;
  /** Player Name */
  player_name: string | null;
}

/** PlayerSummary */
export interface AppApisCharacterReassignmentPlayerSummary {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Player Number */
  player_number: string;
}

/** CharacterListItem */
export interface AppApisCharactersCharacterListItem {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Heritage Name */
  heritage_name: string;
  /** Culture Name */
  culture_name: string;
  /** Archetype Name */
  archetype_name: string;
  /** Secondary Archetype Name */
  secondary_archetype_name?: string | null;
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /** Xp Available */
  xp_available: number;
  /** Xp Total */
  xp_total: number;
  /** Retired */
  retired: boolean;
  /**
   * Deaths
   * @default 0
   */
  deaths?: number;
  /**
   * Corruption
   * @default 0
   */
  corruption?: number;
  /** Events Attended */
  events_attended: number;
  /** Skill Count */
  skill_count: number;
}

/** Chapter */
export interface AppApisEventsChapter {
  /** Id */
  id: string;
  /** Name */
  name: string;
  /** Description */
  description?: string | null;
  /** Chapter Code */
  chapter_code?: string | null;
  /** Location */
  location?: string | null;
  /** Contact Email */
  contact_email?: string | null;
  /** Website */
  website?: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
  /**
   * Member Count
   * Number of players in this chapter
   * @default 0
   */
  member_count?: number;
}

/** ChapterListResponse */
export interface AppApisEventsChapterListResponse {
  /** Chapters */
  chapters: AppApisEventsChapter[];
}

/** CharacterListItem */
export interface AppApisFaceToNameCharacterListItem {
  /** Character Id */
  character_id: string;
  /** Character Name */
  character_name: string;
  /** Heritage Name */
  heritage_name: string;
  /** Culture Name */
  culture_name: string;
  /** Player Name */
  player_name: string;
  /** Chapter Name */
  chapter_name: string;
  /** Photo Count */
  photo_count: number;
}

/** SkillSummary */
export interface AppApisHeritagesSkillSummary {
  /** Id */
  id: string;
  /** Name */
  name: string;
}

/**
 * CandleHistoryResponse
 * Response model for candle history
 */
export interface AppApisPlayersCandleHistoryResponse {
  /** Transactions */
  transactions: AppApisPlayersCandleTransaction[];
  /** Total Earned */
  total_earned: number;
  /** Total Spent */
  total_spent: number;
  /** Current Balance */
  current_balance: number;
}

/**
 * CandleTransaction
 * Candle transaction model
 */
export interface AppApisPlayersCandleTransaction {
  /**
   * Id
   * @format uuid
   */
  id: string;
  /** Amount */
  amount: number;
  /** Reason */
  reason: string;
  /** Granted By User Id */
  granted_by_user_id: string | null;
  /** Granted By Name */
  granted_by_name: string | null;
  /** Used For */
  used_for: string | null;
  /**
   * Created At
   * @format date-time
   */
  created_at: string;
}

/**
 * UpdatePlayerProfileRequest
 * Request model for updating player profile
 */
export interface AppApisPlayersUpdatePlayerProfileRequest {
  /** First Name */
  first_name?: string | null;
  /** Last Name */
  last_name?: string | null;
  /** Phone Number */
  phone_number?: string | null;
  /** Emergency Contact Name */
  emergency_contact_name?: string | null;
  /** Emergency Contact Phone */
  emergency_contact_phone?: string | null;
  /**
   * Email
   * Player email address
   */
  email?: string | null;
  /** Referred By Player Id */
  referred_by_player_id?: string | null;
}

/**
 * SelectedSkillRequest
 * Skill purchase for test character.
 */
export interface AppApisTestCharactersSelectedSkillRequest {
  /** Skill Id */
  skill_id: string;
  /** Quantity */
  quantity: number;
}

export type CheckHealthData = HealthResponse;

export type CreateLoreSubmissionData = LoreSubmissionResponse;

export type CreateLoreSubmissionError = HTTPValidationError;

export interface GetAdminLoreSubmissionsParams {
  /** Chapter Id */
  chapter_id?: string | null;
  /** Event Id */
  event_id?: string | null;
  /** Character Id */
  character_id?: string | null;
}

/** Response Get Admin Lore Submissions */
export type GetAdminLoreSubmissionsData = LoreSubmissionResponse[];

export type GetAdminLoreSubmissionsError = HTTPValidationError;

/** Response Get My Lore Submissions */
export type GetMyLoreSubmissionsData = LoreSubmissionResponse[];

export interface UpdateLoreSubmissionParams {
  /** Submission Id */
  submissionId: string;
}

export type UpdateLoreSubmissionData = LoreSubmissionResponse;

export type UpdateLoreSubmissionError = HTTPValidationError;

export interface DeleteLoreSubmissionParams {
  /** Submission Id */
  submissionId: string;
}

export type DeleteLoreSubmissionData = any;

export type DeleteLoreSubmissionError = HTTPValidationError;

export interface RebuildCharacterParams {
  /**
   * Character Id
   * @format uuid
   */
  characterId: string;
}

/** Response Rebuild Character */
export type RebuildCharacterData = Record<string, any>;

export type RebuildCharacterError = HTTPValidationError;

export interface GetAuditLogsParams {
  /**
   * Limit
   * @default 50
   */
  limit?: number;
  /**
   * Offset
   * @default 0
   */
  offset?: number;
  /** Action Type */
  action_type?: string | null;
  /** User Id */
  user_id?: string | null;
  /** Start Date */
  start_date?: string | null;
  /** End Date */
  end_date?: string | null;
  /** Action */
  action?: string | null;
  /** Entity Type */
  entity_type?: string | null;
  /**
   * Sort By
   * @default "created_at"
   */
  sort_by?: string;
  /**
   * Sort Direction
   * @default "desc"
   */
  sort_direction?: string;
}

/** Response Get Audit Logs */
export type GetAuditLogsData = AuditLogEntry[];

export type GetAuditLogsError = HTTPValidationError;

export type BackfillAuditLogsData = any;

export type GetExportStatusData = ExportStatus;

/** Response Get All Migrations */
export type GetAllMigrationsData = MigrationFile[];

export type DownloadCompletePackageData = any;

export interface GetCharacterSystemMilestonesParams {
  /** Character Id */
  characterId: string;
}

/** Response Get Character System Milestones */
export type GetCharacterSystemMilestonesData = SystemMilestoneProgress[];

export type GetCharacterSystemMilestonesError = HTTPValidationError;

export interface UpdateSystemMilestoneNotesParams {
  /** Notes */
  notes?: string | null;
  /**
   * Shared With Staff
   * @default false
   */
  shared_with_staff?: boolean;
  /** Character Id */
  characterId: string;
  /** System Milestone Id */
  systemMilestoneId: string;
}

export type UpdateSystemMilestoneNotesData = any;

export type UpdateSystemMilestoneNotesError = HTTPValidationError;

export interface MarkSystemMilestoneCompleteParams {
  /** Character Id */
  characterId: string;
  /** System Milestone Id */
  systemMilestoneId: string;
}

export type MarkSystemMilestoneCompleteData = any;

export type MarkSystemMilestoneCompleteError = HTTPValidationError;

export interface GetCharacterCustomMilestonesParams {
  /** Character Id */
  characterId: string;
}

/** Response Get Character Custom Milestones */
export type GetCharacterCustomMilestonesData = CustomMilestoneResponse[];

export type GetCharacterCustomMilestonesError = HTTPValidationError;

export type CreateCustomMilestoneData = CustomMilestoneResponse;

export type CreateCustomMilestoneError = HTTPValidationError;

export interface UpdateCustomMilestoneParams {
  /** Milestone Id */
  milestoneId: string;
}

export type UpdateCustomMilestoneData = CustomMilestoneResponse;

export type UpdateCustomMilestoneError = HTTPValidationError;

export interface DeleteCustomMilestoneParams {
  /** Milestone Id */
  milestoneId: string;
}

export type DeleteCustomMilestoneData = any;

export type DeleteCustomMilestoneError = HTTPValidationError;

export interface GetCharacterJournalEntriesParams {
  /** Character Id */
  characterId: string;
}

/** Response Get Character Journal Entries */
export type GetCharacterJournalEntriesData = JournalEntryResponse[];

export type GetCharacterJournalEntriesError = HTTPValidationError;

export type CreateJournalEntryData = JournalEntryResponse;

export type CreateJournalEntryError = HTTPValidationError;

export interface UpdateJournalEntryParams {
  /** Entry Id */
  entryId: string;
}

export type UpdateJournalEntryData = JournalEntryResponse;

export type UpdateJournalEntryError = HTTPValidationError;

export interface DeleteJournalEntryParams {
  /** Entry Id */
  entryId: string;
}

export type DeleteJournalEntryData = any;

export type DeleteJournalEntryError = HTTPValidationError;

export type ListMyTestCharactersData = TestCharacterListResponse;

export type CreateTestCharacterData = TestCharacterResponse;

export type CreateTestCharacterError = HTTPValidationError;

export interface UpdateTestCharacterParams {
  /** Test Character Id */
  testCharacterId: string;
}

export type UpdateTestCharacterData = TestCharacterResponse;

export type UpdateTestCharacterError = HTTPValidationError;

export interface DeleteTestCharacterParams {
  /** Test Character Id */
  testCharacterId: string;
}

export type DeleteTestCharacterData = any;

export type DeleteTestCharacterError = HTTPValidationError;

export type ListScopedEventsData = AdminEventListResponse;

/** Response List Scoped Characters */
export type ListScopedCharactersData = Record<string, any>[];

export type ListScopedChaptersData = AppApisAdminScopedChapterListResponse;

/** Response List Galleries */
export type ListGalleriesData = GalleryResponse[];

export type CreateGalleryData = GalleryResponse;

export type CreateGalleryError = HTTPValidationError;

export interface UpdateGalleryParams {
  /** Gallery Id */
  galleryId: string;
}

export type UpdateGalleryData = GalleryResponse;

export type UpdateGalleryError = HTTPValidationError;

export interface DeleteGalleryParams {
  /** Gallery Id */
  galleryId: string;
}

export type DeleteGalleryData = any;

export type DeleteGalleryError = HTTPValidationError;

/** Response List Public Galleries */
export type ListPublicGalleriesData = GalleryResponse[];

export interface ListPublicGalleryPhotosParams {
  /** Gallery Id */
  galleryId: string;
}

/** Response List Public Gallery Photos */
export type ListPublicGalleryPhotosData = PublicPhotoResponse[];

export type ListPublicGalleryPhotosError = HTTPValidationError;

/** Response List Public Photos */
export type ListPublicPhotosData = PublicPhotoResponse[];

export interface AddPhotoToGalleryParams {
  /** Gallery Id */
  galleryId: string;
}

export type AddPhotoToGalleryData = PhotoResponse;

export type AddPhotoToGalleryError = HTTPValidationError;

export interface ListGalleryPhotosParams {
  /** Gallery Id */
  galleryId: string;
}

/** Response List Gallery Photos */
export type ListGalleryPhotosData = PhotoResponse[];

export type ListGalleryPhotosError = HTTPValidationError;

export interface BulkAddPhotosToGalleryParams {
  /** Gallery Id */
  galleryId: string;
}

export type BulkAddPhotosToGalleryData = BulkPhotoUploadResponse;

export type BulkAddPhotosToGalleryError = HTTPValidationError;

export interface UpdateGalleryPhotoParams {
  /** Gallery Id */
  galleryId: string;
  /** Photo Id */
  photoId: string;
}

export type UpdateGalleryPhotoData = PhotoResponse;

export type UpdateGalleryPhotoError = HTTPValidationError;

export interface DeleteGalleryPhotoParams {
  /** Gallery Id */
  galleryId: string;
  /** Photo Id */
  photoId: string;
}

export type DeleteGalleryPhotoData = any;

export type DeleteGalleryPhotoError = HTTPValidationError;

export interface ReorderGalleryPhotosParams {
  /** Gallery Id */
  galleryId: string;
}

export type ReorderGalleryPhotosData = any;

export type ReorderGalleryPhotosError = HTTPValidationError;

export type UpdateMyPlayerProfileData = PlayerProfile;

export type UpdateMyPlayerProfileError = HTTPValidationError;

export type CreatePlayerProfileData = PlayerProfile;

export type CreatePlayerProfileError = HTTPValidationError;

export type GetMyPlayerProfileData = PlayerProfile;

export type GetMyCandleHistoryData = AppApisPlayersCandleHistoryResponse;

export interface UpdatePlayerNumberParams {
  /**
   * Player Id
   * @format uuid
   */
  playerId: string;
}

export type UpdatePlayerNumberData = PlayerProfile;

export type UpdatePlayerNumberError = HTTPValidationError;

export type GetCurrentUserInfoData = any;

export type GetMyPermissionsData = any;

export interface ListReferralsParams {
  /**
   * Filter Type
   * @default "all"
   */
  filter_type?: string | null;
}

export type ListReferralsData = ReferralListResponse;

export type ListReferralsError = HTTPValidationError;

export type AcknowledgeReferralData = AcknowledgeReferralResponse;

export type AcknowledgeReferralError = HTTPValidationError;

export type GetReferralStatsData = ReferralStatsResponse;

/** Response List Players For Referral */
export type ListPlayersForReferralData = ChapterPlayersGroup[];

export interface GetSharedMilestonesParams {
  /** Chapter Id */
  chapter_id?: string | null;
  /** Character Id */
  character_id?: string | null;
  /** Player Id */
  player_id?: string | null;
}

/** Response Get Shared Milestones */
export type GetSharedMilestonesData = SharedMilestoneResponse[];

export type GetSharedMilestonesError = HTTPValidationError;

export interface GetSharedJournalsParams {
  /** Chapter Id */
  chapter_id?: string | null;
  /** Character Id */
  character_id?: string | null;
  /** Player Id */
  player_id?: string | null;
  /** Event Id */
  event_id?: string | null;
}

/** Response Get Shared Journals */
export type GetSharedJournalsData = SharedJournalResponse[];

export type GetSharedJournalsError = HTTPValidationError;

export interface ListSystemMilestonesParams {
  /**
   * Include Disabled
   * @default false
   */
  include_disabled?: boolean;
}

/** Response List System Milestones */
export type ListSystemMilestonesData = SystemMilestoneResponse[];

export type ListSystemMilestonesError = HTTPValidationError;

export type CreateSystemMilestoneData = SystemMilestoneResponse;

export type CreateSystemMilestoneError = HTTPValidationError;

export interface UpdateSystemMilestoneParams {
  /** Milestone Id */
  milestoneId: string;
}

export type UpdateSystemMilestoneData = SystemMilestoneResponse;

export type UpdateSystemMilestoneError = HTTPValidationError;

export interface DeleteSystemMilestoneParams {
  /** Milestone Id */
  milestoneId: string;
}

export type DeleteSystemMilestoneData = any;

export type DeleteSystemMilestoneError = HTTPValidationError;

/** Response List Characters For Assignment */
export type ListCharactersForAssignmentData = CharacterSelectionResponse[];

export type AssignSystemMilestoneData = any;

export type AssignSystemMilestoneError = HTTPValidationError;

export type ListFolderPhotosData = FolderPhotosResponse;

export type ListFolderPhotosError = HTTPValidationError;

export interface CalculateXpCostParams {
  /** Body */
  body: number;
  /** Stamina */
  stamina: number;
  /** Character Id */
  character_id: string;
}

export type CalculateXpCostData = XPCostCalculation;

export type CalculateXpCostError = HTTPValidationError;

/** Response List My Characters */
export type ListMyCharactersData = AppApisCharactersCharacterListItem[];

export interface GetMyCharacterParams {
  /** Character Id */
  characterId: string;
}

export type GetMyCharacterData = CharacterDetail;

export type GetMyCharacterError = HTTPValidationError;

export interface UpdateMyCharacterParams {
  /** Character Id */
  characterId: string;
}

export type UpdateMyCharacterData = CharacterDetail;

export type UpdateMyCharacterError = HTTPValidationError;

export interface DeleteMyCharacterParams {
  /** Character Id */
  characterId: string;
}

export type DeleteMyCharacterData = any;

export type DeleteMyCharacterError = HTTPValidationError;

export type CreateCharacterData = CharacterDetail;

export type CreateCharacterError = HTTPValidationError;

/** Response Get My Character Names */
export type GetMyCharacterNamesData = string[];

/** Response List All Characters With Photos */
export type ListAllCharactersWithPhotosData = AppApisFaceToNameCharacterListItem[];

export interface GetCharacterPhotosParams {
  /** Character Id */
  characterId: string;
}

/** Response Get Character Photos */
export type GetCharacterPhotosData = CharacterPhoto[];

export type GetCharacterPhotosError = HTTPValidationError;

export type ListPublicChaptersData = AppApisEventsChapterListResponse;

export interface ListEventsParams {
  /** Chapter Id */
  chapter_id?: string | null;
  /** Status */
  status?: "scheduled" | "completed" | "cancelled" | null;
  /** From Date */
  from_date?: string | null;
  /** To Date */
  to_date?: string | null;
}

export type ListEventsData = EventsListResponse;

export type ListEventsError = HTTPValidationError;

export interface GetEventDetailParams {
  /** User */
  user?: User | null;
  /**
   * Event Id
   * @format uuid
   */
  eventId: string;
}

export type GetEventDetailData = EventDetail;

export type GetEventDetailError = HTTPValidationError;

export interface CreateOrUpdateRsvpParams {
  /**
   * Event Id
   * @format uuid
   */
  eventId: string;
}

export type CreateOrUpdateRsvpData = RSVPResponse;

export type CreateOrUpdateRsvpError = HTTPValidationError;

export type GetMyRsvpsData = MyRSVPsResponse;

export type SyncPlayerProfilesFromProductionData = SyncResponse;

export type SyncPlayerProfilesFromProductionError = HTTPValidationError;

/** Response List All Roles */
export type ListAllRolesData = Role[];

export type CreateRoleData = Role;

export type CreateRoleError = HTTPValidationError;

/** Response List Permissions */
export type ListPermissionsData = Permission[];

export interface UpdateRoleParams {
  /** Role Id */
  roleId: string;
}

export type UpdateRoleData = Role;

export type UpdateRoleError = HTTPValidationError;

export interface DeleteRoleParams {
  /** Role Id */
  roleId: string;
}

export type DeleteRoleData = any;

export type DeleteRoleError = HTTPValidationError;

export interface GetPlayerDetailParams {
  /** Player Id */
  playerId: string;
}

export type GetPlayerDetailData = PlayerDetailResponse;

export type GetPlayerDetailError = HTTPValidationError;

export interface DeletePlayerParams {
  /** Player Id */
  playerId: string;
}

export type DeletePlayerData = any;

export type DeletePlayerError = HTTPValidationError;

export interface ListPlayerCharactersParams {
  /** Player Id */
  playerId: string;
}

/** Response List Player Characters */
export type ListPlayerCharactersData = AppApisAdminPlayersCharacterSummary[];

export type ListPlayerCharactersError = HTTPValidationError;

/** Response List All Players */
export type ListAllPlayersData = AppApisAdminPlayersPlayerSummary[];

export interface UpdatePlayerRolesParams {
  /** Player Id */
  playerId: string;
}

/** Response Update Player Roles */
export type UpdatePlayerRolesData = Record<string, any>;

export type UpdatePlayerRolesError = HTTPValidationError;

export interface UpdatePlayerProfileParams {
  /** Player Id */
  playerId: string;
}

export type UpdatePlayerProfileData = PlayerDetailResponse;

export type UpdatePlayerProfileError = HTTPValidationError;

export interface GetPlayerCandleHistoryParams {
  /** Player Id */
  playerId: string;
}

export type GetPlayerCandleHistoryData = AppApisAdminPlayersCandleHistoryResponse;

export type GetPlayerCandleHistoryError = HTTPValidationError;

export interface CreateCandleTransactionParams {
  /**
   * Force
   * Force the transaction even if it results in a negative balance
   * @default false
   */
  force?: boolean;
  /** Player Id */
  playerId: string;
}

export type CreateCandleTransactionData = any;

export type CreateCandleTransactionError = NegativeBalanceError | HTTPValidationError;

export interface UpdateCandleTransactionParams {
  /** Player Id */
  playerId: string;
  /** Transaction Id */
  transactionId: string;
}

export type UpdateCandleTransactionData = any;

export type UpdateCandleTransactionError = HTTPValidationError;

export interface DeleteCandleTransactionParams {
  /** Player Id */
  playerId: string;
  /** Transaction Id */
  transactionId: string;
}

export type DeleteCandleTransactionData = any;

export type DeleteCandleTransactionError = HTTPValidationError;

export interface GetPlayerCharacterEventsParams {
  /** Player Id */
  playerId: string;
  /** Character Id */
  characterId: string;
}

/** Response Get Player Character Events */
export type GetPlayerCharacterEventsData = Record<string, any>[];

export type GetPlayerCharacterEventsError = HTTPValidationError;

export type CreatePhotoTagData = PhotoTagResponse;

export type CreatePhotoTagError = HTTPValidationError;

export interface GetPhotoTagsParams {
  /** Photo Id */
  photoId: string;
}

/** Response Get Photo Tags */
export type GetPhotoTagsData = PhotoTagResponse[];

export type GetPhotoTagsError = HTTPValidationError;

export interface DeletePhotoTagParams {
  /** Tag Id */
  tagId: string;
}

export type DeletePhotoTagData = any;

export type DeletePhotoTagError = HTTPValidationError;

/** Response Get All Photo Tags */
export type GetAllPhotoTagsData = PhotoTagResponse[];

export type GetMyCharactersForTaggingData = any;

export type GetAllCharactersForTaggingData = any;

export type ListHeritagesData = HeritageListResponse;

export type CreateHeritageData = HeritageResponse;

export type CreateHeritageError = HTTPValidationError;

export interface GetHeritageParams {
  /** Heritage Id */
  heritageId: string;
}

export type GetHeritageData = HeritageResponse;

export type GetHeritageError = HTTPValidationError;

export interface UpdateHeritageParams {
  /** Heritage Id */
  heritageId: string;
}

export type UpdateHeritageData = HeritageResponse;

export type UpdateHeritageError = HTTPValidationError;

export interface DeleteHeritageParams {
  /** Heritage Id */
  heritageId: string;
}

export type DeleteHeritageData = any;

export type DeleteHeritageError = HTTPValidationError;

export type StackUserWebhookData = any;

export type StackUserWebhookError = HTTPValidationError;

export type GetAnalyticsOverviewData = AnalyticsOverview;

export interface GetCharacterBuildsAnalyticsParams {
  /**
   * Active Only
   * Only include active (non-retired) characters
   * @default true
   */
  active_only?: boolean;
  /**
   * Start Date
   * Start date for character creation filter
   */
  start_date?: string | null;
  /**
   * End Date
   * End date for character creation filter
   */
  end_date?: string | null;
}

export type GetCharacterBuildsAnalyticsData = CharacterBuildsAnalytics;

export type GetCharacterBuildsAnalyticsError = HTTPValidationError;

export interface GetXpEconomyAnalyticsParams {
  /**
   * Start Date
   * Start date for filtering
   */
  start_date?: string | null;
  /**
   * End Date
   * End date for filtering
   */
  end_date?: string | null;
}

export type GetXpEconomyAnalyticsData = XPEconomyAnalytics;

export type GetXpEconomyAnalyticsError = HTTPValidationError;

export interface GetEventPerformanceAnalyticsParams {
  /**
   * Start Date
   * Start date for filtering
   */
  start_date?: string | null;
  /**
   * End Date
   * End date for filtering
   */
  end_date?: string | null;
  /**
   * Chapter Id
   * Filter by specific chapter
   */
  chapter_id?: string | null;
}

export type GetEventPerformanceAnalyticsData = EventPerformanceAnalytics;

export type GetEventPerformanceAnalyticsError = HTTPValidationError;

export interface GetPlayerEngagementAnalyticsParams {
  /**
   * Active Days
   * Days to consider a player active
   * @default 90
   */
  active_days?: number;
}

export type GetPlayerEngagementAnalyticsData = PlayerEngagementAnalytics;

export type GetPlayerEngagementAnalyticsError = HTTPValidationError;

export interface GetChapterHealthAnalyticsParams {
  /**
   * Chapter Id
   * Filter by specific chapter
   */
  chapter_id?: string | null;
  /**
   * Start Date
   * Start date for filtering
   */
  start_date?: string | null;
  /**
   * End Date
   * End date for filtering
   */
  end_date?: string | null;
}

export type GetChapterHealthAnalyticsData = ChapterHealthAnalytics;

export type GetChapterHealthAnalyticsError = HTTPValidationError;

/** Response List Archetypes */
export type ListArchetypesData = ArchetypeResponse[];

export type CreateArchetypeData = ArchetypeResponse;

export type CreateArchetypeError = HTTPValidationError;

export interface GetArchetypeParams {
  /** Archetype Id */
  archetypeId: string;
}

export type GetArchetypeData = ArchetypeResponse;

export type GetArchetypeError = HTTPValidationError;

export interface UpdateArchetypeParams {
  /** Archetype Id */
  archetypeId: string;
}

export type UpdateArchetypeData = ArchetypeResponse;

export type UpdateArchetypeError = HTTPValidationError;

export interface DeleteArchetypeParams {
  /** Archetype Id */
  archetypeId: string;
}

export type DeleteArchetypeData = any;

export type DeleteArchetypeError = HTTPValidationError;

export interface ListCulturesParams {
  /** Heritage Id */
  heritage_id?: string | null;
}

/** Response List Cultures */
export type ListCulturesData = CultureResponse[];

export type ListCulturesError = HTTPValidationError;

export type CreateCultureData = CultureResponse;

export type CreateCultureError = HTTPValidationError;

export interface GetCultureParams {
  /** Culture Id */
  cultureId: string;
}

export type GetCultureData = CultureResponse;

export type GetCultureError = HTTPValidationError;

export interface UpdateCultureParams {
  /** Culture Id */
  cultureId: string;
}

export type UpdateCultureData = CultureResponse;

export type UpdateCultureError = HTTPValidationError;

export interface DeleteCultureParams {
  /** Culture Id */
  cultureId: string;
}

export type DeleteCultureData = any;

export type DeleteCultureError = HTTPValidationError;

/** Response List All Characters For Reassignment */
export type ListAllCharactersForReassignmentData = AppApisCharacterReassignmentCharacterSummary[];

export interface GetPlayersByChapterParams {
  /** Chapter Id */
  chapterId: string;
}

/** Response Get Players By Chapter */
export type GetPlayersByChapterData = AppApisCharacterReassignmentPlayerSummary[];

export type GetPlayersByChapterError = HTTPValidationError;

export type ReassignCharacterData = any;

export type ReassignCharacterError = HTTPValidationError;

export interface GetReassignmentHistoryParams {
  /** Character Id */
  characterId: string;
}

/** Response Get Reassignment History */
export type GetReassignmentHistoryData = ReassignmentHistoryRecord[];

export type GetReassignmentHistoryError = HTTPValidationError;

export type SubmitBugReportData = any;

export type SubmitBugReportError = HTTPValidationError;

export type OptimizeBuildData = any;

export type OptimizeBuildError = HTTPValidationError;

export type ListChaptersData = AppApisAdminChapterListResponse;

export type CreateChapterData = AppApisAdminChapter;

export type CreateChapterError = HTTPValidationError;

export interface UpdateChapterParams {
  /** Chapter Id */
  chapterId: string;
}

export type UpdateChapterData = AppApisAdminChapter;

export type UpdateChapterError = HTTPValidationError;

export interface DeleteChapterParams {
  /** Chapter Id */
  chapterId: string;
}

export type DeleteChapterData = any;

export type DeleteChapterError = HTTPValidationError;

export type ListAdminEventsData = AdminEventListResponse;

export type CreateEventData = EventCreated;

export type CreateEventError = HTTPValidationError;

export interface UpdateEventParams {
  /** Event Id */
  eventId: string;
}

export type UpdateEventData = EventUpdated;

export type UpdateEventError = HTTPValidationError;

export interface DeleteEventParams {
  /** Event Id */
  eventId: string;
}

/** Response Delete Event */
export type DeleteEventData = Record<string, any>;

export type DeleteEventError = HTTPValidationError;

export interface GetEventAttendeesParams {
  /** Event Id */
  eventId: string;
}

export type GetEventAttendeesData = EventAttendanceResponse;

export type GetEventAttendeesError = HTTPValidationError;

export interface UpdateAttendanceStatusParams {
  /** Rsvp Id */
  rsvpId: string;
}

/** Response Update Attendance Status */
export type UpdateAttendanceStatusData = Record<string, any>;

export type UpdateAttendanceStatusError = HTTPValidationError;

export interface AddManualRsvpParams {
  /**
   * Event Id
   * @format uuid
   */
  eventId: string;
}

export type AddManualRsvpData = ManualRSVPResponse;

export type AddManualRsvpError = HTTPValidationError;

export type ListAllCharactersData = AdminCharacterListResponse;

export interface GetAdminCharacterParams {
  /**
   * Character Id
   * @format uuid
   */
  characterId: string;
}

/** Response Get Admin Character */
export type GetAdminCharacterData = Record<string, any>;

export type GetAdminCharacterError = HTTPValidationError;

export interface UpdateAdminCharacterParams {
  /**
   * Character Id
   * @format uuid
   */
  characterId: string;
}

/** Response Update Admin Character */
export type UpdateAdminCharacterData = Record<string, any>;

export type UpdateAdminCharacterError = HTTPValidationError;

export interface DeleteAdminCharacterParams {
  /**
   * Character Id
   * @format uuid
   */
  characterId: string;
}

/** Response Delete Admin Character */
export type DeleteAdminCharacterData = Record<string, any>;

export type DeleteAdminCharacterError = HTTPValidationError;

export interface GetAdminCharacterXpHistoryParams {
  /**
   * Character Id
   * @format uuid
   */
  characterId: string;
}

export type GetAdminCharacterXpHistoryData = CharacterXPHistoryResponse;

export type GetAdminCharacterXpHistoryError = HTTPValidationError;

export interface AddAdminXpTransactionParams {
  /**
   * Force
   * @default false
   */
  force?: boolean;
  /** Character Id */
  characterId: string;
}

/** Response Add Admin Xp Transaction */
export type AddAdminXpTransactionData = Record<string, any>;

export type AddAdminXpTransactionError = HTTPValidationError;

export interface DeleteAdminXpTransactionParams {
  /**
   * Force
   * @default false
   */
  force?: boolean;
  /** Transaction Id */
  transactionId: string;
}

/** Response Delete Admin Xp Transaction */
export type DeleteAdminXpTransactionData = Record<string, any>;

export type DeleteAdminXpTransactionError = HTTPValidationError;

/** Character Ids */
export type BulkExportCharacterSheetsPayload = string[];

export type BulkExportCharacterSheetsData = any;

export type BulkExportCharacterSheetsError = HTTPValidationError;

export interface ListSkillsParams {
  /**
   * Show Hidden
   * @default false
   */
  show_hidden?: boolean;
}

export type ListSkillsData = SkillListResponse;

export type ListSkillsError = HTTPValidationError;

export type CreateSkillData = SkillResponse;

export type CreateSkillError = HTTPValidationError;

export interface GetSkillParams {
  /** Skill Id */
  skillId: string;
}

export type GetSkillData = SkillResponse;

export type GetSkillError = HTTPValidationError;

export interface UpdateSkillParams {
  /** Skill Id */
  skillId: string;
}

export type UpdateSkillData = SkillResponse;

export type UpdateSkillError = HTTPValidationError;

export interface DeleteSkillParams {
  /** Skill Id */
  skillId: string;
}

export type DeleteSkillData = any;

export type DeleteSkillError = HTTPValidationError;
