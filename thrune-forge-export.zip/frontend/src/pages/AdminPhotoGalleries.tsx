import React, { useState, useEffect, useCallback } from 'react';
import { convertGoogleDriveUrl, isValidGoogleDriveUrl } from 'utils/googleDriveHelper';
import { useNavigate } from 'react-router-dom';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { ArrowLeft, Plus, Edit, Trash2, Image as ImageIcon, Upload, Loader2, GripVertical, X, FolderOpen } from 'lucide-react';
import type { GalleryResponse, PhotoResponse, GalleryCreate, GalleryUpdate } from 'types';
import { formatDateForDisplay } from 'utils/timezone';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { extractFolderId, isGoogleDriveFolder } from 'utils/googleDriveHelper';

// Helper function to convert Google Drive URLs to publicly accessible format
const getGoogleDriveImageUrl = (url: string | null | undefined): string => {
  if (!url || !url.includes('drive.google.com')) return url || '';
  
  // Extract the file ID from various Google Drive URL formats
  const match = url.match(/[/?&]id=([^&]+)/);
  if (!match) return url;
  
  // Use lh3.googleusercontent.com which works without authentication
  return `https://lh3.googleusercontent.com/d/${match[1]}`;
};

interface PhotoWithFile {
  id: string;
  file?: File;
  photo_url: string;
  thumbnail_url?: string | null;
  description?: string;
  display_order: number;
  isNew?: boolean;
  source?: 'file' | 'google-drive' | 'existing';
  saveStatus?: 'pending' | 'saving' | 'success' | 'failed';
}

// Sortable Photo Item Component
interface SortablePhotoItemProps {
  photo: PhotoWithFile;
  onDelete: (id: string) => void;
  onUpdateDescription: (id: string, description: string) => void;
}

const SortablePhotoItem: React.FC<SortablePhotoItemProps> = ({ photo, onDelete, onUpdateDescription }) => {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: photo.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`flex items-center gap-3 p-3 rounded-lg ${
        photo.isNew 
          ? 'bg-purple-500/10 border-2 border-purple-500 shadow-lg shadow-purple-500/20' 
          : 'bg-card border border-border'
      }`}
    >
      {photo.saveStatus && (
        <Badge 
          variant="secondary" 
          className={`text-xs ${
            photo.saveStatus === 'saving' ? 'bg-blue-500 text-white animate-pulse' :
            photo.saveStatus === 'success' ? 'bg-green-500 text-white' :
            photo.saveStatus === 'failed' ? 'bg-red-500 text-white' :
            'bg-gray-500 text-white'
          }`}
        >
          {photo.saveStatus === 'saving' ? 'SAVING...' :
           photo.saveStatus === 'success' ? 'ADDED' :
           photo.saveStatus === 'failed' ? 'FAILED' :
           'PENDING'}
        </Badge>
      )}
      
      <div
        {...attributes}
        {...listeners}
        className="cursor-grab active:cursor-grabbing text-muted-foreground hover:text-foreground"
      >
        <GripVertical className="h-5 w-5" />
      </div>
      
      <img
        src={getGoogleDriveImageUrl(photo.thumbnail_url || photo.photo_url)}
        alt={photo.description || 'Gallery photo'}
        className="w-16 h-16 object-cover rounded border border-border"
        onError={(e) => {
          const target = e.target as HTMLImageElement;
          const fallbackUrl = photo.photo_url;
          if (target.src !== fallbackUrl) {
            target.src = fallbackUrl;
          }
        }}
      />
      
      <div className="flex-1">
        <Input
          value={photo.description || ''}
          onChange={(e) => onUpdateDescription(photo.id, e.target.value)}
          placeholder="Photo description (optional)"
          className="text-sm"
        />
      </div>
      
      <Button
        variant="ghost"
        size="sm"
        onClick={() => onDelete(photo.id)}
        className="text-destructive hover:text-destructive"
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
};

export default function AdminPhotoGalleries() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();

  // State
  const [galleries, setGalleries] = useState<GalleryResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedGallery, setSelectedGallery] = useState<GalleryResponse | null>(null);
  const [photos, setPhotos] = useState<PhotoWithFile[]>([]);
  const [loadingPhotos, setLoadingPhotos] = useState(false);

  // Dialogs
  const [createGalleryOpen, setCreateGalleryOpen] = useState(false);
  const [editGalleryOpen, setEditGalleryOpen] = useState(false);
  const [deleteGalleryOpen, setDeleteGalleryOpen] = useState(false);
  const [managePhotosOpen, setManagePhotosOpen] = useState(false);

  // Forms
  const [galleryForm, setGalleryForm] = useState<GalleryCreate>({
    name: '',
    description: null,
    event_date: null,
  });
    const [savingPhotos, setSavingPhotos] = useState(false);
    const [saveProgress, setSaveProgress] = useState({ current: 0, total: 0 });

  // Google Drive URL input
  const [googleDriveUrl, setGoogleDriveUrl] = useState('');
  const [googleDriveError, setGoogleDriveError] = useState<string | null>(null);

  const [isLoadingFolder, setIsLoadingFolder] = useState(false);
  
  // Drag and drop sensors
  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Permission check
  useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.MANAGE_PHOTO_GALLERIES)) {
      navigate('/');
      return;
    }
  }, [permissionsLoading, hasPermission, navigate]);

  // Define loadGalleries with useCallback to prevent infinite loops
  const loadGalleries = useCallback(async () => {
    try {
      setLoading(true);
      const response = await apiClient.list_galleries();
      const data = await response.json();
      setGalleries(data.galleries || []);
    } catch (error) {
      console.error('Error loading galleries:', error);
      toast.error('Failed to load galleries');
    } finally {
      setLoading(false);
    }
  }, []);

  // Load galleries when permissions are ready
  useEffect(() => {
    if (!permissionsLoading && hasPermission(PERMISSIONS.MANAGE_PHOTO_GALLERIES)) {
      loadGalleries();
    }
  }, [permissionsLoading, hasPermission, loadGalleries]);

  const loadGalleryPhotos = async (galleryId: string) => {
    try {
      setLoadingPhotos(true);
      const response = await apiClient.list_gallery_photos({ galleryId });
      const data = await response.json();
      setPhotos(data.photos || []);
    } catch (error) {
      console.error('Error loading photos:', error);
      toast.error('Failed to load photos');
    } finally {
      setLoadingPhotos(false);
    }
  };

  const handleCreateGallery = async () => {
    if (!galleryForm.name.trim()) {
      toast.error('Gallery name is required');
      return;
    }

    try {
      await apiClient.create_gallery(galleryForm);
      toast.success('Gallery created successfully');
      setCreateGalleryOpen(false);
      setGalleryForm({ name: '', description: null, event_date: null });
      loadGalleries();
    } catch (error) {
      console.error('Error creating gallery:', error);
      toast.error('Failed to create gallery');
    }
  };

  const handleUpdateGallery = async () => {
    if (!selectedGallery) return;

    try {
      const updateData: GalleryUpdate = {
        name: galleryForm.name || null,
        description: galleryForm.description,
        event_date: galleryForm.event_date,
      };

      await apiClient.update_gallery(
        { galleryId: selectedGallery.id },
        updateData
      );

      toast.success('Gallery updated successfully');
      setEditGalleryOpen(false);
      setSelectedGallery(null);
      loadGalleries();
    } catch (error) {
      console.error('Error updating gallery:', error);
      toast.error('Failed to update gallery');
    }
  };

  const handleDeleteGallery = async () => {
    if (!selectedGallery) return;

    try {
      await apiClient.delete_gallery({ galleryId: selectedGallery.id });
      toast.success('Gallery deleted successfully');
      setDeleteGalleryOpen(false);
      setSelectedGallery(null);
      loadGalleries();
    } catch (error) {
      console.error('Error deleting gallery:', error);
      toast.error('Failed to delete gallery');
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    const newPhotos: PhotoWithFile[] = Array.from(files).map((file, index) => ({
      id: `temp-${Date.now()}-${index}`,
      file,
      photo_url: URL.createObjectURL(file),
      description: '',
      display_order: photos.length + index,
      isNew: true,
    }));

    setPhotos([...photos, ...newPhotos]);
  };

  const handleAddGoogleDriveUrl = async () => {
    if (!googleDriveUrl.trim()) {
      setGoogleDriveError('Please enter a Google Drive URL');
      return;
    }

    const trimmedUrl = googleDriveUrl.trim();

    // Check if it's a folder URL
    if (isGoogleDriveFolder(trimmedUrl)) {
      await handleAddGoogleDriveFolder(trimmedUrl);
      return;
    }

    // Handle individual file URL
    const directUrl = convertGoogleDriveUrl(trimmedUrl);
    if (!directUrl) {
      setGoogleDriveError('Invalid Google Drive URL. Please use a share link or file/folder ID.');
      return;
    }

    // Add single photo to list
    const newPhoto: PhotoWithFile = {
      id: `gdrive-${Date.now()}`,
      photo_url: directUrl,
      thumbnail_url: directUrl,
      description: '',
      display_order: photos.length,
      isNew: true,
      source: 'google-drive',
    };

    setPhotos([...photos, newPhoto]);
    setGoogleDriveUrl('');
    setGoogleDriveError(null);
    toast.success('Google Drive photo added');
  };

  const handleAddGoogleDriveFolder = async (url: string) => {
    const folderId = extractFolderId(url);
    if (!folderId) {
      setGoogleDriveError('Could not extract folder ID from URL');
      return;
    }

    setIsLoadingFolder(true);
    setGoogleDriveError(null);

    try {
      const response = await apiClient.list_folder_photos({ folder_id: folderId });
 
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Failed to load folder contents' }));
        const errorMsg = (errorData as any).detail || 'Failed to load folder contents';
        setGoogleDriveError(errorMsg);
        toast.error(errorMsg);
        return;
      }

      const data = await response.json();

      if (data.total_count === 0) {
        toast.warning(`No images found in folder "${data.folder_name}"`);
        setGoogleDriveUrl('');
        return;
      }

      // Add all photos from folder
      const newPhotos: PhotoWithFile[] = data.photos.map((photo: any, index: number) => ({
        id: `gdrive-${photo.file_id}`,
        photo_url: photo.direct_link,
        thumbnail_url: photo.thumbnail_url,
        description: photo.name,
        display_order: photos.length + index,
        isNew: true,
        source: 'google-drive',
      }));

      setPhotos([...photos, ...newPhotos]);
      setGoogleDriveUrl('');
      setGoogleDriveError(null);
      toast.success(`Added ${data.total_count} photos from "${data.folder_name}"`);
    } catch (error) {
      console.error('Error loading Google Drive folder:', error);
      setGoogleDriveError('Failed to load folder. Check API key and folder permissions.');
      toast.error('Failed to load folder contents');
    } finally {
      setIsLoadingFolder(false);
    }
  };

  const handleDeletePhoto = async (photoId: string) => {
    const photo = photos.find(p => p.id === photoId);
    if (!photo) return;

    // If it's a new photo (not yet saved), just remove from state
    if (photo.isNew) {
      setPhotos(photos.filter(p => p.id !== photoId));
      if (photo.file) {
        URL.revokeObjectURL(photo.photo_url);
      }
      return;
    }

    // If it's an existing photo, delete from server
    if (!selectedGallery) return;

    try {
      await apiClient.delete_gallery_photo({
        galleryId: selectedGallery.id,
        photoId: photoId,
      });

      setPhotos(photos.filter(p => p.id !== photoId));
      toast.success('Photo deleted');
    } catch (error) {
      console.error('Error deleting photo:', error);
      toast.error('Failed to delete photo');
    }
  };

  const handleUpdatePhotoDescription = (photoId: string, description: string) => {
    setPhotos(photos.map(p => p.id === photoId ? { ...p, description } : p));
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setPhotos((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const handleSavePhotos = async () => {
    if (!selectedGallery) return;

    setSavingPhotos(true);
    setSaveProgress({ current: 0, total: 0 });
    
    try {
      const newPhotos = photos.filter(p => p.isNew);
      const totalOperations = newPhotos.length;  // Only count new photos
  
      setSaveProgress({ current: 0, total: totalOperations });
      
      // Initialize all new photos with 'pending' status
      setPhotos(photos.map(p => 
        p.isNew ? { ...p, saveStatus: 'pending' as const } : p
      ));
      
      let successCount = 0;
      let failCount = 0;
      let currentOperation = 0;

      // Add new photos (both file uploads and Google Drive URLs)
      for (let i = 0; i < newPhotos.length; i++) {
        const photo = newPhotos[i];
        currentOperation++;
        setSaveProgress({ current: currentOperation, total: totalOperations });
        
        // Update status to 'saving'
        setPhotos(prevPhotos => prevPhotos.map(p => 
          p.id === photo.id ? { ...p, saveStatus: 'saving' as const } : p
        ));
        
        if (photo.source === 'google-drive') {
          // Google Drive photo - already has URL, just create the record
          try {
            const response = await apiClient.add_photo_to_gallery(
              { galleryId: selectedGallery.id },
              {
                photo_url: photo.photo_url,
                thumbnail_url: photo.thumbnail_url || null,
                description: photo.description || null,
                display_order: photo.display_order,
              }
            );
            
            if (!response.ok) {
              const errorData = await response.json().catch(() => ({}));
              console.error('Failed to add photo:', errorData);
              failCount++;
              // Update status to 'failed'
              setPhotos(prevPhotos => prevPhotos.map(p => 
                p.id === photo.id ? { ...p, saveStatus: 'failed' as const } : p
              ));
            } else {
              successCount++;
              // Update status to 'success'
              setPhotos(prevPhotos => prevPhotos.map(p => 
                p.id === photo.id ? { ...p, saveStatus: 'success' as const } : p
              ));
            }
          } catch (error) {
            console.error('Error adding Google Drive photo:', error);
            failCount++;
            // Update status to 'failed'
            setPhotos(prevPhotos => prevPhotos.map(p => 
              p.id === photo.id ? { ...p, saveStatus: 'failed' as const } : p
            ));
          }
        } else if (photo.file) {
          // File upload - needs storage implementation
          toast.error('File upload not yet implemented - requires storage integration. Use Google Drive URLs instead.');
          setSavingPhotos(false);
          setSaveProgress({ current: 0, total: 0 });
          return;
        }
      }

      if (failCount > 0) {
        toast.warning(`${successCount} photos saved, ${failCount} failed`);
      } else {
        toast.success(`Successfully saved ${successCount} photo(s)`);
      }
      
      // Reload the gallery photos to refresh state
      if (selectedGallery) {
        await loadGalleryPhotos(selectedGallery.id);
      }
      
      setManagePhotosOpen(false);
      loadGalleries();
    } catch (error) {
      console.error('Error saving photos:', error);
      toast.error('Failed to save photos');
    } finally {
      setSavingPhotos(false);
      setSaveProgress({ current: 0, total: 0 });
    }
  };

  const openManagePhotos = (gallery: GalleryResponse) => {
    setSelectedGallery(gallery);
    setManagePhotosOpen(true);
    loadGalleryPhotos(gallery.id);
  };

  const openEditGallery = (gallery: GalleryResponse) => {
    setSelectedGallery(gallery);
    setGalleryForm({
      name: gallery.name,
      description: gallery.description,
      event_date: gallery.event_date,
    });
    setEditGalleryOpen(true);
  };

  const openDeleteGallery = (gallery: GalleryResponse) => {
    setSelectedGallery(gallery);
    setDeleteGalleryOpen(true);
  };

  if (permissionsLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card/50 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => navigate('/')}
                className="text-muted-foreground hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back
              </Button>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                  Photo Galleries
                </h1>
                <p className="text-muted-foreground mt-1">
                  Manage event photo galleries
                </p>
              </div>
            </div>
            <Button onClick={() => setCreateGalleryOpen(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Gallery
            </Button>
          </div>
        </div>
      </div>

      {/* Galleries Grid */}
      <div className="container mx-auto px-4 py-8">
        {galleries.length === 0 ? (
          <Card>
            <CardContent className="flex flex-col items-center justify-center py-12">
              <ImageIcon className="h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No galleries yet. Create one to get started!</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleries.map((gallery) => (
              <Card key={gallery.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-lg">{gallery.name}</CardTitle>
                      {gallery.event_date && (
                        <CardDescription className="mt-1">
                          {formatDateForDisplay(gallery.event_date)}
                        </CardDescription>
                      )}
                    </div>
                    <Badge variant="secondary">
                      {gallery.photo_count} {gallery.photo_count === 1 ? 'photo' : 'photos'}
                    </Badge>
                  </div>
                  {gallery.description && (
                    <p className="text-sm text-muted-foreground mt-2 line-clamp-2">
                      {gallery.description}
                    </p>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => openManagePhotos(gallery)}
                    >
                      <ImageIcon className="h-4 w-4 mr-2" />
                      Manage Photos
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditGallery(gallery)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openDeleteGallery(gallery)}
                      className="text-destructive hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Create Gallery Dialog */}
      <Dialog open={createGalleryOpen} onOpenChange={setCreateGalleryOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create New Gallery</DialogTitle>
            <DialogDescription>
              Create a new photo gallery for an event or occasion
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="name">Gallery Name *</Label>
              <Input
                id="name"
                value={galleryForm.name}
                onChange={(e) => setGalleryForm({ ...galleryForm, name: e.target.value })}
                placeholder="e.g., Spring Festival 2024"
              />
            </div>
            <div>
              <Label htmlFor="event-date">Event Date</Label>
              <Input
                id="event-date"
                type="datetime-local"
                value={galleryForm.event_date || ''}
                onChange={(e) => setGalleryForm({ ...galleryForm, event_date: e.target.value || null })}
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={galleryForm.description || ''}
                onChange={(e) => setGalleryForm({ ...galleryForm, description: e.target.value || null })}
                placeholder="Describe this gallery..."
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateGalleryOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleCreateGallery}>Create Gallery</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Gallery Dialog */}
      <Dialog open={editGalleryOpen} onOpenChange={setEditGalleryOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Gallery</DialogTitle>
            <DialogDescription>Update gallery information</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div>
              <Label htmlFor="edit-name">Gallery Name *</Label>
              <Input
                id="edit-name"
                value={galleryForm.name}
                onChange={(e) => setGalleryForm({ ...galleryForm, name: e.target.value })}
              />
            </div>
            <div>
              <Label htmlFor="edit-event-date">Event Date</Label>
              <Input
                id="edit-event-date"
                type="datetime-local"
                value={galleryForm.event_date || ''}
                onChange={(e) => setGalleryForm({ ...galleryForm, event_date: e.target.value || null })}
              />
            </div>
            <div>
              <Label htmlFor="edit-description">Description</Label>
              <Textarea
                id="edit-description"
                value={galleryForm.description || ''}
                onChange={(e) => setGalleryForm({ ...galleryForm, description: e.target.value || null })}
                rows={3}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditGalleryOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateGallery}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Gallery Dialog */}
      <Dialog open={deleteGalleryOpen} onOpenChange={setDeleteGalleryOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Delete Gallery</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete "{selectedGallery?.name}"? This will also delete all photos in the gallery. This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleteGalleryOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteGallery}>
              Delete Gallery
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manage Photos Dialog */}
      <Dialog open={managePhotosOpen} onOpenChange={setManagePhotosOpen}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Manage Photos - {selectedGallery?.name}</DialogTitle>
            <DialogDescription>
              Upload, reorder, and manage photos in this gallery
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Google Drive URL Input */}
            <div className="space-y-2">
              <Label htmlFor="google-drive-url">Google Drive URL or Folder</Label>
              <div className="flex gap-2">
                <Input
                  id="google-drive-url"
                  value={googleDriveUrl}
                  onChange={(e) => {
                    setGoogleDriveUrl(e.target.value);
                    setGoogleDriveError(null);
                  }}
                  placeholder="https://drive.google.com/file/d/... or /folders/..."
                  className={googleDriveError ? 'border-red-500' : ''}
                  disabled={isLoadingFolder}
                />
                <Button 
                  onClick={handleAddGoogleDriveUrl} 
                  variant="outline"
                  disabled={isLoadingFolder}
                >
                  {isLoadingFolder ? 'Loading...' : 'Add'}
                </Button>
              </div>
              {googleDriveError && (
                <p className="text-sm text-red-500">{googleDriveError}</p>
              )}
              <p className="text-xs text-muted-foreground">
                Supports individual files or entire folders (imports all images)
              </p>
            </div>

            {/* Optional: File Upload (disabled until storage is implemented) */}
            <div className="opacity-50 pointer-events-none">
              <Label htmlFor="photo-upload" className="cursor-pointer">
                <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
                  <Upload className="h-6 w-6 mx-auto mb-2 text-muted-foreground" />
                  <p className="text-xs text-muted-foreground">
                    File upload coming soon - use Google Drive for now
                  </p>
                </div>
              </Label>
              <Input
                id="photo-upload"
                type="file"
                accept="image/*"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                disabled
              />
            </div>

            {/* Photos List */}
            {loadingPhotos ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
              </div>
            ) : photos.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                No photos yet. Upload some to get started!
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Drag photos to reorder them
                </p>
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleDragEnd}
                >
                  <SortableContext
                    items={photos.map(p => p.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    {photos.map((photo) => (
                      <SortablePhotoItem
                        key={photo.id}
                        photo={photo}
                        onDelete={handleDeletePhoto}
                        onUpdateDescription={handleUpdatePhotoDescription}
                      />
                    ))}
                  </SortableContext>
                </DndContext>
              </div>
            )}
          </div>

          <DialogFooter className="flex-col gap-2">
            {savingPhotos && saveProgress.total > 0 && (
              <div className="w-full space-y-1">
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Saving photos...</span>
                  <span>{Math.round((saveProgress.current / saveProgress.total) * 100)}%</span>
                </div>
                <div className="w-full bg-secondary rounded-full h-2">
                  <div 
                    className="bg-primary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${(saveProgress.current / saveProgress.total) * 100}%` }}
                  />
                </div>
                <p className="text-xs text-muted-foreground">
                  {saveProgress.current} of {saveProgress.total} photos processed
                </p>
              </div>
            )}
            <div className="flex justify-end gap-2 w-full">
              <Button variant="outline" onClick={() => setManagePhotosOpen(false)} disabled={savingPhotos}>
                Cancel
              </Button>
              <Button onClick={handleSavePhotos} disabled={savingPhotos}>
                {savingPhotos ? 'Saving...' : 'Save Photos'}
              </Button>
            </div>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
