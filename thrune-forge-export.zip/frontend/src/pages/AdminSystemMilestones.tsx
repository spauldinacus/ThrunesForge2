import { useState, useEffect } from 'react';
import { useUserGuardContext } from 'app/auth';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Plus, Edit, Trash2, Loader2, Settings, CheckCircle2, XCircle, ArrowLeft, UserPlus } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { SystemMilestone, AdminCharacterListItem } from 'types';

interface SystemMilestoneFormData {
  name: string;
  description: string;
  category: string;
  milestone_type: string;
  threshold_value: number;
  enabled: boolean;
}

const MILESTONE_TYPES = [
  { value: 'event_count', label: 'Event Attendance Count', description: 'Number of events attended' },
  { value: 'xp_total', label: 'Total XP Earned', description: 'Total experience points earned' },
  { value: 'skill_count', label: 'Skills Learned', description: 'Number of skills acquired' },
  { value: 'candle_total', label: 'Total Candles', description: 'Total candles earned/spent combined' },
  { value: 'character_age_days', label: 'Character Longevity', description: 'Days since character creation' },
  { value: 'other', label: 'Player Marked', description: 'Player manually marks when requirement is met' },
];

const CATEGORIES = [
  { value: 'progression', label: 'Progression' },
  { value: 'participation', label: 'Participation' },
  { value: 'achievement', label: 'Achievement' },
  { value: 'social', label: 'Social' },
  { value: 'general', label: 'General' },
];

export default function AdminSystemMilestones() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const { toast } = useToast();

  // State
  const [milestones, setMilestones] = useState<SystemMilestoneResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [formOpen, setFormOpen] = useState(false);
  const [editingMilestone, setEditingMilestone] = useState<SystemMilestoneResponse | null>(null);
  const [showDisabled, setShowDisabled] = useState(false);

  // Assignment Dialog State
  const [assignDialogOpen, setAssignDialogOpen] = useState(false);
  const [assigningMilestone, setAssigningMilestone] = useState<SystemMilestoneResponse | null>(null);
  const [characters, setCharacters] = useState<CharacterSelectionResponse[]>([]);
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('');
  const [assignNotes, setAssignNotes] = useState('');

  // Form state
  const [formData, setFormData] = useState<SystemMilestoneFormData>({
    name: '',
    description: '',
    category: 'general',
    milestone_type: 'event_count',
    threshold_value: 1,
    enabled: true,
  });

  useEffect(() => {
    loadMilestones();
  }, [showDisabled]);

  const loadCharacters = async () => {
    try {
      const response = await apiClient.list_characters_for_assignment();
      const data = await response.json();
      setCharacters(data.characters || []);
    } catch (error) {
      console.error('Failed to load characters:', error);
    }
  };

  const handleOpenAssignDialog = (milestone: SystemMilestoneResponse) => {
    setAssigningMilestone(milestone);
    setSelectedCharacterId('');
    setAssignNotes('');
    setAssignDialogOpen(true);
    if (characters.length === 0) {
      loadCharacters();
    }
  };

  const handleAssignMilestone = async () => {
    if (!assigningMilestone || !selectedCharacterId) return;

    try {
      const response = await apiClient.assign_system_milestone({
        milestone_id: assigningMilestone.id,
        character_id: selectedCharacterId,
        notes: assignNotes || undefined
      });

      if (response.ok) {
        toast({ title: 'Success', description: 'Milestone assigned to character' });
        setAssignDialogOpen(false);
      } else {
        const error = await response.json();
        throw new Error(error.detail || 'Failed to assign milestone');
      }
    } catch (error: any) {
      console.error('Failed to assign milestone:', error);
      toast({
        title: 'Error',
        description: error.message || 'Failed to assign milestone',
        variant: 'destructive',
      });
    }
  };

  const loadMilestones = async () => {
    try {
      setLoading(true);
      const response = await apiClient.list_system_milestones();
      const data = await response.json();
      setMilestones(data.milestones || []);
    } catch (error) {
      console.error('Failed to load system milestones:', error);
      toast({
        title: 'Error',
        description: 'Failed to load system milestones',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateMilestone = async () => {
    try {
      const response = await apiClient.create_system_milestone(formData);
      if (response.ok) {
        toast({ title: 'Success', description: 'System milestone created' });
        setFormOpen(false);
        resetForm();
        loadMilestones();
      } else {
        throw new Error('Failed to create milestone');
      }
    } catch (error) {
      console.error('Failed to create system milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to create system milestone',
        variant: 'destructive',
      });
    }
  };

  const handleUpdateMilestone = async () => {
    if (!editingMilestone) return;

    try {
      const updatePayload: any = {};
      if (formData.name !== editingMilestone.name) updatePayload.name = formData.name;
      if (formData.description !== editingMilestone.description) updatePayload.description = formData.description;
      if (formData.category !== editingMilestone.category) updatePayload.category = formData.category;
      if (formData.milestone_type !== editingMilestone.milestone_type) updatePayload.milestone_type = formData.milestone_type;
      if (formData.threshold_value !== editingMilestone.threshold_value) updatePayload.threshold_value = formData.threshold_value;
      if (formData.enabled !== editingMilestone.enabled) updatePayload.enabled = formData.enabled;

      const response = await apiClient.update_system_milestone(
        { milestoneId: editingMilestone.id },
        updatePayload
      );

      if (response.ok) {
        toast({ title: 'Success', description: 'System milestone updated' });
        setFormOpen(false);
        setEditingMilestone(null);
        resetForm();
        loadMilestones();
      } else {
        throw new Error('Failed to update milestone');
      }
    } catch (error) {
      console.error('Failed to update system milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to update system milestone',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteMilestone = async (milestone: SystemMilestoneResponse) => {
    if (!confirm(`Are you sure you want to delete "${milestone.name}"? This will also remove all player progress for this milestone.`)) {
      return;
    }

    try {
      await apiClient.delete_system_milestone({ milestoneId: milestone.id });
      toast.success('Milestone deleted successfully');
      loadMilestones();
    } catch (error) {
      console.error('Failed to delete system milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete system milestone',
        variant: 'destructive',
      });
    }
  };

  const openCreateForm = () => {
    resetForm();
    setEditingMilestone(null);
    setFormOpen(true);
  };

  const openEditForm = (milestone: SystemMilestoneResponse) => {
    setFormData({
      name: milestone.name,
      description: milestone.description,
      category: milestone.category,
      milestone_type: milestone.milestone_type,
      threshold_value: milestone.threshold_value,
      enabled: milestone.enabled,
    });
    setEditingMilestone(milestone);
    setFormOpen(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      category: 'general',
      milestone_type: 'event_count',
      threshold_value: 1,
      enabled: true,
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingMilestone) {
      handleUpdateMilestone();
    } else {
      handleCreateMilestone();
    }
  };

  const getMilestoneTypeInfo = (type: string) => {
    return MILESTONE_TYPES.find((t) => t.value === type) || MILESTONE_TYPES[0];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - System Milestones
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                System Milestones
              </h1>
              <p className="text-muted-foreground mt-2">
                Configure automatic milestones that players can track and earn.
              </p>
            </div>
          </div>

          {/* Actions Bar */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  id="show-disabled"
                  checked={showDisabled}
                  onCheckedChange={setShowDisabled}
                />
                <Label htmlFor="show-disabled" className="text-purple-200">
                  Show Disabled Milestones
                </Label>
              </div>
            </div>
            <Button onClick={openCreateForm}>
              <Plus className="h-4 w-4 mr-2" />
              Create System Milestone
            </Button>
          </div>

          {/* Milestones List */}
          {loading ? (
            <div className="flex justify-center py-12">
              <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
            </div>
          ) : milestones.length > 0 ? (
            <div className="grid gap-4">
              {milestones.map((milestone) => {
                const typeInfo = getMilestoneTypeInfo(milestone.milestone_type);
                return (
                  <Card
                    key={milestone.id}
                    className={`border-border/50 bg-card/50 backdrop-blur-sm ${
                      !milestone.enabled ? 'opacity-60' : ''
                    }`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            {milestone.enabled ? (
                              <CheckCircle2 className="h-5 w-5 text-green-500" />
                            ) : (
                              <XCircle className="h-5 w-5 text-muted-foreground" />
                            )}
                            <CardTitle className="text-lg">{milestone.name}</CardTitle>
                          </div>
                          <CardDescription>{milestone.description}</CardDescription>
                        </div>
                        <div className="flex flex-col gap-2">
                          <Badge variant="outline">{milestone.category}</Badge>
                          {!milestone.enabled && (
                            <Badge variant="secondary">Disabled</Badge>
                          )}
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="text-muted-foreground mb-1">Type</p>
                          <p className="font-medium">{typeInfo.label}</p>
                          <p className="text-xs text-muted-foreground">{typeInfo.description}</p>
                        </div>
                        <div>
                          <p className="text-muted-foreground mb-1">Threshold</p>
                          <p className="font-medium">{milestone.threshold_value}</p>
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button 
                          variant="outline" 
                          size="sm" 
                          onClick={() => handleOpenAssignDialog(milestone)}
                        >
                          <UserPlus className="h-4 w-4 mr-2" />
                          Assign
                        </Button>
                        <Button variant="outline" size="sm" onClick={() => openEditForm(milestone)}>
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                        <Button
                          variant="destructive"
                          size="sm"
                          onClick={() => handleDeleteMilestone(milestone)}
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
              <CardContent className="py-12 text-center">
                <Settings className="h-12 w-12 text-purple-400/50 mx-auto mb-4" />
                <p className="text-purple-300/70 mb-4">No system milestones defined yet.</p>
                <p className="text-sm text-purple-400/60">
                  Create your first system milestone to start tracking player achievements automatically.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </main>

      {/* Create/Edit Form Dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingMilestone ? 'Edit' : 'Create'} System Milestone
            </DialogTitle>
            <DialogDescription>
              Define an automatic milestone that tracks based on system data.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Milestone Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Veteran Adventurer"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what this milestone represents..."
                rows={3}
                required
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category">Category *</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => setFormData({ ...formData, category: value })}
                >
                  <SelectTrigger id="category">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {CATEGORIES.map((cat) => (
                      <SelectItem key={cat.value} value={cat.value}>
                        {cat.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="threshold">Threshold Value *</Label>
                <Input
                  id="threshold"
                  type="number"
                  min="1"
                  value={formData.threshold_value}
                  onChange={(e) =>
                    setFormData({ ...formData, threshold_value: parseInt(e.target.value) || 1 })
                  }
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="milestone-type">Milestone Type *</Label>
              <Select
                value={formData.milestone_type}
                onValueChange={(value) => setFormData({ ...formData, milestone_type: value })}
              >
                <SelectTrigger id="milestone-type">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MILESTONE_TYPES.map((type) => (
                    <SelectItem key={type.value} value={type.value}>
                      <div>
                        <div>{type.label}</div>
                        <div className="text-xs text-muted-foreground">{type.description}</div>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {getMilestoneTypeInfo(formData.milestone_type).description}
              </p>
            </div>

            <div className="flex items-center justify-between rounded-lg border border-border/50 p-4">
              <div className="space-y-0.5">
                <Label htmlFor="enabled">Enabled</Label>
                <p className="text-sm text-muted-foreground">
                  Active milestones will be tracked for all players
                </p>
              </div>
              <Switch
                id="enabled"
                checked={formData.enabled}
                onCheckedChange={(checked) => setFormData({ ...formData, enabled: checked })}
              />
            </div>

            <DialogFooter>
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  setFormOpen(false);
                  setEditingMilestone(null);
                  resetForm();
                }}
              >
                Cancel
              </Button>
              <Button type="submit">
                {editingMilestone ? 'Update' : 'Create'} Milestone
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* Assign Milestone Dialog */}
      <Dialog open={assignDialogOpen} onOpenChange={setAssignDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign Milestone</DialogTitle>
            <DialogDescription>
              Assign "{assigningMilestone?.name}" to a character.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Select Character</Label>
              <Select value={selectedCharacterId} onValueChange={setSelectedCharacterId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a character..." />
                </SelectTrigger>
                <SelectContent className="max-h-[300px]">
                  {characters.map((char) => (
                    <SelectItem key={char.id} value={char.id}>
                      {char.name} ({char.player_name})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Notes (Optional)</Label>
              <Textarea 
                value={assignNotes} 
                onChange={(e) => setAssignNotes(e.target.value)}
                placeholder="Add any initial notes..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setAssignDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleAssignMilestone} disabled={!selectedCharacterId}>
              Assign Milestone
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
