import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, Scroll, Heart, Zap, Plus, Minus } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { HeritageResponse, CultureResponse, ArchetypeResponse, SkillResponse } from 'types';
import { useCharacterReferenceStore } from 'utils/characterReferenceStore';
import {
  SkillWithState,
  CharacterData,
  SkillSortMode
} from 'utils/characterTypes';
import {
  processSkillsWithState,
  sortSkillsByCategory,
  calculateSkillXPCost,
  findDependentSkills
} from 'utils/skillLogic';
import {
  calculateBodyStaminaXPCost,
  calculateTotalXPSpent
} from 'utils/xpCalculations';
import { SkillSelector } from 'components/SkillSelector';
import { StatManager } from 'components/StatManager';
import { XPSummary } from 'components/XPSummary';

// Helper function for API retry logic with exponential backoff
const retryApiCall = async function<T>(
  apiCall: () => Promise<T>,
  maxRetries = 3,
  baseDelay = 1000
): Promise<T> {
  let lastError: Error;
  
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await apiCall();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt === maxRetries) {
        throw lastError;
      }
      
      // Exponential backoff: 1s, 2s, 4s
      const delay = baseDelay * Math.pow(2, attempt - 1);
      console.log(`API call failed (attempt ${attempt}/${maxRetries}), retrying in ${delay}ms...`);
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
  
  throw lastError!;
};

interface LoadingStates {
  heritages: boolean;
  cultures: boolean;
  archetypes: boolean;
  skills: boolean;
  characterNames: boolean;
}

const CharacterCreator = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const testMode = searchParams.get('mode') === 'test';
  const testCharacterId = searchParams.get('id');
  
  // Character data state
  const [characterData, setCharacterData] = useState<CharacterData>({
    name: '',
    heritage_id: '',
    culture_id: '',
    archetype_id: '',
    secondary_archetype_id: '',
    tertiary_archetype_id: '',
    body: 10,
    stamina: 10,
    selected_skills: {}
  });

  // UI state
  const [creating, setCreating] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showSkillSelector, setShowSkillSelector] = useState(false);
  const [showCostConfirmation, setShowCostConfirmation] = useState(false);
  const [skillSortMode, setSkillSortMode] = useState<SkillSortMode>('category');
  const [xpCalculating, setXpCalculating] = useState(false);
  const [nameError, setNameError] = useState<string | null>(null);
  
  // XP tracking
  const [xpSpent, setXpSpent] = useState(0);
  const [xpAvailable, setXpAvailable] = useState(25); // Not used in test mode

  // Loading states for progressive loading
  const [loadingStates, setLoadingStates] = useState<LoadingStates>({
    heritages: false,
    cultures: false,
    archetypes: false,
    skills: false,
    characterNames: false
  });

  // Reference data from store
  const {
    heritages,
    cultures,
    archetypes,
    skills: allSkills, // Fix naming mismatch: store.skills -> allSkills
    characterNames: existingCharacterNames,
    setHeritages,
    setCultures,
    setArchetypes,
    setSkills,
    setCharacterNames,
    isDataFresh,
    // Loading states
    heritagesLoaded,
    culturesLoaded,
    archetypesLoaded,
    skillsLoaded,
    characterNamesLoaded,
    // Loading state setters
    setHeritagesLoaded,
    setCulturesLoaded,
    setArchetypesLoaded,
    setSkillsLoaded,
    setCharacterNamesLoaded
  } = useCharacterReferenceStore();

  // Derived state using memoization
  const selectedHeritage = React.useMemo(() => {
    return heritages?.find?.(h => h.id === characterData.heritage_id) || null;
  }, [heritages, characterData.heritage_id]);

  const selectedArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.archetype_id) || null;
  }, [archetypes, characterData.archetype_id]);

  const selectedSecondaryArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.secondary_archetype_id) || null;
  }, [archetypes, characterData.secondary_archetype_id]);

  const selectedTertiaryArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.tertiary_archetype_id) || null;
  }, [archetypes, characterData.tertiary_archetype_id]);

  // Fix filteredCultures undefined error
  const filteredCultures = React.useMemo(() => {
    if (!cultures || !characterData.heritage_id) return [];
    return cultures.filter(culture => culture.heritage_id === characterData.heritage_id);
  }, [cultures, characterData.heritage_id]);

  const selectedCulture = React.useMemo(() => {
    return filteredCultures?.find?.(c => c.id === characterData.culture_id) || null;
  }, [filteredCultures, characterData.culture_id]);

  // Calculate total candle cost
  const totalCandleCost = React.useMemo(() => {
    let cost = 0;
    if (selectedHeritage?.candle_cost) cost += selectedHeritage.candle_cost;
    if (selectedCulture?.candle_cost) cost += selectedCulture.candle_cost;
    if (selectedArchetype?.candle_cost) cost += selectedArchetype.candle_cost;
    if (selectedSecondaryArchetype?.candle_cost) cost += selectedSecondaryArchetype.candle_cost;
    if (selectedTertiaryArchetype?.candle_cost) cost += selectedTertiaryArchetype.candle_cost;
    return cost;
  }, [selectedHeritage, selectedCulture, selectedArchetype, selectedSecondaryArchetype, selectedTertiaryArchetype]);

  // Process skills with state information using utility
  const getSkillsWithCosts = React.useMemo((): SkillWithState[] => {
    const processedSkills = processSkillsWithState(
      allSkills || [], // Ensure allSkills is always an array
      characterData.selected_skills,
      selectedArchetype,
      selectedHeritage,
      selectedSecondaryArchetype,
      selectedTertiaryArchetype
    );
    return sortSkillsByCategory(processedSkills);
  }, [allSkills, characterData.selected_skills, selectedArchetype, selectedHeritage, selectedSecondaryArchetype, selectedTertiaryArchetype]);


  const getSelectedSkills = React.useMemo((): SkillWithState[] => {
    return getSkillsWithCosts.filter(skill => {
      const purchaseCount = characterData.selected_skills[skill.id] || 0;
      return purchaseCount > 0;
    });
  }, [getSkillsWithCosts, characterData.selected_skills]);

  // Get sorted skills for the skill selector based on current sort mode
  const getSortedSkillsForSelector = React.useMemo((): SkillWithState[] => {
    const skills = getSkillsWithCosts;
    
    if (skillSortMode === 'alphabetical') {
      return [...skills].sort((a, b) => a.name.localeCompare(b.name));
    }
    
    // Category mode is the default (already sorted in getSkillsWithCosts)
    return skills;
  }, [getSkillsWithCosts, skillSortMode]);

  // Debounced XP calculation ref
  const debouncedXPUpdateRef = React.useRef<number>();

  const handleHeritageChange = (heritageId: string) => {
    const newData = {
      ...characterData,
      heritage_id: heritageId,
      culture_id: '' // Reset culture when heritage changes
    };
    setCharacterData(newData);
    updateXPCalculations(newData);
  };

  const updateXPCalculations = React.useCallback((newData?: Partial<CharacterData>) => {
    // Skip XP calculations during initial loading to prevent performance issues
    if (loading || !heritagesLoaded || !culturesLoaded || !archetypesLoaded) {
      return;
    }

    // Clear existing timeout to prevent multiple calculations
    if (debouncedXPUpdateRef.current) {
      clearTimeout(debouncedXPUpdateRef.current);
    }
    
    // Set calculating state
    setXpCalculating(true);
    
    // Debounced XP calculation for optimal performance
    debouncedXPUpdateRef.current = window.setTimeout(() => {
    const updatedCharacterData = { ...characterData, ...newData };
          
    // Determine which archetypes to use for calculation
    // Look up directly from arrays to avoid stale memo issues
    const primaryArch = archetypes?.find(a => a.id === updatedCharacterData.archetype_id) || null;
    const secondaryArch = updatedCharacterData.secondary_archetype_id 
      ? archetypes?.find(a => a.id === updatedCharacterData.secondary_archetype_id) || null
      : null;
    const tertiaryArch = updatedCharacterData.tertiary_archetype_id
      ? archetypes?.find(a => a.id === updatedCharacterData.tertiary_archetype_id) || null
      : null;
    const heritageForCalc = heritages?.find(h => h.id === updatedCharacterData.heritage_id) || null;
    
    const { totalXP } = calculateTotalXPSpent(
      updatedCharacterData,
      allSkills || [], // Ensure allSkills is never undefined
      primaryArch,
      heritageForCalc,
      secondaryArch,
      tertiaryArch
    );
      
      setXpSpent(totalXP);
      if (!testMode) {
        setXpAvailable(25 - totalXP);
      }
      setXpCalculating(false);
    }, 150); // Debounced for better performance
  }, [loading, heritagesLoaded, culturesLoaded, archetypesLoaded, characterData, selectedArchetype, selectedHeritage, selectedSecondaryArchetype, selectedTertiaryArchetype, allSkills, testMode, archetypes]);

  const addSkillPurchase = (skill: SkillWithState) => {
    const currentCount = characterData.selected_skills[skill.id] || 0;
    
    if (currentCount >= skill.max_purchases) {
      toast.error(`Cannot purchase ${skill.name} more than ${skill.max_purchases} time(s)`);
      return;
    }
    
    const newCount = currentCount + 1;
    const newSelectedSkills = {
      ...characterData.selected_skills,
      [skill.id]: newCount
    };
    
    const newData = {
      ...characterData,
      selected_skills: newSelectedSkills
    };
    
    setCharacterData(newData);
    
    // Use debounced XP calculation
    updateXPCalculations(newData);
  };
  
  const removeSkillPurchase = (skill: SkillWithState) => {
    const currentCount = characterData.selected_skills[skill.id] || 0;
    
    if (currentCount <= 0) {
      return;
    }
    
    // Find all skills that depend on this skill as a prerequisite using utility
    const dependentSkills = findDependentSkills(skill.id, allSkills, characterData.selected_skills);
    
    // Create new selected skills object with cascading removals
    const newSelectedSkills = { ...characterData.selected_skills };
    const removedSkills: string[] = [skill.name];
    
    // Check if this skill will still have purchases after removal
    const newCount = currentCount - 1;
    if (newCount <= 0) {
      // This skill will be completely removed, check for dependent skills
      delete newSelectedSkills[skill.id];
      
      // Remove all dependent skills
      for (const dependentSkill of dependentSkills) {
        if (newSelectedSkills[dependentSkill.id]) {
          delete newSelectedSkills[dependentSkill.id];
          removedSkills.push(dependentSkill.name);
        }
      }
    } else {
      // Just reduce the count
      newSelectedSkills[skill.id] = newCount;
    }
    
    const newData = {
      ...characterData,
      selected_skills: newSelectedSkills
    };
    
    setCharacterData(newData);
    
    // Use debounced XP calculation
    updateXPCalculations(newData);
    
    // Show notification if dependent skills were removed
    if (removedSkills.length > 1) {
      toast.info(`Removed skills: ${removedSkills.join(', ')} (cascade effect)`);
    }
  };

  const removeAllSelectedSkills = () => {
    const newData = {
      ...characterData,
      selected_skills: {}
    };
    
    setCharacterData(newData);
    updateXPCalculations(newData);
    toast.success('All selected skills removed');
  };

  
  const handleStatChange = (stat: 'body' | 'stamina', increment: boolean) => {
    const currentValue = characterData[stat];
    const newValue = increment ? currentValue + 1 : currentValue - 1;
    
    // Get minimum value from heritage base, default to 10 if no heritage selected
    const minValue = selectedHeritage ? 
      (stat === 'body' ? selectedHeritage.base_body : selectedHeritage.base_stamina) : 10;
    
    // Prevent going below heritage base or above reasonable limits
    if (newValue < minValue || newValue > 100) {
      return;
    }
    
    const newData = {
      ...characterData,
      [stat]: newValue
    };
    
    setCharacterData(newData);
    updateXPCalculations(newData);
  };
  
  const validateCharacterName = (name: string) => {
    if (!name.trim()) {
      setNameError(null);
      return;
    }
    
    const trimmedName = name.trim();
    const isDuplicate = (existingCharacterNames || []).some(existingName => 
      existingName.toLowerCase() === trimmedName.toLowerCase()
    );
    
    if (isDuplicate) {
      setNameError(`You already have a character named "${trimmedName}". Choose a different name.`);
    } else {
      setNameError(null);
    }
  };
  
  const handleCharacterNameChange = (newName: string) => {
    setCharacterData({ ...characterData, name: newName });
    validateCharacterName(newName);
  };

  const executeCreation = async () => {
    setCreating(true);
    setShowCostConfirmation(false);
    
    try {
      // Convert selected_skills from Record<string, number> to List[dict] format for backend
      const skillPurchases: Array<{skill_id: string, quantity: number}> = [];
      for (const [skillId, purchaseCount] of Object.entries(characterData.selected_skills)) {
        if (purchaseCount > 0) {
          skillPurchases.push({ skill_id: skillId, quantity: purchaseCount });
        }
      }
      
      const characterPayload = {
        name: characterData.name,
        heritage_id: characterData.heritage_id,
        culture_id: characterData.culture_id,
        archetype_id: characterData.archetype_id,
        secondary_archetype_id: characterData.secondary_archetype_id || undefined,
        tertiary_archetype_id: characterData.tertiary_archetype_id || undefined,
        body: characterData.body,
        stamina: characterData.stamina,
        corruption: 0,
        deaths: 0,
        selected_skills: skillPurchases
      };
      
      let response;
      if (testMode && testCharacterId) {
        // Update existing test character
        response = await apiClient.update_test_character({ characterId: testCharacterId }, characterPayload);
      } else if (testMode) {
        // Create new test character
        response = await apiClient.create_test_character(characterPayload);
      } else {
        // Create real character
        response = await apiClient.create_character(characterPayload);
      }
      
      // Check response status
      if (!response.ok) {
        let errorMessage = testMode ? 'Test character save failed' : 'Character creation failed';
        try {
          const errorData = await response.text();
          
          // Check for duplicate character name error
          if (errorData.includes('You already have a character named')) {
            errorMessage = errorData.replace(/["{}]/g, '').replace('detail:', '').trim();
          } else if (errorData.includes('Insufficient XP')) {
            errorMessage = 'Insufficient XP for selected skills and stats';
          } else if (errorData.includes('Invalid heritage')) {
            errorMessage = 'Invalid heritage, culture, or archetype combination';
          } else if (errorData.includes('Maximum 3 test characters')) {
            errorMessage = 'Maximum 3 test characters allowed. Delete one to create a new one.';
          } else if (errorData.includes('Insufficient candles')) {
            errorMessage = 'Insufficient candles to purchase selected options.';
          } else if (response.status === 400) {
            // Try to extract the actual error message from the response
            try {
              const errorJson = JSON.parse(errorData);
              if (errorJson.detail) {
                errorMessage = errorJson.detail;
              } else {
                errorMessage = 'Invalid character data provided';
              }
            } catch {
              errorMessage = 'Invalid character data provided';
            }
          } else if (response.status >= 500) {
            errorMessage = 'Server error occurred. Please try again.';
          }
        } catch (parseError) {
          // Could not parse error response, use generic message
        }
        toast.error(errorMessage);
        setCreating(false); // Reset loading state on error
        return;
      }
      
      // Parse response for successful creation
      let data;
      try {
        data = await response.json();
      } catch (parseError) {
        console.error('Failed to parse response JSON, but creation likely succeeded:', parseError);
        // Character creation succeeded but response parsing failed
        const successMessage = testMode ? `Test character "${characterData.name}" saved successfully!` : `Character "${characterData.name}" created successfully!`;
        toast.success(successMessage);
        navigate(testMode ? '/test-characters' : '/my-characters');
        return; // Don't reset creating state - let navigation happen
      }
      
      // Validate response data structure
      if (!data || !data.id) {
        console.error('Invalid response data structure:', data);
        const successMessage = testMode ? `Test character "${characterData.name}" saved!` : `Character "${characterData.name}" created!`;
        toast.success(successMessage);
        navigate(testMode ? '/test-characters' : '/my-characters');
        return; // Don't reset creating state - let the navigation happen
      }
      
      // Success with valid response!
      const successMessage = testMode && testCharacterId 
        ? `Test character "${characterData.name}" updated successfully!`
        : testMode
        ? `Test character "${characterData.name}" created!`
        : `Character "${characterData.name}" created!`;
      toast.success(successMessage);
      navigate(testMode ? '/test-characters' : '/my-characters');
    } catch (error) {
      console.error('Character creation error:', error);
      toast.error('An unexpected error occurred. Please try again.');
      setCreating(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!characterData.name.trim()) {
      toast.error('Please enter a character name');
      return;
    }

    // Add validation for UUID format and non-empty values
    if (!characterData.heritage_id || characterData.heritage_id.trim() === '') {
      toast.error('Please select a heritage');
      return;
    }

    if (!characterData.culture_id || characterData.culture_id.trim() === '') {
      toast.error('Please select a culture');
      return;
    }

    if (!characterData.archetype_id || characterData.archetype_id.trim() === '') {
      toast.error('Please select an archetype');
      return;
    }

    // Validate UUID format for all IDs
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    
    if (!uuidRegex.test(characterData.heritage_id)) {
      toast.error('Invalid heritage selection. Please select again.');
      return;
    }

    if (!uuidRegex.test(characterData.culture_id)) {
      toast.error('Invalid culture selection. Please select again.');
      return;
    }

    if (!uuidRegex.test(characterData.archetype_id)) {
      toast.error('Invalid archetype selection. Please select again.');
      return;
    }
    
    if (!characterData.heritage_id || !characterData.culture_id || !characterData.archetype_id) {
      toast.error('Please select heritage, culture, and archetype');
      return;
    }

    // Check for candle cost - skip for test mode or updates
    if (!testMode && !testCharacterId && totalCandleCost > 0) {
      setShowCostConfirmation(true);
      return;
    }
    
    executeCreation();
  };
  
  // Update body/stamina when heritage changes
  useEffect(() => {
    // Only reset body/stamina to heritage base when creating NEW character
    // Skip if editing existing test character
    if (selectedHeritage && !testCharacterId) {
      const newData = {
        ...characterData,
        body: selectedHeritage.base_body,
        stamina: selectedHeritage.base_stamina
      };
      setCharacterData(newData);
      updateXPCalculations(newData);
    }
  }, [selectedHeritage?.id]);
  
  // Load data in parallel for optimal performance
  React.useEffect(() => {
    const loadData = async () => {
      try {
        // ⚡ Cache validation - skip API calls if we have fresh data
        if (isDataFresh() && 
            heritages?.length > 0 && 
            cultures?.length > 0 && 
            archetypes?.length > 0 && 
            characterNamesLoaded) {
          // Mark all as loaded since we have cached data
          setHeritagesLoaded(true);
          setCulturesLoaded(true);
          setArchetypesLoaded(true);
          setCharacterNamesLoaded(true);
          setSkillsLoaded(allSkills?.length > 0);
          setLoading(false);
          return; // Skip all API calls
        }

        // 🚀 Load independent datasets in parallel using Promise.all()
        const parallelPromises = [];
        
        // Load heritages, cultures, archetypes, and skills in parallel
        if (!heritagesLoaded) {
          parallelPromises.push(
            apiClient.list_heritages()
              .then(res => res.json())
              .then(heritagesData => {
                const parsedHeritages = Array.isArray(heritagesData) ? heritagesData : heritagesData.heritages || [];
                setHeritages(parsedHeritages);
                setHeritagesLoaded(true);
              })
              .catch(error => {
                console.error('Failed to load heritages:', error);
                setHeritages([]);
                setHeritagesLoaded(true);
              })
          );
        }

        if (!culturesLoaded) {
          parallelPromises.push(
            apiClient.list_cultures()
              .then(res => res.json())
              .then(culturesData => {
                const parsedCultures = Array.isArray(culturesData) ? culturesData : culturesData.cultures || [];
                setCultures(parsedCultures);
                setCulturesLoaded(true);
              })
              .catch(error => {
                console.error('Failed to load cultures:', error);
                setCultures([]);
                setCulturesLoaded(true);
              })
          );
        }

        if (!archetypesLoaded) {
          parallelPromises.push(
            apiClient.list_archetypes()
              .then(res => res.json())
              .then(archetypesData => {
                const parsedArchetypes = Array.isArray(archetypesData) ? archetypesData : archetypesData.archetypes || [];
                setArchetypes(parsedArchetypes);
                setArchetypesLoaded(true);
              })
              .catch(error => {
                console.error('Failed to load archetypes:', error);
                setArchetypes([]);
                setArchetypesLoaded(true);
              })
          );
        }

        // Don't load character names in test mode
        if (!characterNamesLoaded && !testMode) {
          parallelPromises.push(
            apiClient.get_my_character_names()
              .then(res => res.json())
              .then(characterNamesData => {
                const parsedNames = Array.isArray(characterNamesData) ? characterNamesData : [];
                setCharacterNames(parsedNames);
                setCharacterNamesLoaded(true);
              })
              .catch(error => {
                console.error('Failed to load character names:', error);
                setCharacterNames([]);
                setCharacterNamesLoaded(true);
              })
          );
        } else if (testMode) {
          setCharacterNamesLoaded(true); // Skip in test mode
        }

        // Load skills in parallel with other data (no more separate loading)
        if (!skillsLoaded) {
          parallelPromises.push(
            retryApiCall(() => apiClient.list_skills(), 3, 1000)
              .then(res => res.json())
              .then(skillsData => {
                const parsedSkills = Array.isArray(skillsData) ? skillsData : skillsData.skills || [];
                setSkills(parsedSkills);
                setSkillsLoaded(true);
                console.log(`✅ Skills loaded successfully: ${parsedSkills.length} skills`);
              })
              .catch(error => {
                console.error('Failed to load skills after retries:', error);
                setSkills([]);
                setSkillsLoaded(true); // Still mark as loaded to prevent infinite loops
                toast.error('Failed to load skills. Some features may be limited.');
              })
          );
        }

        // Wait for all parallel operations to complete
        if (parallelPromises.length > 0) {
          await Promise.all(parallelPromises);
        }

        // Mark loading as complete when all core data is loaded (including skills)
        if (heritagesLoaded && culturesLoaded && archetypesLoaded && characterNamesLoaded && skillsLoaded) {
          setLoading(false);
        }
      } catch (error) {
        console.error('Error loading data:', error);
        setLoading(false);
      }
    };

    loadData();
  }, [heritagesLoaded, culturesLoaded, archetypesLoaded, characterNamesLoaded, skillsLoaded, testMode]);

  // Load test character data if editing
  React.useEffect(() => {
    const loadTestCharacter = async () => {
      if (!testMode || !testCharacterId) return;

      let testChar: any = null;
      
      try {
        setLoading(true);
        const response = await apiClient.list_my_test_characters();
        const data = await response.json();
        testChar = data.test_characters?.find((tc: any) => tc.id === testCharacterId);
        
        if (testChar) {
          // Convert selected_skills from array format to object format
          const skillsObject: Record<string, number> = {};
          if (testChar.selected_skills && Array.isArray(testChar.selected_skills)) {
            testChar.selected_skills.forEach((skill: any) => {
              if (skill.skill_id && skill.quantity) {
                skillsObject[skill.skill_id] = skill.quantity;
              }
            });
          }
          
          const loadedData = {
            name: testChar.name,
            heritage_id: testChar.heritage_id,
            culture_id: testChar.culture_id,
            archetype_id: testChar.archetype_id,
            secondary_archetype_id: testChar.secondary_archetype_id || '',
            tertiary_archetype_id: testChar.tertiary_archetype_id || '',
            body: testChar.body,
            stamina: testChar.stamina,
            selected_skills: skillsObject
          };
          
          setCharacterData(loadedData);
          
          // Store loaded data for XP calculation in finally block
          (window as any).__loadedTestCharData = loadedData;
        }
      } catch (error) {
        console.error('Failed to load test character:', error);
        toast.error('Failed to load test character');
      } finally {
        // Trigger XP calculation AFTER loading is complete with the loaded data
        if (testChar) {
          const loadedData = (window as any).__loadedTestCharData;
          delete (window as any).__loadedTestCharData;
          
          // Set loading to false first so the callback will have correct state
          setLoading(false);
          
          // Use requestAnimationFrame to ensure React has re-rendered with new callback
          requestAnimationFrame(() => {
            updateXPCalculations(loadedData);
          });
        } else {
          setLoading(false);
        }
      }
    };
    
    if (testMode && testCharacterId && heritagesLoaded && culturesLoaded && archetypesLoaded && skillsLoaded) {
      loadTestCharacter();
    }
  }, [testMode, testCharacterId, heritagesLoaded, culturesLoaded, archetypesLoaded, skillsLoaded]);
  
  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <Scroll className="w-16 h-16 text-purple-400 mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl text-purple-100">Loading Character Creator...</h2>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="outline" 
          onClick={() => navigate(testMode ? '/test-characters' : '/my-characters')}
          className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-purple-100">
            {testMode ? 'Test Character Builder' : 'Character Creator'}
          </h1>
          <p className="text-purple-300">
            {testMode ? 'Experiment with builds • No XP limits' : 'Create your new LARP character'}
          </p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Character Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name" className="text-purple-300">Character Name</Label>
                <Input
                  id="name"
                  value={characterData.name}
                  onChange={(e) => handleCharacterNameChange(e.target.value)}
                  className={`bg-slate-800/50 border-purple-500/30 text-purple-100 focus:border-purple-400 ${
                    nameError && !testMode ? 'border-red-500/50 focus:border-red-400' : ''
                  }`}
                  placeholder="Enter character name"
                />
                {nameError && !testMode && (
                  <p className="text-red-400 text-sm mt-1 flex items-center">
                    <span className="w-2 h-2 bg-red-400 rounded-full mr-2"></span>
                    {nameError}
                  </p>
                )}
                {!testMode && (existingCharacterNames || []).length > 0 && (
                  <div className="mt-2">
                    <p className="text-purple-400 text-xs mb-1">Existing characters:</p>
                    <div className="flex flex-wrap gap-1">
                      {(existingCharacterNames || []).map((name, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-purple-500/30 text-purple-300">
                          {name}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-purple-300">Heritage</Label>
                  {heritagesLoaded ? (
                    <Select
                      value={characterData.heritage_id}
                      onValueChange={(value) => {
                        setCharacterData({ 
                          ...characterData, 
                          heritage_id: value, 
                          culture_id: '' // Reset culture when heritage changes
                        });
                      }}
                    >
                      <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                        <SelectValue placeholder="Select heritage" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-purple-500/30">
                        {(heritages || []).map((heritage) => (
                          <SelectItem key={heritage.id} value={heritage.id} className="text-purple-100">
                            {heritage.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="h-10 w-full bg-purple-900/30 border border-purple-500/30 rounded-md animate-pulse flex items-center px-3">
                      <div className="h-4 bg-purple-500/40 rounded w-32 animate-pulse"></div>
                    </div>
                  )}
                </div>
                
                <div>
                  <Label className="text-purple-300">Culture</Label>
                  {culturesLoaded ? (
                    <Select
                      value={characterData.culture_id}
                      onValueChange={(value) => setCharacterData({ ...characterData, culture_id: value })}
                      disabled={!characterData.heritage_id}
                    >
                      <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                        <SelectValue placeholder="Select culture" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-purple-500/30">
                        {filteredCultures.map((culture) => (
                          <SelectItem key={culture.id} value={culture.id} className="text-purple-100">
                            {culture.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="h-10 w-full bg-purple-900/30 border border-purple-500/30 rounded-md animate-pulse flex items-center px-3">
                      <div className="h-4 bg-purple-500/40 rounded w-28 animate-pulse"></div>
                    </div>
                  )}
                </div>

                <div>
                  <Label className="text-purple-300">Primary Archetype</Label>
                  {archetypesLoaded ? (
                    <Select
                      value={characterData.archetype_id}
                      onValueChange={(value) => setCharacterData({ ...characterData, archetype_id: value })}
                    >
                      <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                        <SelectValue placeholder="Select archetype" />
                      </SelectTrigger>
                      <SelectContent className="bg-slate-800 border-purple-500/30">
                        {(archetypes || []).map((archetype) => (
                          <SelectItem key={archetype.id} value={archetype.id} className="text-purple-100">
                            {archetype.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="h-10 w-full bg-purple-900/30 border border-purple-500/30 rounded-md animate-pulse flex items-center px-3">
                      <div className="h-4 bg-purple-500/40 rounded w-36 animate-pulse"></div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Stats */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Body & Stamina</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-red-400 flex items-center">
                      <Heart className="w-4 h-4 mr-2" />
                      Body
                    </Label>
                    <span className="text-yellow-400 text-sm">
                      {selectedHeritage ? `Cost: ${calculateBodyStaminaXPCost(selectedHeritage.base_body, characterData.body, selectedHeritage.base_body)} XP` : 'Select heritage first'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('body', false)}
                      disabled={!selectedHeritage || characterData.body <= (selectedHeritage?.base_body || 0)}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-2xl font-bold text-purple-100 min-w-[3rem] text-center">
                      {selectedHeritage ? characterData.body : '—'}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('body', true)}
                      disabled={!selectedHeritage || characterData.body >= 200}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-blue-400 flex items-center">
                      <Zap className="w-4 h-4 mr-2" />
                      Stamina
                    </Label>
                    <span className="text-yellow-400 text-sm">
                      {selectedHeritage ? `Cost: ${calculateBodyStaminaXPCost(selectedHeritage.base_stamina, characterData.stamina, selectedHeritage.base_stamina)} XP` : 'Select heritage first'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('stamina', false)}
                      disabled={!selectedHeritage || characterData.stamina <= (selectedHeritage?.base_stamina || 0)}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-2xl font-bold text-purple-100 min-w-[3rem] text-center">
                      {selectedHeritage ? characterData.stamina : '—'}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('stamina', true)}
                      disabled={!selectedHeritage || characterData.stamina >= 200}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Skills */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-purple-100">Skills ({getSelectedSkills.length})</CardTitle>
                <SkillSelector
                  skills={getSortedSkillsForSelector}
                  selectedSkills={characterData.selected_skills}
                  sortMode={skillSortMode}
                  onSortModeChange={setSkillSortMode}
                  onAddSkill={addSkillPurchase}
                  onRemoveSkill={removeSkillPurchase}
                  xpAvailable={xpAvailable}
                  xpCalculating={xpCalculating}
                  isLoading={loading} // Use unified loading state
                />
              </div>
              {getSelectedSkills.length > 0 && (
                <div className="mt-4">
                  <Button
                    variant="outline"
                    onClick={removeAllSelectedSkills}
                    className="w-full border-red-500/30 text-red-400 hover:bg-red-500/10 hover:border-red-500/50"
                  >
                    <Minus className="mr-2 h-4 w-4" />
                    Remove All Selected Skills
                  </Button>
                </div>
              )}
            </CardHeader>
          </Card>
        </div>
        
        {/* Right Column - XP Summary */}
        <div className="space-y-6">
          {/* Create Character Button */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardContent className="pt-6">
              <Button 
                type="submit" 
                onClick={handleSubmit}
                disabled={creating || !characterData.name.trim() || nameError || !characterData.heritage_id || !characterData.culture_id || !characterData.archetype_id || xpAvailable < 0}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-lg transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {creating ? (
                  <>
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                    Creating Character...
                  </>
                ) : (
                  'Create Character'
                )}
              </Button>
              
              {/* Validation Messages */}
              <div className="mt-4 space-y-2">
                {!characterData.name.trim() && (
                  <p className="text-amber-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-amber-400 rounded-full mr-2"></span>
                    Character name required
                  </p>
                )}
                {nameError && !testMode && (
                  <p className="text-red-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-red-400 rounded-full mr-2"></span>
                    {nameError}
                  </p>
                )}
                {!characterData.heritage_id && (
                  <p className="text-amber-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-amber-400 rounded-full mr-2"></span>
                    Heritage selection required
                  </p>
                )}
                {!characterData.culture_id && characterData.heritage_id && (
                  <p className="text-amber-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-amber-400 rounded-full mr-2"></span>
                    Culture selection required
                  </p>
                )}
                {!characterData.archetype_id && (
                  <p className="text-amber-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-amber-400 rounded-full mr-2"></span>
                    Archetype selection required
                  </p>
                )}
                {xpAvailable < 0 && (
                  <p className="text-red-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-red-400 rounded-full mr-1"></span>
                    Insufficient XP: {Math.abs(xpAvailable)} over budget
                  </p>
                )}
                {characterData.name.trim() && !nameError && characterData.heritage_id && characterData.culture_id && characterData.archetype_id && xpAvailable >= 0 && (
                  <p className="text-green-400 text-sm flex items-center">
                    <span className="w-2 h-2 bg-green-400 rounded-full mr-2"></span>
                    Ready to create character
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* XP Summary */}
          <XPSummary 
            xpSpent={xpSpent}
            xpAvailable={xpAvailable} 
            xpCalculating={xpCalculating}
            selectedSkills={getSelectedSkills}
            maxXP={25}
            testMode={testMode}
          />
          
          {/* Character Summary */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Character Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {selectedHeritage && (
                <div className="border border-purple-500/20 rounded-lg p-4 bg-purple-900/20">
                  <h4 className="font-medium text-purple-200 mb-3 text-lg">{selectedHeritage.name}</h4>
                  
                  {/* Heritage Benefits */}
                  {selectedHeritage.benefit_name && selectedHeritage.benefit && (
                    <div className="mb-3">
                      <div className="text-green-400 font-medium text-sm mb-1">✨ {selectedHeritage.benefit_name}</div>
                      <p className="text-purple-300 text-sm pl-4">{selectedHeritage.benefit}</p>
                    </div>
                  )}
                  
                  {/* Heritage Flaws */}
                  {selectedHeritage.weakness_name && selectedHeritage.weakness && (
                    <div className="mb-3">
                      <div className="text-red-400 font-medium text-sm mb-1">⚠️ {selectedHeritage.weakness_name}</div>
                      <p className="text-purple-300 text-sm pl-4">{selectedHeritage.weakness}</p>
                    </div>
                  )}
                  
                  {/* Heritage Costuming */}
                  {selectedHeritage.costuming_requirements && (
                    <div>
                      <div className="text-blue-400 font-medium text-sm mb-1">👗 Costuming Requirements</div>
                      <p className="text-purple-300 text-sm pl-4">{selectedHeritage.costuming_requirements}</p>
                    </div>
                  )}
                </div>
              )}
              
              {selectedCulture && (
                <div className="border border-purple-500/20 rounded-lg p-4 bg-blue-900/20">
                  <h4 className="font-medium text-purple-200 mb-3 text-lg">{selectedCulture.name}</h4>
                  
                  {/* Culture Benefits */}
                  {selectedCulture.benefit_name && selectedCulture.benefit && (
                    <div className="mb-3">
                      <div className="text-green-400 font-medium text-sm mb-1">✨ {selectedCulture.benefit_name}</div>
                      <p className="text-purple-300 text-sm pl-4">{selectedCulture.benefit}</p>
                    </div>
                  )}
                  
                  {/* Culture Costuming */}
                  {selectedCulture.costuming_requirements && (
                    <div>
                      <div className="text-blue-400 font-medium text-sm mb-1">👗 Costuming Requirements</div>
                      <p className="text-purple-300 text-sm pl-4">{selectedCulture.costuming_requirements}</p>
                    </div>
                  )}
                </div>
              )}
              
              {selectedArchetype && (
                <div className="border border-purple-500/20 rounded-lg p-4 bg-amber-900/20">
                  <h4 className="font-medium text-purple-200 mb-3 text-lg">{selectedArchetype.name}</h4>
                  <p className="text-purple-300 text-sm">{selectedArchetype.description}</p>
                </div>
              )}
            </CardContent>
          </Card>
          <AlertDialog open={showCostConfirmation} onOpenChange={setShowCostConfirmation}>
            <AlertDialogContent className="bg-slate-900 border-purple-800/30">
              <AlertDialogHeader>
                <AlertDialogTitle className="text-purple-100">Confirm Candle Cost</AlertDialogTitle>
                <AlertDialogDescription className="text-purple-300">
                  Creating this character will cost <span className="text-amber-400 font-bold">{totalCandleCost} Candles</span>.
                  <br /><br />
                  This cost comes from your selected heritage, culture, or archetype options. This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel className="bg-slate-800 text-purple-300 border-purple-800/30 hover:bg-slate-700">Cancel</AlertDialogCancel>
                <AlertDialogAction 
                  onClick={executeCreation}
                  className="bg-amber-600 hover:bg-amber-700 text-white"
                >
                  Confirm & Spend {totalCandleCost} Candles
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>
    </div>
  );
};

export default CharacterCreator;
