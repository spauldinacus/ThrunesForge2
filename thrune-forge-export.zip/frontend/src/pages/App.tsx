import { useEffect } from 'react';
import { useUser } from '@stackframe/react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Settings, Calendar, Users, Shield, Gamepad2, Crown, Scroll, Sparkles, History, MapPin, Zap, BookOpen, AlertCircle, Aperture, BarChart3, UserCog, Target, Images, UserCheck } from 'lucide-react';
import { useAdminStatus } from 'utils/useAdminStatus';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import { UserButton } from 'components/UserButton';
import { useHasProfile, useProfileStatusStore } from 'utils/profileStatusStore';
import { BugReportButton } from 'components/BugReportButton';

export default function App() {
  const user = useUser();
  const navigate = useNavigate();

  // Use unified permission system for both regular and admin features
   const { hasPermission, hasAnyPermission, hasProfile: hasProfileFromServer, loading: permissionsLoading } = usePermissions();
    
  // Get the current value and update function from global store
  const hasProfileFromStore = useHasProfile();
  const updateProfileStatus = useProfileStatusStore((state) => state.updateProfileStatus);

  // Sync server data into global store when permissions are loaded
  useEffect(() => {
    if (!permissionsLoading) {
      updateProfileStatus(hasProfileFromServer);
    }
  }, [hasProfileFromServer, permissionsLoading, updateProfileStatus]);

  // Use store value as final source of truth
  const hasProfile = permissionsLoading ? false : hasProfileFromServer;

  // Consistent purple gradient for all tiles
  const tileGradient = "from-purple-600/20 to-purple-800/20";

  const navigationTiles = [
    {
      title: "Player Profile",
      description: "View and manage your player information",
      icon: User,
      path: "/player-profile",
      gradient: tileGradient
    },
    {
      title: "Character Management",
      description: "Create and manage your characters",
      icon: Crown,
      path: "/my-characters",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Event Registration",
      description: "Browse and RSVP to upcoming Thrune events",
      icon: Calendar,
      path: "/events",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Character Test Lab",
      description: "No XP limits. Experiment freely.",
      icon: Sparkles,
      path: "/testcharacters",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Lore Research Tracker",
      description: "Track your research progress.",
      icon: BookOpen,
      path: "/myloresubmissions",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "My Milestones & Journal",
      description: "Track achievements and document your journey",
      icon: Target,
      path: "/my-milestones",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Photo Gallery",
      description: "Browse event photos and memories, tag your characters",
      icon: Images,
      path: "/photo-gallery",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Face to Name",
      description: "Browse all characters with photos across chapters",
      icon: Aperture,
      path: "/face-to-name",
      gradient: tileGradient,
      requiresProfile: true
    },
    {
      title: "Explore Chapters",
      description: "Discover Thrune chapters and communities",
      icon: MapPin,
      path: "/chapters",
      gradient: tileGradient,
      requiresProfile: true
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with Auth */}
      <header className="relative z-5 flex justify-between items-center p-5">
        <div>
        <img 
          src="https://i0.wp.com/thrunelarp.com/wp-content/uploads/2024/03/Logo_Text_Final.png?w=1080&ssl=1" 
          alt="Thrune LARP Logo" 
          width="175">
        </img></div>
        
        <div className="flex items-center space-x-4">
          {user ? (
            <UserButton />
          ) : (
            <Button 
              variant="outline"
              className="bg-purple-600/20 border-purple-500/50 text-purple-100 hover:bg-purple-600/30"
              onClick={() => navigate('/auth/sign-in')}
            >
              Sign In
            </Button>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-2">
        {/* Welcome Section */}
          <div className="text-center mb-10">
          {user ? (
            <>
              <h1 className="text-3xl md:text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-blue-400 to-amber-400 mb-4">
                Welcome back, {user.displayName || user.primaryEmail}
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto">
                Step into Darkness, Embrace the Light, Choose your path at Thrune LARP
              </p>
            </>
          ) : (
            <>
              <h1 className="text-4xl md:text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-blue-400 to-amber-400 mb-4">
                Welcome to Thrune's Forge
              </h1>
              <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-8">
                The ultimate platform for Live Action Role-Playing management. Create characters, join events, and forge your legend.
              </p>
              <Button 
                size="lg"
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8 py-3 text-lg"
                onClick={() => navigate('/auth/sign-in')}
              >
                Begin Your Journey
              </Button>
            </>
          )}
        </div>

        {/* Navigation Tiles - Only show for authenticated users */}
        {user && (
          <div className="space-y-8">
            {/* Profile Completion Warning - Show if user doesn't have profile */}
            {!permissionsLoading && !hasProfile && (
              <Card className="bg-gradient-to-r from-amber-600/20 to-orange-600/20 backdrop-blur-sm border-amber-500/50 shadow-xl">
                <CardContent className="p-6">
                  <div className="flex items-center gap-4">
                    <div className="p-3 rounded-full bg-amber-500/20">
                      <AlertCircle className="w-8 h-8 text-amber-300" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-white mb-2">
                        Complete Your Player Profile
                      </h3>
                      <p className="text-amber-200 mb-4">
                        Before you can create characters or participate in events, please complete your player profile with your basic information and preferences.
                      </p>
                      <Button 
                        className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white"
                        onClick={() => navigate('/player-profile')}
                      >
                        Complete Profile Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* Regular User Navigation */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {navigationTiles.map((tile, index) => {
                const Icon = tile.icon;
                const isDisabled = tile.requiresProfile && !hasProfile;
                
                return (
                  <Card 
                    key={index}
                    className={`group transition-all duration-300 bg-gradient-to-br ${tile.gradient} backdrop-blur-sm border-purple-500/30 shadow-xl ${
                      isDisabled 
                        ? 'opacity-50 cursor-not-allowed' 
                        : 'cursor-pointer hover:scale-105 hover:border-purple-400/60 hover:shadow-2xl hover:shadow-purple-500/20'
                    }`}
                    onClick={() => {
                      if (isDisabled) {
                        // Show message about needing profile
                        return;
                      }
                      navigate(tile.path);
                    }}
                  >
                    <CardContent className="p-6 text-center">
                      <div className="mb-4 flex justify-center">
                        <div className={`p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 transition-all duration-300 ${
                          !isDisabled && 'group-hover:from-purple-500/30 group-hover:to-purple-700/30'
                        }`}>
                          <Icon className={`w-8 h-8 text-purple-300 transition-colors ${
                            !isDisabled && 'group-hover:text-purple-200'
                          }`} />
                        </div>
                      </div>
                      <h3 className={`text-lg font-semibold text-white mb-2 transition-colors ${
                        !isDisabled && 'group-hover:text-purple-200'
                      }`}>
                        {tile.title}
                      </h3>
                      <p className={`text-slate-400 text-sm transition-colors ${
                        !isDisabled && 'group-hover:text-slate-300'
                      }`}>
                        {isDisabled ? 'Complete your profile first' : tile.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            {/* Admin Tools - Only show if user has any admin permissions */}
            {user && !permissionsLoading && hasAnyPermission(Object.values(PERMISSIONS)) && (
              <div className="space-y-4">
                <h2 className="text-2xl font-bold text-white mb-4 flex items-center gap-2">
                  <Shield className="h-6 w-6 text-purple-400" />
                  Admin Tools
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  
                  {/* Player Management - First Priority */}
                  {hasPermission(PERMISSIONS.MANAGE_PLAYERS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminPlayers')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <Users className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Players
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          User accounts & roles
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  
                  {/* Character Management - Second Priority */}
                  {hasPermission(PERMISSIONS.MANAGE_CHARACTERS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminCharacters')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <Crown className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Characters
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          Manage all characters
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  {/* Referral Management */}
                  {hasPermission(PERMISSIONS.MANAGE_PLAYERS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminReferrals')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <Users className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Referrals
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          View and manage referrals
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Character Reassignment */}
                  {hasPermission(PERMISSIONS.CHARACTER_REASSIGNMENT) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminCharacterReassignment')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <UserCog className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Character Reassignment
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          Reassign characters to players
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Event Management - Third Priority */}
                  {hasPermission(PERMISSIONS.MANAGE_EVENTS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/ManageEvents')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <Calendar className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Events
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          Create & organize events
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Chapter Management */}
                  {hasPermission(PERMISSIONS.MANAGE_CHAPTERS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminChapters')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <MapPin className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Chapters
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          Chapter organization
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Game System Management */}
                  {hasAnyPermission([PERMISSIONS.MANAGE_ARCHETYPES, PERMISSIONS.MANAGE_HERITAGES, PERMISSIONS.MANAGE_CULTURES, PERMISSIONS.MANAGE_SKILLS]) && (
                    <>
                      {hasPermission(PERMISSIONS.MANAGE_ARCHETYPES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/AdminArchetypes')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Gamepad2 className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Manage Archetypes
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Character archetypes
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.MANAGE_HERITAGES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/AdminHeritages')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Scroll className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Manage Heritages
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Character backgrounds
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.MANAGE_CULTURES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/AdminCultures')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Sparkles className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Manage Cultures
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Cultural variations
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.MANAGE_SKILLS) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/AdminSkills')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Zap className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Manage Skills
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Character abilities
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.MANAGE_LORE_SUBMISSIONS) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/admin-lore-submissions')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <BookOpen className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Lore Submissions
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Manage lore research
                            </p>
                          </CardContent>
                        </Card>
                      )}

                      {hasPermission(PERMISSIONS.MANAGE_PHOTO_GALLERIES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/admin-photo-galleries')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Images className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Photo Galleries
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Manage event photo galleries
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.VIEW_SHARED_MILESTONES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/admin-shared-content')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Target className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              Shared Player Content
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              View milestones & journals
                            </p>
                          </CardContent>
                        </Card>
                      )}
                      
                      {hasPermission(PERMISSIONS.VIEW_SHARED_MILESTONES) && (
                        <Card 
                          className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                          onClick={() => navigate('/admin-system-milestones')}
                        >
                          <CardContent className="p-6 text-center">
                            <div className="mb-4 flex justify-center">
                              <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                                <Settings className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                              </div>
                            </div>
                            <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                              System Milestones
                            </h3>
                            <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                              Define automatic milestones
                            </p>
                          </CardContent>
                        </Card>
                      )}
                    </>
                  )}
                                    
                  {/* Analytics Hub */}
                  {hasPermission(PERMISSIONS.VIEW_ANALYTICS) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminAnalytics')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <BarChart3 className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Analytics Hub
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          System insights & metrics
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                  {/* Role Management - Super Admin only */}
                  {hasPermission(PERMISSIONS.MANAGE_ROLES) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/AdminRoles')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <Shield className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Manage Roles
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          User permissions & roles
                        </p>
                      </CardContent>
                    </Card>
                  )}

                  {/* Audit Logs */}
                  {(hasPermission(PERMISSIONS.VIEW_AUDIT_LOGS) || hasPermission(PERMISSIONS.VIEW_ADMIN_PANEL)) && (
                    <Card 
                      className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-purple-800/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
                      onClick={() => navigate('/admin-audit-logs')}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="mb-4 flex justify-center">
                          <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-purple-700/20 group-hover:from-purple-500/30 group-hover:to-purple-700/30 transition-all duration-300">
                            <History className="w-8 h-8 text-purple-300 group-hover:text-purple-200" />
                          </div>
                        </div>
                        <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-purple-200 transition-colors">
                          Audit Logs
                        </h3>
                        <p className="text-purple-300 text-sm group-hover:text-purple-200 transition-colors">
                          View system activity
                        </p>
                      </CardContent>
                    </Card>
                  )}
                  
                </div>
              </div>
            )}
          </div>
        )}

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
          <div className="absolute top-3/4 left-1/2 w-48 h-48 bg-amber-600/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
        </div>
      </main>
    </div>
  );
}
