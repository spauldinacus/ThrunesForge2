import { useEffect, useState } from "react";
import type { TestCharacterResponse, ArchetypeResponse } from "types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PlusCircle, Trash2, Edit, Sparkles, ArrowLeft, Zap, TrendingDown } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { apiClient } from "app";

  interface TestCharacterListData {
    test_characters: TestCharacterResponse[];
    count: number;
    max_allowed?: number;  // ← Add ? to make it optional
  }

export default function TestCharacters() {
  const navigate = useNavigate();
  const [testCharacters, setTestCharacters] = useState<TestCharacterResponse[]>([]);
  const [archetypes, setArchetypes] = useState<ArchetypeResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [maxAllowed, setMaxAllowed] = useState(3);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [characterToDelete, setCharacterToDelete] = useState<string | null>(null);
  const [optimizationDialogOpen, setOptimizationDialogOpen] = useState(false);
  const [selectedCharacterForOptimization, setSelectedCharacterForOptimization] = useState<TestCharacterResponse | null>(null);
  const [optimizationResults, setOptimizationResults] = useState<any>(null);
  const [loadingOptimization, setLoadingOptimization] = useState(false);
  
  // Helper function to get archetype name by ID
  const getArchetypeName = (archetypeId: string | undefined | null): string => {
    if (!archetypeId) return '';
    const archetype = archetypes.find(a => a.id === archetypeId);
    return archetype?.name || archetypeId;
  };
  
  // Load test characters and archetypes
  const loadTestCharacters = async () => {
    try {
      setLoading(true);
      
      // Load both test characters and archetypes in parallel
      const [charactersResponse, archetypesResponse] = await Promise.all([
        apiClient.list_my_test_characters(),
        apiClient.list_archetypes()
      ]);
      
      const charactersData: TestCharacterListData = await charactersResponse.json();
      const archetypesData = await archetypesResponse.json();
      
      setTestCharacters(charactersData.test_characters || []);
      setMaxAllowed(charactersData.max_allowed || 3);
      setArchetypes(Array.isArray(archetypesData) ? archetypesData : archetypesData.archetypes || []);
    } catch (error) {
      console.error("Failed to load test characters:", error);
      toast.error("Failed to load test characters");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTestCharacters();
  }, []);

  // Handle optimization
  const handleOptimize = async (character: TestCharacterResponse) => {
    setSelectedCharacterForOptimization(character);
    setLoadingOptimization(true);
    setOptimizationDialogOpen(true);
    
    try {
      const stream = apiClient.optimize_build({
        selected_skills: character.selected_skills.map(s => ({
          skill_id: s.skill_id,
          quantity: s.quantity
        })),
        heritage_id: character.heritage_id,
        body: character.body,
        stamina: character.stamina
      });
      
      // Collect all streamed data with improved SSE parsing
      let buffer = '';
      let finalResult = null;
      
      try {
        for await (const chunk of stream) {
          console.log('🔍 RAW CHUNK:', JSON.stringify(chunk), 'TYPE:', typeof chunk, 'LENGTH:', chunk?.length);
          
          if (!chunk) {
            console.warn('⚠️ RECEIVED EMPTY CHUNK');
            continue;
          }
          
          // Accumulate chunks
          buffer += chunk;
          console.log('📦 BUFFER SO FAR (length:', buffer.length, '):', buffer.substring(0, 200) + '...');
        }
        
        console.log('✅ STREAM COMPLETE. FULL BUFFER:', buffer);
        
        // Process all lines after stream completes
        const lines = buffer.split('\n');
        
        for (const line of lines) {
          const trimmedLine = line.trim();
          
          if (!trimmedLine || trimmedLine === '') continue;
          
          console.log('📝 PROCESSING LINE:', trimmedLine);
          
          // Handle SSE format: "data: {...}"
          if (trimmedLine.startsWith('data: ')) {
            const jsonStr = trimmedLine.substring(6).trim();
            console.log('📦 JSON STRING:', jsonStr);
            
            try {
              const parsed = JSON.parse(jsonStr);
              console.log('✅ PARSED EVENT:', parsed);
              
              // Check if this is the final result (type: 'complete')
              if (parsed.type === 'complete') {
                finalResult = parsed.data;
                console.log('✅ FOUND COMPLETE EVENT with data:', finalResult);
                break;
              }
              // Otherwise it's a progress or status update, continue
            } catch (e) {
              console.warn('❌ Parse error:', e, 'Line:', trimmedLine);
            }
          }
        }
      } catch (streamError) {
        console.error('❌ STREAM ERROR:', streamError);
        throw new Error(`Stream failed: ${streamError}`);
      }
      
      console.log('🏁 FINAL RESULT:', finalResult);
            
      if (!finalResult) {
        throw new Error('No optimization results received');
      }
      
      const data = finalResult;

      // Calculate savings based on current XP
      const results = {
        ...data,
        current_xp: character.xp_cost,
        optimal_combinations: data.optimal_combinations.map((combo: any) => ({
          ...combo,
          xp_savings: character.xp_cost - combo.xp_cost
        })),
        potential_savings: character.xp_cost - (data.optimal_combinations[0]?.xp_cost || 0)
      };
      
      setOptimizationResults(results);
    } catch (error) {
      console.error("Failed to optimize build:", error);
      toast.error("Failed to calculate optimization");
    } finally {
      setLoadingOptimization(false);
    }
  };

  
  // Handle create new test character
  const handleCreate = () => {
    if (testCharacters.length >= maxAllowed) {
      toast.error(`Maximum ${maxAllowed} test characters allowed. Delete one first.`);
      return;
    }
    // Navigate to character creator in test mode
    navigate("/character-creator?mode=test");
  };

  // Handle edit test character
  const handleEdit = (characterId: string) => {
    navigate(`/character-creator?mode=test&id=${characterId}`);
  };

  // Handle delete confirmation
  const confirmDelete = (characterId: string) => {
    setCharacterToDelete(characterId);
    setDeleteDialogOpen(true);
  };

  // Handle delete test character
  const handleDelete = async () => {
    if (!characterToDelete) return;

    try {
      await apiClient.delete_test_character({ testCharacterId: characterToDelete });
      toast.success("Test character deleted");
      setDeleteDialogOpen(false);
      setCharacterToDelete(null);
      loadTestCharacters(); // Reload list
    } catch (error) {
      console.error("Failed to delete test character:", error);
      toast.error("Failed to delete test character");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Navigation Header */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Character Test Lab
        </div>
      </header>

      {/* Main Container */}
      <div className="container mx-auto p-6 space-y-6">
        {/* Create Character Button - Top right */}
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <Sparkles className="h-6 w-6 text-amber-400" />
            <p className="text-purple-300 text-sm">
              {testCharacters.length} of {maxAllowed} test characters • No XP limits • Experiment freely
            </p>
          </div>
          <Button
            onClick={handleCreate}
            disabled={testCharacters.length >= maxAllowed}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <PlusCircle className="w-4 h-4 mr-2" />
            Create Test Character
          </Button>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-12">
            <div className="text-purple-300">Loading test characters...</div>
          </div>
        ) : testCharacters.length === 0 ? (
          <Card className="bg-purple-950/40 border-purple-800/50 backdrop-blur-sm">
            <CardContent className="py-12 text-center">
              <Sparkles className="h-16 w-16 text-amber-400/50 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-purple-100 mb-2">
                No Test Characters Yet
              </h3>
              <p className="text-purple-300/70 mb-6">
                Create test characters to experiment with different builds and find the optimal archetype combinations.
              </p>
              <Button
                onClick={handleCreate}
                className="bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white"
              >
                <PlusCircle className="mr-2 h-4 w-4" />
                Create Test Character
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">

            {/* Character cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testCharacters.map((character) => (
                <Card
                  key={character.id}
                  className="bg-gradient-to-br from-purple-950/60 to-indigo-950/60 border-purple-700/50 backdrop-blur-sm hover:border-amber-500/50 transition-all duration-300 shadow-xl"
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-amber-400">
                          {character.name}
                        </CardTitle>
                        <CardDescription className="text-purple-300">
                          XP Cost: {character.xp_cost}
                        </CardDescription>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleOptimize(character)}
                        className="text-amber-400 hover:text-amber-300 hover:bg-amber-950/50"
                      >
                        <Zap className="h-4 w-4 mr-1" />
                        Optimize
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {/* Archetypes - show secondary and tertiary if present */}
                    {(character.secondary_archetype_id || character.tertiary_archetype_id) && (
                      <div className="bg-black/30 rounded-lg p-3 border border-purple-800/30">
                        <div className="text-purple-400 text-xs mb-1">Archetypes</div>
                        <div className="space-y-1">
                          <div className="text-purple-200 text-sm">Primary: {getArchetypeName(character.archetype_id)}</div>
                          {character.secondary_archetype_id && (
                            <div className="text-purple-200 text-sm">Secondary: {getArchetypeName(character.secondary_archetype_id)}</div>
                          )}
                          {character.tertiary_archetype_id && (
                            <div className="text-purple-200 text-sm">Tertiary: {getArchetypeName(character.tertiary_archetype_id)}</div>
                          )}
                        </div>
                      </div>
                    )}

                    {/* Stats */}
                    <div className="grid grid-cols-2 gap-3">
                      <div className="bg-black/30 rounded-lg p-3 border border-purple-800/30">
                        <div className="text-purple-400 text-xs mb-1">Body</div>
                        <div className="text-amber-200 text-lg font-bold">{character.body}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 border border-purple-800/30">
                        <div className="text-purple-400 text-xs mb-1">Stamina</div>
                        <div className="text-amber-200 text-lg font-bold">{character.stamina}</div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-3 border border-purple-800/30 col-span-2">
                        <div className="text-purple-400 text-xs mb-1">XP Spent</div>
                        <div className="text-amber-200 text-lg font-bold">{character.xp_cost}</div>
                      </div>
                    </div>

                    {/* Skills count */}
                    <div className="bg-black/30 rounded-lg p-3 border border-purple-800/30">
                      <div className="text-purple-400 text-xs mb-1">Skills</div>
                      <div className="text-purple-200 text-sm">
                        {character.selected_skills?.length || 0} selected
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-2 pt-2">
                      <Button
                        onClick={() => handleEdit(character.id)}
                        variant="outline"
                        className="flex-1 border-amber-600/50 text-amber-400 hover:bg-amber-950/50 hover:text-amber-300"
                      >
                        <Edit className="mr-2 h-4 w-4" />
                        Edit
                      </Button>
                      <Button
                        onClick={() => confirmDelete(character.id)}
                        variant="outline"
                        className="border-red-600/50 text-red-400 hover:bg-red-950/50 hover:text-red-300"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Delete confirmation dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent className="bg-gradient-to-br from-purple-950 to-indigo-950 border-purple-700/50">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-amber-200">Delete Test Character?</AlertDialogTitle>
            <AlertDialogDescription className="text-purple-300">
              This will permanently delete this test character. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-purple-700/50 text-purple-300 hover:bg-purple-900/50">
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

              {/* Optimization Dialog */}
      <Dialog open={optimizationDialogOpen} onOpenChange={setOptimizationDialogOpen}>
        <DialogContent className="bg-gradient-to-br from-purple-950 to-indigo-950 border-purple-700/50 max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-amber-200 to-amber-400">
              <Zap className="inline h-6 w-6 mr-2" />
              Build Optimizer
            </DialogTitle>
            <DialogDescription className="text-purple-300">
              {selectedCharacterForOptimization?.name} - Analyzing archetype combinations for your skills
            </DialogDescription>
          </DialogHeader>

          {loadingOptimization ? (
            <div className="py-12 text-center text-purple-300">
              Calculating optimal builds...
            </div>
          ) : optimizationResults ? (
            <div className="space-y-6">
              {/* Current Build Summary */}
              <Card className="bg-purple-900/40 border-purple-700/50">
                <CardHeader>
                  <CardTitle className="text-lg text-amber-200">Current Build</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold text-purple-200">
                    {optimizationResults.current_xp} XP
                  </div>
                  {optimizationResults.potential_savings > 0 && (
                    <Badge className="mt-2 bg-green-600/20 text-green-400 border-green-600/50">
                      <TrendingDown className="h-3 w-3 mr-1" />
                      Save up to {optimizationResults.potential_savings} XP
                    </Badge>
                  )}
                  {optimizationResults.potential_savings === 0 && (
                    <Badge className="mt-2 bg-amber-600/20 text-amber-400 border-amber-600/50">
                      ✓ Already Optimal!
                    </Badge>
                  )}
                </CardContent>
              </Card>

              {/* Top 5 Optimal Combinations */}
              <div className="space-y-3">
                <h3 className="text-lg font-semibold text-amber-200">
                  Recommended Archetype Combinations
                </h3>
                {optimizationResults.optimal_combinations.map((combo: any, index: number) => (
                  <Card
                    key={index}
                    className={`bg-gradient-to-r ${
                      index === 0
                        ? 'from-amber-950/60 to-amber-900/60 border-amber-600/70'
                        : 'from-purple-950/40 to-indigo-950/40 border-purple-700/50'
                    } backdrop-blur-sm`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          {index === 0 && (
                            <Badge className="mb-2 bg-amber-600 text-white">
                              ⭐ Most Optimal
                            </Badge>
                          )}
                          <div className="text-lg font-semibold text-purple-100">
                            {combo.archetype_name}
                            {combo.secondary_archetype_name && ` + ${combo.secondary_archetype_name}`}
                            {combo.tertiary_archetype_name && ` + ${combo.tertiary_archetype_name}`}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-amber-200">
                            {combo.xp_cost} XP
                          </div>
                          {combo.xp_savings > 0 && (
                            <div className="text-sm text-green-400">
                              -{combo.xp_savings} XP
                            </div>
                          )}
                          {combo.xp_savings === 0 && (
                            <div className="text-sm text-purple-400">
                              Current
                            </div>
                          )}
                          {combo.xp_savings < 0 && (
                            <div className="text-sm text-red-400">
                              +{Math.abs(combo.xp_savings)} XP
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          ) : null}
        </DialogContent>
      </Dialog>
        
    </div>
  );
}
