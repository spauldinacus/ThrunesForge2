import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ArrowLeft, Users, CheckCircle, Clock, Trophy, Loader2, Check, ArrowUpDown } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { useUserGuardContext } from 'app/auth';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import type { ReferralStatsResponse, ReferralResponse } from 'types';

export default function AdminReferrals() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading, permissions, isAdmin } = usePermissions();
  const [stats, setStats] = useState<ReferralStatsResponse | null>(null);
  const [referrals, setReferrals] = useState<ReferralRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'pending' | 'acknowledged'>('all');
  const [acknowledgeDialog, setAcknowledgeDialog] = useState<{
    open: boolean;
    referral: ReferralRecord | null;
  }>({ open: false, referral: null });
  const [acknowledging, setAcknowledging] = useState(false);
  const [sortField, setSortField] = useState<'player_name' | 'referred_by_name' | 'created_at' | 'status'>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    if (permissionsLoading) return;

    if (!hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
      toast.error('You do not have permission to view this page');
      navigate('/');
      return;
    }

    loadData();
  }, [filter, permissionsLoading]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [statsResponse, referralsResponse] = await Promise.all([
        apiClient.get_referral_stats(),
        apiClient.list_referrals({ filter_type: filter })
      ]);
      
      const statsData: ReferralStatsResponse = await statsResponse.json();
      const referralsData = await referralsResponse.json();
      
      console.log('Stats data:', statsData);
      console.log('Referrals data:', referralsData);
      
      setStats(statsData);
      // Ensure referrals is always an array
      setReferrals(Array.isArray(referralsData.referrals) ? referralsData.referrals : []);
    } catch (error) {
      console.error('Failed to load referral data:', error);
      toast.error('Failed to load referral data');
    } finally {
      setLoading(false);
    }
  };
  
  const handleSort = (field: typeof sortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const sortedReferrals = React.useMemo(() => {
    if (!referrals || referrals.length === 0) return [];
    
    const sorted = [...referrals].sort((a, b) => {
      let aValue: any;
      let bValue: any;
      
      switch (sortField) {
        case 'player_name':
          aValue = a.player_name?.toLowerCase() || '';
          bValue = b.player_name?.toLowerCase() || '';
          break;
        case 'referred_by_name':
          aValue = a.referred_by_name?.toLowerCase() || '';
          bValue = b.referred_by_name?.toLowerCase() || '';
          break;
        case 'created_at':
          aValue = new Date(a.created_at).getTime();
          bValue = new Date(b.created_at).getTime();
          break;
        case 'status':
          aValue = a.referral_acknowledged ? 1 : 0;
          bValue = b.referral_acknowledged ? 1 : 0;
          break;
        default:
          return 0;
      }
      
      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
    
    return sorted;
  }, [referrals, sortField, sortDirection]);
  
  useEffect(() => {
    if (hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
      loadData();
    }
  }, [filter]);

  const handleAcknowledge = async () => {
    if (!acknowledgeDialog.referral) return;
    
    try {
      setAcknowledging(true);
      await apiClient.acknowledge_referral({
        player_id: acknowledgeDialog.referral.player_id
      });
      
      toast.success('Referral acknowledged successfully!');
      setAcknowledgeDialog({ open: false, referral: null });
      loadData(); // Reload data
    } catch (error) {
      console.error('Failed to acknowledge referral:', error);
      toast.error('Failed to acknowledge referral');
    } finally {
      setAcknowledging(false);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (permissionsLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  if (!hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-900">
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Referral Management
        </div>
      </header>

      <div className="container mx-auto p-6 space-y-6">
        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card key="total" className="bg-black/60 backdrop-blur-xl border-purple-500/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-purple-200">
                  Total Referrals
                </CardTitle>
                <Users className="w-4 h-4 text-purple-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">
                  {stats.total_referrals}
                </div>
              </CardContent>
            </Card>

            <Card key="pending" className="bg-black/60 backdrop-blur-xl border-amber-500/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-amber-200">
                  Pending Review
                </CardTitle>
                <Clock className="w-4 h-4 text-amber-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">
                  {stats.pending_referrals}
                </div>
              </CardContent>
            </Card>

            <Card key="acknowledged" className="bg-black/60 backdrop-blur-xl border-green-500/30">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-green-200">
                  Acknowledged
                </CardTitle>
                <CheckCircle className="w-4 h-4 text-green-400" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-white">
                  {stats.acknowledged_referrals}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Top Referrers */}
        {stats && Array.isArray(stats.top_referrers) && stats.top_referrers.length > 0 && (
          <Card className="bg-black/60 backdrop-blur-xl border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-lg text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400 flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" />
                Top Referrers
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {stats.top_referrers.map((referrer, index) => (
                  <div 
                    key={referrer.player_id} 
                    className="flex items-center justify-between p-3 rounded bg-black/40 border border-purple-500/20"
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                        index === 0 ? 'bg-amber-500/20 text-amber-300' :
                        index === 1 ? 'bg-gray-400/20 text-gray-300' :
                        index === 2 ? 'bg-orange-600/20 text-orange-300' :
                        'bg-purple-500/20 text-purple-300'
                      }`}>
                        {index + 1}
                      </div>
                      <div>
                        <div className="text-white font-medium">
                          {referrer.player_name}
                        </div>
                        <div className="text-purple-200/60 text-sm">
                          #{referrer.player_number}
                        </div>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-purple-500/20 text-purple-200">
                      {referrer.referral_count} {referrer.referral_count === 1 ? 'referral' : 'referrals'}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Referrals Table */}
        <Card className="bg-black/60 backdrop-blur-xl border-purple-500/30">
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle className="text-lg text-purple-200">
                All Referrals
              </CardTitle>
              <Select value={filter} onValueChange={(value: any) => setFilter(value)}>
                <SelectTrigger className="w-[180px] bg-black/40 border-purple-500/30 text-white">
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent className="bg-black/95 border-purple-500/30">
                  <SelectItem value="all" className="text-white">All Referrals</SelectItem>
                  <SelectItem value="pending" className="text-white">Pending</SelectItem>
                  <SelectItem value="acknowledged" className="text-white">Acknowledged</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent>
            {referrals.length === 0 ? (
              <div className="text-center text-purple-200/60 py-8">
                No referrals found
              </div>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-purple-500/30">
                      <TableHead 
                        className="text-purple-200 cursor-pointer hover:text-purple-100 transition-colors"
                        onClick={() => handleSort('player_name')}
                      >
                        <div className="flex items-center gap-2">
                          Player
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-200 cursor-pointer hover:text-purple-100 transition-colors"
                        onClick={() => handleSort('referred_by_name')}
                      >
                        <div className="flex items-center gap-2">
                          Referred By
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-200 cursor-pointer hover:text-purple-100 transition-colors"
                        onClick={() => handleSort('created_at')}
                      >
                        <div className="flex items-center gap-2">
                          Date Joined
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-200 cursor-pointer hover:text-purple-100 transition-colors"
                        onClick={() => handleSort('status')}
                      >
                        <div className="flex items-center gap-2">
                          Status
                          <ArrowUpDown className="w-4 h-4" />
                        </div>
                      </TableHead>
                      <TableHead className="text-purple-200">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedReferrals.map((referral) => (
                      <TableRow key={referral.player_id} className="border-purple-500/20">
                        <TableCell className="text-white">
                          <div>
                            <div className="font-medium">{referral.player_name}</div>
                            <div className="text-sm text-purple-200/60">
                              #{referral.player_number}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-white">
                          <div>
                            <div className="font-medium">{referral.referred_by_name}</div>
                            <div className="text-sm text-purple-200/60">
                              #{referral.referred_by_number}
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-purple-200">
                          {formatDate(referral.created_at)}
                        </TableCell>
                        <TableCell>
                          {referral.referral_acknowledged ? (
                            <div>
                              <Badge variant="secondary" className="bg-green-500/20 text-green-300">
                                <Check className="w-3 h-3 mr-1" />
                                Verified
                              </Badge>
                              {referral.referral_acknowledged_at && (
                                <div className="text-xs text-purple-200/60 mt-1">
                                  {formatDate(referral.referral_acknowledged_at)}
                                </div>
                              )}
                            </div>
                          ) : (
                            <Badge variant="secondary" className="bg-amber-500/20 text-amber-300">
                              <Clock className="w-3 h-3 mr-1" />
                              Pending
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          {!referral.referral_acknowledged && (
                            <Button
                              size="sm"
                              onClick={() => setAcknowledgeDialog({ open: true, referral })}
                              className="bg-green-600/80 hover:bg-green-600 text-white"
                            >
                              Acknowledge
                            </Button>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Acknowledge Dialog */}
      <Dialog open={acknowledgeDialog.open} onOpenChange={(open) => !acknowledging && setAcknowledgeDialog({ open, referral: null })}>
        <DialogContent className="bg-black/90 border-purple-500/30">
          <DialogHeader>
            <DialogTitle className="text-xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
              Acknowledge Referral
            </DialogTitle>
            <DialogDescription className="text-purple-200/80">
              This will permanently lock the referral and mark it as verified.
            </DialogDescription>
          </DialogHeader>
          
          {acknowledgeDialog.referral && (
            <div className="space-y-3 py-4">
              <div className="p-4 rounded bg-purple-500/10 border border-purple-500/30">
                <div className="text-sm text-purple-200/60 mb-1">Player</div>
                <div className="text-white font-medium">
                  {acknowledgeDialog.referral.player_name} (#{acknowledgeDialog.referral.player_number})
                </div>
              </div>
              
              <div className="p-4 rounded bg-purple-500/10 border border-purple-500/30">
                <div className="text-sm text-purple-200/60 mb-1">Referred By</div>
                <div className="text-white font-medium">
                  {acknowledgeDialog.referral.referred_by_name} (#{acknowledgeDialog.referral.referred_by_number})
                </div>
              </div>
            </div>
          )}
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setAcknowledgeDialog({ open: false, referral: null })}
              disabled={acknowledging}
              className="border-purple-500/50 text-purple-200 hover:bg-purple-600/20"
            >
              Cancel
            </Button>
            <Button
              onClick={handleAcknowledge}
              disabled={acknowledging}
              className="bg-green-600/80 hover:bg-green-600 text-white"
            >
              {acknowledging ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Acknowledging...
                </>
              ) : (
                <>
                  <Check className="w-4 h-4 mr-2" />
                  Confirm
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
