import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiClient } from "app";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, RefreshCw, Download, TrendingUp, TrendingDown, Minus, Calendar, Users } from "lucide-react";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { AnalyticsLayout } from "components/AnalyticsLayout";
import { AnalyticsCard } from "components/AnalyticsCard";
import type { 
  EventPerformanceAnalytics, 
  AttendanceTrend, 
  UpcomingEventRSVP,
  RSVPAccuracyByEvent,
  EventRanking,
  ChapterComparison,
  AppApisAdminScopedChapterResponse  // ✅ Use the actual type
} from "types";

const COLORS = ['#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe', '#ede9fe'];

export default function AdminEventPerformance() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [data, setData] = useState<EventPerformanceAnalytics | null>(null);
  const [chapters, setChapters] = useState<AppApisAdminScopedChapterResponse[]>([]);
  const [selectedChapter, setSelectedChapter] = useState<string>("all");
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setRefreshing(true);
      setError(null);

      // Load chapters for filter
      const chaptersResponse = await apiClient.list_scoped_chapters();
      const chaptersData = await chaptersResponse.json();
      setChapters(chaptersData.chapters || []);  // ✅ Fixed: extracts chapters array

      // Load analytics data
      const params: { chapter_id?: string } = {};
      if (selectedChapter !== "all") {
        params.chapter_id = selectedChapter;
      } 
      const response = await apiClient.get_event_performance_analytics(params);
      const analyticsData = await response.json();
      setData(analyticsData);
    } catch (err) {
      console.error('Failed to load event performance analytics:', err);
      setError('Failed to load analytics data. Please try again.');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadData();
  }, [selectedChapter]);

  const exportToCSV = () => {
    if (!data) return;

    // Prepare CSV data
    const csvRows = [];
    csvRows.push('Event Performance Analytics Report');
    csvRows.push('');
    csvRows.push('Overall Statistics');
    csvRows.push(`Total Events,${data.total_events}`);
    csvRows.push(`Past Events,${data.total_past_events}`);
    csvRows.push(`Average Attendance,${data.avg_attendance_per_event}`);
    csvRows.push(`Attendance Trend,${data.attendance_trend}`);
    csvRows.push(`RSVP Accuracy,${data.overall_rsvp_accuracy}%`);
    csvRows.push(`No-Show Rate,${data.no_show_rate}%`);
    csvRows.push('');
    
    csvRows.push('Monthly Trends');
    csvRows.push('Month,Year,Event Count,Total Attendance,Avg Attendance');
    data.monthly_trends.forEach(trend => {
      csvRows.push(`${trend.month},${trend.year},${trend.event_count},${trend.total_attendance},${trend.avg_attendance}`);
    });
    csvRows.push('');

    csvRows.push('RSVP Accuracy by Event');
    csvRows.push('Event,Date,RSVP Yes,Attended,Accuracy %');
    data.rsvp_accuracy_by_event.forEach(event => {
      csvRows.push(`${event.title},${new Date(event.event_date).toLocaleDateString()},${event.rsvp_yes_count},${event.actual_attended},${event.accuracy_rate}`);
    });
    csvRows.push('');

    csvRows.push('Chapter Comparison');
    csvRows.push('Chapter,Event Count,Avg Attendance,RSVP Accuracy %');
    data.chapter_comparisons.forEach(chapter => {
      csvRows.push(`${chapter.chapter_name},${chapter.event_count},${chapter.avg_attendance},${chapter.rsvp_accuracy}`);
    });

    // Create and download CSV
    const csvContent = csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', `event-performance-${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', { 
      month: 'short', 
      day: 'numeric',
      year: 'numeric'
    });
  };

  const getTrendIcon = (trend: string) => {
    if (trend === "growing") return <TrendingUp className="h-5 w-5 text-green-500" />;
    if (trend === "declining") return <TrendingDown className="h-5 w-5 text-red-500" />;
    return <Minus className="h-5 w-5 text-yellow-500" />;
  };

  if (loading) {
    return (
      <AnalyticsLayout>
        <div className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center gap-4">
            <RefreshCw className="h-8 w-8 animate-spin text-purple-500" />
            <p className="text-muted-foreground">Loading event performance analytics...</p>
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  if (error || !data) {
    return (
      <AnalyticsLayout>
        <div className="flex items-center justify-center h-64">
          <div className="flex flex-col items-center gap-4">
            <p className="text-red-500">{error || 'Failed to load data'}</p>
            <Button onClick={loadData}>Retry</Button>
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  return (
    <AnalyticsLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" onClick={() => navigate('/admin-analytics')}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Event Performance Analytics
              </h1>
              <p className="text-muted-foreground mt-1">
                Attendance trends, RSVP accuracy, and event metrics
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Select value={selectedChapter} onValueChange={setSelectedChapter}>
              <SelectTrigger className="w-48 bg-card/50 border-purple-500/20">
                <SelectValue placeholder="All Chapters" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Chapters</SelectItem>
                {chapters.map(chapter => (
                  <SelectItem key={chapter.id} value={chapter.id}>
                    {chapter.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="icon"
              onClick={loadData}
              disabled={refreshing}
              className="border-purple-500/20"
            >
              <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
            </Button>
            <Button
              variant="outline"
              onClick={exportToCSV}
              className="border-purple-500/20"
            >
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <AnalyticsCard
            title="Total Events"
            value={data.total_events}
            icon={Calendar}
            subtitle={`${data.total_past_events} completed`}
          />
          <AnalyticsCard
            title="Avg Attendance"
            value={data.avg_attendance_per_event}
            icon={Users}
            subtitle="per event"
          />
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader className="pb-2">
              <CardDescription className="flex items-center gap-2">
                <TrendingUp className="h-4 w-4" />
                Attendance Trend
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2">
                {getTrendIcon(data.attendance_trend)}
                <span className="text-2xl font-bold capitalize">
                  {data.attendance_trend}
                </span>
              </div>
            </CardContent>
          </Card>
          <AnalyticsCard
            title="RSVP Accuracy"
            value={`${data.overall_rsvp_accuracy}%`}
            icon={TrendingUp}
            subtitle={`${data.no_show_rate}% no-shows`}
          />
        </div>

        {/* Monthly Trends */}
        <Card className="bg-card/50 backdrop-blur border-purple-500/20">
          <CardHeader>
            <CardTitle>Monthly Attendance Trends (Last 12 Months)</CardTitle>
            <CardDescription>Event count and attendance over time</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={[...data.monthly_trends].reverse()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                  <XAxis 
                    dataKey="month" 
                    stroke="#888"
                  />
                  <YAxis stroke="#888" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1a1a2e', 
                      border: '1px solid #8b5cf6',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="event_count" 
                    stroke="#8b5cf6" 
                    strokeWidth={2}
                    name="Event Count"
                    dot={{ fill: '#8b5cf6' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="total_attendance" 
                    stroke="#60a5fa" 
                    strokeWidth={2}
                    name="Total Attendance"
                    dot={{ fill: '#60a5fa' }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="avg_attendance" 
                    stroke="#fbbf24" 
                    strokeWidth={2}
                    name="Avg Attendance"
                    dot={{ fill: '#fbbf24' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        {data.upcoming_events.length > 0 && (
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Upcoming Events (Next 30 Days)</CardTitle>
              <CardDescription>Current RSVP counts</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Chapter</TableHead>
                    <TableHead className="text-right">Total RSVPs</TableHead>
                    <TableHead className="text-right">Going</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.upcoming_events.map(event => (
                    <TableRow key={event.event_id}>
                      <TableCell className="font-medium">{event.title}</TableCell>
                      <TableCell>{formatDate(event.starts_at)}</TableCell>
                      <TableCell>{event.chapter_name}</TableCell>
                      <TableCell className="text-right">{event.rsvp_count}</TableCell>
                      <TableCell className="text-right">
                        <span className="text-green-400 font-semibold">{event.going_count}</span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        )}

        {/* RSVP Accuracy Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* RSVP Breakdown */}
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>RSVP Accuracy Breakdown</CardTitle>
              <CardDescription>Overall RSVP vs actual attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-around text-center">
                  <div>
                    <div className="text-3xl font-bold text-purple-400">
                      {data.overall_rsvp_accuracy}%
                    </div>
                    <div className="text-sm text-muted-foreground">Accuracy</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-red-400">
                      {data.no_show_rate}%
                    </div>
                    <div className="text-sm text-muted-foreground">No-Shows</div>
                  </div>
                  <div>
                    <div className="text-3xl font-bold text-blue-400">
                      {data.surprise_attendance_rate}%
                    </div>
                    <div className="text-sm text-muted-foreground">Surprise</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Event Accuracy */}
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Recent Events RSVP Accuracy</CardTitle>
              <CardDescription>Last 10 events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-64 overflow-y-auto">
                {data.rsvp_accuracy_by_event.slice(0, 10).map(event => (
                  <div key={event.event_id} className="flex items-center justify-between p-2 rounded bg-background/50">
                    <div className="flex-1 min-w-0">
                      <div className="font-medium truncate">{event.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {event.rsvp_yes_count} RSVP / {event.actual_attended} attended
                      </div>
                    </div>
                    <div className={`text-lg font-bold ml-4 ${
                      event.accuracy_rate >= 80 ? 'text-green-400' :
                      event.accuracy_rate >= 60 ? 'text-yellow-400' : 'text-red-400'
                    }`}>
                      {event.accuracy_rate}%
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Event Rankings */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Most Attended */}
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Most Attended Events</CardTitle>
              <CardDescription>Top 10 by attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>Chapter</TableHead>
                    <TableHead className="text-right">Attendance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.most_attended_events.map((event, idx) => (
                    <TableRow key={event.event_id}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <span className="text-purple-400 font-bold">#{idx + 1}</span>
                          <div>
                            <div className="font-medium">{event.title}</div>
                            <div className="text-xs text-muted-foreground">
                              {formatDate(event.event_date)}
                            </div>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{event.chapter_name}</TableCell>
                      <TableCell className="text-right font-semibold text-green-400">
                        {event.attendance_count}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Least Attended */}
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Least Attended Events</CardTitle>
              <CardDescription>Bottom 10 by attendance</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Event</TableHead>
                    <TableHead>Chapter</TableHead>
                    <TableHead className="text-right">Attendance</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.least_attended_events.map(event => (
                    <TableRow key={event.event_id}>
                      <TableCell>
                        <div>
                          <div className="font-medium">{event.title}</div>
                          <div className="text-xs text-muted-foreground">
                            {formatDate(event.event_date)}
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>{event.chapter_name}</TableCell>
                      <TableCell className="text-right font-semibold text-yellow-400">
                        {event.attendance_count}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>

        {/* Chapter Comparison */}
        <Card className="bg-card/50 backdrop-blur border-purple-500/20">
          <CardHeader>
            <CardTitle>Chapter Performance Comparison</CardTitle>
            <CardDescription>Events, attendance, and RSVP accuracy by chapter</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {/* Events per Chapter Chart */}
              <div>
                <h4 className="text-sm font-semibold mb-4">Events Per Chapter</h4>
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data.chapter_comparisons}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#444" />
                      <XAxis dataKey="chapter_name" stroke="#888" />
                      <YAxis stroke="#888" />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: '#1a1a2e',
                          border: '1px solid #8b5cf6',
                          borderRadius: '8px'
                        }}
                      />
                      <Bar dataKey="event_count" fill="#8b5cf6" name="Events" />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Chapter Stats Table */}
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Chapter</TableHead>
                    <TableHead className="text-right">Events</TableHead>
                    <TableHead className="text-right">Avg Attendance</TableHead>
                    <TableHead className="text-right">RSVP Accuracy</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.chapter_comparisons.map(chapter => (
                    <TableRow key={chapter.chapter_id}>
                      <TableCell className="font-medium">{chapter.chapter_name}</TableCell>
                      <TableCell className="text-right">{chapter.event_count}</TableCell>
                      <TableCell className="text-right">{chapter.avg_attendance.toFixed(1)}</TableCell>
                      <TableCell className="text-right">
                        <span className={`font-semibold ${
                          chapter.rsvp_accuracy >= 80 ? 'text-green-400' :
                          chapter.rsvp_accuracy >= 60 ? 'text-yellow-400' : 'text-red-400'
                        }`}>
                          {chapter.rsvp_accuracy.toFixed(1)}%
                        </span>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

                {/* XP Purchase Economics */}
        <Card className="bg-gradient-to-br from-purple-950/40 to-blue-950/40 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-200 flex items-center gap-2">
              <TrendingUp className="h-6 w-6" />
              XP Purchase Economics
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Summary Stats */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-purple-950/30 border-purple-500/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-purple-300">Total Ticket XP</p>
                  <p className="text-3xl font-bold text-purple-100">
                    {data.xp_purchase_metrics.total_ticket_xp_purchased}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-blue-950/30 border-blue-500/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300">Total Candle XP</p>
                  <p className="text-3xl font-bold text-blue-100">
                    {data.xp_purchase_metrics.total_candle_xp_purchased}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-amber-950/30 border-amber-500/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-amber-300">Total XP Purchased</p>
                  <p className="text-3xl font-bold text-amber-100">
                    {data.xp_purchase_metrics.total_xp_purchased}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-orange-950/30 border-orange-500/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-orange-300">Candles Spent</p>
                  <p className="text-3xl font-bold text-orange-100">
                    {data.xp_purchase_metrics.candles_spent_on_xp}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Averages */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-purple-900/20 border-purple-400/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-purple-300">Avg Ticket XP per Event</p>
                  <p className="text-2xl font-bold text-purple-100">
                    {data.xp_purchase_metrics.avg_ticket_xp_per_event.toFixed(2)}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-blue-900/20 border-blue-400/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300">Avg Candle XP per Event</p>
                  <p className="text-2xl font-bold text-blue-100">
                    {data.xp_purchase_metrics.avg_candle_xp_per_event.toFixed(2)}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Monthly Trend Chart */}
            <div>
              <h3 className="text-lg font-semibold text-purple-200 mb-4">Monthly XP Purchase Trend</h3>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={[...data.monthly_xp_purchase_trend].reverse()}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#4c1d95" />
                  <XAxis dataKey="month" stroke="#a78bfa" />
                  <YAxis stroke="#a78bfa" />
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: '#1e1b4b', 
                      border: '1px solid #6d28d9',
                      borderRadius: '8px'
                    }}
                  />
                  <Legend />
                  <Bar dataKey="ticket_xp" name="Ticket XP" fill="#8b5cf6" stackId="xp" />
                  <Bar dataKey="candle_xp" name="Candle XP" fill="#3b82f6" stackId="xp" />
                </BarChart>
              </ResponsiveContainer>
            </div>

            {/* Player Participation */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="bg-purple-900/20 border-purple-400/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-purple-300">Players Buying Ticket XP</p>
                  <p className="text-2xl font-bold text-purple-100">
                    {data.xp_purchase_metrics.players_purchasing_ticket_xp}
                  </p>
                </CardContent>
              </Card>
              
              <Card className="bg-blue-900/20 border-blue-400/20">
                <CardContent className="pt-6">
                  <p className="text-sm text-blue-300">Players Buying Candle XP</p>
                  <p className="text-2xl font-bold text-blue-100">
                    {data.xp_purchase_metrics.players_purchasing_candle_xp}
                  </p>
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className="text-center text-sm text-muted-foreground">
          Last updated: {new Date(data.last_updated).toLocaleString()}
        </div>
      </div>
    </AnalyticsLayout>
  );
}
