import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { useUserGuardContext } from 'app/auth';
import { apiClient } from 'app';
import { toast } from 'sonner';
import { Sword, Heart, Zap, Star, Scroll, Calendar, Trophy, Plus, History, Clock, Eye, ArrowLeft } from 'lucide-react';
import type {
  CharacterDetail,
  CharacterListItem as CharacterListItemType,
  XPTransaction
} from 'types';

const MyCharacters = () => {
  const navigate = useNavigate();
  const { user } = useUserGuardContext();
  const [characters, setCharacters] = useState<CharacterListItemType[]>([]);
  const [selectedCharacter, setSelectedCharacter] = useState<CharacterDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [showXPHistory, setShowXPHistory] = useState(false);

  const loadCharacters = async () => {
    setLoading(true);
    try {
      const response = await apiClient.list_my_characters();
      const data = await response.json();
      setCharacters(data || []);
    } catch (error) {
      console.error('Failed to load characters:', error);
      toast.error('Failed to load characters');
    } finally {
      setLoading(false);
    }
  };

  const loadCharacter = async (characterId: string) => {
    setDetailsLoading(true);
    try {
      const response = await apiClient.get_my_character({ characterId });
      const character = await response.json();
      setSelectedCharacter(character);
    } catch (error) {
      console.error('Failed to load character details:', error);
      toast.error('Failed to load character details');
    } finally {
      setDetailsLoading(false);
    }
  };

  useEffect(() => {
    loadCharacters();
  }, []);

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadge = (character: CharacterListItemType) => {
    if (character.retired) {
      return <Badge variant="destructive">Retired</Badge>;
    }
    if (character.xp_available > 0) {
      return <Badge variant="default">XP Available</Badge>;
    }
    return <Badge variant="secondary">Active</Badge>;
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-between mb-6">
          <Skeleton className="h-10 w-32" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Card key={i} className="h-64">
              <CardHeader>
                <Skeleton className="h-6 w-32" />
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // Navigation Header Component
  const NavigationHeader = () => (
    <header className="relative z-10 flex justify-between items-center p-6">
      <div className="flex items-center space-x-4">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
      </div>
      
      <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
        My Characters
      </div>
    </header>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      <NavigationHeader />
      <div className="container mx-auto p-6 space-y-6">
        {/* Create Character Button - Moved to top right */}
        <div className="flex justify-end mb-6">
          <Button 
            onClick={() => navigate('/character-creator')}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Create Character
          </Button>
        </div>

        {/* Characters Grid */}
        {characters.length === 0 ? (
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardContent className="flex flex-col items-center justify-center py-12">
              <Scroll className="w-16 h-16 text-purple-400 mb-4" />
              <h3 className="text-xl font-semibold text-purple-100 mb-2">No Characters Yet</h3>
              <p className="text-purple-300 text-center mb-6">
                Create your first character to begin your LARP journey in Thrune's Forge.
              </p>
              <Button 
                onClick={() => navigate('/character-creator')}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Plus className="w-4 h-4 mr-2" />
                Create Your First Character
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {characters.map((character) => (
              <Card 
                key={character.id} 
                className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm hover:bg-slate-800/60 transition-all duration-200 hover:border-purple-400/30"
              >
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg text-purple-100">{character.name}</CardTitle>
                      <p className="text-sm text-purple-300">
                        {character.heritage_name} • {character.culture_name}
                      </p>
                      <p className="text-xs text-purple-400">
                        {character.archetype_name}
                        {character.secondary_archetype_name && (
                          <span className="text-orange-400"> • {character.secondary_archetype_name}</span>
                        )}
                      </p>
                    </div>
                    <Badge 
                      variant={character.retired ? "destructive" : "default"}
                      className="text-xs"
                    >
                      {character.retired ? "Retired" : "Active"}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-3">
                  {/* Character Stats Grid */}
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="text-sm text-purple-400">Body</div>
                      <div className="text-lg font-semibold text-red-400">{character.body}</div>
                    </div>
                    <div>
                      <div className="text-sm text-purple-400">Stamina</div>
                      <div className="text-lg font-semibold text-blue-400">{character.stamina}</div>
                    </div>
                    <div>
                      <div className="text-sm text-purple-400">Deaths</div>
                      <div className="text-lg font-semibold text-purple-100">
                        {character.deaths || 0}
                      </div>
                    </div>
                    <div>
                      <div className="text-sm text-purple-400">Events</div>
                      <div className="text-lg font-semibold text-purple-100">{character.events_attended}</div>
                    </div>
                    <div>
                      <div className="text-sm text-purple-400">Corruption</div>
                      <div className="text-lg font-semibold text-purple-100">{character.corruption || 0}/10</div>
                    </div>
                    <div>
                      <div className="text-sm text-purple-400">Skills</div>
                      <div className="text-lg font-semibold text-green-400">{character.skill_count}</div>
                    </div>
                  </div>
                  
                  {/* XP Display */}
                  <div className="text-sm">
                    <span className="text-yellow-400">XP Available: {character.xp_available || 0}</span>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex gap-2 pt-2">
                    <Dialog onOpenChange={(open) => {
                      if (!open) {
                        // Reset selected character when dialog closes
                        setSelectedCharacter(null);
                        setDetailsLoading(false);
                      }
                    }}>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="sm" 
                          className="flex-1 border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                          onClick={() => {
                            // Reset state and load fresh data for this specific character
                            setSelectedCharacter(null);
                            loadCharacter(character.id);
                          }}
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl max-h-[80vh] bg-slate-900 border-purple-500/30">
                        <DialogHeader>
                          <DialogTitle className="text-purple-100">
                            {selectedCharacter?.name || 'Character Details'}
                          </DialogTitle>
                        </DialogHeader>
                        
                        {detailsLoading ? (
                          <div className="space-y-4">
                            <Skeleton className="h-6 w-full" />
                            <Skeleton className="h-6 w-3/4" />
                            <Skeleton className="h-32 w-full" />
                          </div>
                        ) : selectedCharacter ? (
                          <ScrollArea className="max-h-[60vh]">
                            <div className="space-y-6 pr-4">
                              {/* Character Info */}
                              <div className="grid grid-cols-2 gap-4">
                                <div>
                                  <h3 className="text-lg font-semibold text-purple-100 mb-2">Character Info</h3>
                                  <div className="space-y-2 text-sm">
                                    <p><span className="text-purple-300">Heritage:</span> <span className="text-purple-100">{selectedCharacter.heritage_name}</span></p>
                                    <p><span className="text-purple-300">Culture:</span> <span className="text-purple-100">{selectedCharacter.culture_name}</span></p>
                                    <p><span className="text-purple-300">Archetype:</span> <span className="text-purple-100">{selectedCharacter.archetype_name}</span></p>
                                    {selectedCharacter.secondary_archetype_name && (
                                      <p><span className="text-purple-300">Secondary Archetype:</span> <span className="text-purple-100">{selectedCharacter.secondary_archetype_name}</span></p>
                                    )}
                                    {selectedCharacter.tertiary_archetype_name && (
                                      <p><span className="text-purple-300">Tertiary Archetype:</span> <span className="text-purple-100">{selectedCharacter.tertiary_archetype_name}</span></p>
                                    )}
                                    <p><span className="text-purple-300">Status:</span> <span className={selectedCharacter.retired ? 'text-red-400' : 'text-green-400'}>{selectedCharacter.retired ? 'Retired' : 'Active'}</span></p>
                                    <p><span className="text-purple-300">Deaths:</span> <span className="text-purple-100">{selectedCharacter.deaths || 0}</span></p>
                                  </div>
                                </div>
                                
                                <div>
                                  <h3 className="text-lg font-semibold text-purple-100 mb-2">Stats & XP</h3>
                                  <div className="space-y-2 text-sm">
                                    <p><span className="text-red-400">Body:</span> <span className="text-purple-100">{selectedCharacter.body}</span></p>
                                    <p><span className="text-blue-400">Stamina:</span> <span className="text-purple-100">{selectedCharacter.stamina}</span></p>
                                    <p><span className="text-yellow-400">XP Available:</span> <span className="text-purple-100">{selectedCharacter.xp_available}</span></p>
                                    <p><span className="text-purple-300">Total XP:</span> <span className="text-purple-100">{selectedCharacter.xp_total}</span></p>
                                    <p><span className="text-purple-300">Events:</span> <span className="text-purple-100">{selectedCharacter.events_attended}</span></p>
                                    <p><span className="text-orange-400">Corruption:</span> <span className="text-purple-100">{selectedCharacter.corruption || 0}/10</span></p>
                                  </div>
                                </div>
                              </div>
                                                            
                              {/* Heritage Benefits & Flaws */}
                              <div>
                                <h3 className="text-lg font-semibold text-purple-100 mb-2">Heritage: {selectedCharacter.heritage_name}</h3>
                                <div className="space-y-2 text-sm">
                                  <div className="p-3 bg-green-900/20 rounded border border-green-500/30">
                                    <div className="text-green-400 font-medium mb-1">
                                      {selectedCharacter.heritage.benefit_name || 'Benefit'}
                                    </div>
                                    <p className="text-purple-100">{selectedCharacter.heritage.benefit}</p>
                                  </div>
                                  <div className="p-3 bg-red-900/20 rounded border border-red-500/30">
                                    <div className="text-red-400 font-medium mb-1">
                                      {selectedCharacter.heritage.weakness_name || 'Weakness'}
                                    </div>
                                    <p className="text-purple-100">{selectedCharacter.heritage.weakness}</p>
                                  </div>
                                </div>
                              </div>
                              
                              {/* Culture Benefits */}
                              <div>
                                <h3 className="text-lg font-semibold text-purple-100 mb-2">Culture: {selectedCharacter.culture_name}</h3>
                                <div className="p-3 bg-blue-900/20 rounded border border-blue-500/30">
                                  <div className="text-blue-400 font-medium mb-1">
                                    {selectedCharacter.culture.benefit_name || 'Cultural Benefit'}
                                  </div>
                                  <p className="text-purple-100">{selectedCharacter.culture.benefit}</p>
                                </div>
                              </div>
                              {/* Skills */}
                              <div>
                                <div className="flex justify-between items-center mb-3">
                                  <h3 className="text-lg font-semibold text-purple-100">Skills ({selectedCharacter.skills.length})</h3>
                                </div>
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                                  {selectedCharacter.skills.map((skill) => (
                                    <div key={skill.id} className="flex items-center justify-between p-2 bg-slate-800/50 rounded border border-purple-500/20">
                                      <div>
                                        <span className="text-purple-100 font-medium">{skill.name}</span>
                                        {skill.is_primary && <Badge variant="default" className="ml-2 text-xs">Primary</Badge>}
                                        {skill.is_secondary && !skill.is_primary && <Badge variant="secondary" className="ml-2 text-xs">Secondary</Badge>}
                                      </div>
                                      <span className="text-yellow-400 text-sm">{skill.xp_cost} XP</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                              
                              {/* Notes - Always show both sections */}
                              <div>
                                <h3 className="text-lg font-semibold text-purple-100 mb-3">Notes</h3>
                                <div className="mb-3">
                                  <h4 className="text-purple-300 font-medium mb-1">Player Notes:</h4>
                                  <p className="text-purple-100 text-sm bg-slate-800/30 p-3 rounded border border-purple-500/20 whitespace-pre-wrap">
                                    {selectedCharacter.player_notes || <span className="text-purple-400 italic">No player notes recorded</span>}
                                  </p>
                                </div>
                                <div>
                                  <h4 className="text-purple-300 font-medium mb-1">Addictions/Diseases:</h4>
                                  <p className="text-purple-100 text-sm bg-slate-800/30 p-3 rounded border border-purple-500/20 whitespace-pre-wrap">
                                    {selectedCharacter.addictions_diseases || <span className="text-purple-400 italic">No addictions or diseases recorded</span>}
                                  </p>
                                </div>
                              </div>
                              
                              {/* XP History Button */}
                              <div className="flex justify-center">
                                <Button 
                                  variant="outline" 
                                  onClick={() => setShowXPHistory(true)}
                                  className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                                >
                                  <Clock className="w-4 h-4 mr-2" />
                                  View XP History
                                </Button>
                              </div>
                            </div>
                          </ScrollArea>
                        ) : null}
                      </DialogContent>
                    </Dialog>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
        
        {/* XP History Modal */}
        {selectedCharacter && (
          <Dialog open={showXPHistory} onOpenChange={setShowXPHistory}>
            <DialogContent className="max-w-2xl max-h-[80vh] bg-slate-900 border-purple-500/30">
              <DialogHeader>
                <DialogTitle className="text-purple-100">
                  XP History - {selectedCharacter.name}
                </DialogTitle>
              </DialogHeader>
              
              <ScrollArea className="max-h-[60vh]">
                <div className="space-y-3 pr-4">
                  {selectedCharacter.xp_transactions && selectedCharacter.xp_transactions.length > 0 ? (
                    selectedCharacter.xp_transactions.map((transaction) => (
                      <div key={transaction.id} className="flex items-center justify-between p-3 bg-slate-800/50 rounded border border-purple-500/20">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge 
                              variant={transaction.amount > 0 ? "default" : "destructive"}
                              className="text-xs"
                            >
                              {transaction.transaction_type}
                            </Badge>
                            <span className="text-sm text-purple-300">
                              {new Date(transaction.created_at).toLocaleDateString()}
                            </span>
                          </div>
                          <p className="text-purple-100 text-sm">{transaction.reason}</p>
                        </div>
                        <div className="text-right">
                          <span className={`font-bold ${
                            transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                          }`}>
                            {transaction.amount > 0 ? '+' : ''}{transaction.amount} XP
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-purple-300">
                      <Clock className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No XP transactions yet</p>
                    </div>
                  )}
                </div>
              </ScrollArea>
              
              <div className="flex justify-between items-center pt-4 border-t border-purple-500/20">
                <div className="text-sm text-purple-300">
                  Total XP Earned: <span className="text-yellow-400 font-bold">{selectedCharacter.xp_total}</span>
                </div>
                <div className="text-sm text-purple-300">
                  Available XP: <span className="text-green-400 font-bold">{selectedCharacter.xp_available}</span>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  );
};

export default MyCharacters;
