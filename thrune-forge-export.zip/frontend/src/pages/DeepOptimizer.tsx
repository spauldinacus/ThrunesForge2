import { useEffect, useState } from "react";
import { apiClient } from "app";
import type { TestCharacterResponse, ArchetypeResponse } from "types";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Zap, ArrowLeft, TrendingDown, Sparkles, Map } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { BuildPathPlanner } from "@/components/BuildPathPlanner";

interface TestCharacterListData {
  test_characters: TestCharacterResponse[];
  count: number;
  max_allowed?: number;
}

export default function DeepOptimizer() {
  const navigate = useNavigate();
  const [testCharacters, setTestCharacters] = useState<TestCharacterResponse[]>([]);
  const [archetypes, setArchetypes] = useState<ArchetypeResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCharacter, setSelectedCharacter] = useState<TestCharacterResponse | null>(null);
  const [optimizationResults, setOptimizationResults] = useState<any>(null);
  const [loadingOptimization, setLoadingOptimization] = useState(false);
  const [streamLog, setStreamLog] = useState<string[]>([]);
  const [planningCombination, setPlanningCombination] = useState<any>(null);

  // Helper function to get archetype name by ID
  const getArchetypeName = (archetypeId: string | undefined | null): string => {
    if (!archetypeId) return '';
    const archetype = archetypes.find(a => a.id === archetypeId);
    return archetype?.name || archetypeId;
  };

  // Load test characters and archetypes
  const loadData = async () => {
    try {
      setLoading(true);
      
      const [charactersResponse, archetypesResponse] = await Promise.all([
        apiClient.list_my_test_characters(),
        apiClient.list_archetypes()
      ]);
      
      const charactersData: TestCharacterListData = await charactersResponse.json();
      const archetypesData = await archetypesResponse.json();
      
      setTestCharacters(charactersData.test_characters || []);
      setArchetypes(Array.isArray(archetypesData) ? archetypesData : archetypesData.archetypes || []);
    } catch (error) {
      console.error("Failed to load data:", error);
      toast.error("Failed to load characters and archetypes");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCharacterSelect = (characterId: string) => {
    const character = testCharacters.find(c => c.id === characterId);
    setSelectedCharacter(character || null);
    setOptimizationResults(null); // Reset results when changing character
    setStreamLog([]);
  };

  const handleOptimize = async () => {
    if (!selectedCharacter) return;
    
    setLoadingOptimization(true);
    setOptimizationResults(null);
    setStreamLog(["Initializing optimization engine..."]);
    
    try {
      const stream = apiClient.optimize_build({
        selected_skills: selectedCharacter.selected_skills.map(s => ({
          skill_id: s.skill_id,
          quantity: s.quantity
        })),
        heritage_id: selectedCharacter.heritage_id,
        body: selectedCharacter.body,
        stamina: selectedCharacter.stamina,
        include_three_archetypes: true // Enable 3-archetype analysis
      });
      
      let buffer = '';
      let finalResult = null;
      
      try {
        for await (const chunk of stream) {
          if (!chunk) continue;
          
          buffer += chunk;
          
          // Try to parse partial updates for logging/progress if possible
          // Note: This is a simplified approach, real SSE parsing happens below
          if (chunk.includes("data:")) {
             // We could extract progress messages here if the backend sends them
          }
        }
        
        // Process all lines after stream completes
        const lines = buffer.split('\n');
        
        for (const line of lines) {
          const trimmedLine = line.trim();
          
          if (!trimmedLine || trimmedLine === '') continue;
          
          if (trimmedLine.startsWith('data: ')) {
            const jsonStr = trimmedLine.substring(6).trim();
            
            try {
              const parsed = JSON.parse(jsonStr);
              
              if (parsed.type === 'progress') {
                  setStreamLog(prev => [...prev, parsed.message]);
              } else if (parsed.type === 'complete') {
                finalResult = parsed.data;
                setStreamLog(prev => [...prev, "Optimization complete!"]);
              }
            } catch (e) {
              console.warn('Parse error:', e);
            }
          }
        }
      } catch (streamError) {
        console.error('Stream error:', streamError);
        throw new Error(`Stream failed: ${streamError}`);
      }
      
      if (!finalResult) {
        throw new Error('No optimization results received');
      }
      
      // Calculate savings based on current XP
      const results = {
        ...finalResult,
        current_xp: selectedCharacter.xp_cost,
        optimal_combinations: finalResult.optimal_combinations.map((combo: any) => ({
          ...combo,
          xp_savings: selectedCharacter.xp_cost - combo.xp_cost
        })),
        potential_savings: selectedCharacter.xp_cost - (finalResult.optimal_combinations[0]?.xp_cost || 0)
      };
      
      setOptimizationResults(results);
      toast.success("Deep optimization complete!");
    } catch (error) {
      console.error("Failed to optimize build:", error);
      toast.error("Failed to calculate optimization");
      setStreamLog(prev => [...prev, "Error: Optimization failed."]);
    } finally {
      setLoadingOptimization(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 p-6 space-y-6">
      {/* Header */}
      <header className="flex justify-between items-center">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Deep Archetype Optimizer
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Selection & Controls */}
        <div className="lg:col-span-1 space-y-6">
          <Card className="bg-purple-950/40 border-purple-800/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100 flex items-center">
                <Sparkles className="h-5 w-5 mr-2 text-amber-400" />
                Select Character
              </CardTitle>
              <CardDescription className="text-purple-300/70">
                Choose a test character to perform a deep 3-archetype optimization analysis.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {loading ? (
                <div className="text-purple-300 text-center py-4">Loading characters...</div>
              ) : (
                <>
                  <Select onValueChange={handleCharacterSelect} value={selectedCharacter?.id}>
                    <SelectTrigger className="bg-black/20 border-purple-700/50 text-purple-100">
                      <SelectValue placeholder="Select a character..." />
                    </SelectTrigger>
                    <SelectContent className="bg-purple-950 border-purple-700 text-purple-100">
                      {testCharacters.map(char => (
                        <SelectItem key={char.id} value={char.id}>
                          {char.name} ({char.xp_cost} XP)
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  {selectedCharacter && (
                    <div className="bg-black/20 rounded-lg p-4 space-y-3 border border-purple-800/30">
                      <div className="flex justify-between items-center">
                        <span className="text-purple-300 text-sm">Current Build Cost:</span>
                        <span className="text-amber-200 font-bold">{selectedCharacter.xp_cost} XP</span>
                      </div>
                      <div className="flex justify-between items-center">
                         <span className="text-purple-300 text-sm">Skills:</span>
                         <span className="text-purple-200 text-sm">{selectedCharacter.selected_skills.length} selected</span>
                      </div>
                      <div className="flex justify-between items-center">
                         <span className="text-purple-300 text-sm">Primary Archetype:</span>
                         <span className="text-purple-200 text-sm">{getArchetypeName(selectedCharacter.archetype_id)}</span>
                      </div>
                       {selectedCharacter.secondary_archetype_id && (
                        <div className="flex justify-between items-center">
                           <span className="text-purple-300 text-sm">Secondary:</span>
                           <span className="text-purple-200 text-sm">{getArchetypeName(selectedCharacter.secondary_archetype_id)}</span>
                        </div>
                       )}
                       {selectedCharacter.tertiary_archetype_id && (
                        <div className="flex justify-between items-center">
                           <span className="text-purple-300 text-sm">Tertiary:</span>
                           <span className="text-purple-200 text-sm">{getArchetypeName(selectedCharacter.tertiary_archetype_id)}</span>
                        </div>
                       )}
                    </div>
                  )}

                  <Button 
                    onClick={handleOptimize} 
                    disabled={!selectedCharacter || loadingOptimization}
                    className="w-full bg-gradient-to-r from-amber-600 to-amber-500 hover:from-amber-500 hover:to-amber-400 text-white"
                  >
                    {loadingOptimization ? (
                      <>Analyzing...</>
                    ) : (
                      <>
                        <Zap className="h-4 w-4 mr-2" />
                        Run Deep Analysis
                      </>
                    )}
                  </Button>
                </>
              )}
            </CardContent>
          </Card>
          
          {/* Analysis Log */}
          {(loadingOptimization || streamLog.length > 0) && (
             <Card className="bg-black/40 border-purple-800/30">
               <CardHeader className="py-3">
                 <CardTitle className="text-sm text-purple-300">Analysis Log</CardTitle>
               </CardHeader>
               <CardContent className="py-2 px-4 max-h-48 overflow-y-auto font-mono text-xs text-purple-200/70 space-y-1">
                 {streamLog.map((log, i) => (
                   <div key={i} className="border-b border-purple-800/10 pb-1 last:border-0">{log}</div>
                 ))}
               </CardContent>
             </Card>
          )}
        </div>

        {/* Right Column: Results */}
        <div className="lg:col-span-2 space-y-6">
          {!optimizationResults && !loadingOptimization && (
            <div className="h-full flex flex-col items-center justify-center p-12 border-2 border-dashed border-purple-800/30 rounded-xl bg-purple-950/10">
              <Zap className="h-16 w-16 text-purple-800/50 mb-4" />
              <h3 className="text-xl font-medium text-purple-300/50">Ready to Optimize</h3>
              <p className="text-purple-400/30 text-center max-w-md mt-2">
                Select a character and run the analysis to find the most efficient 3-archetype combination for your skills.
              </p>
            </div>
          )}

          {optimizationResults && (
            <div className="space-y-6">
              {/* Summary Card */}
              <Card className="bg-purple-900/40 border-purple-700/50">
                <CardHeader>
                  <CardTitle className="text-lg text-amber-200">Analysis Results</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 bg-black/20 rounded-lg">
                      <div className="text-purple-400 text-sm mb-1">Current XP Cost</div>
                      <div className="text-2xl font-bold text-purple-200">{optimizationResults.current_xp} XP</div>
                    </div>
                    <div className="p-4 bg-black/20 rounded-lg">
                      <div className="text-purple-400 text-sm mb-1">Optimized XP Cost</div>
                      <div className="text-2xl font-bold text-amber-200">{optimizationResults.optimal_combinations[0]?.xp_cost} XP</div>
                    </div>
                    <div className="p-4 bg-black/20 rounded-lg border border-green-900/30">
                      <div className="text-purple-400 text-sm mb-1">Potential Savings</div>
                      <div className="text-2xl font-bold text-green-400 flex items-center">
                        {optimizationResults.potential_savings > 0 ? (
                            <>
                                <TrendingDown className="h-5 w-5 mr-2" />
                                {optimizationResults.potential_savings} XP
                            </>
                        ) : (
                            <span className="text-purple-300">0 XP</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Combinations List */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-purple-200">Recommended Combinations</h3>
                {optimizationResults.optimal_combinations.map((combo: any, index: number) => (
                  <Card
                    key={index}
                    className={`bg-gradient-to-r ${
                      index === 0
                        ? 'from-amber-950/60 to-amber-900/60 border-amber-600/70'
                        : 'from-purple-950/40 to-indigo-950/40 border-purple-700/50'
                    } backdrop-blur-sm transition-all hover:border-amber-500/30`}
                  >
                    <CardContent className="p-6">
                      <div className="flex items-start md:items-center justify-between flex-col md:flex-row gap-4">
                        <div className="flex-1">
                          {index === 0 && (
                            <Badge className="mb-2 bg-amber-600 text-white border-none">
                              ⭐ Most Optimal
                            </Badge>
                          )}
                          <div className="flex flex-wrap items-center gap-2 text-lg font-semibold text-purple-100">
                            <span className="bg-purple-900/50 px-3 py-1 rounded border border-purple-700/50">
                              {combo.archetype_name}
                            </span>
                            {combo.secondary_archetype_name && (
                                <>
                                    <span className="text-purple-400">+</span>
                                    <span className="bg-purple-900/50 px-3 py-1 rounded border border-purple-700/50">
                                        {combo.secondary_archetype_name}
                                    </span>
                                </>
                            )}
                            {combo.tertiary_archetype_name && (
                                <>
                                    <span className="text-purple-400">+</span>
                                    <span className="bg-purple-900/50 px-3 py-1 rounded border border-purple-700/50">
                                        {combo.tertiary_archetype_name}
                                    </span>
                                </>
                            )}
                          </div>
                        </div>
                        
                        <div className="text-right w-full md:w-auto flex flex-row md:flex-col justify-between items-center md:items-end border-t md:border-t-0 border-white/10 pt-3 md:pt-0">
                          <div className="text-3xl font-bold text-amber-200">
                            {combo.xp_cost} XP
                          </div>
                          {combo.xp_savings > 0 && (
                            <div className="text-sm text-green-400 font-medium">
                              Save {combo.xp_savings} XP
                            </div>
                          )}
                           {combo.xp_savings === 0 && (
                            <div className="text-sm text-purple-400/70">
                              Current Build
                            </div>
                          )}
                           {combo.xp_savings < 0 && (
                            <div className="text-sm text-red-400/70">
                              +{Math.abs(combo.xp_savings)} XP (Costlier)
                            </div>
                          )}
                          
                          <Button
                            size="sm"
                            variant="outline"
                            className="mt-2 w-full md:w-auto border-purple-500/50 hover:bg-purple-500/20 text-purple-200"
                            onClick={() => setPlanningCombination(combo)}
                          >
                            <Map className="w-4 h-4 mr-2" />
                            Plan Build Path
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Build Path Planner Dialog */}
      <Dialog open={!!planningCombination} onOpenChange={(open) => !open && setPlanningCombination(null)}>
        <DialogContent className="max-w-5xl bg-slate-950 border-purple-800 text-purple-100 h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="text-2xl font-medieval text-amber-500">
              Build Path Planner
            </DialogTitle>
            <DialogDescription className="text-purple-300">
              Interactively plan the sequence of skill purchases and archetype unlocks to optimize your XP spending.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex-1 min-h-0 mt-4">
            {planningCombination && selectedCharacter && (
              <BuildPathPlanner 
                combination={planningCombination} 
                archetypes={archetypes}
                selectedSkills={selectedCharacter.selected_skills.map(s => ({
                    skill_id: s.skill_id,
                    quantity: s.quantity
                }))} 
              />
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
