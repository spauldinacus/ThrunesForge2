import { useState, useEffect } from 'react';
import { AnalyticsLayout } from 'components/AnalyticsLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, Download, AlertCircle, ArrowUpDown } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { apiClient } from 'app';
import { CharacterBuildsAnalytics } from 'types';
import { toast } from 'sonner';

const COLORS = ['#9333ea', '#a855f7', '#c084fc', '#e9d5ff', '#f3e8ff', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95', '#2e1065'];

export default function AdminCharacterBuilds() {
  const [data, setData] = useState<CharacterBuildsAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeOnly, setActiveOnly] = useState(true);
  const [error, setError] = useState<string | null>(null);
    
  // Sorting state for tables
  const [skillSort, setSkillSort] = useState<'name' | 'count'>('count');
  const [skillSortDir, setSkillSortDir] = useState<'asc' | 'desc'>('desc');
  const [heritageSort, setHeritageSort] = useState<'name' | 'count'>('count');
  const [heritageSortDir, setHeritageSortDir] = useState<'asc' | 'desc'>('desc');
  const [cultureSort, setCultureSort] = useState<'name' | 'count'>('count');
  const [cultureSortDir, setCultureSortDir] = useState<'asc' | 'desc'>('desc');
  const [archetypeSort, setArchetypeSort] = useState<'name' | 'count'>('count');
  const [archetypeSortDir, setArchetypeSortDir] = useState<'asc' | 'desc'>('desc');

  // Sorting helper functions
  const toggleSkillSort = (field: 'name' | 'count') => {
    if (skillSort === field) {
      setSkillSortDir(skillSortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setSkillSort(field);
      setSkillSortDir('desc');
    }
  };

  const toggleHeritageSort = (field: 'name' | 'count') => {
    if (heritageSort === field) {
      setHeritageSortDir(heritageSortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setHeritageSort(field);
      setHeritageSortDir('desc');
    }
  };

  const toggleCultureSort = (field: 'name' | 'count') => {
    if (cultureSort === field) {
      setCultureSortDir(cultureSortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setCultureSort(field);
      setCultureSortDir('desc');
    }
  };

  const toggleArchetypeSort = (field: 'name' | 'count') => {
    if (archetypeSort === field) {
      setArchetypeSortDir(archetypeSortDir === 'asc' ? 'desc' : 'asc');
    } else {
      setArchetypeSort(field);
      setArchetypeSortDir('desc');
    }
  };

  // Sorted data
  const sortedSkills = data?.all_skills ? [...data.all_skills].sort((a, b) => {
    if (skillSort === 'name') {
      return skillSortDir === 'asc' 
        ? a.skill_name.localeCompare(b.skill_name)
        : b.skill_name.localeCompare(a.skill_name);
    }
    return skillSortDir === 'asc'
      ? a.character_count - b.character_count
      : b.character_count - a.character_count;
  }) : [];

  const sortedHeritages = data?.heritage_distribution ? [...data.heritage_distribution].sort((a, b) => {
    if (heritageSort === 'name') {
      return heritageSortDir === 'asc'
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    }
    return heritageSortDir === 'asc'
      ? a.count - b.count
      : b.count - a.count;
  }) : [];

  const sortedCultures = data?.culture_distribution ? [...data.culture_distribution].sort((a, b) => {
    if (cultureSort === 'name') {
      return cultureSortDir === 'asc'
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    }
    return cultureSortDir === 'asc'
      ? a.count - b.count
      : b.count - a.count;
  }) : [];

  const sortedArchetypes = data?.archetype_distribution ? [...data.archetype_distribution].sort((a, b) => {
    if (archetypeSort === 'name') {
      return archetypeSortDir === 'asc'
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    }
    return archetypeSortDir === 'asc'
      ? a.count - b.count
      : b.count - a.count;
  }) : [];
  
  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get_character_builds_analytics({ activeOnly });
      const analytics = await response.json();
      setData(analytics);
    } catch (err) {
      console.error('Failed to fetch character builds analytics:', err);
      setError('Failed to load analytics data');
      toast.error('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeOnly]);

  const exportToCSV = () => {
    if (!data) return;

    const csv: string[] = [];
    
    // Top Skills
    csv.push('\n=== TOP SKILLS ===');
    csv.push('Skill Name,Character Count,Percentage');
    data.top_skills.forEach(skill => {
      csv.push(`${skill.skill_name},${skill.character_count},${skill.percentage}%`);
    });

    // Archetype Distribution
    csv.push('\n=== ARCHETYPE DISTRIBUTION ===');
    csv.push('Archetype,Count,Percentage');
    data.archetype_distribution.forEach(arch => {
      csv.push(`${arch.name},${arch.count},${arch.percentage}%`);
    });

    // Heritage Distribution
    csv.push('\n=== HERITAGE DISTRIBUTION ===');
    csv.push('Heritage,Count,Percentage');
    data.heritage_distribution.forEach(heritage => {
      csv.push(`${heritage.name},${heritage.count},${heritage.percentage}%`);
    });

    // Culture Distribution
    csv.push('\n=== CULTURE DISTRIBUTION ===');
    csv.push('Culture,Count,Percentage');
    data.culture_distribution.forEach(culture => {
      csv.push(`${culture.name},${culture.count},${culture.percentage}%`);
    });

    // Top Combinations
    csv.push('\n=== TOP ARCHETYPE + HERITAGE COMBINATIONS ===');
    csv.push('Combination,Count,Percentage');
    data.top_archetype_heritage_combos.forEach(combo => {
      csv.push(`${combo.combination},${combo.count},${combo.percentage}%`);
    });

    csv.push('\n=== TOP TRIFECTA COMBINATIONS ===');
    csv.push('Combination,Count,Percentage');
    data.top_trifecta_combos.forEach(combo => {
      csv.push(`${combo.combination},${combo.count},${combo.percentage}%`);
    });

    // Orphaned Options
    if (data.orphaned_options.length > 0) {
      csv.push('\n=== ORPHANED OPTIONS (UNUSED) ===');
      csv.push('Type,Name');
      data.orphaned_options.forEach(option => {
        csv.push(`${option.type},${option.name}`);
      });
    }

    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `character-builds-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    toast.success('Analytics exported to CSV');
  };

  if (loading) {
    return (
      <AnalyticsLayout>
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Character Builds Analytics
              </h1>
              <p className="text-muted-foreground mt-2">Skill, archetype, heritage, and culture popularity patterns</p>
            </div>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-card/50 backdrop-blur border-purple-500/20">
                <CardHeader>
                  <Skeleton className="h-6 w-48" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-64 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  if (error || !data) {
    return (
      <AnalyticsLayout>
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>{error || 'Failed to load analytics'}</AlertDescription>
        </Alert>
        <Button onClick={fetchData} className="mt-4">
          <RefreshCw className="mr-2 h-4 w-4" />
          Retry
        </Button>
      </AnalyticsLayout>
    );
  }

  return (
    <AnalyticsLayout>
      <div className="space-y-6">
        {/* Header with controls */}
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Character Builds Analytics
            </h1>
            <p className="text-muted-foreground mt-2">
              Analyzing {data.total_characters_analyzed} characters
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2">
              <Switch
                id="active-only"
                checked={activeOnly}
                onCheckedChange={setActiveOnly}
              />
              <Label htmlFor="active-only">Active characters only</Label>
            </div>
            <Button onClick={fetchData} variant="outline" size="sm">
              <RefreshCw className="mr-2 h-4 w-4" />
              Refresh
            </Button>
            <Button onClick={exportToCSV} variant="outline" size="sm">
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Popularity Section */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-purple-300">Popularity Rankings</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Top Skills Chart */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Top 10 Skills</CardTitle>
                <CardDescription>Most popular skill selections</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.top_skills}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis 
                      dataKey="skill_name" 
                      angle={-45} 
                      textAnchor="end" 
                      height={100}
                      tick={{ fontSize: 12 }}
                    />
                    <YAxis />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #9333ea' }}
                      formatter={(value: number, name: string) => {
                        if (name === 'character_count') return [value, 'Characters'];
                        return [value, name];
                      }}
                    />
                    <Bar dataKey="character_count" fill="#9333ea" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Average Stats Chart */}
            {/* Body Distribution Chart */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Body Distribution</CardTitle>
                <CardDescription>
                  <span className="text-3xl font-bold text-red-500">{data.average_body.toFixed(1)}</span>
                  {' '}average across all characters
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.body_distribution || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="value" label={{ value: 'Body', position: 'insideBottom', offset: -5 }} />
                    <YAxis label={{ value: 'Characters', angle: -90, position: 'insideLeft' }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #ef4444' }}
                      formatter={(value: number) => [value, 'Characters']}
                    />
                    <Bar dataKey="count" fill="#ef4444" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Stamina Distribution Chart */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Stamina Distribution</CardTitle>
                <CardDescription>
                  <span className="text-3xl font-bold text-green-500">{data.average_stamina.toFixed(1)}</span>
                  {' '}average across all characters
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.stamina_distribution || []}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                    <XAxis dataKey="value" label={{ value: 'Stamina', position: 'insideBottom', offset: -5 }} />
                    <YAxis label={{ value: 'Characters', angle: -90, position: 'insideLeft' }} />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #10b981' }}
                      formatter={(value: number) => [value, 'Characters']}
                    />
                    <Bar dataKey="count" fill="#10b981" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            
            {/* Archetype Distribution */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Archetype Distribution</CardTitle>
                <CardDescription>Character archetype popularity</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.archetype_distribution.filter(a => a.count > 0)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} (${percentage}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {data.archetype_distribution.filter(a => a.count > 0).map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #9333ea' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Heritage Distribution */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Heritage Distribution</CardTitle>
                <CardDescription>Character heritage popularity</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.heritage_distribution.filter(h => h.count > 0)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} (${percentage}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {data.heritage_distribution.filter(h => h.count > 0).map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #9333ea' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Culture Distribution */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Culture Distribution</CardTitle>
                <CardDescription>Character culture popularity</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.culture_distribution.filter(c => c.count > 0)}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percentage }) => `${name} (${percentage}%)`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="count"
                    >
                      {data.culture_distribution.filter(c => c.count > 0).map((_, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#1a1a2e', border: '1px solid #9333ea' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Build Combinations Section */}
        <div className="space-y-6">
          <h2 className="text-2xl font-bold text-purple-300">Build Combinations</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Archetype + Heritage Combos */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Top Archetype + Heritage</CardTitle>
                <CardDescription>Most common archetype and heritage pairings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.top_archetype_heritage_combos.slice(0, 8).map((combo, i) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded bg-purple-500/10 border border-purple-500/20">
                      <span className="text-sm font-medium">{combo.combination}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{combo.count}</Badge>
                        <span className="text-xs text-muted-foreground">{combo.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Archetype + Culture Combos */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Top Archetype + Culture</CardTitle>
                <CardDescription>Most common archetype and culture pairings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.top_archetype_culture_combos.slice(0, 8).map((combo, i) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded bg-purple-500/10 border border-purple-500/20">
                      <span className="text-sm font-medium">{combo.combination}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{combo.count}</Badge>
                        <span className="text-xs text-muted-foreground">{combo.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Heritage + Culture Combos */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Top Heritage + Culture</CardTitle>
                <CardDescription>Most common heritage and culture pairings</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.top_heritage_culture_combos.slice(0, 8).map((combo, i) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded bg-purple-500/10 border border-purple-500/20">
                      <span className="text-sm font-medium">{combo.combination}</span>
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{combo.count}</Badge>
                        <span className="text-xs text-muted-foreground">{combo.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Full Trifecta Combos */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Top Trifecta Builds</CardTitle>
                <CardDescription>Complete archetype + heritage + culture combinations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.top_trifecta_combos.slice(0, 8).map((combo, i) => (
                    <div key={i} className="flex justify-between items-center p-2 rounded bg-purple-500/10 border border-purple-500/20">
                      <span className="text-sm font-medium truncate">{combo.combination}</span>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <Badge variant="outline">{combo.count}</Badge>
                        <span className="text-xs text-muted-foreground">{combo.percentage}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Skill Synergies Section */}
        {data.skill_synergies.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-purple-300">Skill Synergies</h2>
            
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Skills Commonly Taken Together</CardTitle>
                <CardDescription>Skill pairs that frequently appear in the same build</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {data.skill_synergies.map((synergy, i) => (
                    <div key={i} className="flex justify-between items-center p-3 rounded bg-purple-500/10 border border-purple-500/20">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium">{synergy.skill1_name}</span>
                        <span className="text-xs text-muted-foreground">+ {synergy.skill2_name}</span>
                      </div>
                      <Badge variant="outline">{synergy.pair_count} builds</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Complete Option Tables Section */}
        <div className="space-y-6 mt-8">
          <h2 className="text-2xl font-bold text-purple-300">Complete Distribution Lists</h2>
          
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {/* All Skills Table */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>All Skills</CardTitle>
                <CardDescription>Complete list of all skills with character counts</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleSkillSort('name')}
                          className="hover:bg-purple-500/20"
                        >
                          Skill Name
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleSkillSort('count')}
                          className="hover:bg-purple-500/20"
                        >
                          Characters
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedSkills.map((skill) => (
                      <TableRow key={skill.skill_id}>
                        <TableCell className="font-medium">{skill.skill_name}</TableCell>
                        <TableCell className="text-right">{skill.character_count}</TableCell>
                        <TableCell className="text-right text-muted-foreground">{skill.percentage}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* All Heritages Table */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>All Heritages</CardTitle>
                <CardDescription>Complete list of all heritages with character counts</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleHeritageSort('name')}
                          className="hover:bg-purple-500/20"
                        >
                          Heritage Name
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleHeritageSort('count')}
                          className="hover:bg-purple-500/20"
                        >
                          Characters
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedHeritages.map((heritage) => (
                      <TableRow key={heritage.id}>
                        <TableCell className="font-medium">{heritage.name}</TableCell>
                        <TableCell className="text-right">{heritage.count}</TableCell>
                        <TableCell className="text-right text-muted-foreground">{heritage.percentage}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* All Cultures Table */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>All Cultures</CardTitle>
                <CardDescription>Complete list of all cultures with character counts</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleCultureSort('name')}
                          className="hover:bg-purple-500/20"
                        >
                          Culture Name
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleCultureSort('count')}
                          className="hover:bg-purple-500/20"
                        >
                          Characters
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedCultures.map((culture) => (
                      <TableRow key={culture.id}>
                        <TableCell className="font-medium">{culture.name}</TableCell>
                        <TableCell className="text-right">{culture.count}</TableCell>
                        <TableCell className="text-right text-muted-foreground">{culture.percentage}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            {/* All Archetypes Table */}
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>All Archetypes</CardTitle>
                <CardDescription>Complete list of all archetypes with character counts</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleArchetypeSort('name')}
                          className="hover:bg-purple-500/20"
                        >
                          Archetype Name
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => toggleArchetypeSort('count')}
                          className="hover:bg-purple-500/20"
                        >
                          Characters
                          <ArrowUpDown className="ml-2 h-4 w-4" />
                        </Button>
                      </TableHead>
                      <TableHead className="text-right">Percentage</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {sortedArchetypes.map((archetype) => (
                      <TableRow key={archetype.id}>
                        <TableCell className="font-medium">{archetype.name}</TableCell>
                        <TableCell className="text-right">{archetype.count}</TableCell>
                        <TableCell className="text-right text-muted-foreground">{archetype.percentage}%</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AnalyticsLayout>
  );
}
