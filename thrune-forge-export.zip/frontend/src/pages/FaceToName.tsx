import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { Character } from 'types';
import { CharacterListItem } from "types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { ArrowUpDown, ArrowUp, ArrowDown, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

// COMPONENT
export default function FaceToName() {
  const [characters, setCharacters] = useState<CharacterListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const navigate = useNavigate();
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortColumn(column);
      setSortDirection("asc");
    }
  };

  useEffect(() => {
    loadCharacters();
  }, []);

  const loadCharacters = async () => {
    try {
      const response = await apiClient.list_all_characters_with_photos();
      const data = await response.json();
      setCharacters(data);
    } catch (error) {
      console.error("Failed to load characters:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredCharacters = characters
    .filter(char =>
      char.character_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      char.player_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      char.chapter_name.toLowerCase().includes(searchTerm.toLowerCase())
    )
    .sort((a, b) => {
      if (!sortColumn) return 0;
      
      let aVal: string | number = "";
      let bVal: string | number = "";
      
      if (sortColumn === "photo_count") {
        aVal = a.photo_count;
        bVal = b.photo_count;
      } else {
        aVal = a[sortColumn as keyof typeof a]?.toString().toLowerCase() || "";
        bVal = b[sortColumn as keyof typeof b]?.toString().toLowerCase() || "";
      }
      
      if (aVal < bVal) return sortDirection === "asc" ? -1 : 1;
      if (aVal > bVal) return sortDirection === "asc" ? 1 : -1;
      return 0;
    });

    return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 border-b border-purple-800/30">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
        
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Face to Name
        </h1>
        <div className="w-32" /> {/* Spacer */}
      </header>

      {/* Main Content */}
      <div className="container mx-auto p-6">
        <div className="mb-6">
          <Input
            placeholder="Search by character, player, or chapter..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="max-w-md bg-slate-900/50 border-purple-700/30 text-purple-200"
          />
        </div>

        <Card className="bg-slate-900/50 border-purple-700/30">
          <CardContent className="p-6">
          {loading ? (
            <div className="text-center text-purple-300">Loading...</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead 
                    onClick={() => handleSort("character_name")}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center gap-2">
                      Character Name
                      {sortColumn === "character_name" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead 
                    onClick={() => handleSort("heritage_name")}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center gap-2">
                      Heritage
                      {sortColumn === "heritage_name" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead 
                    onClick={() => handleSort("culture_name")}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center gap-2">
                      Culture
                      {sortColumn === "culture_name" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead 
                    onClick={() => handleSort("player_name")}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center gap-2">
                      Player
                      {sortColumn === "player_name" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead 
                    onClick={() => handleSort("chapter_name")}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center gap-2">
                      Chapter
                      {sortColumn === "chapter_name" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                  <TableHead 
                    onClick={() => handleSort("photo_count")}
                    className="text-right cursor-pointer hover:bg-purple-900/20"
                  >
                    <div className="flex items-center justify-end gap-2">
                      Photos
                      {sortColumn === "photo_count" ? (
                        sortDirection === "asc" ? <ArrowUp className="h-4 w-4" /> : <ArrowDown className="h-4 w-4" />
                      ) : <ArrowUpDown className="h-4 w-4 opacity-50" />}
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCharacters.map((char) => (
                  <TableRow
                    key={char.character_id}
                    onClick={() => navigate(`/character-photos?id=${char.character_id}`)}
                    className="cursor-pointer hover:bg-purple-900/20"
                  >
                    <TableCell className="font-medium text-purple-200">{char.character_name}</TableCell>
                    <TableCell className="text-slate-300">{char.heritage_name}</TableCell>
                    <TableCell className="text-slate-300">{char.culture_name}</TableCell>
                    <TableCell className="text-slate-300">{char.player_name}</TableCell>
                    <TableCell className="text-slate-300">{char.chapter_name}</TableCell>
                    <TableCell className="text-right text-purple-300">{char.photo_count}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  </div>   
  );
}
