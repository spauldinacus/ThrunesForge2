import { useEffect, useState } from 'react';
import { apiClient } from 'app';
import type {
  PlayerEngagementAnalytics,
  ActivityStatusBreakdown,
  RetentionCohort,
  EngagedPlayer,
  AtRiskPlayer,
  EventsAttendedDistribution,
  CharacterCountDistribution,
  MostPlayedCharacter,
} from 'types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { RefreshCw, Download, TrendingDown, TrendingUp, AlertTriangle, Users, UserCheck } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { AnalyticsLayout } from 'components/AnalyticsLayout';

const COLORS = ['#8b5cf6', '#a78bfa', '#c4b5fd', '#ddd6fe', '#ede9fe'];
const CHART_COLORS = {
  primary: '#8b5cf6',
  secondary: '#a78bfa',
  tertiary: '#c4b5fd',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
};

export default function AdminPlayerEngagement() {
  const [data, setData] = useState<PlayerEngagementAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeDays, setActiveDays] = useState(90);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await apiClient.get_player_engagement_analytics({ activeDays });
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError('Failed to load player engagement analytics');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeDays]);

  const exportToCSV = () => {
    if (!data) return;

    const csvData = [
      ['Player Engagement Analytics'],
      [''],
      ['Activity Status'],
      ['Total Players', data.total_players],
      ['Active Players', data.active_players],
      ['Inactive Players', data.inactive_players],
      ['Active Rate (%)', data.active_rate],
      [''],
      ['Activity Breakdown by Period'],
      ['Period', 'Active Count', 'Percentage'],
      ...data.activity_breakdown.map(ab => [ab.period, ab.active_count, ab.percentage]),
      [''],
      ['Retention Metrics'],
      ['Overall Churn Rate (%)', data.overall_churn_rate],
      ['New Player Conversion Rate (%)', data.new_player_conversion_rate],
      [''],
      ['Engagement Metrics'],
      ['Average Events per Player', data.avg_events_per_player],
      ['Average Characters per Player', data.avg_characters_per_player],
      [''],
      ['Top Engaged Players'],
      ['Player Name', 'Player Number', 'Events Attended', 'Character Count'],
      ...data.top_engaged_players.map(p => [p.player_name, p.player_number, p.events_attended, p.character_count]),
      [''],
      ['At-Risk Players'],
      ['Player Name', 'Player Number', 'Days Since Last Event', 'Recent Events', 'Previous Events', 'Trend'],
      ...data.at_risk_players.map(p => [p.player_name, p.player_number, p.days_since_last_event, p.events_last_3mo, p.events_previous_3mo, p.trend]),
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `player-engagement-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  if (loading) {
    return (
      <AnalyticsLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Player Engagement</h1>
              <p className="text-muted-foreground mt-2">Player activity, retention, and engagement analytics</p>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  if (error || !data) {
    return (
      <AnalyticsLayout>
        <Alert variant="destructive">
          <AlertDescription>{error || 'Failed to load data'}</AlertDescription>
        </Alert>
      </AnalyticsLayout>
    );
  }

  return (
    <AnalyticsLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Player Engagement</h1>
            <p className="text-muted-foreground mt-2">Player activity, retention, and engagement analytics</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={fetchData}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button variant="outline" size="sm" onClick={exportToCSV}>
              <Download className="h-4 w-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Activity Status Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground">Activity Status</h2>
          
          {/* Big stat cards */}
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Players</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{data.total_players}</div>
                <p className="text-xs text-muted-foreground mt-1">All registered players</p>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Players</CardTitle>
                <UserCheck className="h-4 w-4 text-success" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-success">{data.active_players}</div>
                <p className="text-xs text-muted-foreground mt-1">Attended in last {activeDays} days</p>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Rate</CardTitle>
                <TrendingUp className="h-4 w-4 text-primary" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">{data.active_rate}%</div>
                <p className="text-xs text-muted-foreground mt-1">{data.inactive_players} inactive players</p>
              </CardContent>
            </Card>
          </div>

          {/* Activity breakdown charts */}
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Active vs Inactive</CardTitle>
                <CardDescription>Player activity breakdown</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={[
                        { name: 'Active', value: data.active_players },
                        { name: 'Inactive', value: data.inactive_players },
                      ]}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      <Cell fill={CHART_COLORS.success} />
                      <Cell fill={CHART_COLORS.danger} />
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Activity by Time Period</CardTitle>
                <CardDescription>Active players over different periods</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.activity_breakdown}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="period" className="text-muted-foreground" />
                    <YAxis className="text-muted-foreground" />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Bar dataKey="active_count" fill={CHART_COLORS.primary} name="Active Players" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Retention Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground">Retention Analysis</h2>
          
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Churn Rate</CardTitle>
                <TrendingDown className="h-4 w-4 text-warning" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{data.overall_churn_rate}%</div>
                <p className="text-xs text-muted-foreground mt-1">Players inactive for 6+ months</p>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">New Player Conversion</CardTitle>
                <UserCheck className="h-4 w-4 text-success" />
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{data.new_player_conversion_rate}%</div>
                <p className="text-xs text-muted-foreground mt-1">Attended 2+ events</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>New Players Over Time</CardTitle>
                <CardDescription>Monthly cohorts (last 12 months)</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={[...data.retention_cohorts].reverse()}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis 
                      dataKey={(item: RetentionCohort) => `${item.month} ${item.year}`}
                      className="text-muted-foreground"
                    />
                    <YAxis className="text-muted-foreground" />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Legend />
                    <Line 
                      type="monotone" 
                      dataKey="new_players" 
                      stroke={CHART_COLORS.primary} 
                      name="New Players"
                      strokeWidth={2}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Retention Rates</CardTitle>
                <CardDescription>Average retention over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart
                    data={[
                      {
                        period: '1 Month',
                        rate: data.retention_cohorts.length > 0
                          ? data.retention_cohorts.reduce((sum, c) => sum + c.retention_1mo_rate, 0) / data.retention_cohorts.length
                          : 0,
                      },
                      {
                        period: '3 Months',
                        rate: data.retention_cohorts.length > 0
                          ? data.retention_cohorts.reduce((sum, c) => sum + c.retention_3mo_rate, 0) / data.retention_cohorts.length
                          : 0,
                      },
                      {
                        period: '6 Months',
                        rate: data.retention_cohorts.length > 0
                          ? data.retention_cohorts.reduce((sum, c) => sum + c.retention_6mo_rate, 0) / data.retention_cohorts.length
                          : 0,
                      },
                      {
                        period: '1 Year',
                        rate: data.retention_cohorts.length > 0
                          ? data.retention_cohorts.reduce((sum, c) => sum + c.retention_1yr_rate, 0) / data.retention_cohorts.length
                          : 0,
                      },
                    ]}
                  >
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="period" className="text-muted-foreground" />
                    <YAxis className="text-muted-foreground" />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                      formatter={(value: number) => `${value.toFixed(1)}%`}
                    />
                    <Bar dataKey="rate" fill={CHART_COLORS.secondary} name="Retention Rate (%)" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Engagement Patterns Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground">Engagement Patterns</h2>
          
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Events per Player</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{data.avg_events_per_player}</div>
              <p className="text-xs text-muted-foreground mt-1">Across all players</p>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Events Attended Distribution</CardTitle>
                <CardDescription>Player distribution by event count</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.events_distribution}>
                    <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                    <XAxis dataKey="bracket" className="text-muted-foreground" />
                    <YAxis className="text-muted-foreground" />
                    <Tooltip
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                      labelStyle={{ color: 'hsl(var(--foreground))' }}
                    />
                    <Bar dataKey="player_count" fill={CHART_COLORS.tertiary} name="Players" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Top Engaged Players</CardTitle>
                <CardDescription>Most active community members</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.top_engaged_players.slice(0, 5).map((player, idx) => (
                    <div
                      key={player.player_id}
                      className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-primary/20 text-primary font-semibold text-sm">
                          {idx + 1}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{player.player_name}</p>
                          <p className="text-xs text-muted-foreground">{player.player_number}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground">{player.events_attended} events</p>
                        <p className="text-xs text-muted-foreground">{player.character_count} chars</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* At-risk players */}
          {data.at_risk_players.length > 0 && (
            <Card className="border-warning/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-warning" />
                  At-Risk Players
                </CardTitle>
                <CardDescription>Players with declining attendance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.at_risk_players.map((player) => (
                    <div
                      key={player.player_id}
                      className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                    >
                      <div>
                        <p className="font-medium text-foreground">{player.player_name}</p>
                        <p className="text-xs text-muted-foreground">{player.player_number}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-foreground">
                          {player.days_since_last_event} days ago
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {player.events_last_3mo} events (last 3mo) vs {player.events_previous_3mo} (prev 3mo)
                        </p>
                        <p className="text-xs font-semibold text-warning capitalize">
                          {player.trend}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Character Ownership Section */}
        <div className="space-y-4">
          <h2 className="text-2xl font-semibold text-foreground">Character Ownership</h2>
          
          <Card className="border-border/50 bg-card/50 backdrop-blur">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Average Characters per Player</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">{data.avg_characters_per_player}</div>
              <p className="text-xs text-muted-foreground mt-1">Active characters only</p>
            </CardContent>
          </Card>

          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Players by Character Count</CardTitle>
                <CardDescription>Distribution of character ownership</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.character_distribution}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ character_count, percentage }) => `${character_count} chars (${percentage.toFixed(0)}%)`}
                      outerRadius={100}
                      fill="#8884d8"
                      dataKey="player_count"
                    >
                      {data.character_distribution.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/50 bg-card/50 backdrop-blur">
              <CardHeader>
                <CardTitle>Most Played Characters</CardTitle>
                <CardDescription>By events attended</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {data.most_played_characters.slice(0, 5).map((char, idx) => (
                    <div
                      key={char.character_id}
                      className="flex items-center justify-between p-3 rounded-lg bg-background/50 border border-border/50"
                    >
                      <div className="flex items-center gap-3">
                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-secondary/20 text-secondary font-semibold text-sm">
                          {idx + 1}
                        </div>
                        <div>
                          <p className="font-medium text-foreground">{char.character_name}</p>
                          <p className="text-xs text-muted-foreground">{char.player_name}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-foreground">{char.events_attended} events</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Last updated timestamp */}
        <div className="text-center text-sm text-muted-foreground">
          Last updated: {new Date(data.last_updated).toLocaleString()}
        </div>
      </div>
    </AnalyticsLayout>
  );
}
