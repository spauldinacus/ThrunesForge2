import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import { auth } from 'app/auth';
import { apiClient } from 'app';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { ArrowLeft, Calendar, MapPin, Users, Settings, UserCheck, UserX, Plus, Edit, Building, Clock, Trash2, Shield, FileText, Download } from 'lucide-react';
import type { ChapterResponse, CreateEventRequest, AdminEventResponse, UpdateEventRequest } from 'types';
import { formatDateForDisplay, formatTimeForDisplay, convertLocalDatetimeToUTC, convertUTCToLocalDatetime } from 'utils/timezone';

const ManageEvents = () => {
  // ALL HOOKS MUST BE DECLARED FIRST - before any conditional logic or returns
  const navigate = useNavigate();
  const { user } = useUserGuardContext();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  
  // All useState hooks
  const [activeTab, setActiveTab] = useState('events');
  const [chapters, setChapters] = useState<ChapterResponse[]>([]);
  const [events, setEvents] = useState<AdminEventResponse[]>([]);
  const [filteredEvents, setFilteredEvents] = useState<AdminEventResponse[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [eventsLoading, setEventsLoading] = useState(false);
  const [selectedChapterFilter, setSelectedChapterFilter] = useState<string>('all');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('all');
  const [newEvent, setNewEvent] = useState({
    title: '',
    description: '',
    location: '',
    chapter_id: '',
    starts_at: '',
    ends_at: '',
    status: 'upcoming'
  });
  const [editingEvent, setEditingEvent] = useState<AdminEventResponse | null>(null);
  const [editFormData, setEditFormData] = useState<UpdateEventRequest>({});
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [deletingEvent, setDeletingEvent] = useState<AdminEventResponse | null>(null);
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    const [exportProgress, setExportProgress] = useState<{
    show: boolean;
    eventName: string;
    totalCharacters: number;
    progress: number;
    status: string;
  }>({ show: false, eventName: '', totalCharacters: 0, progress: 0, status: '' });

  // Function declarations (must come before useEffect that calls them)
  const loadChapters = async () => {
    try {
      const response = await apiClient.list_scoped_chapters();
      const data = await response.json();
      setChapters(data.chapters || []);
    } catch (error) {
      console.error('Failed to load chapters:', error);
      toast.error('Failed to load chapters');
    }
  };

  const loadEvents = async () => {
    setEventsLoading(true);
    try {
      const response = await apiClient.list_scoped_events();
      const data = await response.json();
      setEvents(data.events || []);
    } catch (error) {
      console.error('Failed to load events:', error);
      toast.error('Failed to load events');
    } finally {
      setEventsLoading(false);
    }
  };

  // All useEffect hooks
  useEffect(() => {
    const loadData = async () => {
      try {
        // Load chapters
        await loadChapters();
        
        // Load events
        await loadEvents();
      } catch (error) {
        console.error('Failed to load data:', error);
        toast.error('Failed to load data');
      }
    };

    loadData();
  }, []);

  // Filter events based on selected filters
  useEffect(() => {
    let filtered = events;
    
    if (selectedChapterFilter !== 'all') {
      filtered = filtered.filter(event => event.chapter_id === selectedChapterFilter);
    }
    
    if (selectedStatusFilter !== 'all') {
      if (selectedStatusFilter === 'upcoming') {
        filtered = filtered.filter(event => new Date(event.starts_at) > new Date());
      } else if (selectedStatusFilter === 'past') {
        filtered = filtered.filter(event => new Date(event.starts_at) <= new Date());
      } else {
        filtered = filtered.filter(event => event.status === selectedStatusFilter);
      }
    }
    
    setFilteredEvents(filtered);
  }, [events, selectedChapterFilter, selectedStatusFilter]);

  // NOW all conditional logic and returns can happen AFTER all hooks are declared
  
  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-purple-400 text-lg">Verifying permissions...</div>
        </div>
      </div>
    );
  }

  // Block access if user doesn't have permission
  if (!hasPermission(PERMISSIONS.MANAGE_EVENTS)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <Card className="bg-slate-900 border-red-500/20 max-w-md">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-300 mb-4">You don't have permission to manage events.</p>
            <Button 
              onClick={() => navigate('/')}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const handleInputChange = (field: keyof CreateEventRequest, value: string) => {
    setNewEvent(prev => ({ ...prev, [field]: value }));
  };

  const validateForm = (): string | null => {
    if (!newEvent.title.trim()) return 'Event title is required';
    if (!newEvent.chapter_id) return 'Chapter selection is required';
    if (!newEvent.location.trim()) return 'Location is required';
    if (!newEvent.starts_at) return 'Start date/time is required';
    if (!newEvent.ends_at) return 'End date/time is required';
    
    const startDate = new Date(newEvent.starts_at);
    const endDate = new Date(newEvent.ends_at);
    if (endDate <= startDate) return 'End date must be after start date';
    
    return null;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      toast.error(validationError);
      return;
    }

    setIsLoading(true);
    try {
      // Convert local datetime values to UTC before sending to backend
      const eventData = {
        ...newEvent,
        starts_at: convertLocalDatetimeToUTC(newEvent.starts_at),
        ends_at: convertLocalDatetimeToUTC(newEvent.ends_at)
      };
      
      await apiClient.create_event(eventData);
      toast.success('Event created successfully!');
      
      // Reset form
      setNewEvent({
        title: '',
        description: '',
        chapter_id: '',
        location: '',
        starts_at: '',
        ends_at: '',
        status: 'upcoming'
      });
      
      // Switch back to events tab
      setActiveTab('events');
      
      // Reload events
      await loadEvents();
    } catch (error: any) {
      console.error('Failed to create event:', error);
      if (error.status === 403) {
        toast.error('Access denied. You must be an admin to create events.');
      } else {
        toast.error('Failed to create event. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusText = (event: AdminEventResponse) => {
    if (event.status === 'cancelled') return 'Cancelled';
    if (event.status === 'completed') return 'Completed';
    if (event.status === 'upcoming') return 'Upcoming';
    return 'Scheduled';
  };

  const getStatusStyling = (status: string) => {
  const statusLower = status.toLowerCase();
  switch (statusLower) {
    case 'upcoming':
      return {
        variant: 'default' as const,
        className: 'bg-green-600 hover:bg-green-700 text-white'
      };
    case 'past':
      return {
        variant: 'secondary' as const,
        className: 'bg-gray-600 hover:bg-gray-700 text-gray-200'
      };
    case 'cancelled':
      return {
        variant: 'destructive' as const,
        className: 'bg-red-600 hover:bg-red-700 text-white'
      };
    case 'completed':
      return {
        variant: 'secondary' as const,
        className: 'bg-blue-600 hover:bg-blue-700 text-white'
      };
    default:
      return {
        variant: 'default' as const,
        className: 'bg-purple-600 hover:bg-purple-700 text-white'
      };
  }
};


  const handleManageEvent = (eventId: string) => {
    if (!eventId || eventId === 'undefined') {
      toast.error('Invalid event ID');
      return;
    }
    navigate(`/admin-event-details?eventId=${eventId}`);
  };

  const handleEditEvent = (event: AdminEventResponse) => {
    setEditingEvent(event);
    setEditFormData({
      title: event.title,
      description: event.description || '',
      location: event.location || '',
      chapter_id: event.chapter_id,
      // Convert UTC times back to local datetime format for the inputs
      starts_at: convertUTCToLocalDatetime(event.starts_at),
      ends_at: convertUTCToLocalDatetime(event.ends_at),
      status: event.status
    });
    setShowEditDialog(true);
  };

  const handleUpdateEvent = async () => {
    if (!editingEvent) return;
    
    setIsLoading(true);
    try {
      // Convert local datetime values to UTC before sending to backend
      const updateData = {
        ...editFormData,
        starts_at: editFormData.starts_at ? convertLocalDatetimeToUTC(editFormData.starts_at) : undefined,
        ends_at: editFormData.ends_at ? convertLocalDatetimeToUTC(editFormData.ends_at) : undefined
      };
      
      await apiClient.update_event(
        { eventId: editingEvent.id },
        updateData
      );
      
      toast.success('Event updated successfully');
      setShowEditDialog(false);
      setEditingEvent(null);
      setEditFormData({});
      await loadEvents(); // Reload events
    } catch (error: any) {
      console.error('Failed to update event:', error);
      toast.error('Failed to update event. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDeleteEvent = (event: AdminEventResponse) => {
    setDeletingEvent(event);
    setShowDeleteDialog(true);
  };

  const handleExportEventPDFs = async (event: AdminEventResponse) => {
    try {
      // Initialize progress dialog
      setExportProgress({
        show: true,
        eventName: event.title,
        totalCharacters: 0,
        progress: 0,
        status: 'Loading attendees...'
      });
      
      // Get attendees for this event
      const attendeesResponse = await apiClient.get_event_attendees({ eventId: event.id });
      const attendeesData = await attendeesResponse.json();
      
      // Extract character IDs from attendees who have characters
      const characterIds = attendeesData.attendees
        .filter((attendee: any) => attendee.character_id)
        .map((attendee: any) => attendee.character_id);
      
      if (characterIds.length === 0) {
        setExportProgress(prev => ({ ...prev, show: false }));
        toast.error('No characters found for this event\'s attendees');
        return;
      }
      
      // Update with character count
      setExportProgress(prev => ({
        ...prev,
        totalCharacters: characterIds.length,
        progress: 33,
        status: `Generating ${characterIds.length} character sheets...`
      }));
      
      // Get auth token
      const token = await auth.getAuthToken();
      
      // Use the environment-aware API URL (brain.baseUrl already includes /routes)
      const url = `${apiClient.baseUrl}/admin/characters/export-pdf`;
      
      const response = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(characterIds)
      });
      
      if (!response.ok) {
        throw new Error(`Bulk export failed: ${response.status}`);
      }
      
      // Update progress
      setExportProgress(prev => ({
        ...prev,
        progress: 66,
        status: 'Processing PDF bundle...'
      }));
      
      // Get binary data as blob
      const blob = await response.blob();
      
      // Final progress update
      setExportProgress(prev => ({
        ...prev,
        progress: 100,
        status: 'Download starting...'
      }));
      
      const url2 = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url2;
      a.download = `${event.title.replace(/[^a-zA-Z0-9]/g, '_')}_character_sheets_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url2);
      document.body.removeChild(a);
      
      toast.success(`Exported ${characterIds.length} character sheets for ${event.title}`);
      
      // Close dialog after a short delay
      setTimeout(() => {
        setExportProgress(prev => ({ ...prev, show: false }));
      }, 1000);
    } catch (error: any) {
      console.error('Failed to export PDFs:', error);
      setExportProgress(prev => ({ ...prev, show: false }));
      toast.error('Failed to export character sheets. Please try again.');
    }
  };

  const confirmDeleteEvent = async () => {
    if (!deletingEvent) return;
    
    setIsLoading(true);
    try {
      await apiClient.delete_event({ eventId: deletingEvent.id });
      
      toast.success('Event deleted successfully');
      setShowDeleteDialog(false);
      setDeletingEvent(null);
      await loadEvents(); // Reload events
    } catch (error: any) {
      console.error('Failed to delete event:', error);
      if (error.status === 400) {
        toast.error('Cannot delete event with existing RSVPs. Cancel the event instead.');
      } else {
        toast.error('Failed to delete event. Please try again.');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <header className="relative z-10 flex justify-between items-center p-6">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
          
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
            Manage Events
          </div>
        </header>

        {/* Main Content */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 bg-black/40 border-purple-500/30">
            <TabsTrigger value="events" className="text-purple-200 data-[state=active]:bg-purple-800/50 data-[state=active]:text-white">
              <Settings className="w-4 h-4 mr-2" />
              Event Management
            </TabsTrigger>
            <TabsTrigger value="create" className="text-purple-200 data-[state=active]:bg-purple-800/50 data-[state=active]:text-white">
              <Plus className="w-4 h-4 mr-2" />
              Create Event
            </TabsTrigger>
          </TabsList>

          {/* Events List Tab */}
          <TabsContent value="events" className="space-y-6">
            {/* Filters */}
            <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-xl text-purple-200">Filter Events</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-purple-200 font-medium">Chapter</Label>
                    <Select value={selectedChapterFilter} onValueChange={setSelectedChapterFilter}>
                      <SelectTrigger className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900/90 border-purple-400/30">
                        <SelectItem value="all" className="text-purple-100 hover:bg-purple-800/50">All Chapters</SelectItem>
                        {chapters.map((chapter) => (
                          <SelectItem key={chapter.id} value={chapter.id} className="text-purple-100 hover:bg-purple-800/50">
                            {chapter.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label className="text-purple-200 font-medium">Status</Label>
                    <Select value={selectedStatusFilter} onValueChange={setSelectedStatusFilter}>
                      <SelectTrigger className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900/90 border-purple-400/30">
                        <SelectItem value="all" className="text-purple-100 hover:bg-purple-800/50">All Events</SelectItem>
                        <SelectItem value="scheduled" className="text-purple-100 hover:bg-purple-800/50">Scheduled</SelectItem>
                        <SelectItem value="completed" className="text-purple-100 hover:bg-purple-800/50">Completed</SelectItem>
                        <SelectItem value="cancelled" className="text-purple-100 hover:bg-purple-800/50">Cancelled</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Events Grid */}
            {eventsLoading ? (
              <div className="text-center py-12">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400 mx-auto"></div>
                <p className="text-purple-200 mt-4">Loading events...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredEvents.map((event) => {
                    const styling = getStatusStyling(getStatusText(event));
                    return (
                      <Card key={event.id} className="group relative bg-gray-900/80 backdrop-blur border-purple-800/30 hover:border-purple-600/50 transition-all duration-300 transform hover:scale-[1.02] hover:shadow-lg hover:shadow-purple-500/20">
                        <CardContent className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <h3 className="text-xl font-bold text-white mb-2 group-hover:text-purple-300 transition-colors">
                                {event.title}
                              </h3>
                              <div className="flex items-center text-purple-300 mb-2">
                                <MapPin className="w-4 h-4 mr-2" />
                                <span className="text-sm">{event.chapter_name}</span>
                              </div>
                              {event.location && (
                                <div className="flex items-center text-gray-400 mb-2">
                                  <Building className="w-4 h-4 mr-2" />
                                  <span className="text-sm">{event.location}</span>
                                </div>
                              )}
                              <div className="flex items-center text-blue-400">
                                <Clock className="w-4 h-4 mr-2" />
                                <span className="text-sm">
                                  {formatDateForDisplay(event.starts_at)} - {formatTimeForDisplay(event.starts_at)}
                                </span>
                              </div>
                            </div>
                            <div className="flex flex-col items-end space-y-2">

                              <Badge variant={styling.variant} className={styling.className}>
                              {getStatusText(event)}
                              </Badge>
                            </div>
                          </div>
                          
                          {event.description && (
                            <p className="text-gray-300 text-sm mb-4 line-clamp-2">
                              {event.description}
                            </p>
                          )}
                          
                          <div className="space-y-3">
                            <div className="flex items-center justify-between text-sm">
                              <div className="flex items-center text-purple-200/80">
                                <Users className="w-4 h-4 mr-1" />
                                {event.total_rsvps || 0} RSVPs
                              </div>
                              <div className="flex items-center text-green-400">
                                <UserCheck className="w-4 h-4 mr-1" />
                                {event.attended_count || 0} attended
                              </div>
                            </div>
                            
                            <div className="flex gap-2">
                              <Button 
                                onClick={() => {
                                  handleManageEvent(event.id);
                                }}
                                className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white"
                                size="sm"
                              >
                                <Edit className="w-4 h-4 mr-2" />
                                Manage Event
                              </Button>
                              
                              <Button
                                onClick={() => handleExportEventPDFs(event)}
                                variant="outline"
                                size="sm"
                                className="border-amber-500/50 text-amber-300 hover:bg-amber-800/20"
                                title="Export character sheets for all attendees"
                              >
                                <FileText className="w-4 h-4" />
                              </Button>
                              
                              <Button
                                onClick={() => handleEditEvent(event)}
                                variant="outline"
                                size="sm"
                                className="border-purple-500/50 text-purple-300 hover:bg-purple-800/20"
                              >
                                <Edit className="w-4 h-4" />
                              </Button>
                              
                              <Button
                                onClick={() => handleDeleteEvent(event)}
                                variant="outline"
                                size="sm"
                                className="border-red-500/50 text-red-400 hover:bg-red-800/20"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
              </div>
            )}
            
            {!eventsLoading && filteredEvents.length === 0 && (
              <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm">
                <CardContent className="py-12 text-center">
                  <Calendar className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                  <p className="text-purple-200 text-lg mb-2">No events found</p>
                  <p className="text-purple-300/70">Try adjusting your filters or create a new event.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Create Event Tab */}
          <TabsContent value="create">
            <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-2xl text-purple-200 flex items-center">
                  <Calendar className="w-6 h-6 mr-3 text-purple-400" />
                  Create New Event
                </CardTitle>
                <CardDescription className="text-purple-200/70">
                  Fill out the details below to create a new LARP event
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Event Title */}
                    <div className="md:col-span-2">
                      <Label htmlFor="title" className="text-purple-200 font-medium">
                        Event Title *
                      </Label>
                      <Input
                        id="title"
                        value={newEvent.title}
                        onChange={(e) => handleInputChange('title', e.target.value)}
                        placeholder="Enter event title..."
                        className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100 placeholder-purple-300/50"
                        required
                      />
                    </div>

                    {/* Chapter Selection */}
                    <div>
                      <Label htmlFor="chapter" className="text-purple-200 font-medium">
                        Chapter *
                      </Label>
                      <Select value={newEvent.chapter_id} onValueChange={(value) => handleInputChange('chapter_id', value)}>
                        <SelectTrigger className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100">
                          <SelectValue placeholder="Select a chapter" />
                        </SelectTrigger>
                        <SelectContent className="bg-purple-900/90 border-purple-400/30">
                          {chapters
                            .filter(chapter => chapter.id && chapter.id.trim() !== '')
                            .map((chapter) => (
                              <SelectItem key={chapter.id} value={chapter.id} className="text-purple-100 hover:bg-purple-800/50">
                                {chapter.name}
                              </SelectItem>
                            ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Location */}
                    <div>
                      <Label htmlFor="location" className="text-purple-200 font-medium flex items-center">
                        <MapPin className="w-4 h-4 mr-1" />
                        Location *
                      </Label>
                      <Input
                        id="location"
                        value={newEvent.location}
                        onChange={(e) => handleInputChange('location', e.target.value)}
                        placeholder="Event location..."
                        className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100 placeholder-purple-300/50"
                        required
                      />
                    </div>

                    {/* Start Date/Time */}
                    <div>
                      <Label htmlFor="starts_at" className="text-purple-200 font-medium">
                        Start Date & Time *
                      </Label>
                      <Input
                        id="starts_at"
                        type="datetime-local"
                        value={newEvent.starts_at}
                        onChange={(e) => handleInputChange('starts_at', e.target.value)}
                        className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100"
                        required
                      />
                    </div>

                    {/* End Date/Time */}
                    <div>
                      <Label htmlFor="ends_at" className="text-purple-200 font-medium">
                        End Date & Time *
                      </Label>
                      <Input
                        id="ends_at"
                        type="datetime-local"
                        value={newEvent.ends_at}
                        onChange={(e) => handleInputChange('ends_at', e.target.value)}
                        className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100"
                        required
                      />
                    </div>

                    {/* Event Status */}
                    <div>
                      <Label htmlFor="status" className="text-purple-200 font-medium">
                        Event Status
                      </Label>
                      <Select value={newEvent.status} onValueChange={(value) => handleInputChange('status', value as 'scheduled' | 'completed' | 'cancelled' | 'upcoming')}>
                        <SelectTrigger className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-purple-900/90 border-purple-400/30">
                          <SelectItem value="upcoming" className="text-purple-100 hover:bg-purple-800/50">Upcoming</SelectItem>
                          <SelectItem value="scheduled" className="text-purple-100 hover:bg-purple-800/50">Scheduled</SelectItem>
                          <SelectItem value="completed" className="text-purple-100 hover:bg-purple-800/50">Completed</SelectItem>
                          <SelectItem value="cancelled" className="text-purple-100 hover:bg-purple-800/50">Cancelled</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Description */}
                    <div className="md:col-span-2">
                      <Label htmlFor="description" className="text-purple-200 font-medium">
                        Event Description
                      </Label>
                      <Textarea
                        id="description"
                        value={newEvent.description}
                        onChange={(e) => handleInputChange('description', e.target.value)}
                        placeholder="Describe the event details, plot, requirements, etc..."
                        rows={4}
                        className="mt-1 bg-purple-900/20 border-purple-400/30 text-purple-100 placeholder-purple-300/50"
                      />
                    </div>
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end space-x-4 pt-6 border-t border-purple-500/20">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setActiveTab('events')}
                      className="border-purple-400/30 text-purple-200 hover:bg-purple-800/20"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white px-8"
                    >
                      {isLoading ? (
                        <>
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                          Creating...
                        </>
                      ) : (
                        <>
                          <Users className="w-4 h-4 mr-2" />
                          Create Event
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Edit Event Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gray-900 border-purple-500/30 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl text-purple-200">Edit Event</DialogTitle>
            <DialogDescription className="text-purple-200/70">
              Update the event details below
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <Label htmlFor="edit-title" className="text-purple-200">Event Title</Label>
              <Input
                id="edit-title"
                value={editFormData.title || ''}
                onChange={(e) => setEditFormData({ ...editFormData, title: e.target.value })}
                className="bg-gray-800 border-purple-500/30 text-white"
              />
            </div>
            
            <div>
              <Label htmlFor="edit-description" className="text-purple-200">Description</Label>
              <Textarea
                id="edit-description"
                value={editFormData.description || ''}
                onChange={(e) => setEditFormData({ ...editFormData, description: e.target.value })}
                className="bg-gray-800 border-purple-500/30 text-white"
                rows={3}
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-location" className="text-purple-200">Location</Label>
                <Input
                  id="edit-location"
                  value={editFormData.location || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, location: e.target.value })}
                  className="bg-gray-800 border-purple-500/30 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="edit-chapter" className="text-purple-200">Chapter</Label>
                <Select
                  value={editFormData.chapter_id || ''}
                  onValueChange={(value) => setEditFormData({ ...editFormData, chapter_id: value })}
                >
                  <SelectTrigger className="bg-gray-800 border-purple-500/30 text-white">
                    <SelectValue placeholder="Select chapter" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-purple-500/30">
                    {chapters.map((chapter) => (
                      <SelectItem key={chapter.id} value={chapter.id} className="text-white">
                        {chapter.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="edit-starts-at" className="text-purple-200">Start Date & Time</Label>
                <Input
                  id="edit-starts-at"
                  type="datetime-local"
                  value={editFormData.starts_at || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, starts_at: e.target.value })}
                  className="bg-gray-800 border-purple-500/30 text-white"
                />
              </div>
              
              <div>
                <Label htmlFor="edit-ends-at" className="text-purple-200">End Date & Time</Label>
                <Input
                  id="edit-ends-at"
                  type="datetime-local"
                  value={editFormData.ends_at || ''}
                  onChange={(e) => setEditFormData({ ...editFormData, ends_at: e.target.value })}
                  className="bg-gray-800 border-purple-500/30 text-white"
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="edit-status" className="text-purple-200">Status</Label>
              <Select
                value={editFormData.status || ''}
                onValueChange={(value) => setEditFormData({ ...editFormData, status: value as 'scheduled' | 'completed' | 'cancelled' })}
              >
                <SelectTrigger className="bg-gray-800 border-purple-500/30 text-white">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-purple-500/30">
                  <SelectItem value="upcoming" className="text-white">Upcoming</SelectItem>
                  <SelectItem value="scheduled" className="text-white">Scheduled</SelectItem>
                  <SelectItem value="completed" className="text-white">Completed</SelectItem>
                  <SelectItem value="cancelled" className="text-white">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <div className="flex gap-3 mt-6">
            <Button
              onClick={() => setShowEditDialog(false)}
              variant="outline"
              className="flex-1 border-purple-500/30 text-purple-200 hover:bg-purple-800/20"
            >
              Cancel
            </Button>
            <Button
              onClick={handleUpdateEvent}
              disabled={isLoading}
              className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              {isLoading ? 'Updating...' : 'Update Event'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Export Progress Dialog */}
      <Dialog open={exportProgress.show} onOpenChange={(open) => !open && setExportProgress(prev => ({ ...prev, show: false }))}>
        <DialogContent className="bg-gradient-to-br from-purple-950/95 to-blue-950/95 border-purple-500/50 backdrop-blur-md">
          <DialogHeader>
            <DialogTitle className="text-2xl bg-gradient-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
              Exporting Character Sheets
            </DialogTitle>
            <DialogDescription className="text-purple-200/80">
              Event: {exportProgress.eventName}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Status Message */}
            <div className="text-center">
              <p className="text-purple-200 text-lg font-medium">
                {exportProgress.status}
              </p>
              {exportProgress.totalCharacters > 0 && (
                <p className="text-purple-300/70 text-sm mt-2">
                  {exportProgress.totalCharacters} character{exportProgress.totalCharacters !== 1 ? 's' : ''}
                </p>
              )}
            </div>
            
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="w-full bg-purple-900/40 rounded-full h-3 overflow-hidden border border-purple-500/30">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-500 ease-out rounded-full"
                  style={{ width: `${exportProgress.progress}%` }}
                />
              </div>
              <p className="text-center text-purple-300/60 text-sm">
                {exportProgress.progress}%
              </p>
            </div>
            
            {/* Loading Animation */}
            {exportProgress.progress < 100 && (
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Delete Event Dialog */}
      <Dialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <DialogContent className="bg-gray-900 border-red-500/30 text-white">
          <DialogHeader>
            <DialogTitle className="text-xl text-red-400">Delete Event</DialogTitle>
            <DialogDescription className="text-red-200/70">
              Are you sure you want to delete this event? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          {deletingEvent && (
            <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-4 my-4">
              <h3 className="font-semibold text-red-200">{deletingEvent.title}</h3>
              <p className="text-red-300/70 text-sm mt-1">
                {deletingEvent.total_rsvps > 0 
                  ? `This event has ${deletingEvent.total_rsvps} RSVPs. Consider cancelling instead of deleting.`
                  : 'This event has no RSVPs and can be safely deleted.'
                }
              </p>
            </div>
          )}
          
          <div className="flex gap-3 mt-6">
            <Button
              onClick={() => setShowDeleteDialog(false)}
              variant="outline"
              className="flex-1 border-gray-500/30 text-gray-200 hover:bg-gray-800/20"
            >
              Cancel
            </Button>
            <Button
              onClick={confirmDeleteEvent}
              disabled={isLoading}
              className="flex-1 bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800"
            >
              {isLoading ? 'Deleting...' : 'Delete Event'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ManageEvents;
