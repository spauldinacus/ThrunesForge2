import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { ArrowLeft, Edit2, Edit3, Save, X, User, Mail, Phone, Clock, Shield, Hash, Loader2, Star, Flame, History } from 'lucide-react';
import { toast } from 'sonner';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Check, ChevronsUpDown } from 'lucide-react';
import { cn } from '@/lib/utils';
import { apiClient } from 'app';
import { useUserGuardContext } from 'app/auth';
import { useAdminStatus } from 'utils/useAdminStatus';
import { PlayerProfileSetup } from 'components/PlayerProfileSetup';
import type { 
  PlayerProfile as PlayerProfileType, 
  PlayerListItem,
  ChapterPlayersGroup,
  UpdatePlayerProfileRequest,
  UpdatePlayerNumberRequest,
  CandleHistoryResponse,
  CandleTransaction
} from 'types';


export default function PlayerProfile() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<PlayerProfileType | null>(null);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [playersForReferral, setPlayersForReferral] = useState<ChapterPlayersGroup[]>([]);
  const [referralSelectorOpen, setReferralSelectorOpen] = useState(false);
  const [referralSearchValue, setReferralSearchValue] = useState("");
  const [saving, setSaving] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [candleHistory, setCandleHistory] = useState<CandleTransaction[]>([]);
  const [formData, setFormData] = useState<UpdatePlayerProfileRequest>({});
  
  // Use centralized admin status hook
  const { isAdmin, adminStatusLoading } = useAdminStatus();

  // Referral selector state
  const [editingPlayerNumber, setEditingPlayerNumber] = useState(false);
  const [playerNumberForm, setPlayerNumberForm] = useState<UpdatePlayerNumberRequest>({
    player_number: '',
    reason: ''
  });
  const [savingPlayerNumber, setSavingPlayerNumber] = useState(false);

  // Load profile on mount
  useEffect(() => {
    loadProfile();
    loadAvailablePlayers();
  }, []);

  const loadAvailablePlayers = async () => {
    try {
      const response = await apiClient.list_players_for_referral();
      const data: ChapterPlayersGroup[] = await response.json();
    setPlayersForReferral(data);
    } catch (error) {
      console.error('Failed to load players for referral:', error);
    }
  };
  
  const loadProfile = async () => {
    try {
      setLoading(true);
      const response = await apiClient.get_my_player_profile();
      const profileData: PlayerProfileType = await response.json();
      setProfile(profileData);
      
      // Initialize form data
      setFormData({
        first_name: profileData.first_name,
        last_name: profileData.last_name,
        phone_number: profileData.phone_number,
        emergency_contact_name: profileData.emergency_contact_name,
        emergency_contact_phone: profileData.emergency_contact_phone,
        email: profileData.email,
        referred_by_player_id: profileData.referred_by_player_id || undefined
      });
    } catch (error: any) {
      console.error('Failed to load profile:', error);
      if (error.status === 404) {
        // Profile doesn't exist, user needs to complete setup
        setProfile(null);
      } else {
        toast.error('Failed to load profile');
      }
    } finally {
      setLoading(false);
    }
  };

  const loadCandleHistory = async () => {
    try {
      // Try brain client first
      try {
        const response = await apiClient.get_my_candle_history();
        const historyData = await response.json();
        setCandleHistory(historyData.transactions || []);
        return;
      } catch (brainError) {
        // Import auth for authentication
        const { auth } = await import('app/auth');
        
        // Get the brain client's base URL and construct the correct endpoint URL
        const brainBaseUrl = (apiClient as any).baseUrl || '';
        const endpointUrl = `${brainBaseUrl}/players/candle-history`;
        
        // Fallback to direct API call to work around CORS issue
        const authToken = await auth.getAuthHeaderValue();
        const response = await fetch(endpointUrl, {
          method: 'GET',
          headers: {
            'Authorization': authToken,
            'Content-Type': 'application/json',
          },
          credentials: 'include',
        });
        
        if (!response.ok) {
          if (response.status === 404) {
            setCandleHistory([]);
            return;
          }
          throw new Error(`HTTP ${response.status}: ${response.statusText}`);
        }
        
        const historyData = await response.json();
        setCandleHistory(historyData.transactions || []);
      }
    } catch (error) {
      console.error('Failed to load candle history:', error);
      // Check if it's a CORS error or 404 (no profile)
      if (error && (error as any).status === 404) {
        // Don't show error toast for 404, just leave history empty
        setCandleHistory([]);
      } else {
        console.error('CORS or network error loading candle history:', error);
        toast.error('Failed to load candle history');
      }
    }
  };

  const handleSave = async () => {
    if (!profile) return;
    
    try {
      setSaving(true);
      const response = await apiClient.update_my_player_profile(formData);
      const updatedProfile: PlayerProfileType = await response.json();
      setProfile(updatedProfile);
      setEditing(false);
      toast.success('Profile updated successfully!');
    } catch (error: any) {
      console.error('Failed to update profile:', error);
      toast.error('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  const handleCancel = () => {
    if (profile) {
      setFormData({
        first_name: profile.first_name,
        last_name: profile.last_name,
        phone_number: profile.phone_number,
        emergency_contact_name: profile.emergency_contact_name,
        emergency_contact_phone: profile.emergency_contact_phone,
        email: profile.email
      });
    }
    setEditing(false);
  };

  const handlePlayerNumberSave = async () => {
    if (!profile) return;
    
    try {
      setSavingPlayerNumber(true);
      const response = await apiClient.update_player_number(
        { playerId: profile.id },
        playerNumberForm
      );
      const updatedProfile: PlayerProfileType = await response.json();
      setProfile(updatedProfile);
      setEditingPlayerNumber(false);
      setPlayerNumberForm({ player_number: '', reason: '' });
      toast.success('Player number updated successfully!');
    } catch (error: any) {
      console.error('Failed to update player number:', error);
      const errorMsg = error.detail || 'Failed to update player number';
      toast.error(errorMsg);
    } finally {
      setSavingPlayerNumber(false);
    }
  };

  const handlePlayerNumberCancel = () => {
    setPlayerNumberForm({ player_number: '', reason: '' });
    setEditingPlayerNumber(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  // Show loading state - only wait for profile data, not admin status
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  // Navigation Header Component
  const NavigationHeader = () => (
    <header className="relative z-10 flex justify-between items-center p-6">
      <div className="flex items-center space-x-4">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
      </div>
      
      <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
        Player Profile
      </div>
    </header>
  );

  // Show profile setup if no profile exists
  if (!profile) {
    return (
      <div>
        <NavigationHeader />
        <PlayerProfileSetup />
      </div>
    );
  }

  return (
    <div>
      <NavigationHeader />
      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Profile Card */}
          <div className="lg:col-span-2">
            <Card className="bg-black/60 backdrop-blur-xl border-purple-500/30 shadow-2xl shadow-purple-500/10">
              <CardHeader className="flex flex-row items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="p-3 rounded-full bg-gradient-to-br from-purple-500/20 to-amber-500/20">
                    <User className="w-6 h-6 text-purple-300" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
                      {profile.first_name} {profile.last_name}
                    </CardTitle>
                    <div className="flex items-center gap-2">
                      {!editingPlayerNumber ? (
                        <>
                          <p className="text-purple-200/60">Player #{profile.player_number}</p>
                          {isAdmin && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setPlayerNumberForm({
                                  player_number: profile.player_number,
                                  reason: ''
                                });
                                setEditingPlayerNumber(true);
                              }}
                              className="h-6 w-6 p-0 text-purple-400 hover:text-purple-300 hover:bg-purple-600/20"
                            >
                              <Shield className="w-3 h-3" />
                            </Button>
                          )}
                        </>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex items-center gap-2">
                            <Input
                              value={playerNumberForm.player_number}
                              onChange={(e) => setPlayerNumberForm(prev => ({ ...prev, player_number: e.target.value.toUpperCase() }))}
                              placeholder="FL2508001"
                              className="h-8 w-24 text-sm bg-black/40 border-purple-500/30 text-white"
                              maxLength={9}
                            />
                            <Button
                              size="sm"
                              onClick={handlePlayerNumberSave}
                              disabled={savingPlayerNumber || !playerNumberForm.player_number || !playerNumberForm.reason}
                              className="h-8 bg-green-600/80 hover:bg-green-600 text-white"
                            >
                              {savingPlayerNumber ? (
                                <Loader2 className="w-3 h-3 animate-spin" />
                              ) : (
                                'Save'
                              )}
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={handlePlayerNumberCancel}
                              className="h-8 text-purple-200 hover:bg-purple-600/20"
                            >
                              Cancel
                            </Button>
                          </div>
                          <Input
                            value={playerNumberForm.reason}
                            onChange={(e) => setPlayerNumberForm(prev => ({ ...prev, reason: e.target.value }))}
                            placeholder="Reason for change (required)"
                            className="h-8 text-sm bg-black/40 border-purple-500/30 text-white"
                            maxLength={500}
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setEditing(!editing)}
                  className="bg-purple-600/20 border-purple-500/50 text-purple-200 hover:bg-purple-600/30"
                >
                  <Edit3 className="w-4 h-4 mr-2" />
                  {editing ? 'Cancel' : 'Edit'}
                </Button>
              </CardHeader>
              
              <CardContent className="space-y-6">
                {/* Basic Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-purple-300 flex items-center gap-2">
                    <Star className="w-5 h-5" />
                    Basic Information
                  </h3>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label className="text-purple-200">First Name</Label>
                      {editing ? (
                        <Input
                          value={formData.first_name || ''}
                          onChange={(e) => setFormData(prev => ({ ...prev, first_name: e.target.value }))}
                          className="bg-black/40 border-purple-500/30 text-white"
                        />
                      ) : (
                        <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                          {profile.first_name}
                        </p>
                      )}
                    </div>
                    
                    <div className="space-y-2">
                      <Label className="text-purple-200">Last Name</Label>
                      {editing ? (
                        <Input
                          value={formData.last_name || ''}
                          onChange={(e) => setFormData(prev => ({ ...prev, last_name: e.target.value }))}
                          className="bg-black/40 border-purple-500/30 text-white"
                        />
                      ) : (
                        <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                          {profile.last_name}
                        </p>
                      )}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-purple-200">Phone Number</Label>
                    {editing ? (
                      <Input
                        value={formData.phone_number || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, phone_number: e.target.value }))}
                        className="bg-black/40 border-purple-500/30 text-white"
                        placeholder="(555) 123-4567"
                      />
                    ) : (
                      <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                        {profile.phone_number || 'Not provided'}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-purple-200">Email Address</Label>
                    {editing ? (
                      <Input
                        value={formData.email || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                        className="bg-black/40 border-purple-500/30 text-white"
                        placeholder="your.email@example.com"
                        type="email"
                      />
                    ) : (
                      <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                        {profile.email || 'Not provided'}
                      </p>
                    )}
                  </div>
                </div>

                {/* Emergency Contact */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-purple-300">Emergency Contact</h3>
                  
                  <div className="space-y-2">
                    <Label className="text-purple-200">Contact Name</Label>
                    {editing ? (
                      <Input
                        value={formData.emergency_contact_name || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_name: e.target.value }))}
                        className="bg-black/40 border-purple-500/30 text-white"
                        placeholder="Emergency contact name"
                      />
                    ) : (
                      <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                        {profile.emergency_contact_name || 'Not provided'}
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <Label className="text-purple-200">Contact Phone</Label>
                    {editing ? (
                      <Input
                        value={formData.emergency_contact_phone || ''}
                        onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_phone: e.target.value }))}
                        className="bg-black/40 border-purple-500/30 text-white"
                        placeholder="(555) 123-4567"
                      />
                    ) : (
                      <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                        {profile.emergency_contact_phone || 'Not provided'}
                      </p>
                    )}
                  </div>
                </div>

                <div className="space-y-2">
                    <Label className="text-purple-200">
                      Referred By
                    </Label>
                    {!editing && !profile.referred_by_player_id && (
                      <div className="text-purple-200/40 text-sm">Not specified</div>
                    )}
                    {!editing && profile.referred_by_player_id && (
                      <div className="flex items-center justify-between">
                        <div className="text-purple-200">
                          {profile.referred_by_player_name} ({profile.referred_by_player_number})
                        </div>
                        {profile.referral_acknowledged && (
                          <Badge variant="secondary" className="bg-green-500/20 text-green-300">
                            Verified ✓
                          </Badge>
                        )}
                      </div>
                    )}
                    {editing && !profile.referral_acknowledged && (
                      <Popover open={referralSelectorOpen} onOpenChange={setReferralSelectorOpen}>
                        <PopoverTrigger asChild>
                          <Button
                            variant="outline"
                            role="combobox"
                            aria-expanded={referralSelectorOpen}
                            className="w-full justify-between bg-black/40 border-purple-500/30 text-white hover:bg-black/60"
                          >
                            {formData.referred_by_player_id
                              ? (() => {
                                  const selected = (playersForReferral || [])
                                    .flatMap(group => group.players)
                                    .find(p => p.id === formData.referred_by_player_id);
                                  return selected ? `${selected.name} (${selected.player_number})` : 'Select player...';
                                })()
                              : 'Select player...'}
                            <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-full p-0 bg-black/95 border-purple-500/30">
                          <Command className="bg-transparent">
                            <CommandInput 
                              placeholder="Search players..." 
                              className="text-white"
                              value={referralSearchValue}
                              onValueChange={setReferralSearchValue}
                            />
                                  <CommandList>
                                    <CommandEmpty className="text-purple-300/60 py-6 text-center">No players found.</CommandEmpty>
                                    {playersForReferral && playersForReferral.length > 0 && playersForReferral
                                      .filter(chapter => chapter?.players && Array.isArray(chapter.players) && chapter.players.length > 0)
                                      .map(chapter => (
                                        <CommandGroup key={chapter.chapter_name} heading={chapter.chapter_name}>
                                          {chapter.players.map(player => (
                                            <CommandItem
                                              key={player.id}
                                              value={`${player.name} ${player.player_number}`}
                                              onSelect={() => {
                                                setFormData({ ...formData, referred_by_player_id: player.id });
                                                setReferralSelectorOpen(false);
                                              }}
                                            >
                                              <Check
                                                className={cn(
                                                  "mr-2 h-4 w-4",
                                                  formData.referred_by_player_id === player.id ? "opacity-100" : "opacity-0"
                                                )}
                                              />
                                              {player.name} ({player.player_number})
                                            </CommandItem>
                                          ))}
                                        </CommandGroup>
                                      ))}
                                  </CommandList>
                          </Command>
                        </PopoverContent>
                      </Popover>
                    )}
                    {editing && profile.referral_acknowledged && (
                      <div className="text-purple-300/60 text-sm italic">
                        Referral is locked and cannot be changed
                      </div>
                    )}
                    {profile.referral_acknowledged && profile.referral_acknowledged_at && (
                      <div className="text-xs text-purple-300/60 mt-1">
                        Verified {formatDate(profile.referral_acknowledged_at)}
                      </div>
                    )}
                  </div> 
                
                {/* Chapter Information */}
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold text-purple-300">Chapter Information</h3>
                  
                  <div className="space-y-2">
                    <Label className="text-purple-200">Chapter</Label>
                    <p className="text-white bg-black/20 p-3 rounded border border-purple-500/20">
                      {profile.chapter_name}
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                {editing && (
                  <div className="flex gap-3 pt-4">
                    <Button
                      onClick={handleSave}
                      disabled={saving}
                      className="bg-gradient-to-r from-purple-600 to-amber-600 hover:from-purple-700 hover:to-amber-700 text-white"
                    >
                      {saving ? (
                        <>
                          <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        'Save Changes'
                      )}
                    </Button>
                    <Button
                      variant="outline"
                      onClick={handleCancel}
                      className="border-purple-500/50 text-purple-200 hover:bg-purple-600/20"
                    >
                      Cancel
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar - Candles & Stats */}
          <div className="space-y-6">
            {/* Candles Available */}
            <Card className="bg-black/60 backdrop-blur-xl border-amber-500/30 shadow-2xl shadow-amber-500/10">
              <CardHeader className="text-center">
                <div className="flex justify-center mb-3">
                  <div className="p-4 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20">
                    <Flame className="w-8 h-8 text-amber-300" />
                  </div>
                </div>
                <CardTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">
                  Candles Available
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="text-4xl font-bold text-amber-300">
                  {profile.candles_available}
                </div>
                <Badge 
                  variant="outline" 
                  className="bg-amber-500/20 border-amber-500/50 text-amber-200 px-4 py-2"
                >
                  Candles
                </Badge>
                
                <Dialog open={showHistory} onOpenChange={setShowHistory}>
                  <DialogTrigger asChild>
                    <Button
                      variant="outline"
                      className="w-full bg-amber-600/20 border-amber-500/50 text-amber-200 hover:bg-amber-600/30"
                      onClick={loadCandleHistory}
                    >
                      <History className="w-4 h-4 mr-2" />
                      View History
                    </Button>
                  </DialogTrigger>
                  
                  <DialogContent className="max-w-2xl bg-black/90 border-amber-500/30">
                    <DialogHeader>
                      <DialogTitle className="text-2xl text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">
                        Candle History
                      </DialogTitle>
                    </DialogHeader>
                    
                    <div className="max-h-96 overflow-y-auto">
                      {candleHistory.length === 0 ? (
                        <p className="text-center text-purple-200/60 py-8">
                          No candle transactions yet
                        </p>
                      ) : (
                        <Table>
                          <TableHeader>
                            <TableRow className="border-amber-500/30">
                              <TableHead className="text-amber-200">Date</TableHead>
                              <TableHead className="text-amber-200">Amount</TableHead>
                              <TableHead className="text-amber-200">Reason</TableHead>
                              <TableHead className="text-amber-200">Granted By</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {candleHistory.map((transaction) => (
                              <TableRow key={transaction.id} className="border-amber-500/20">
                                <TableCell className="text-white">
                                  {formatDate(transaction.created_at)}
                                </TableCell>
                                <TableCell className={`font-semibold ${
                                  transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                                }`}>
                                  {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                                </TableCell>
                                <TableCell className="text-white">
                                  {transaction.reason}
                                </TableCell>
                                <TableCell className="text-purple-200">
                                  {transaction.granted_by_name || 'System'}
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      )}
                    </div>
                  </DialogContent>
                </Dialog>
              </CardContent>
            </Card>

            {/* Profile Stats */}
            <Card className="bg-black/60 backdrop-blur-xl border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-lg text-purple-300">Profile Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-purple-200/80">Member Since</span>
                  <span className="text-white font-semibold">
                    {formatDate(profile.created_at)}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-purple-200/80">Last Updated</span>
                  <span className="text-white font-semibold">
                    {formatDate(profile.updated_at)}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
