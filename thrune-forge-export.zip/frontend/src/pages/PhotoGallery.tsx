import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { PhotoGalleryResponse } from 'types';
import { ArrowLeft, Tag, X, Users } from 'lucide-react';

interface Gallery {
  id: string;
  name: string;
  description?: string | null;
  event_date?: string | null;
  photo_count: number;
  created_at: string;
  updated_at: string;
}

const PhotoGallery = () => {
  const navigate = useNavigate();
  const [galleries, setGalleries] = useState<Gallery[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadGalleries = async () => {
      setLoading(true);
      try {
        const response = await apiClient.list_public_galleries();
        const data = await response.json();
        setGalleries(data.galleries || []);
      } catch (error) {
        console.error('Failed to load galleries:', error);
        toast.error('Failed to load photo galleries');
      } finally {
        setLoading(false);
      }
    };
    loadGalleries();
  }, []);

  const handleGalleryClick = (galleryId: string) => {
    navigate(`/gallery-photos?id=${galleryId}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 border-b border-purple-800/30">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/')}
          className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Button>
        
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Photo Gallery
        </h1>
        <div className="w-32" /> {/* Spacer */}
      </header>
                 
      {/* Gallery Grid */}
      <div className="container mx-auto p-6">
        {loading ? (
          <div className="text-center text-purple-300">Loading galleries...</div>
        ) : galleries.length === 0 ? (
          <div className="text-center text-purple-300">No photo galleries available yet.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {galleries.map((gallery) => (
              <Card 
                key={gallery.id}
                className="cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all bg-slate-900/50 border-purple-700/30"
                onClick={() => handleGalleryClick(gallery.id)}
              >
                <CardContent className="p-6">
                  <div className="space-y-3">
                    <h3 className="text-xl font-bold text-purple-200">{gallery.name}</h3>
                    
                    {gallery.event_date && (
                      <p className="text-sm text-purple-400">
                        {new Date(gallery.event_date).toLocaleDateString('en-US', { 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </p>
                    )}
                    
                    {gallery.description && (
                      <p className="text-sm text-purple-300">{gallery.description}</p>
                    )}
                    
                    <Badge className="bg-purple-600">
                      {gallery.photo_count} {gallery.photo_count === 1 ? 'photo' : 'photos'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default PhotoGallery;
