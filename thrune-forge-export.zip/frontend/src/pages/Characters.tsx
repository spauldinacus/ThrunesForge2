
import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Sparkles, User, Plus } from "lucide-react";

export default function Characters() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Character Management
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full bg-gradient-to-br from-purple-500/20 to-blue-500/20">
              <Sparkles className="w-12 h-12 text-purple-300" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-blue-400 mb-4">
            Your Characters
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Create and manage your LARP characters. Each character has their own story, abilities, and progression.
          </p>
        </div>

        {/* Placeholder content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Create New Character Card */}
          <Card 
            className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-purple-600/20 to-blue-600/20 backdrop-blur-sm border-purple-500/30 hover:border-purple-400/60 shadow-xl hover:shadow-2xl hover:shadow-purple-500/20"
            onClick={() => navigate('/character-creator')}
          >
            <CardContent className="p-6 text-center">
              <div className="mb-4 flex justify-center">
                <div className="p-3 rounded-full bg-gradient-to-br from-green-500/20 to-emerald-500/20 group-hover:from-green-500/30 group-hover:to-emerald-500/30 transition-all duration-300">
                  <Plus className="w-8 h-8 text-green-300 group-hover:text-green-200" />
                </div>
              </div>
              <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-green-200 transition-colors">
                Create New Character
              </h3>
              <p className="text-slate-400 text-sm group-hover:text-slate-300 transition-colors">
                Start your next adventure
              </p>
            </CardContent>
          </Card>

          {/* Example Character Cards */}
          {[1, 2].map((index) => (
            <Card key={index} className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-slate-800/40 to-slate-700/40 backdrop-blur-sm border-slate-600/30 hover:border-slate-500/60 shadow-xl hover:shadow-2xl hover:shadow-slate-500/20">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  <div className="p-2 rounded-full bg-gradient-to-br from-purple-500/20 to-blue-500/20">
                    <User className="w-6 h-6 text-purple-300" />
                  </div>
                  <div>
                    <CardTitle className="text-white text-lg">Character Slot {index}</CardTitle>
                    <p className="text-slate-400 text-sm">Ready for creation</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-slate-300 text-sm">
                  Create a new character to begin your LARP journey in this slot.
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>
    </div>
  );
}
