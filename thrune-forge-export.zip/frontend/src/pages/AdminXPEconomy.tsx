import { useState, useEffect } from 'react';
import { AnalyticsLayout } from 'components/AnalyticsLayout';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, PieChart, Pie, LineChart, Line, AreaChart, Area, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Download, RefreshCw, Calendar } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import { apiClient } from 'app';
import { 
  XPEconomyAnalytics,
  XPBracketDistribution,
  TopXPEarner,
  XPSpendingCategory,
  MonthlyXPTrend,
  CandleMetrics
} from 'types';

const COLORS = ['#8b5cf6', '#7c3aed', '#6d28d9', '#5b21b6', '#4c1d95'];

export default function AdminXPEconomy() {
  const [analytics, setAnalytics] = useState<XPEconomyAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');

  const fetchAnalytics = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const params: { start_date?: string; end_date?: string } = {};
      if (startDate) params.start_date = new Date(startDate).toISOString();
      if (endDate) params.end_date = new Date(endDate).toISOString();
      
      const response = await apiClient.get_xp_economy_analytics(params);
      const data = await response.json();
      setAnalytics(data);
    } catch (err) {
      console.error('Failed to fetch XP economy analytics:', err);
      setError('Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAnalytics();
  }, []);

  const exportToCSV = () => {
    if (!analytics) return;
    
    const csvRows = [];
    csvRows.push('XP Economy Analytics Report');
    csvRows.push('');
    csvRows.push('Distribution Metrics');
    csvRows.push('Bracket,Player Count,Percentage');
    analytics.xp_brackets.forEach((bracket) => {
      csvRows.push(`${bracket.bracket},${bracket.player_count},${bracket.percentage}%`);
    });
    csvRows.push('');
    csvRows.push('Top XP Earners');
    csvRows.push('Player Name,Player Number,Total XP');
    analytics.top_earners.forEach((earner) => {
      csvRows.push(`${earner.player_name},${earner.player_number},${earner.total_xp}`);
    });
    csvRows.push('');
    csvRows.push('Spending by Category');
    csvRows.push('Category,Total XP,Percentage');
    analytics.spending_by_category.forEach((cat) => {
      csvRows.push(`${cat.category},${cat.total_xp},${cat.percentage}%`);
    });
    
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `xp-economy-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  if (loading) {
    return (
      <AnalyticsLayout>
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <div>
              <Skeleton className="h-8 w-64 mb-2" />
              <Skeleton className="h-4 w-96" />
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[1, 2, 3].map((i) => <Skeleton key={i} className="h-32" />)}
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  if (error || !analytics) {
    return (
      <AnalyticsLayout>
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle>Error Loading Analytics</CardTitle>
            <CardDescription>{error || 'Unknown error occurred'}</CardDescription>
          </CardHeader>
        </Card>
      </AnalyticsLayout>
    );
  }

  return (
    <AnalyticsLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">XP Economy Analytics</h2>
            <p className="text-muted-foreground">
              Comprehensive XP distribution, spending patterns, and earning trends
            </p>
          </div>
          <div className="flex gap-2">
            <Button onClick={fetchAnalytics} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={exportToCSV} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Filter Controls */}
        <Card className="bg-card/50 backdrop-blur">
          <CardHeader>
            <CardTitle className="text-lg flex items-center gap-2">
              <Calendar className="w-5 h-5" />
              Filter by Date Range
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 items-end">
              <div className="flex-1">
                <label className="text-sm font-medium text-muted-foreground mb-2 block">
                  Start Date
                </label>
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground"
                />
              </div>
              <div className="flex-1">
                <label className="text-sm font-medium text-muted-foreground mb-2 block">
                  End Date
                </label>
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md bg-background text-foreground"
                />
              </div>
              <Button onClick={fetchAnalytics}>
                Apply Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Distribution Section */}
        <div className="space-y-4">
          <h3 className="text-2xl font-semibold text-foreground">XP Distribution</h3>
          
          {/* Stat Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="bg-gradient-to-br from-purple-500/10 to-purple-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Average XP</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.average_xp_per_player.toFixed(0)}</div>
                <p className="text-xs text-muted-foreground mt-1">per player</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-violet-500/10 to-violet-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Median XP</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.median_xp_per_player.toFixed(0)}</div>
                <p className="text-xs text-muted-foreground mt-1">middle value</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-indigo-500/10 to-indigo-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Active Characters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.total_characters_analyzed}</div>
                <p className="text-xs text-muted-foreground mt-1">in analysis</p>
              </CardContent>
            </Card>
          </div>

          {/* XP Brackets Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Player Distribution by XP Bracket</CardTitle>
              <CardDescription>Number of players in each XP range</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={analytics.xp_brackets}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="bracket" stroke="hsl(var(--muted-foreground))" />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Bar dataKey="player_count" fill="#8b5cf6" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top Earners Table */}
          <Card>
            <CardHeader>
              <CardTitle>Top 10 XP Earners</CardTitle>
              <CardDescription>Players with the highest total XP</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">Rank</th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">Player Name</th>
                      <th className="text-left py-3 px-4 font-medium text-muted-foreground">Player Number</th>
                      <th className="text-right py-3 px-4 font-medium text-muted-foreground">Total XP</th>
                    </tr>
                  </thead>
                  <tbody>
                    {analytics.top_earners.map((earner, index) => (
                      <tr key={earner.player_id} className="border-b border-border/50 hover:bg-muted/50">
                        <td className="py-3 px-4 font-semibold text-foreground">#{index + 1}</td>
                        <td className="py-3 px-4 text-foreground">{earner.player_name}</td>
                        <td className="py-3 px-4 text-muted-foreground">{earner.player_number}</td>
                        <td className="py-3 px-4 text-right font-semibold text-foreground">{earner.total_xp}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Spending Patterns Section */}
        <div className="space-y-4">
          <h3 className="text-2xl font-semibold text-foreground">Spending Patterns</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Spending by Category Pie */}
            <Card>
              <CardHeader>
                <CardTitle>XP Spending by Category</CardTitle>
                <CardDescription>Distribution of XP expenditures</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={analytics.spending_by_category}
                      dataKey="total_xp"
                      nameKey="category"
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      label={(entry) => `${entry.category} (${entry.percentage}%)`}
                    >
                      {analytics.spending_by_category.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Average Spending Card */}
            <Card>
              <CardHeader>
                <CardTitle>Average XP Spending</CardTitle>
                <CardDescription>Per character statistics</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-6 bg-gradient-to-br from-purple-500/10 to-violet-600/5 rounded-lg">
                  <div className="text-4xl font-bold text-foreground mb-2">
                    {analytics.avg_xp_spent_per_character.toFixed(1)}
                  </div>
                  <p className="text-sm text-muted-foreground">XP spent per character</p>
                </div>
                
                <div className="space-y-2">
                  <h4 className="font-semibold text-foreground">Breakdown by Category</h4>
                  {analytics.spending_by_category.map((cat, index) => (
                    <div key={cat.category} className="flex justify-between items-center py-2 border-b border-border/50">
                      <span className="text-foreground flex items-center gap-2">
                        <div className="w-3 h-3 rounded-full" style={{ backgroundColor: COLORS[index % COLORS.length] }} />
                        {cat.category}
                      </span>
                      <span className="font-semibold text-foreground">{cat.total_xp} XP</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Earning Trends Section */}
        <div className="space-y-4">
          <h3 className="text-2xl font-semibold text-foreground">Earning Trends</h3>
          
          {/* Monthly XP Trend */}
          <Card>
            <CardHeader>
              <CardTitle>XP Distribution Over Time (Last 12 Months)</CardTitle>
              <CardDescription>Total XP distributed each month</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={analytics.monthly_xp_trend.slice().reverse()}>
                  <defs>
                    <linearGradient id="colorTotal" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorCandle" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ec4899" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#ec4899" stopOpacity={0.1}/>
                    </linearGradient>
                    <linearGradient id="colorEvent" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.8}/>
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.1}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="month" 
                    stroke="hsl(var(--muted-foreground))"
                  />
                  <YAxis stroke="hsl(var(--muted-foreground))" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'hsl(var(--card))', border: '1px solid hsl(var(--border))' }}
                    labelStyle={{ color: 'hsl(var(--foreground))' }}
                  />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="candle_xp" 
                    stroke="#ec4899" 
                    fillOpacity={1} 
                    fill="url(#colorCandle)" 
                    name="Candle XP"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="event_xp" 
                    stroke="#10b981" 
                    fillOpacity={1} 
                    fill="url(#colorEvent)" 
                    name="Event XP"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Average per Event */}
          <Card className="bg-gradient-to-br from-emerald-500/10 to-emerald-600/5">
            <CardHeader>
              <CardTitle>Average XP per Event</CardTitle>
              <CardDescription>Mean XP distributed across all events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground">
                {analytics.avg_xp_per_event.toFixed(1)} XP
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Candle Economy Section */}
        <div className="space-y-4">
          <h3 className="text-2xl font-semibold text-foreground">Candle Economy</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-br from-amber-500/10 to-amber-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Total Candles</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.candle_metrics.total_candles_purchased.toLocaleString()}</div>
                <p className="text-xs text-muted-foreground mt-1">all time purchases</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-orange-500/10 to-orange-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Avg per Purchase</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.candle_metrics.avg_candles_per_purchase.toFixed(0)}</div>
                <p className="text-xs text-muted-foreground mt-1">candles per transaction</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-yellow-500/10 to-yellow-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Players Who Bought</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.candle_metrics.players_who_purchased}</div>
                <p className="text-xs text-muted-foreground mt-1">unique players</p>
              </CardContent>
            </Card>
            
            <Card className="bg-gradient-to-br from-amber-500/10 to-yellow-600/5">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">Purchase Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-foreground">{analytics.candle_metrics.purchase_percentage}%</div>
                <p className="text-xs text-muted-foreground mt-1">of all players</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Footer Metadata */}
        <div className="text-center text-sm text-muted-foreground pt-6 border-t border-border">
          Last updated: {new Date(analytics.last_updated).toLocaleString()} • 
          {analytics.total_characters_analyzed} characters analyzed
        </div>
      </div>
    </AnalyticsLayout>
  );
}
