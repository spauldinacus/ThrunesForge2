import { useState, useEffect } from 'react';
import { useUserGuardContext } from 'app/auth';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Target, BookOpen, Loader2, ArrowLeft } from 'lucide-react';
import { apiClient } from 'app';
import { MilestoneCard } from 'components/MilestoneCard';
import { JournalEntryCard } from 'components/JournalEntryCard';
import { CustomMilestoneForm, type CustomMilestoneFormData } from 'components/CustomMilestoneForm';
import { JournalEntryForm, type JournalEntryFormData } from 'components/JournalEntryForm';
import { useToast } from '@/hooks/use-toast';
import {
  SystemMilestoneProgress,
  CustomMilestoneResponse,
  JournalEntryResponse,
  MyCharacter,
} from 'types';

export default function MyMilestones() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const { toast } = useToast();

  // State
  const [characters, setCharacters] = useState<MyCharacter[]>([]);
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('');
  const [systemMilestones, setSystemMilestones] = useState<SystemMilestoneProgress[]>([]);
  const [customMilestones, setCustomMilestones] = useState<CustomMilestoneResponse[]>([]);
  const [journalEntries, setJournalEntries] = useState<JournalEntryResponse[]>([]);
  const [loading, setLoading] = useState(true);

  // Form states
  const [milestoneFormOpen, setMilestoneFormOpen] = useState(false);
  const [journalFormOpen, setJournalFormOpen] = useState(false);
  const [editingMilestone, setEditingMilestone] = useState<CustomMilestoneResponse | null>(null);
  const [editingJournal, setEditingJournal] = useState<JournalEntryResponse | null>(null);
  const [editingSystemMilestoneId, setEditingSystemMilestoneId] = useState<string | null>(null);

  // Filter states
  const [milestoneFilter, setMilestoneFilter] = useState<string>('all'); // all, completed, incomplete
  const [milestoneCategoryFilter, setMilestoneCategoryFilter] = useState<string>('all');

  useEffect(() => {
    loadCharacters();
  }, []);

  useEffect(() => {
    if (selectedCharacterId) {
      loadCharacterData();
    }
  }, [selectedCharacterId]);

  const loadCharacters = async () => {
    try {
      const response = await apiClient.list_my_characters();
      const data = await response.json();
      setCharacters(data || []);
    } catch (error) {
      console.error('Failed to load characters:', error);
      toast({
        title: 'Error',
        description: 'Failed to load characters',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  const loadCharacterData = async () => {
    setLoading(true);
    try {
      // Load system milestones
      const systemResponse = await apiClient.get_character_system_milestones({ characterId: selectedCharacterId });
      if (systemResponse.ok) {
        const systemData = await systemResponse.json();
        setSystemMilestones(systemData);
      }

      // Load custom milestones
      const customResponse = await apiClient.get_character_custom_milestones({ characterId: selectedCharacterId });
      if (customResponse.ok) {
        const customData = await customResponse.json();
        setCustomMilestones(customData);
      }

      // Load journal entries
      const journalResponse = await apiClient.get_character_journal_entries({ characterId: selectedCharacterId });
      if (journalResponse.ok) {
        const journalData = await journalResponse.json();
        setJournalEntries(journalData);
      }
    } catch (error) {
      console.error('Failed to load character data:', error);
      toast({
        title: 'Error',
        description: 'Failed to load character data',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Custom Milestone Handlers
  const handleCreateCustomMilestone = async (data: CustomMilestoneFormData) => {
    try {
      const response = await apiClient.create_custom_milestone({
        character_id: selectedCharacterId,
        name: data.name,
        description: data.description,
        category: data.category,
        target_progress: data.targetProgress,
        notes: data.notes,
        shared_with_staff: data.sharedWithStaff,
      });

      if (response.ok) {
        toast({ title: 'Success', description: 'Custom milestone created' });
        setMilestoneFormOpen(false);
        loadCharacterData();
      } else {
        throw new Error('Failed to create milestone');
      }
    } catch (error) {
      console.error('Failed to create custom milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to create custom milestone',
        variant: 'destructive',
      });
    }
  };

  const handleUpdateCustomMilestone = async (data: CustomMilestoneFormData) => {
    if (!editingMilestone) return;

    try {
      const response = await apiClient.update_custom_milestone(
        { milestoneId: editingMilestone.id },
        {
          name: data.name,
          description: data.description,
          category: data.category,
          current_progress: data.currentProgress,
          target_progress: data.targetProgress,
          notes: data.notes,
          shared_with_staff: data.sharedWithStaff,
        }
      );

      if (response.ok) {
        toast({ title: 'Success', description: 'Milestone updated' });
        setMilestoneFormOpen(false);
        setEditingMilestone(null);
        loadCharacterData();
      } else {
        throw new Error('Failed to update milestone');
      }
    } catch (error) {
      console.error('Failed to update custom milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to update custom milestone',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteCustomMilestone = async (milestoneId: string) => {
    if (!window.confirm('Are you sure you want to delete this milestone?')) return;

    try {
      await apiClient.delete_custom_milestone({ milestoneId });
      toast.success('Milestone deleted successfully');
      loadCustomMilestones(selectedCharacterId!);
    } catch (error) {
      console.error('Failed to delete custom milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete custom milestone',
        variant: 'destructive',
      });
    }
  };

  const handleUpdateSystemMilestoneNotes = async (milestoneId: string, notes: string, shared: boolean) => {
    try {
      const response = await apiClient.update_system_milestone_notes({
        characterId: selectedCharacterId,
        systemMilestoneId: milestoneId,
        notes: notes,
        shared_with_staff: shared,
      });

      if (response.ok) {
        toast({ title: 'Success', description: 'Milestone updated' });
        setEditingSystemMilestoneId(null);
        loadCharacterData();
      } else {
        throw new Error('Failed to update milestone');
      }
    } catch (error) {
      console.error('Failed to update system milestone:', error);
      toast({
        title: 'Error',
        description: 'Failed to update milestone',
        variant: 'destructive',
      });
    }
  };

  const handleMarkSystemMilestoneComplete = async (milestoneId: string) => {
  try {
    const response = await apiClient.mark_system_milestone_complete({
      characterId: selectedCharacterId,
      systemMilestoneId: milestoneId,
    });

    if (response.ok) {
      toast({ title: 'Success', description: 'Milestone completion toggled' });
      loadCharacterData();
    } else {
      throw new Error('Failed to toggle milestone');
    }
  } catch (error) {
    console.error('Failed to mark milestone complete:', error);
    toast({
      title: 'Error',
      description: 'Failed to toggle milestone completion',
      variant: 'destructive',
    });
  }
};

  // Journal Handlers
  const handleCreateJournal = async (data: JournalEntryFormData) => {
    try {
      const response = await apiClient.create_journal_entry({
        character_id: selectedCharacterId,
        title: data.title,
        content: data.content,
        tags: data.tags,
        event_id: data.eventId,
        shared_with_staff: data.sharedWithStaff,
      });

      if (response.ok) {
        toast({ title: 'Success', description: 'Journal entry created' });
        setJournalFormOpen(false);
        loadCharacterData();
      } else {
        throw new Error('Failed to create journal entry');
      }
    } catch (error) {
      console.error('Failed to create journal entry:', error);
      toast({
        title: 'Error',
        description: 'Failed to create journal entry',
        variant: 'destructive',
      });
    }
  };

  const handleUpdateJournal = async (data: JournalEntryFormData) => {
    if (!editingJournal) return;

    try {
      const response = await apiClient.update_journal_entry(
        { entryId: editingJournal.id },
        {
          title: data.title,
          content: data.content,
          tags: data.tags,
          event_id: data.eventId,
          shared_with_staff: data.sharedWithStaff,
        }
      );

      if (response.ok) {
        toast({ title: 'Success', description: 'Journal entry updated' });
        setJournalFormOpen(false);
        setEditingJournal(null);
        loadCharacterData();
      } else {
        throw new Error('Failed to update journal entry');
      }
    } catch (error) {
      console.error('Failed to update journal entry:', error);
      toast({
        title: 'Error',
        description: 'Failed to update journal entry',
        variant: 'destructive',
      });
    }
  };

  const handleDeleteJournal = async (entryId: string) => {
    if (!window.confirm('Are you sure you want to delete this journal entry?')) return;

    try {
      await apiClient.delete_journal_entry({ entryId });
      toast.success('Journal entry deleted successfully');
      loadJournalEntries(selectedCharacterId!);
    } catch (error) {
      console.error('Failed to delete journal entry:', error);
      toast({
        title: 'Error',
        description: 'Failed to delete journal entry',
        variant: 'destructive',
      });
    }
  };

  const handleToggleJournalShare = async (entry: JournalEntryResponse) => {
    try {
      const response = await apiClient.update_journal_entry(
        { entryId: entry.id },
        { shared_with_staff: !entry.shared_with_staff }
      );

      if (response.ok) {
        toast({
          title: 'Success',
          description: entry.shared_with_staff ? 'Journal entry is now private' : 'Journal entry shared with staff',
        });
        loadCharacterData();
      } else {
        throw new Error('Failed to update journal entry');
      }
    } catch (error) {
      console.error('Failed to toggle journal share:', error);
      toast({
        title: 'Error',
        description: 'Failed to update journal entry',
        variant: 'destructive',
      });
    }
  };

  // Filter milestones
  const filteredSystemMilestones = systemMilestones.filter((m) => {
    if (milestoneFilter === 'completed' && !m.completed) return false;
    if (milestoneFilter === 'incomplete' && m.completed) return false;
    if (milestoneCategoryFilter !== 'all' && m.category !== milestoneCategoryFilter) return false;
    return true;
  });

  const filteredCustomMilestones = customMilestones.filter((m) => {
    if (milestoneFilter === 'completed' && !m.completed) return false;
    if (milestoneFilter === 'incomplete' && m.completed) return false;
    if (milestoneCategoryFilter !== 'all' && m.category !== milestoneCategoryFilter) return false;
    return true;
  });

  // Get unique categories
  const allCategories = [
    ...new Set([
      ...systemMilestones.map((m) => m.category),
      ...customMilestones.map((m) => m.category),
    ]),
  ];

  if (loading && characters.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-950 via-slate-900 to-black flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
      </div>
    );
  }

  if (characters.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-950 via-slate-900 to-black p-8">
        <div className="max-w-4xl mx-auto">
          <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl text-purple-100">No Characters Found</CardTitle>
              <CardDescription className="text-purple-300/70">
                You need to create a character before you can track milestones.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button onClick={() => (window.location.href = '/character-creator')}>
                Create Character
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          My Milestones & Journal
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                My Milestones & Journal
              </h1>
              <p className="text-muted-foreground mt-2">
                Track your character's journey, achievements, and stories.
              </p>
            </div>
          </div>

          {/* Character Selector */}
          <Card className="mb-6 border-purple-500/20 bg-black/40 backdrop-blur-sm">
            <CardContent className="pt-6">
              <div className="flex items-center gap-4">
                <label className="text-sm font-medium text-purple-200">Character:</label>
                <Select value={selectedCharacterId} onValueChange={setSelectedCharacterId}>
                  <SelectTrigger className="w-[300px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {characters.map((char) => (
                      <SelectItem key={char.id} value={char.id}>
                        {char.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs defaultValue="milestones" className="space-y-6">
            <TabsList className="grid w-full max-w-[400px] grid-cols-2">
              <TabsTrigger value="milestones" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Milestones
              </TabsTrigger>
              <TabsTrigger value="journal" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Journal
              </TabsTrigger>
            </TabsList>

            {/* Milestones Tab */}
            <TabsContent value="milestones" className="space-y-6">
              {/* Filters and Actions */}
              <div className="flex flex-wrap items-center gap-4">
                <Select value={milestoneFilter} onValueChange={setMilestoneFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Milestones</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="incomplete">In Progress</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={milestoneCategoryFilter} onValueChange={setMilestoneCategoryFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Categories" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    {allCategories.map((cat) => (
                      <SelectItem key={cat} value={cat}>
                        {cat.replace('_', ' ')}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Button
                  onClick={() => {
                    setEditingMilestone(null);
                    setMilestoneFormOpen(true);
                  }}
                  className="ml-auto"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Custom Milestone
                </Button>
              </div>

              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                </div>
              ) : (
                <div className="space-y-8">
                  {/* System Milestones */}
                  {filteredSystemMilestones.length > 0 && (
                    <div>
                      <h2 className="text-2xl font-semibold text-purple-100 mb-4">System Milestones</h2>
                      <div className="grid gap-4">
                        {filteredSystemMilestones.map((milestone) => (
                          <MilestoneCard
                            key={milestone.id}
                            name={milestone.name}
                            description={milestone.description}
                            category={milestone.category}
                            milestoneType={milestone.milestone_type}
                            currentProgress={milestone.current_progress}
                            targetProgress={milestone.threshold_value}
                            completed={milestone.completed}
                            notes={milestone.notes || undefined}
                            sharedWithStaff={milestone.shared_with_staff}
                            awardedBy={milestone.awarded_by_user_name}
                            onMarkComplete={milestone.milestone_type === 'other' ? () => handleMarkSystemMilestoneComplete(milestone.id) : undefined}
                            onAddNotes={() => {
                              const notes = prompt('Add notes for this milestone:', milestone.notes || '');
                              if (notes !== null) {
                                handleUpdateSystemMilestoneNotes(
                                  milestone.id,
                                  notes,
                                  milestone.shared_with_staff
                                );
                              }
                            }}
                            onToggleShare={() =>
                              handleUpdateSystemMilestoneNotes(
                                milestone.id,
                                milestone.notes || '',
                                !milestone.shared_with_staff
                              )
                            }
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Custom Milestones */}
                  {filteredCustomMilestones.length > 0 && (
                    <div>
                      <h2 className="text-2xl font-semibold text-purple-100 mb-4">Custom Milestones</h2>
                      <div className="grid gap-4">
                        {filteredCustomMilestones.map((milestone) => (
                          <MilestoneCard
                            key={milestone.id}
                            name={milestone.name}
                            description={milestone.description}
                            category={milestone.category}
                            currentProgress={milestone.current_progress}
                            targetProgress={milestone.target_progress}
                            completed={milestone.completed}
                            notes={milestone.notes || undefined}
                            sharedWithStaff={milestone.shared_with_staff}
                            isCustom
                            onEdit={() => {
                              setEditingMilestone(milestone);
                              setMilestoneFormOpen(true);
                            }}
                            onDelete={() => handleDeleteCustomMilestone(milestone.id)}
                          />
                        ))}
                      </div>
                    </div>
                  )}

                  {filteredSystemMilestones.length === 0 && filteredCustomMilestones.length === 0 && (
                    <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
                      <CardContent className="py-12 text-center">
                        <Target className="h-12 w-12 text-purple-400/50 mx-auto mb-4" />
                        <p className="text-purple-300/70">No milestones found with the selected filters.</p>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </TabsContent>

            {/* Journal Tab */}
            <TabsContent value="journal" className="space-y-6">
              <div className="flex justify-end">
                <Button
                  onClick={() => {
                    setEditingJournal(null);
                    setJournalFormOpen(true);
                  }}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  New Journal Entry
                </Button>
              </div>

              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                </div>
              ) : journalEntries.length > 0 ? (
                <div className="grid gap-4">
                  {journalEntries.map((entry) => (
                    <JournalEntryCard
                      key={entry.id}
                      title={entry.title}
                      content={entry.content}
                      tags={entry.tags}
                      eventTitle={entry.event_title || undefined}
                      sharedWithStaff={entry.shared_with_staff}
                      createdAt={entry.created_at}
                      onEdit={() => {
                        setEditingJournal(entry);
                        setJournalFormOpen(true);
                      }}
                      onDelete={() => handleDeleteJournal(entry.id)}
                      onToggleShare={() => handleToggleJournalShare(entry)}
                    />
                  ))}
                </div>
              ) : (
                <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
                  <CardContent className="py-12 text-center">
                    <BookOpen className="h-12 w-12 text-purple-400/50 mx-auto mb-4" />
                    <p className="text-purple-300/70 mb-4">No journal entries yet.</p>
                    <p className="text-sm text-purple-400/60">
                      Start documenting your character's journey and experiences.
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Forms */}
      <CustomMilestoneForm
        open={milestoneFormOpen}
        onOpenChange={(open) => {
          setMilestoneFormOpen(open);
          if (!open) setEditingMilestone(null);
        }}
        onSubmit={editingMilestone ? handleUpdateCustomMilestone : handleCreateCustomMilestone}
        initialData={
          editingMilestone
            ? {
                name: editingMilestone.name,
                description: editingMilestone.description,
                category: editingMilestone.category,
                targetProgress: editingMilestone.target_progress || undefined,
                currentProgress: editingMilestone.current_progress,
                notes: editingMilestone.notes || undefined,
                sharedWithStaff: editingMilestone.shared_with_staff,
              }
            : undefined
        }
        isEdit={!!editingMilestone}
      />

      <JournalEntryForm
        open={journalFormOpen}
        onOpenChange={(open) => {
          setJournalFormOpen(open);
          if (!open) setEditingJournal(null);
        }}
        onSubmit={editingJournal ? handleUpdateJournal : handleCreateJournal}
        initialData={
          editingJournal
            ? {
                title: editingJournal.title,
                content: editingJournal.content,
                tags: editingJournal.tags,
                eventId: editingJournal.event_id || undefined,
                sharedWithStaff: editingJournal.shared_with_staff,
              }
            : undefined
        }
        isEdit={!!editingJournal}
      />
    </div>
  );
}
