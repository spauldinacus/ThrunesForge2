


import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, BookOpen, MapPin, Users, Star, Loader2 } from "lucide-react";
import { apiClient } from "app";
import { toast } from "sonner";
import { ChapterListResponse } from "types";

export default function Chapters() {
  const navigate = useNavigate();
  const [chapters, setChapters] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadChapters = async () => {
      try {
        setLoading(true);
        const response = await apiClient.list_public_chapters();
        const data: ChapterListResponse = await response.json();
        setChapters(data.chapters || []);
      } catch (error) {
        console.error('Failed to load chapters:', error);
        toast.error('Failed to load chapters');
      } finally {
        setLoading(false);
      }
    };
    loadChapters();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="flex items-center space-x-3 text-purple-300">
          <Loader2 className="w-6 h-6 animate-spin" />
          <span>Loading chapters...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Navigation Header */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Chapters
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full bg-gradient-to-br from-indigo-500/20 to-purple-500/20">
              <BookOpen className="w-12 h-12 text-indigo-300" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400 mb-4">
            LARP Chapters
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Discover and join LARP chapters in your area. Each chapter offers unique settings, stories, and communities.
          </p>
        </div>

        {/* Chapters Grid */}
        {chapters.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-slate-400 text-lg">No chapters available at this time.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {chapters.map((chapter, index) => (
              <Card key={chapter.id} className="group cursor-pointer transition-all duration-300 hover:scale-105 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 backdrop-blur-sm border-indigo-500/30 hover:border-indigo-400/60 shadow-xl hover:shadow-2xl hover:shadow-indigo-500/20">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-white text-xl group-hover:text-indigo-200 transition-colors">
                        {chapter.name}
                      </CardTitle>
                      {chapter.location && (
                        <div className="flex items-center mt-2 text-slate-300 text-sm">
                          <MapPin className="w-4 h-4 mr-1 text-indigo-400" />
                          {chapter.location}
                        </div>
                      )}
                      {chapter.chapter_code && (
                        <div className="mt-1 text-slate-400 text-xs font-mono">
                          Chapter Code: {chapter.chapter_code}
                        </div>
                      )}
                    </div>
                    <Badge 
                      variant="secondary"
                      className="bg-green-600/20 text-green-300 border-green-500/30"
                    >
                      Active
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {chapter.description && (
                    <p className="text-slate-300 text-sm leading-relaxed">
                      {chapter.description}
                    </p>
                  )}
                  
                  {/* Member Count */}
                  <div className="flex items-center text-purple-300 text-sm">
                    <Users className="w-4 h-4 mr-2" />
                    <span>{chapter.member_count || 0} {chapter.member_count === 1 ? 'member' : 'members'}</span>
                  </div>
                  
                  <div className="flex justify-between items-center text-sm">
                    {chapter.contact_email && (
                      <div className="text-slate-300">
                        📧 <a 
                          href={`mailto:${chapter.contact_email}?subject=Interest in joining ${chapter.name}`}
                          className="hover:text-indigo-300 underline cursor-pointer"
                        >
                          {chapter.contact_email}
                        </a>
                      </div>
                    )}
                    {chapter.website && (
                      <div className="text-slate-300">
                        🌐 <a 
                          href={chapter.website.startsWith('http') ? chapter.website : `https://${chapter.website}`} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="hover:text-indigo-300 underline"
                        >
                          Website
                        </a>
                      </div>
                    )}
                  </div>
                  
                  <div className="text-slate-400 text-xs">
                    Established: {new Date(chapter.created_at).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/4 right-1/3 w-64 h-64 bg-indigo-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>
    </div>
  );
}
