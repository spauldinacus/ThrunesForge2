import React, { useState, useEffect } from 'react'; // Deploy Fix
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { apiClient } from 'app';
import type {
  CharacterDetail,
  HeritageResponse,
  CultureResponse,
  ArchetypeResponse,
  SkillResponse,
} from 'types';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  ArrowLeft, 
  Save, 
  AlertTriangle, 
  Skull, 
  Shield, 
  Plus, 
  Minus,
  RotateCcw,
  Heart,
  Zap
} from "lucide-react";
import { toast } from 'sonner';

// Import components from CharacterCreator pattern
import { useCharacterReferenceStore } from 'utils/characterReferenceStore';
import {
  SkillWithState,
  CharacterData,
  SkillSortMode
} from 'utils/characterTypes';
import {
  processSkillsWithState,
  sortSkillsByCategory,
  calculateSkillXPCost,
  findDependentSkills
} from 'utils/skillLogic';
import {
  calculateBodyStaminaXPCost,
  calculateTotalXPSpent
} from 'utils/xpCalculations';
import { SkillSelector } from 'components/SkillSelector';
import { StatManager } from 'components/StatManager';
import { XPSummary } from 'components/XPSummary';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

// Utility function for UUID validation
const isValidUUID = (str: string): boolean => {
  const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  return uuidRegex.test(str);
};

// Extended CharacterData interface for admin features
interface AdminCharacterData extends CharacterData {
  id?: string;
  player_name?: string;
  status?: string;
  secondary_archetype_id: '', // Use empty string instead of null
  tertiary_archetype_id: '',  // Use empty string instead of null
  corruption?: number;
  deaths?: number;
  xp_total?: number;
  xp_available?: number;
  xp_spent?: number;
  retired?: boolean;
  player_notes?: string;
  addictions_diseases?: string;
}

const AdminCharacterEditor = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const characterId = searchParams.get('id');

  // Character data state following CharacterCreator pattern
const [characterData, setCharacterData] = useState<AdminCharacterData>({
    id: '',
    name: '',
    player_profile_id: '',
    heritage_id: '',
    culture_id: '',
    archetype_id: '',
    secondary_archetype_id: null,
    tertiary_archetype_id: null,
    body: 10,
    stamina: 10,
    selected_skills: {},
    xp_total: 0,
    xp_spent: 0,
    xp_available: 0,
    player_notes: '',
    addictions_diseases: '',
    deaths: 0,
    corruption: 0,
    retired: false,
    first_name: '',
    last_name: '',
    player_number: '',
    events_attended: 0,
    heritage: { name: '', benefit_name: '', benefit: '', weakness_name: '', weakness: '' },
    culture: { name: '', benefit_name: '', benefit: '' }
  });
  
  // UI state following CharacterCreator pattern
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [canEditCore, setCanEditCore] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [skillSortMode, setSkillSortMode] = useState<SkillSortMode>('category');
  const [xpCalculating, setXpCalculating] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [originalCharacterData, setOriginalCharacterData] = useState<AdminCharacterData | null>(null);
  
  // XP tracking
  const [xpSpent, setXpSpent] = useState(0);
  const [xpAvailable, setXpAvailable] = useState(25);

  // Reference data from store (following CharacterCreator pattern)
  const {
    heritages,
    cultures,
    archetypes,
    skills: allSkills,
    setHeritages,
    setCultures,
    setArchetypes,
    setSkills,
    isDataFresh,
    heritagesLoaded,
    culturesLoaded,
    archetypesLoaded,
    skillsLoaded,
    setHeritagesLoaded,
    setCulturesLoaded,
    setArchetypesLoaded,
    setSkillsLoaded
  } = useCharacterReferenceStore();

  // Derived state using memoization (following CharacterCreator pattern)
  const selectedHeritage = React.useMemo(() => {
    return heritages?.find?.(h => h.id === characterData.heritage_id) || null;
  }, [heritages, characterData.heritage_id]);

  const selectedArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.archetype_id) || null;
  }, [archetypes, characterData.archetype_id]);

  const selectedSecondaryArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.secondary_archetype_id) || null;
  }, [archetypes, characterData.secondary_archetype_id]);

  const selectedTertiaryArchetype = React.useMemo(() => {
    return archetypes?.find?.(a => a.id === characterData.tertiary_archetype_id) || null;
  }, [archetypes, characterData.tertiary_archetype_id]);

  const filteredCultures = React.useMemo(() => {
    if (!cultures || !characterData.heritage_id) return [];
    return cultures.filter(culture => culture.heritage_id === characterData.heritage_id);
  }, [cultures, characterData.heritage_id]);

  // Real-time XP calculation functions - placed after all derived state
  const calculateSkillsXP = React.useCallback((selectedSkills: Record<string, number>): number => {
    if (!allSkills || !selectedArchetype || !selectedHeritage) return 0;
    
    let totalSkillsXP = 0;
    Object.entries(selectedSkills).forEach(([skillId, purchaseCount]) => {
      const skill = allSkills.find(s => s.id === skillId);
      if (skill && purchaseCount > 0) {
        for (let i = 1; i <= purchaseCount; i++) {
          totalSkillsXP += calculateSkillXPCost(skill, selectedArchetype, selectedHeritage, selectedSecondaryArchetype, selectedTertiaryArchetype);
        }
      }
    });
    
    return totalSkillsXP;
  }, [allSkills, selectedArchetype, selectedHeritage, selectedSecondaryArchetype, selectedTertiaryArchetype]);

  const calculateBodyXP = React.useCallback((currentBody: number): number => {
    if (!selectedHeritage) return 0;
    return calculateBodyStaminaXPCost(selectedHeritage.base_body, currentBody, selectedHeritage.base_body);
  }, [selectedHeritage]);

  const calculateStaminaXP = React.useCallback((currentStamina: number): number => {
    if (!selectedHeritage) return 0;
    return calculateBodyStaminaXPCost(selectedHeritage.base_stamina, currentStamina, selectedHeritage.base_stamina);
  }, [selectedHeritage]);

  const calculateArchetypeXP = React.useCallback((secondaryId?: string, tertiaryId?: string): number => {
    let archetypeXP = 0;
    if (secondaryId) archetypeXP += 50;
    if (tertiaryId) archetypeXP += 50;
    return archetypeXP;
  }, []);

  const calculateTotalSpentXP = React.useCallback((data?: Partial<AdminCharacterData>): number => {
    const currentData = { ...characterData, ...data };
    
    const skillsXP = calculateSkillsXP(currentData.selected_skills || {});
    const bodyXP = calculateBodyXP(currentData.body || 10);
    const staminaXP = calculateStaminaXP(currentData.stamina || 10);
    const archetypeXP = calculateArchetypeXP(currentData.secondary_archetype_id, currentData.tertiary_archetype_id);
    
    return skillsXP + bodyXP + staminaXP + archetypeXP;
  }, [characterData, calculateSkillsXP, calculateBodyXP, calculateStaminaXP, calculateArchetypeXP]);

  // Debounced XP calculation ref
  const debouncedXPUpdateRef = React.useRef<number>();

  // Process skills with state information using utility (following CharacterCreator pattern)
  const getSkillsWithCosts = React.useMemo((): SkillWithState[] => {
    const processedSkills = processSkillsWithState(
      allSkills || [],
      characterData.selected_skills,
      selectedArchetype,
      selectedHeritage,
      selectedSecondaryArchetype,
      selectedTertiaryArchetype,
      true  // Show hidden skills in admin editor
    );
    return sortSkillsByCategory(processedSkills);
  }, [allSkills, characterData.selected_skills, selectedArchetype, selectedHeritage, selectedSecondaryArchetype, selectedTertiaryArchetype]);

  const getSelectedSkills = React.useMemo((): SkillWithState[] => {
    return getSkillsWithCosts.filter(skill => {
      const purchaseCount = characterData.selected_skills[skill.id] || 0;
      return purchaseCount > 0;
    });
  }, [getSkillsWithCosts, characterData.selected_skills]);

  // Get sorted skills for the skill selector based on current sort mode
  const getSortedSkillsForSelector = React.useMemo((): SkillWithState[] => {
    const skills = getSkillsWithCosts;
    
    if (skillSortMode === 'alphabetical') {
      return [...skills].sort((a, b) => a.name.localeCompare(b.name));
    }
    
    // Category mode is the default (already sorted in getSkillsWithCosts)
    return skills;
  }, [getSkillsWithCosts, skillSortMode]);

  // Update XP calculations (following CharacterCreator pattern)
  const updateXPCalculations = React.useCallback((newData?: Partial<AdminCharacterData>) => {
    if (loading || !heritagesLoaded || !culturesLoaded || !archetypesLoaded) {
      return;
    }

    if (debouncedXPUpdateRef.current) {
      clearTimeout(debouncedXPUpdateRef.current);
    }
    
    setXpCalculating(true);
    
    debouncedXPUpdateRef.current = window.setTimeout(() => {
      const updatedCharacterData = { ...characterData, ...newData };
      
      // Use new real-time calculation functions instead of old utility
      const finalXPSpent = calculateTotalSpentXP(updatedCharacterData);
      const maxXP = updatedCharacterData.xp_total  || 25;
      
      setXpSpent(finalXPSpent);
      setXpAvailable(maxXP - finalXPSpent);
      setXpCalculating(false);
    }, 150);
  }, [loading, heritagesLoaded, culturesLoaded, archetypesLoaded, characterData, calculateTotalSpentXP]);

  // Handle heritage change (following CharacterCreator pattern)
  const handleHeritageChange = (heritageId: string) => {
    // Find the new heritage to get base stats
    const newHeritage = heritages?.find(h => h.id === heritageId);

    const newData = {
      ...characterData,
      heritage_id: heritageId,
      culture_id: '', // Reset culture when heritage changes
      // Reset body/stamina to new heritage base
      body: newHeritage ? newHeritage.base_body : 10,
      stamina: newHeritage ? newHeritage.base_stamina : 10
    };
    setCharacterData(newData);
    setHasUnsavedChanges(true);
    updateXPCalculations(newData);
  };

  // Handle stat changes (following CharacterCreator pattern)
  const handleStatChange = (stat: 'body' | 'stamina', increment: boolean) => {
    const currentValue = characterData[stat];
    const newValue = increment ? currentValue + 1 : currentValue - 1;
    
    const minValue = selectedHeritage ? 
      (stat === 'body' ? selectedHeritage.base_body : selectedHeritage.base_stamina) : 10;
    
    if (newValue < minValue || newValue > 100) {
      return;
    }
    
    const newData = {
      ...characterData,
      [stat]: newValue
    };
    
    setCharacterData(newData);
    setHasUnsavedChanges(true);
    updateXPCalculations(newData);
  };

  // Add skill purchase (following CharacterCreator pattern)
  const addSkillPurchase = (skill: SkillWithState) => {
    const currentCount = characterData.selected_skills[skill.id] || 0;
    
    if (currentCount >= skill.max_purchases) {
      toast.error(`Cannot purchase ${skill.name} more than ${skill.max_purchases} time(s)`);
      return;
    }
    
    const newCount = currentCount + 1;
    const newSelectedSkills = {
      ...characterData.selected_skills,
      [skill.id]: newCount
    };
    
    const newData = {
      ...characterData,
      selected_skills: newSelectedSkills
    };
    
    setCharacterData(newData);
    setHasUnsavedChanges(true);
    updateXPCalculations(newData);
  };

  // Remove skill purchase (following CharacterCreator pattern)
  const removeSkillPurchase = (skill: SkillWithState) => {
    const currentCount = characterData.selected_skills[skill.id] || 0;
    
    if (currentCount <= 0) {
      return;
    }
    
    const dependentSkills = findDependentSkills(skill.id, allSkills, characterData.selected_skills);
    
    const newSelectedSkills = { ...characterData.selected_skills };
    const removedSkills: string[] = [skill.name];
    
    const newCount = currentCount - 1;
    if (newCount <= 0) {
      delete newSelectedSkills[skill.id];
      
      for (const dependentSkill of dependentSkills) {
        if (newSelectedSkills[dependentSkill.id]) {
          delete newSelectedSkills[dependentSkill.id];
          removedSkills.push(dependentSkill.name);
        }
      }
    } else {
      newSelectedSkills[skill.id] = newCount;
    }
    
    const newData = {
      ...characterData,
      selected_skills: newSelectedSkills
    };
    
    setCharacterData(newData);
    setHasUnsavedChanges(true);
    updateXPCalculations(newData);
    
    if (removedSkills.length > 1) {
      toast.info(`Removed skills: ${removedSkills.join(', ')} (cascade effect)`);
    }
  };

  // Load character data
  const loadCharacterData = async () => {
    if (!characterId || !isValidUUID(characterId)) {
      setError('Invalid character ID provided');
      setLoading(false);
      return;
    }
    
    try {
      setLoading(true);
      setError(null);
      
      const characterResponse = await apiClient.get_admin_character({ characterId });
      
      if (!characterResponse.ok) {
        const status = characterResponse.status;
        let errorMessage = 'Failed to load character data';
        
        switch (status) {
          case 404:
            errorMessage = 'Character not found';
            break;
          case 403:
            errorMessage = 'Access denied';
            break;
          case 401:
            errorMessage = 'Authentication required';
            break;
          default:
            errorMessage = `Failed to load character data (Error ${status})`;
        }
        
        setError(errorMessage);
        return;
      }
      
      const characterData = await characterResponse.json();
      
      // Transform selected_skills from enriched array format to object format if needed
      if (characterData.selected_skills && Array.isArray(characterData.selected_skills)) {
        const skillsObject: Record<string, number> = {};
        characterData.selected_skills.forEach((skill: any) => {
          if (skill.skill_id) {
            // Count occurrences since enriched format duplicates entries instead of using quantity
            skillsObject[skill.skill_id] = (skillsObject[skill.skill_id] || 0) + 1;
          }
        });
        characterData.selected_skills = skillsObject;
      } else {
      }
      
      const loadedData = {
        ...characterData,
        player_name: `${characterData.first_name || ''} ${characterData.last_name || ''}`.trim()
      } as AdminCharacterData;
      
      setCharacterData(loadedData);
      setOriginalCharacterData(JSON.parse(JSON.stringify(loadedData))); // Deep copy for comparison during save
      
      // Load additional data if needed
      await Promise.all([
        !heritagesLoaded ? loadHeritages() : Promise.resolve(),
        !culturesLoaded ? loadCultures() : Promise.resolve(),
        !archetypesLoaded ? loadArchetypes() : Promise.resolve(),
        !skillsLoaded ? loadSkills() : Promise.resolve()
      ]);
      
    } catch (error) {
      console.error('Error loading character data:', error);
      setError('An unexpected error occurred while loading character data');
    } finally {
      setLoading(false);
    }
  };

  // Load supporting data functions
  const loadHeritages = async () => {
    try {
      const response = await apiClient.list_heritages();
      if (response.ok) {
        const data = await response.json();
        const heritagesArray = Array.isArray(data) ? data : data?.heritages || [];
        setHeritages(heritagesArray);
        setHeritagesLoaded(true);
      }
    } catch (error) {
      console.error('Error loading heritages:', error);
      setHeritages([]);
      setHeritagesLoaded(true);
    }
  };

  const loadCultures = async () => {
    try {
      const response = await apiClient.list_cultures({});
      if (response.ok) {
        const data: any = await response.json();
        const culturesArray = Array.isArray(data) ? data : data?.cultures || [];
        setCultures(culturesArray);
        setCulturesLoaded(true);
      }
    } catch (error) {
      console.error('Error loading cultures:', error);
      setCultures([]);
      setCulturesLoaded(true);
    }
  };

  const loadArchetypes = async () => {
    try {
      const response = await apiClient.list_archetypes();
      if (response.ok) {
        const data = await response.json();
        const archetypesArray = Array.isArray(data) ? data : data?.archetypes || [];
        setArchetypes(archetypesArray);
        setArchetypesLoaded(true);
      }
    } catch (error) {
      console.error('Error loading archetypes:', error);
      setArchetypes([]);
      setArchetypesLoaded(true);
    }
  };

  const loadSkills = async () => {
    try {
      // Force reload skills, bypassing cache for admin editor
      const response = await apiClient.list_skills({ show_hidden: true });
      if (response.ok) {
        const data = await response.json();
        const skillsArray = Array.isArray(data) ? data : data?.skills || [];
        console.log(`Loaded ${skillsArray.length} skills (including hidden/admin-only)`);
        setSkills(skillsArray);
        setSkillsLoaded(true);
      }
    } catch (error) {
      console.error('Error loading skills:', error);
      setSkills([]);
      setSkillsLoaded(true);
    }
  };

  // Handle save
  const handleSave = async () => {
    if (!characterData.id) {
      toast.error('No character data to save');
      return;
    }

    // Validate required core fields
    if (!characterData.heritage_id || !characterData.culture_id || !characterData.archetype_id) {
      toast.error('Heritage, Culture and Primary Archetype are required.');
      return;
    }

    try {
      setSaving(true);
      setError(null);

      // Convert selected_skills back to array format for the API
      const skillPurchases: Array<{skill_id: string, quantity: number}> = [];
      for (const [skillId, purchaseCount] of Object.entries(characterData.selected_skills)) {
        if (purchaseCount > 0) {
          skillPurchases.push({ skill_id: skillId, quantity: purchaseCount });
        }
      }

      // Build payload with only changed fields
      const updatePayload: any = {};

      // Helper to handle empty strings as null for optional UUID fields
      const sanitizeId = (id: string | null | undefined) => (!id || id === 'none' || id === '') ? null : id;
      
      if (originalCharacterData) {
        if (characterData.name !== originalCharacterData.name) updatePayload.name = characterData.name;
        
        // Core fields are required, so we don't sanitize to null, but we do check for changes
        if (characterData.heritage_id !== originalCharacterData.heritage_id) 
          updatePayload.heritage_id = characterData.heritage_id;
          
        if (characterData.culture_id !== originalCharacterData.culture_id) 
          updatePayload.culture_id = characterData.culture_id;
          
        if (characterData.archetype_id !== originalCharacterData.archetype_id) 
          updatePayload.archetype_id = characterData.archetype_id;
          
        // Optional fields can be sanitized to null
        if (characterData.secondary_archetype_id !== originalCharacterData.secondary_archetype_id) 
          updatePayload.secondary_archetype_id = sanitizeId(characterData.secondary_archetype_id);
          
        if (characterData.tertiary_archetype_id !== originalCharacterData.tertiary_archetype_id) 
          updatePayload.tertiary_archetype_id = sanitizeId(characterData.tertiary_archetype_id);

        if (characterData.body !== originalCharacterData.body) updatePayload.body = characterData.body;
        if (characterData.stamina !== originalCharacterData.stamina) updatePayload.stamina = characterData.stamina;
        if (characterData.corruption !== originalCharacterData.corruption) updatePayload.corruption = characterData.corruption ?? 0;
        if (characterData.deaths !== originalCharacterData.deaths) updatePayload.deaths = characterData.deaths ?? 0;
        if (characterData.status !== originalCharacterData.status) updatePayload.retired = characterData.status === 'Retired';
        if (characterData.player_notes !== originalCharacterData.player_notes) 
          updatePayload.player_notes = characterData.player_notes ?? null;
        if (characterData.addictions_diseases !== originalCharacterData.addictions_diseases) 
          updatePayload.addictions_diseases = characterData.addictions_diseases ?? null;
        
        // Only include skills if they changed
        if (JSON.stringify(characterData.selected_skills) !== JSON.stringify(originalCharacterData.selected_skills)) {
          updatePayload.selected_skills = skillPurchases;
        }
      }
      
      const response = await apiClient.update_admin_character(
        { characterId: characterData.id },
        updatePayload
      );
      if (!response.ok) {
        const errorData = await response.text();
        throw new Error(`Save failed: ${errorData}`);
      }

      setHasUnsavedChanges(false);
      toast.success('Character saved successfully!');
      navigate('/admin-characters');
    } catch (error) {
      console.error('Error saving character:', error);
      setError('Failed to save character. Please try again.');
      toast.error('Failed to save character');
    } finally {
      setSaving(false);
    }
  };

  // Handle rebuild character
  const handleRebuild = async () => {
    if (!characterData.id) return;

    if (!window.confirm("Are you sure you want to rebuild this character? This will remove ALL skills, reset stats to base, and remove secondary/tertiary archetypes. This cannot be undone.")) {
      return;
    }

    try {
      setSaving(true);
      const response = await apiClient.rebuild_character({ characterId: characterData.id });
      
      if (!response.ok) {
        throw new Error("Failed to rebuild character");
      }

      toast.success("Character reset successfully. You can now modify Heritage and Culture.");
      setCanEditCore(true);
      await loadCharacterData();
      
    } catch (error) {
      console.error('Error rebuilding character:', error);
      toast.error("Failed to rebuild character");
    } finally {
      setSaving(false);
    }
  };


  // Load data effect
  useEffect(() => {
    const loadData = async () => {
      try {
        const parallelPromises = [];
        
        // Admin editor ALWAYS reloads skills to ensure hidden skills are included
        // Other data can use cache if fresh
        const hasFreshCache = isDataFresh() && 
            heritages?.length > 0 && 
            cultures?.length > 0 && 
            archetypes?.length > 0;
        
        if (!hasFreshCache || !heritagesLoaded || !heritages?.length) {
          parallelPromises.push(loadHeritages());
        }
        if (!hasFreshCache || !culturesLoaded || !cultures?.length) {
          parallelPromises.push(loadCultures());
        }
        if (!hasFreshCache || !archetypesLoaded || !archetypes?.length) {
          parallelPromises.push(loadArchetypes());
        }
        
        // ALWAYS reload skills in admin mode to ensure hidden/admin-only skills are loaded
        parallelPromises.push(loadSkills());

        if (parallelPromises.length > 0) {
          await Promise.all(parallelPromises);
        }
      } catch (error) {
        console.error('Error loading reference data:', error);
      }
    };

    loadData();
  }, []);

  // Load character data effect
  useEffect(() => {
    if (characterId) {
      loadCharacterData();
    }
  }, [characterId]);

  // Trigger XP calculations when character data loads
  useEffect(() => {
    if (!loading && characterData.id && heritagesLoaded && culturesLoaded && archetypesLoaded && skillsLoaded) {
      updateXPCalculations();
    }
  }, [loading, characterData.id, heritagesLoaded, culturesLoaded, archetypesLoaded, skillsLoaded, updateXPCalculations]);

  // Update XP calculations when dependencies change
  useEffect(() => {
    if (!loading && heritagesLoaded && culturesLoaded && archetypesLoaded && skillsLoaded) {
      updateXPCalculations();
    }
  }, [characterData.secondary_archetype_id, characterData.tertiary_archetype_id, characterData.selected_skills, characterData.body, characterData.stamina, selectedArchetype?.id, selectedHeritage?.id]);

  // Early returns for loading and error states
  if (loading) {
    return (
      <div className="container mx-auto p-6">
        <div className="text-center">
          <div className="w-16 h-16 bg-purple-400/20 rounded-full mx-auto mb-4 animate-pulse" />
          <h2 className="text-xl text-purple-100">Loading Character Editor...</h2>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6">
        <Card className="bg-gray-800 border-red-500/30 max-w-md mx-auto">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Error Loading Character
            </CardTitle>
            <CardDescription className="text-gray-300">
              {error}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Button onClick={() => loadCharacterData()} className="bg-purple-600 hover:bg-purple-700">
                Try Again
              </Button>
              <Button variant="outline" onClick={() => navigate('/admin-characters')} className="border-purple-500/50 text-purple-400">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Characters
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button 
          variant="outline" 
          onClick={() => navigate('/admin-characters')}
          className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-purple-100">Edit Character</h1>
          <p className="text-purple-300">Admin Character Editor</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          {hasUnsavedChanges && (
            <Badge variant="outline" className="border-yellow-500 text-yellow-400">
              Unsaved Changes
            </Badge>
          )}
          <Button
            onClick={handleSave}
            disabled={saving || !hasUnsavedChanges}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <Save className="w-4 h-4 mr-2" />
            {saving ? 'Saving...' : 'Save Character'}
          </Button>
          
          <Button
            variant="destructive"
            onClick={handleRebuild}
            disabled={saving}
            className="bg-red-900/50 hover:bg-red-900 border border-red-500/50 text-red-100 ml-2"
          >
            <RotateCcw className="w-4 h-4 mr-2" />
            Rebuild
          </Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Character Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Basic Info */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Basic Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="name" className="text-purple-300">Character Name</Label>
                  <Input
                    id="name"
                    value={characterData.name}
                    onChange={(e) => {
                      setCharacterData({ ...characterData, name: e.target.value });
                      setHasUnsavedChanges(true);
                    }}
                    className="bg-slate-800/50 border-purple-500/30 text-purple-100 focus:border-purple-400"
                  />
                </div>
                <div>
                  <Label htmlFor="player_name" className="text-purple-300">Player Name</Label>
                  <Input
                    id="player_name"
                    value={(characterData as AdminCharacterData).player_name || ''}
                    onChange={(e) => {
                      setCharacterData({ ...characterData, player_name: e.target.value } as AdminCharacterData);
                      setHasUnsavedChanges(true);
                    }}
                    className="bg-slate-800/50 border-purple-500/30 text-purple-100 focus:border-purple-400"
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label className="text-purple-300">Heritage</Label>
                  <Select
                    value={characterData.heritage_id}
                    onValueChange={handleHeritageChange}
                    disabled={!canEditCore}
                  >
                    <SelectTrigger className={`bg-slate-800/50 border-purple-500/30 text-purple-100 ${canEditCore ? 'border-yellow-500/50' : ''}`}>
                      <SelectValue placeholder="Select heritage" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      {(heritages || []).map((heritage) => (
                        <SelectItem key={heritage.id} value={heritage.id} className="text-purple-100">
                          {heritage.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <Label className="text-purple-300">Culture</Label>
                  <Select
                    value={characterData.culture_id}
                    onValueChange={(value) => {
                      setCharacterData({ ...characterData, culture_id: value });
                      setHasUnsavedChanges(true);
                    }}
                    disabled={!canEditCore}
                  >
                    <SelectTrigger className={`bg-slate-800/50 border-purple-500/30 text-purple-100 ${canEditCore ? 'border-yellow-500/50' : ''}`}>
                      <SelectValue placeholder="Select culture" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      {filteredCultures.map((culture) => (
                        <SelectItem key={culture.id} value={culture.id} className="text-purple-100">
                          {culture.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-purple-300">Primary Archetype</Label>
                  <Select
                    value={characterData.archetype_id}
                    onValueChange={(value) => {
                      setCharacterData({ 
                        ...characterData, 
                        archetype_id: value,
                        secondary_archetype_id: (characterData.secondary_archetype_id === value ? '' : characterData.secondary_archetype_id) || '',
                        tertiary_archetype_id: (characterData.tertiary_archetype_id === value ? '' : characterData.tertiary_archetype_id) || ''
                      } as AdminCharacterData);
                      setHasUnsavedChanges(true);
                    }}
                  >
                    <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                      <SelectValue placeholder="Select archetype" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      {(archetypes || []).map((archetype) => (
                        <SelectItem key={archetype.id} value={archetype.id} className="text-purple-100">
                          {archetype.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Secondary and Tertiary Archetypes */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label className="text-purple-300">Secondary Archetype <span className="text-yellow-400 text-sm">(50 XP)</span></Label>
                  <Select
                    value={characterData.secondary_archetype_id || 'none'}
                    onValueChange={(value) => {
                      const newValue = value === 'none' ? '' : value;
                      setCharacterData({ 
                        ...characterData, 
                        secondary_archetype_id: newValue,
                        tertiary_archetype_id: characterData.tertiary_archetype_id === newValue ? '' : characterData.tertiary_archetype_id
                      });
                      setHasUnsavedChanges(true);
                    }}
                  >
                    <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                      <SelectValue placeholder="Select secondary archetype" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      <SelectItem value="none" className="text-purple-100">None</SelectItem>
                      {(archetypes || [])
                        .filter(archetype => archetype.id !== characterData.archetype_id)
                        .map((archetype) => (
                          <SelectItem key={archetype.id} value={archetype.id} className="text-purple-100">
                            {archetype.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label className="text-purple-300">Tertiary Archetype <span className="text-yellow-400 text-sm">(50 XP)</span></Label>
                  <Select
                    value={characterData.tertiary_archetype_id || 'none'}
                    onValueChange={(value) => {
                      const newValue = value === 'none' ? '' : value;
                      setCharacterData({ ...characterData, tertiary_archetype_id: newValue });
                      setHasUnsavedChanges(true);
                    }}
                  >
                    <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100">
                      <SelectValue placeholder="Select tertiary archetype" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      <SelectItem value="none" className="text-purple-100">None</SelectItem>
                      {(archetypes || [])
                        .filter(archetype => 
                          archetype.id !== characterData.archetype_id && 
                          archetype.id !== characterData.secondary_archetype_id
                        )
                        .map((archetype) => (
                          <SelectItem key={archetype.id} value={archetype.id} className="text-purple-100">
                            {archetype.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Admin Fields - Deaths, Corruption, Status */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Character Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <Label className="text-red-400 flex items-center">
                    <Skull className="w-4 h-4 mr-2" />
                    Deaths
                  </Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (characterData.deaths > 0) {
                          setCharacterData({ ...characterData, deaths: characterData.deaths - 1 });
                          setHasUnsavedChanges(true);
                        }
                      }}
                      disabled={characterData.deaths <= 0}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-lg font-bold text-purple-100 min-w-[3rem] text-center">
                      {characterData.deaths}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        setCharacterData({ ...characterData, deaths: characterData.deaths + 1 });
                        setHasUnsavedChanges(true);
                      }}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div>
                  <Label className="text-purple-400">Corruption</Label>
                  <div className="flex items-center gap-2 mt-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (characterData.corruption > 0) {
                          setCharacterData({ ...characterData, corruption: characterData.corruption - 1 });
                          setHasUnsavedChanges(true);
                        }
                      }}
                      disabled={characterData.corruption <= 0}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-lg font-bold text-purple-100 min-w-[3rem] text-center">
                      {characterData.corruption}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        if (characterData.corruption < 10) {
                          setCharacterData({ ...characterData, corruption: characterData.corruption + 1 });
                          setHasUnsavedChanges(true);
                        }
                      }}
                      disabled={characterData.corruption >= 10}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="text-xs text-purple-400 mt-1">Max: 10</div>
                </div>

                <div>
                  <Label className="text-green-400 flex items-center">
                    <Shield className="w-4 h-4 mr-2" />
                    Status
                  </Label>
                  <Select
                    value={characterData.status || 'Active'}
                    onValueChange={(value) => {
                      setCharacterData({ ...characterData, status: value });
                      setHasUnsavedChanges(true);
                    }}
                  >
                    <SelectTrigger className="bg-slate-800/50 border-purple-500/30 text-purple-100 mt-2">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-500/30">
                      <SelectItem value="Active" className="text-green-400">Active</SelectItem>
                      <SelectItem value="Retired" className="text-red-400">Retired</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Player Notes */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Player Notes</CardTitle>
              <CardDescription className="text-purple-300">
                Notes that will appear on the character sheet PDF
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={characterData.player_notes || ''}
                onChange={(e) => {
                  setCharacterData({ ...characterData, player_notes: e.target.value });
                  setHasUnsavedChanges(true);
                }}
                placeholder="Factions and other player notes needed."
                className="bg-slate-800/50 border-purple-500/30 text-purple-100 focus:border-purple-400 min-h-[120px]"
                rows={5}
              />
            </CardContent>
          </Card>
                    
          {/* Addictions & Diseases */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Addictions & Diseases</CardTitle>
              <CardDescription className="text-purple-300">
                Medical conditions and addictions affecting the character
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                value={characterData.addictions_diseases || ''}
                onChange={(e) => {
                  setCharacterData({ ...characterData, addictions_diseases: e.target.value });
                  setHasUnsavedChanges(true);
                }}
                placeholder="List any addictions or diseases the character has..."
                className="bg-slate-800/50 border-purple-500/30 text-purple-100 focus:border-purple-400 min-h-[120px]"
                rows={5}
              />
            </CardContent>
          </Card>
          
          {/* Stats */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-purple-100">Body & Stamina</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-6">
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-red-400 flex items-center">
                      <Heart className="w-4 h-4 mr-2" />
                      Body
                    </Label>
                    <div className="text-right text-sm">
                      <div className="text-yellow-400">
                        {selectedHeritage ? `Spent: ${calculateBodyStaminaXPCost(selectedHeritage.base_body, characterData.body, selectedHeritage.base_body)} XP` : 'Select heritage first'}
                      </div>
                      <div className="text-purple-300">
                        {selectedHeritage ? `Base: ${selectedHeritage.base_body}` : ''}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('body', false)}
                      disabled={!selectedHeritage || characterData.body <= (selectedHeritage?.base_body || 0)}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-2xl font-bold text-purple-100 min-w-[3rem] text-center">
                      {selectedHeritage ? characterData.body : '—'}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('body', true)}
                      disabled={!selectedHeritage || characterData.body >= 200}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <Label className="text-blue-400 flex items-center">
                      <Zap className="w-4 h-4 mr-2" />
                      Stamina
                    </Label>
                    <div className="text-right text-sm">
                      <div className="text-yellow-400">
                        {selectedHeritage ? `Spent: ${calculateBodyStaminaXPCost(selectedHeritage.base_stamina, characterData.stamina, selectedHeritage.base_stamina)} XP` : 'Select heritage first'}
                      </div>
                      <div className="text-purple-300">
                        {selectedHeritage ? `Base: ${selectedHeritage.base_stamina}` : ''}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('stamina', false)}
                      disabled={!selectedHeritage || characterData.stamina <= (selectedHeritage?.base_stamina || 0)}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                    <span className="text-2xl font-bold text-purple-100 min-w-[3rem] text-center">
                      {selectedHeritage ? characterData.stamina : '—'}
                    </span>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleStatChange('stamina', true)}
                      disabled={!selectedHeritage || characterData.stamina >= 200}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          {/* Skills */}
          <Card className="border-purple-500/20 bg-slate-900/50 backdrop-blur-sm">
            <CardHeader>
              <div className="flex justify-between items-center">
                <CardTitle className="text-purple-100">Skills ({getSelectedSkills.length})</CardTitle>
                <SkillSelector
                  skills={getSortedSkillsForSelector}
                  selectedSkills={characterData.selected_skills}
                  sortMode={skillSortMode}
                  onSortModeChange={setSkillSortMode}
                  onAddSkill={addSkillPurchase}
                  onRemoveSkill={removeSkillPurchase}
                  xpAvailable={xpAvailable}
                  xpCalculating={xpCalculating}
                  isLoading={loading}
                />
              </div>
            </CardHeader>
            <CardContent>
              {getSelectedSkills.length > 0 ? (
                <div className="space-y-2">
                  <div className="grid gap-2 max-h-48 overflow-y-auto">
                    {getSelectedSkills.map((skill) => {
                      const purchaseCount = characterData.selected_skills[skill.id] || 1;
                      return (
                        <div key={skill.id} className="flex justify-between items-center text-sm bg-slate-800/30 rounded p-2">
                          <div className="flex flex-col">
                            <span className="text-purple-200 font-medium">{skill.name}</span>
                            {purchaseCount > 1 && (
                              <span className="text-purple-400 text-xs">x{purchaseCount}</span>
                            )}
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge 
                              variant="secondary" 
                              className={`text-xs ${
                                skill.is_primary ? 'bg-green-600/20 text-green-300' :
                                skill.is_secondary ? 'bg-blue-600/20 text-blue-300' :
                                'bg-purple-600/20 text-purple-300'
                              }`}
                            >
                              {skill.xp_cost ?? 0} XP
                            </Badge>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-purple-400">
                  <p className="text-sm">No skills selected</p>
                  <p className="text-xs opacity-75">Use the + button above to add skills</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        
        {/* Right Column - XP Summary */}
        <div className="space-y-6">
          <XPSummary
            xpSpent={xpSpent}
            xpAvailable={xpAvailable}
            xpCalculating={xpCalculating}
            selectedSkills={getSelectedSkills.map(skill => ({
              ...skill,
              purchase_count: characterData.selected_skills[skill.id] || 0
            }))}
            totalEarnedXP={characterData.xp_total}
          />
        </div>
      </div>
    </div>
  );
};

export default AdminCharacterEditor;
