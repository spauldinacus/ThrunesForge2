import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, Edit, Trash2, Search, Filter, ExternalLink, ArrowLeft } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import LoreSubmissionForm from 'components/LoreSubmissionForm';
import {
  LoreSubmissionResponse,
  AdminEventResponse,
  ChapterResponse,
  CharacterListItem,
} from 'types';

export default function AdminLoreSubmissions() {
  const [submissions, setSubmissions] = useState<LoreSubmissionResponse[]>([]);
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();  
  const [filteredSubmissions, setFilteredSubmissions] = useState<LoreSubmissionResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [showCreateDialog, setShowCreateDialog] = useState(false);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [selectedSubmission, setSelectedSubmission] = useState<LoreSubmissionResponse | null>(null);
  const [deleting, setDeleting] = useState<string | null>(null);

  // Filter states
  const [searchTerm, setSearchTerm] = useState('');
  const [filterChapter, setFilterChapter] = useState<string>('all');
  const [filterEvent, setFilterEvent] = useState<string>('all');
  const [filterCharacter, setFilterCharacter] = useState<string>('all');

  // Data for filters
  const [chapters, setChapters] = useState<ChapterResponse[]>([]);
  const [events, setEvents] = useState<AdminEventResponse[]>([]);
  const [characters, setCharacters] = useState<CharacterListItem[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [submissions, searchTerm, filterChapter, filterEvent, filterCharacter]);

  // Check permissions on component mount
  useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.MANAGE_LORE_SUBMISSIONS)) {
      // Redirect to home if user doesn't have permission
      navigate('/');
      return;
    }
  }, [permissionsLoading, navigate]);
  
  const loadData = async () => {
    try {
      setLoading(true);
      const [submissionsRes, chaptersRes, eventsRes, charactersRes] = await Promise.all([
        apiClient.get_admin_lore_submissions({}),
        apiClient.list_scoped_chapters(),
        apiClient.list_scoped_events(),
        apiClient.list_scoped_characters(),
      ]);

      const submissionsData = await submissionsRes.json();
      const chaptersData = await chaptersRes.json();
      const eventsData = await eventsRes.json();
      const charactersData = await charactersRes.json();

      setSubmissions(submissionsData);
      setChapters(chaptersData.chapters || []);  // ✅ Extracts array from response
      setEvents(eventsData.events || []);
      setCharacters(charactersData);
    } catch (error) {
      console.error('Error loading lore submissions:', error);
      toast.error('Failed to load lore submissions');
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...submissions];

    // Search filter
    if (searchTerm) {
      filtered = filtered.filter(
        (sub) =>
        sub.character_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.lores_used.toLowerCase().includes(searchTerm.toLowerCase()) ||
        sub.outcome.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (sub.items_used || '').toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    // Chapter filter
    if (filterChapter !== 'all') {
      filtered = filtered.filter((sub) => sub.chapter_id === filterChapter);
    }

    // Event filter
    if (filterEvent !== 'all') {
      filtered = filtered.filter((sub) => sub.event_id === filterEvent);
    }

    // Character filter
    if (filterCharacter !== 'all') {
      filtered = filtered.filter((sub) => sub.character_id === filterCharacter);
    }

    setFilteredSubmissions(filtered);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this lore submission?')) {
      return;
    }

    setDeleting(id);
    try {
      await apiClient.delete_lore_submission({ submissionId: id });
      toast.success('Lore submission deleted successfully');
      loadData();
    } catch (error) {
      console.error('Error deleting lore submission:', error);
      toast.error('Failed to delete lore submission');
    } finally {
      setDeleting(null);
    }
  };

  const handleEdit = (submission: LoreSubmissionResponse) => {
    setSelectedSubmission(submission);
    setShowEditDialog(true);
  };

  const handleFormSuccess = () => {
    setShowCreateDialog(false);
    setShowEditDialog(false);
    setSelectedSubmission(null);
    loadData();
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const clearFilters = () => {
    setSearchTerm('');
    setFilterChapter('all');
    setFilterEvent('all');
    setFilterCharacter('all');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header with navigation */}
        <header className="relative z-10 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
          
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
            Lore Submissions
          </div>

          <Button
            onClick={() => setShowCreateDialog(true)}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            New Submission
          </Button>
        </header>

        {/* Filters */}
        <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-700/30 rounded-lg p-6 space-y-4">
          <div className="flex items-center gap-2 text-purple-200">
            <Filter className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Filters</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {/* Search */}
            <div className="lg:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-purple-400" />
                <Input
                  placeholder="Search submissions..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-purple-900/20 border-purple-700/50 text-purple-100"
                />
              </div>
            </div>

            {/* Chapter Filter */}
            <Select value={filterChapter} onValueChange={setFilterChapter}>
              <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
                <SelectValue placeholder="All Chapters" />
              </SelectTrigger>
              <SelectContent className="bg-purple-900 border-purple-700">
                <SelectItem value="all" className="text-purple-100">
                  All Chapters
                </SelectItem>
                {chapters.map((chapter) => (
                  <SelectItem key={chapter.id} value={chapter.id} className="text-purple-100">
                    {chapter.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Event Filter */}
            <Select value={filterEvent} onValueChange={setFilterEvent}>
              <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
                <SelectValue placeholder="All Events" />
              </SelectTrigger>
              <SelectContent className="bg-purple-900 border-purple-700">
                <SelectItem value="all" className="text-purple-100">
                  All Events
                </SelectItem>
                {events.map((event) => (
                  <SelectItem key={event.id} value={event.id} className="text-purple-100">
                    {event.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>

            {/* Character Filter */}
            <Select value={filterCharacter} onValueChange={setFilterCharacter}>
              <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
                <SelectValue placeholder="All Characters" />
              </SelectTrigger>
              <SelectContent className="bg-purple-900 border-purple-700">
                <SelectItem value="all" className="text-purple-100">
                  All Characters
                </SelectItem>
                {characters.map((character) => (
                  <SelectItem key={character.id} value={character.id} className="text-purple-100">
                    {character.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Clear Filters */}
          {(searchTerm || filterChapter !== 'all' || filterEvent !== 'all' || filterCharacter !== 'all') && (
            <Button
              variant="outline"
              onClick={clearFilters}
              size="sm"
              className="border-purple-700/50 text-purple-200 hover:bg-purple-900/20"
            >
              Clear Filters
            </Button>
          )}
        </div>

        {/* Results Count */}
        <div className="text-purple-300">
          Showing {filteredSubmissions.length} of {submissions.length} submission(s)
        </div>

        {/* Table */}
        <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-700/30 rounded-lg overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center p-12">
              <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
            </div>
          ) : filteredSubmissions.length === 0 ? (
            <div className="text-center p-12 text-purple-300">
              No lore submissions found
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-purple-700/30">
                    <TableHead className="text-purple-200">Date</TableHead>
                    <TableHead className="text-purple-200">Character</TableHead>
                    <TableHead className="text-purple-200">Chapter</TableHead>
                    <TableHead className="text-purple-200">Event</TableHead>
                    <TableHead className="text-purple-200">Lores Used</TableHead>
                    <TableHead className="text-purple-200">Items Used</TableHead>
                    <TableHead className="text-purple-200">Outcome</TableHead>
                    <TableHead className="text-purple-200">Link</TableHead>
                    <TableHead className="text-purple-200 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSubmissions.map((submission) => (
                    <TableRow key={submission.id} className="border-purple-700/30">
                      <TableCell className="text-purple-100">
                        {formatDate(submission.created_at)}
                      </TableCell>
                      <TableCell className="text-purple-100 font-medium">
                        {submission.character_name}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-blue-900/30 text-blue-200 border-blue-700/50">
                          {submission.chapter_name}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-purple-900/30 text-purple-200 border-purple-700/50">
                          {submission.event_name}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-purple-100 max-w-xs truncate">
                        {submission.lores_used}
                      </TableCell>
                      <TableCell className="text-purple-100 max-w-xs truncate">
                        {submission.items_used || '—'}
                      </TableCell>
                      <TableCell className="text-purple-100 max-w-md truncate">
                        {submission.outcome}
                      </TableCell>
                      <TableCell>
                        {submission.link && (
                          <a
                            href={submission.link}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-blue-400 hover:text-blue-300"
                          >
                            <ExternalLink className="w-4 h-4" />
                          </a>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleEdit(submission)}
                            className="border-purple-700/50 text-purple-200 hover:bg-purple-900/20"
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDelete(submission.id)}
                            disabled={deleting === submission.id}
                            className="border-red-700/50 text-red-300 hover:bg-red-900/20"
                          >
                            {deleting === submission.id ? (
                              <Loader2 className="w-4 h-4 animate-spin" />
                            ) : (
                              <Trash2 className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </div>
      </div>

      {/* Create Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="bg-gradient-to-br from-purple-900 to-blue-900 border-purple-700 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-purple-200">Create Lore Submission</DialogTitle>
            <DialogDescription className="text-purple-300">
              Log a new lore research request and its outcome
            </DialogDescription>
          </DialogHeader>
          <LoreSubmissionForm
            onSuccess={handleFormSuccess}
            onCancel={() => setShowCreateDialog(false)}
          />
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="bg-gradient-to-br from-purple-900 to-blue-900 border-purple-700 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl text-purple-200">Edit Lore Submission</DialogTitle>
            <DialogDescription className="text-purple-300">
              Update the lore submission details
            </DialogDescription>
          </DialogHeader>
          {selectedSubmission && (
            <LoreSubmissionForm
              onSuccess={handleFormSuccess}
              onCancel={() => {
                setShowEditDialog(false);
                setSelectedSubmission(null);
              }}
              existingSubmission={selectedSubmission}
            />
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
