import { useEffect, useState } from 'react';
import { apiClient } from 'app';
import type {
  ChapterHealthAnalytics,
  ChapterOverview,
  ChapterGrowthTrend,
  ChapterComparisonMetric,
  CrossChapterPlayer,
  ChapterOverlapFlow,
  ChapterConsistencyMetric,
} from 'types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { RefreshCw, Download, TrendingUp, TrendingDown, Minus, AlertTriangle, MapPin } from 'lucide-react';
import { BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from 'recharts';
import { AnalyticsLayout } from 'components/AnalyticsLayout';

const CHART_COLORS = {
  primary: '#8b5cf6',
  secondary: '#a78bfa',
  tertiary: '#c4b5fd',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
};

const STATUS_COLORS = {
  'Growing': '#10b981',
  'Stable': '#3b82f6',
  'Declining': '#ef4444',
  'Active': '#10b981',
  'Inactive': '#6b7280',
};

export default function AdminChapterHealth() {
  const [data, setData] = useState<ChapterHealthAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedChapter, setSelectedChapter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const params: any = {};
      if (selectedChapter !== 'all') {
        params.chapter_id = selectedChapter;
      }
      
      const response = await apiClient.get_chapter_health_analytics(params);
      const result = await response.json();
      setData(result);
    } catch (err) {
      setError('Failed to load chapter health analytics');
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [selectedChapter]);

  const exportToCSV = () => {
    if (!data) return;

    const csvData = [
      ['Chapter Health Analytics'],
      [''],
      ['Overview'],
      ['Total Chapters', data.total_chapters],
      ['Active Chapters', data.active_chapters],
      ['Inactive Chapters', data.inactive_chapters],
      [''],
      ['Chapter Details'],
      ['Chapter Name', 'Events Hosted', 'Avg Attendance', 'Unique Players', 'Last Event', 'Status'],
      ...data.chapter_list.map(ch => [
        ch.chapter_name,
        ch.events_hosted,
        ch.avg_attendance.toFixed(1),
        ch.unique_players,
        ch.last_event_date || 'Never',
        ch.status
      ]),
      [''],
      ['Cross-Chapter Activity'],
      ['Total Cross-Chapter Players', data.total_cross_chapter_players],
      ['Cross-Chapter Percentage', `${data.cross_chapter_percentage.toFixed(1)}%`],
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `chapter-health-analytics-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const getFilteredChapters = () => {
    if (!data) return [];
    if (statusFilter === 'all') return data.chapter_list;
    return data.chapter_list.filter(ch => ch.status === statusFilter);
  };

  const getStatusIcon = (status: string) => {
    if (status === 'Growing') return <TrendingUp className="w-4 h-4 text-green-400" />;
    if (status === 'Declining') return <TrendingDown className="w-4 h-4 text-red-400" />;
    return <Minus className="w-4 h-4 text-blue-400" />;
  };

  if (loading) {
    return (
      <AnalyticsLayout>
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground">Chapter Health</h1>
              <p className="text-muted-foreground mt-2">Chapter metrics, growth trends, and comparative analysis</p>
            </div>
          </div>
          <div className="grid gap-6 md:grid-cols-3">
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
            <Skeleton className="h-32" />
          </div>
        </div>
      </AnalyticsLayout>
    );
  }

  if (error || !data) {
    return (
      <AnalyticsLayout>
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error || 'No data available'}</AlertDescription>
        </Alert>
      </AnalyticsLayout>
    );
  }

  const filteredChapters = getFilteredChapters();

  return (
    <AnalyticsLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground">Chapter Health</h1>
            <p className="text-muted-foreground mt-2">Chapter metrics, growth trends, and comparative analysis</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={fetchData} variant="outline" size="sm">
              <RefreshCw className="w-4 h-4 mr-2" />
              Refresh
            </Button>
            <Button onClick={exportToCSV} variant="outline" size="sm">
              <Download className="w-4 h-4 mr-2" />
              Export CSV
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="bg-card/50 backdrop-blur border-purple-500/20">
          <CardContent className="pt-6">
            <div className="flex gap-4 flex-wrap">
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm text-muted-foreground mb-2 block">Chapter</label>
                <Select value={selectedChapter} onValueChange={setSelectedChapter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Chapters" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Chapters</SelectItem>
                    {data.chapter_list.map(ch => (
                      <SelectItem key={ch.chapter_id} value={ch.chapter_id}>
                        {ch.chapter_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex-1 min-w-[200px]">
                <label className="text-sm text-muted-foreground mb-2 block">Status Filter</label>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger>
                    <SelectValue placeholder="All Statuses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Statuses</SelectItem>
                    <SelectItem value="Growing">Growing</SelectItem>
                    <SelectItem value="Stable">Stable</SelectItem>
                    <SelectItem value="Declining">Declining</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Overview Cards */}
        <div className="grid gap-6 md:grid-cols-3">
          <Card className="bg-gradient-to-br from-purple-500/10 to-purple-500/5 border-purple-500/20">
            <CardHeader>
              <CardTitle className="text-lg">Total Chapters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-foreground">{data.total_chapters}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-500/10 to-green-500/5 border-green-500/20">
            <CardHeader>
              <CardTitle className="text-lg">Active Chapters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-green-400">{data.active_chapters}</div>
              <p className="text-sm text-muted-foreground mt-2">
                {((data.active_chapters / data.total_chapters) * 100).toFixed(1)}% of total
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-gray-500/10 to-gray-500/5 border-gray-500/20">
            <CardHeader>
              <CardTitle className="text-lg">Inactive Chapters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-4xl font-bold text-gray-400">{data.inactive_chapters}</div>
              {data.inactive_chapters > 0 && (
                <Alert variant="destructive" className="mt-2">
                  <AlertTriangle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    {data.inactive_chapters} chapter{data.inactive_chapters > 1 ? 's' : ''} need attention
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Chapter List Table */}
        <Card className="bg-card/50 backdrop-blur border-purple-500/20">
          <CardHeader>
            <CardTitle>All Chapters</CardTitle>
            <CardDescription>Overview of all chapter metrics and status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Chapter</th>
                    <th className="text-right p-3 text-sm font-medium text-muted-foreground">Events</th>
                    <th className="text-right p-3 text-sm font-medium text-muted-foreground">Avg Attendance</th>
                    <th className="text-right p-3 text-sm font-medium text-muted-foreground">Players</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Last Event</th>
                    <th className="text-left p-3 text-sm font-medium text-muted-foreground">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredChapters.map(chapter => (
                    <tr key={chapter.chapter_id} className="border-b border-border/50 hover:bg-accent/5">
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-purple-400" />
                          <span className="font-medium">{chapter.chapter_name}</span>
                        </div>
                      </td>
                      <td className="text-right p-3">{chapter.events_hosted}</td>
                      <td className="text-right p-3">{chapter.avg_attendance.toFixed(1)}</td>
                      <td className="text-right p-3">{chapter.unique_players}</td>
                      <td className="p-3 text-sm text-muted-foreground">
                        {chapter.last_event_date || 'Never'}
                      </td>
                      <td className="p-3">
                        <div className="flex items-center gap-2">
                          {getStatusIcon(chapter.status)}
                          <span className="text-sm" style={{ color: STATUS_COLORS[chapter.status as keyof typeof STATUS_COLORS] || '#6b7280' }}>
                            {chapter.status}
                          </span>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Growth Trends */}
        {data.growth_trends.length > 0 && (
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Player Growth Trends</CardTitle>
              <CardDescription>Player count by chapter over time</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={data.growth_trends}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                  <XAxis dataKey="month" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip
                    contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                    labelStyle={{ color: '#f3f4f6' }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="player_count"
                    stroke={CHART_COLORS.primary}
                    strokeWidth={2}
                    dot={{ fill: CHART_COLORS.primary }}
                    name="Player Count"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Chapter Comparisons */}
        {data.chapter_comparisons.length > 0 && (
          <>
            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Total Events by Chapter</CardTitle>
                <CardDescription>All-time event count per chapter</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.chapter_comparisons}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="chapter_name" stroke="#9ca3af" angle={-45} textAnchor="end" height={100} />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                    />
                    <Bar dataKey="total_events" fill={CHART_COLORS.primary} radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Average Attendance by Chapter</CardTitle>
                <CardDescription>Mean player attendance per event</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.chapter_comparisons}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="chapter_name" stroke="#9ca3af" angle={-45} textAnchor="end" height={100} />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                    />
                    <Bar dataKey="avg_attendance" fill={CHART_COLORS.secondary} radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="bg-card/50 backdrop-blur border-purple-500/20">
              <CardHeader>
                <CardTitle>Unique Players by Chapter</CardTitle>
                <CardDescription>Total unique players served</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.chapter_comparisons}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                    <XAxis dataKey="chapter_name" stroke="#9ca3af" angle={-45} textAnchor="end" height={100} />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip
                      contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px' }}
                    />
                    <Bar dataKey="unique_players" fill={CHART_COLORS.success} radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </>
        )}

        {/* Cross-Chapter Activity */}
        <div className="grid gap-6 md:grid-cols-2">
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Cross-Chapter Players</CardTitle>
              <CardDescription>Players attending multiple chapters</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="text-4xl font-bold text-purple-400">{data.total_cross_chapter_players}</div>
                  <p className="text-sm text-muted-foreground mt-1">
                    {data.cross_chapter_percentage.toFixed(1)}% of all players
                  </p>
                </div>
                {data.cross_chapter_players.length > 0 && (
                  <div className="mt-4">
                    <h4 className="text-sm font-medium mb-2">Top Multi-Chapter Players</h4>
                    <div className="space-y-2">
                      {data.cross_chapter_players.slice(0, 5).map(player => (
                        <div key={player.player_id} className="flex justify-between items-center p-2 bg-accent/5 rounded">
                          <span className="text-sm">{player.player_name}</span>
                          <span className="text-sm text-muted-foreground">{player.chapter_count} chapters</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Chapter Overlap Flows</CardTitle>
              <CardDescription>Player movement between chapters</CardDescription>
            </CardHeader>
            <CardContent>
              {data.chapter_overlap_flows.length > 0 ? (
                <div className="space-y-2">
                  {data.chapter_overlap_flows.slice(0, 10).map((flow, idx) => (
                    <div key={idx} className="flex items-center gap-2 p-2 bg-accent/5 rounded text-sm">
                      <span className="flex-1">{flow.from_chapter_name}</span>
                      <span className="text-purple-400">→</span>
                      <span className="flex-1">{flow.to_chapter_name}</span>
                      <span className="text-muted-foreground">{flow.player_count}</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No cross-chapter flows detected</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Consistency Metrics */}
        {data.consistency_metrics.length > 0 && (
          <Card className="bg-card/50 backdrop-blur border-purple-500/20">
            <CardHeader>
              <CardTitle>Event Consistency</CardTitle>
              <CardDescription>Chapter event scheduling patterns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="text-left p-3 text-sm font-medium text-muted-foreground">Chapter</th>
                      <th className="text-right p-3 text-sm font-medium text-muted-foreground">Events/Month</th>
                      <th className="text-right p-3 text-sm font-medium text-muted-foreground">Consistency Score</th>
                      <th className="text-right p-3 text-sm font-medium text-muted-foreground">Longest Gap (days)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {data.consistency_metrics.map(metric => (
                      <tr key={metric.chapter_id} className="border-b border-border/50 hover:bg-accent/5">
                        <td className="p-3">{metric.chapter_name}</td>
                        <td className="text-right p-3">{metric.events_per_month.toFixed(2)}</td>
                        <td className="text-right p-3">
                          <span className={metric.consistency_score >= 0.7 ? 'text-green-400' : metric.consistency_score >= 0.4 ? 'text-yellow-400' : 'text-red-400'}>
                            {(metric.consistency_score * 100).toFixed(0)}%
                          </span>
                        </td>
                        <td className="text-right p-3">{metric.longest_gap_days}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Last Updated */}
        <p className="text-sm text-muted-foreground text-center">
          Last updated: {new Date(data.last_updated).toLocaleString()}
        </p>
      </div>
    </AnalyticsLayout>
  );
}
