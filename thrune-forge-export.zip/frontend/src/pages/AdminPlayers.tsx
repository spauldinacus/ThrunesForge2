import React, { useState, useEffect } from 'react';
import { useUserGuardContext } from 'app/auth';
import { useNavigate } from 'react-router-dom';
import { apiClient } from 'app';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Separator } from '@/components/ui/separator';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Command, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { cn } from '@/lib/utils';
import { toast } from 'sonner';
import { Users, UserCog, Edit, Shield, User, Search, SortAsc, SortDesc, Filter, ArrowLeft, Trash2, Coins, ChevronsUpDown, Check, AlertTriangle } from 'lucide-react';
import type { 
  PlayerSummary, 
  PlayerDetailResponse, 
  Role, 
  UpdatePlayerRolesRequest,
  UpdatePlayerProfileRequest,
  ChapterPlayersGroup,
  Chapter
} from 'types';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';

interface CharacterSummary {
  id: string;
  name: string;
  heritage_name: string;
  culture_name: string;
  archetype_name: string;
  status: string;
}

const AdminPlayers: React.FC = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const { hasPermission, hasAnyPermission, loading: permissionsLoading } = usePermissions();
  
  const [players, setPlayers] = useState<PlayerSummary[]>([]);
  const [filteredPlayers, setFilteredPlayers] = useState<PlayerSummary[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlayer, setSelectedPlayer] = useState<PlayerDetailResponse | null>(null);
  const [editDialogOpen, setEditDialogOpen] = useState(false);
  const [roleDialogOpen, setRoleDialogOpen] = useState(false);
  const [profileDialogOpen, setProfileDialogOpen] = useState(false);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [playerToDelete, setPlayerToDelete] = useState<PlayerSummary | null>(null);
  
  const [assignedRoles, setAssignedRoles] = useState<{role_id: string, chapter_id?: string | null}[]>([]);
  
  const [roleChangeReason, setRoleChangeReason] = useState('');
  const [profileChanges, setProfileChanges] = useState<Partial<UpdatePlayerProfileRequest>>({});
  const [profileChangeReason, setProfileChangeReason] = useState('');
  const [candleDialogOpen, setCandleDialogOpen] = useState(false);
  const [candleHistory, setCandleHistory] = useState<any>(null);
  const [candleAmount, setCandleAmount] = useState<string>('');
  const [candleReason, setCandleReason] = useState('');
  const [loadingCandles, setLoadingCandles] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<any | null>(null);
  const [isConfirmingNegative, setIsConfirmingNegative] = useState(false);
  const [negativeTxDetails, setNegativeTxDetails] = useState<{ amount: number; reason: string } | null>(null);
  const [deleteTransactionDialogOpen, setDeleteTransactionDialogOpen] = useState(false);
  const [transactionToDelete, setTransactionToDelete] = useState<any | null>(null);
  const [transactionType, setTransactionType] = useState<string>('general');
  const [selectedCharacterId, setSelectedCharacterId] = useState<string | null>(null);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [playerCharacters, setPlayerCharacters] = useState<any[]>([]);
  const [characterEvents, setCharacterEvents] = useState<any[]>([]);
  const [loadingCharacterData, setLoadingCharacterData] = useState(false);
  const [playersForReferral, setPlayersForReferral] = useState<ChapterPlayersGroup[]>([]);
  const [referralSelectorOpen, setReferralSelectorOpen] = useState(false);
  const [referralSearchValue, setReferralSearchValue] = useState("");
  
  // Character dialog state
  const [characterDialogOpen, setCharacterDialogOpen] = useState(false);
  const [selectedPlayerCharacters, setSelectedPlayerCharacters] = useState<CharacterSummary[]>([]);
  const [loadingCharacters, setLoadingCharacters] = useState(false);
  const [viewingCharactersFor, setViewingCharactersFor] = useState<{name: string} | null>(null);

  // Filtering and sorting state
  const [searchTerm, setSearchTerm] = useState('');
  const [chapterFilter, setChapterFilter] = useState('all');
  const [sortField, setSortField] = useState<keyof PlayerSummary>('created_at');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

  // Check permissions and redirect if necessary
  useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
      navigate('/');
    }
  }, [permissionsLoading, navigate]);

  useEffect(() => {
    if (!permissionsLoading && hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
      loadData();
    }
  }, [permissionsLoading]);

  // Filter and sort players whenever data or filters change
  useEffect(() => {
    let filtered = players.filter(player => {
      // Search filter
      const searchMatch = searchTerm === '' || 
        `${player.first_name} ${player.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
        player.player_number.toLowerCase().includes(searchTerm.toLowerCase());
      
      // Chapter filter
      const chapterMatch = chapterFilter === 'all' || player.chapter_name === chapterFilter;
      
      return searchMatch && chapterMatch;
    });

    // Sort filtered results
    filtered.sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      // Handle special cases
      if (sortField === 'created_at') {
        aValue = new Date(a.created_at).getTime();
        bValue = new Date(b.created_at).getTime();
      } else if (sortField === 'character_count') {
        aValue = a.character_count;
        bValue = b.character_count;
      } else if (sortField === 'email') {
        // Handle null email values by treating them as empty strings
        aValue = (a.email || '').toLowerCase();
        bValue = (b.email || '').toLowerCase();
      } else if (typeof aValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }
      
      if (sortDirection === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    setFilteredPlayers(filtered);
  }, [players, searchTerm, chapterFilter, sortField, sortDirection]);

  const loadData = async () => {
    try {
      const [playersRes, rolesRes, chaptersRes] = await Promise.all([
        apiClient.list_all_players(),
        apiClient.list_all_roles(),
        apiClient.list_scoped_chapters()
      ]);
      
      const playersData = await playersRes.json();
      const rolesData = await rolesRes.json();
      const chaptersData = await chaptersRes.json();
      
      setPlayers(playersData);
      setFilteredPlayers(playersData);
      setRoles(rolesData.roles || []);
      setChapters(chaptersData.chapters || []);
      setLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load player data');
    }
  };

  const loadPlayerDetail = async (playerId: string) => {
    try {
      const response = await apiClient.get_player_detail({ playerId });
      const playerData = await response.json();
      setSelectedPlayer(playerData);
      // Map existing roles to the state structure
      // Note: playerData.roles is PlayerAssignedRole[] which has chapter_id
      setAssignedRoles(playerData.roles.map((role: any) => ({
        role_id: role.id,
        chapter_id: role.chapter_id || null
      })));
      return playerData;
    } catch (error) {
      console.error('Error loading player detail:', error);
      toast.error('Failed to load player details');
      return null;
    }
  };

  const handleEditRoles = async (playerId: string) => {
    const playerData = await loadPlayerDetail(playerId);
    if (playerData) {
      // Map existing roles to the state structure
      // Note: playerData.roles is PlayerAssignedRole[] which has chapter_id
      setAssignedRoles(playerData.roles.map((role: any) => ({
        role_id: role.id,
        chapter_id: role.chapter_id || null
      })));
      setRoleDialogOpen(true);
    }
  };

  const handleEditProfile = async (playerId: string) => {
    const playerData = await loadPlayerDetail(playerId);
    if (playerData) {
      setProfileChanges({
        first_name: playerData.first_name,
        last_name: playerData.last_name,
        phone_number: playerData.phone_number,
        emergency_contact_name: playerData.emergency_contact_name,
        emergency_contact_phone: playerData.emergency_contact_phone,
        chapter_id: playerData.chapter_id,
        player_number: playerData.player_number,
        referred_by_player_id: playerData.referred_by_player_id || undefined
        // Don't initialize reason here - it comes from profileChangeReason
      });
      
      // Load players for referral dropdown if not already acknowledged
      if (!playerData.referral_acknowledged) {
        loadPlayersForReferral();
      }
            
      setProfileDialogOpen(true);
    }
  };
    
  const loadPlayersForReferral = async () => {
    try {
      const response = await apiClient.list_players_for_referral();
      const data = await response.json();
      setPlayersForReferral(data.players || []);
    } catch (error) {
      console.error('Error loading players for referral:', error);
      toast.error('Failed to load players for referral selection');
    }
  };
  
  const saveRoleChanges = async () => {
    if (!selectedPlayer || !roleChangeReason.trim()) {
      toast.error('Please provide a reason for the role change');
      return;
    }

    try {
      // Create request with assignments
      const request = {
        assignments: assignedRoles,
        reason: roleChangeReason
      };

      // Call the endpoint with the new payload structure
      // Note: The generated client might need the object key "assignments" or similar depending on the contract
      // Based on inspection, the contract expects UpdatePlayerRolesRequest which has 'assignments' field
      await apiClient.update_player_roles(
        { playerId: selectedPlayer.id },
        request as any // Cast to any to bypass potential type mismatch if client not fully updated
      );

      toast.success('Player roles updated successfully');
      setRoleDialogOpen(false);
      setRoleChangeReason('');
      loadData(); // Refresh list to show updated roles
    } catch (error) {
      console.error('Error updating roles:', error);
      toast.error('Failed to update roles');
    }
  };

  const saveProfileChanges = async () => {
    if (!selectedPlayer || !profileChangeReason.trim()) {
      toast.error('Please provide a reason for the changes');
      return;
    }

    try {
      const response = await apiClient.update_player_profile(
        { playerId: selectedPlayer.id },
        {
          ...profileChanges,
          reason: profileChangeReason
        }
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ detail: 'Unknown error' }));
        console.error('Error updating profile:', errorData);
        toast.error(`Failed to update player profile: ${errorData.detail || 'Unknown error'}`);
        return;
      }

      toast.success('Player profile updated successfully');
      setProfileDialogOpen(false);
      setProfileChangeReason('');
      loadData();
    } catch (error) {
      console.error('Error updating profile:', error);
      toast.error('Failed to update player profile');
    }
  };

  const handleRoleToggle = (roleId: string, isChecked: boolean) => {
    if (isChecked) {
      // Add role with no chapter by default
      setAssignedRoles(prev => [...prev, { role_id: roleId, chapter_id: null }]);
    } else {
      // Remove role
      setAssignedRoles(prev => prev.filter(r => r.role_id !== roleId));
    }
  };

  const handleRoleChapterChange = (roleId: string, chapterId: string | null) => {
    setAssignedRoles(prev => prev.map(r => 
      r.role_id === roleId ? { ...r, chapter_id: chapterId === "global" ? null : chapterId } : r
    ));
  };

  const handleManageCandles = async (playerId: string) => {
    try {
      setLoadingCandles(true);
      const playerData = await loadPlayerDetail(playerId);
      const [historyResponse, charactersResponse] = await Promise.all([
        apiClient.get_player_candle_history({ playerId }),
        apiClient.list_player_characters({ playerId })
      ]);
      const historyData = await historyResponse.json();
      const charactersData = await charactersResponse.json();
      
      setCandleHistory(historyData);
      setPlayerCharacters(charactersData);
      setCandleDialogOpen(true);
    } catch (error) {
      console.error('Error loading candle data:', error);
      toast.error('Failed to load candle data');
    } finally {
      setLoadingCandles(false);
    }
  };
  
  const loadCharacterEvents = async (characterId: string) => {
    if (!characterId || !selectedPlayer) return;
    
    try {
      setLoadingCharacterData(true);
      const response = await apiClient.get_player_character_events({ 
        playerId: selectedPlayer.id, 
        characterId 
      });
      const data = await response.json();
      setCharacterEvents(data || []);
    } catch (error) {
      console.error('Error loading character events:', error);
      toast.error('Failed to load character events');
      setCharacterEvents([]);
    } finally {
      setLoadingCharacterData(false);
    }
  };
  
  const submitCandleTransaction = async (force: boolean = false) => {
    if (!selectedPlayer || !candleReason.trim() || candleAmount === '') {
      toast.error('Please fill in all fields');
      return;
    }
    
    const amount = parseInt(candleAmount);
    if (isNaN(amount) || amount === 0) {
      toast.error('Please enter a valid non-zero amount');
      return;
    }

    try {
      setLoadingCandles(true);
      
      // Refresh player data to get current candle balance
      const freshPlayerData = await loadPlayerDetail(selectedPlayer.id);
      if (!freshPlayerData) {
        toast.error('Failed to refresh player data');
        return;
      }
      
      if (editingTransaction) {
        // Update existing transaction
        await apiClient.update_candle_transaction(
          { playerId: freshPlayerData.id, transactionId: editingTransaction.id },
          { 
            amount, 
            reason: candleReason,
            transaction_type: transactionType,
            character_id: selectedCharacterId || undefined,
            event_id: selectedEventId || undefined
          }
        );
        toast.success('Transaction updated successfully');
      } else {
        // Create new transaction
        const response = await apiClient.create_candle_transaction(
          { 
            playerId: freshPlayerData.id,
            ...(force && { force: true })
          },
          { 
            amount, 
            reason: candleReason,
            transaction_type: transactionType,
            character_id: selectedCharacterId || undefined,
            event_id: selectedEventId || undefined
          }
        );
        
        const data = await response.json();
        
        // Check if transaction would cause negative balance
        if (!data.success && data.would_cause_negative && !force) {
          // Show confirmation dialog
          setNegativeTxDetails({ amount, reason: candleReason });
          setIsConfirmingNegative(true);
          return; // Don't proceed, wait for user confirmation
        }
        
        // Transaction succeeded
        if (data.success) {
          toast.success(`Successfully ${amount > 0 ? 'added' : 'removed'} ${Math.abs(amount)} candles`);
        } else {
          // Unexpected error from backend
          toast.error('Failed to create transaction');
          return;
        }
      }
      
      // Refresh candle history
      const historyResponse = await apiClient.get_player_candle_history({ playerId: freshPlayerData.id });
      const historyData = await historyResponse.json();
      setCandleHistory(historyData);
      
      // Reset form
      setCandleAmount('');
      setCandleReason('');
      setTransactionType('general');
      setSelectedCharacterId(null);
      setSelectedEventId(null);
      setCharacterEvents([]);
      setEditingTransaction(null);
      
      // Refresh player list to show updated balance
      loadData();
    } catch (error: any) {
      console.error('Error with candle transaction:', error);
      toast.error('Failed to process candle transaction');
    } finally {
      setLoadingCandles(false);
    }
  };

  const handleConfirmNegativeBalance = async () => {
    setIsConfirmingNegative(false);
    // Retry with force=true
    await submitCandleTransaction(true);
    setNegativeTxDetails(null);
  };

  const handleCancelNegativeBalance = () => {
    setIsConfirmingNegative(false);
    setNegativeTxDetails(null);
  };

  const handleEditCandleTransaction = (transaction: any) => {
    // Put form in edit mode with transaction data
    setCandleAmount(transaction.amount.toString());
    setCandleReason(transaction.reason);
    setTransactionType(transaction.transaction_type || 'general');
    setSelectedCharacterId(transaction.character_id || null);
    setSelectedEventId(transaction.event_id || null);
    setEditingTransaction(transaction);
    
    // Load events if character is selected
    if (transaction.character_id) {
      loadCharacterEvents(transaction.character_id);
    }
    
    toast.info('Edit the transaction details below and submit');
  };

  const handleCancelEdit = () => {
    setCandleAmount('');
    setCandleReason('');
    setTransactionType('general');
    setSelectedCharacterId(null);
    setSelectedEventId(null);
    setCharacterEvents([]);
    setEditingTransaction(null);
  };

  const handleViewCharacters = async (player: PlayerSummary) => {
    try {
      setViewingCharactersFor({ name: `${player.first_name} ${player.last_name}` });
      setCharacterDialogOpen(true);
      setLoadingCharacters(true);
      // Cast to any because the method is newly added and types might not be updated yet
      const response = await (apiClient as any).list_player_characters({ playerId: player.id });
      const data = await response.json();
      setSelectedPlayerCharacters(data);
    } catch (error) {
      console.error('Error loading characters:', error);
      toast.error('Failed to load characters');
    } finally {
      setLoadingCharacters(false);
    }
  };

  const handleDeleteCandleTransaction = (transaction: any) => {
    setTransactionToDelete(transaction);
    setDeleteTransactionDialogOpen(true);
  };
  
  const confirmDeleteCandleTransaction = async () => {
    if (!transactionToDelete || !selectedPlayer) return;
    
    try {
      await apiClient.delete_candle_transaction({
        playerId: selectedPlayer.id,
        transactionId: transactionToDelete.id
      });
      
      toast.success('Transaction deleted successfully');
      setDeleteTransactionDialogOpen(false);
      setTransactionToDelete(null);
      
      // Refresh candle history
      const response = await apiClient.get_player_candle_history({ playerId: selectedPlayer.id });
      const data = await response.json();
      setCandleHistory(data);
      
      // Refresh player list to show updated balance
      loadData();
    } catch (error: any) {
      console.error('Error deleting transaction:', error);
      const errorMessage = error?.body?.detail || 'Failed to delete transaction';
      toast.error(errorMessage);
    }
  };

  const handleSort = (field: keyof PlayerSummary) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: keyof PlayerSummary) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />;
  };

  const getUniqueChapters = () => {
    const chapters = [...new Set(players.map(p => p.chapter_name))];
    return chapters.sort();
  };

  const getRoleBadgeVariant = (roleName: string) => {
    if (roleName.includes('Super Admin')) return 'destructive';
    if (roleName.includes('Admin')) return 'default';
    if (roleName.includes('Coordinator')) return 'secondary';
    return 'outline';
  };

  const handleDeletePlayer = (player: PlayerSummary) => {
    setPlayerToDelete(player);
    setDeleteDialogOpen(true);
  };

const confirmDeletePlayer = async () => {
  if (!playerToDelete) return;
  
  try {
    await apiClient.delete_player({ playerId: playerToDelete.id });
    toast.success(`Player ${playerToDelete.first_name} ${playerToDelete.last_name} deleted successfully`);
    setDeleteDialogOpen(false);
    setPlayerToDelete(null);
    loadData(); // Refresh the player list
  } catch (error) {
    console.error('Error deleting player:', error);
    toast.error('Failed to delete player');
  }
};

  const handlePlayerNameClick = (playerId: string) => {
    // Navigate to player profile - this would need a proper route
    navigate(`/admin-player-profile/${playerId}`);
  };

  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-purple-400 text-lg">Verifying permissions...</div>
        </div>
      </div>
    );
  }

  // Block access if user doesn't have permission
  if (!hasPermission(PERMISSIONS.MANAGE_PLAYERS)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <Card className="bg-slate-900 border-red-500/20 max-w-md">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-300 mb-4">You don't have permission to manage players.</p>
            <Button 
              onClick={() => navigate('/')}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show loading state while data is being fetched
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
        <div className="flex items-center justify-center h-64">
          <div className="text-muted-foreground">Loading players...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - Player Management
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Player Management
              </h1>
              <p className="text-muted-foreground mt-2">
                Manage player profiles, roles, and permissions
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <Users className="h-8 w-8 text-purple-400" />
              <span className="text-2xl font-bold text-purple-400">{players.length}</span>
              <span className="text-muted-foreground">Players</span>
            </div>
          </div>

          {/* Search and Filter Controls */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-slate-800/30 rounded-lg border border-slate-700">
            <div className="space-y-2">
              <Label htmlFor="search" className="text-slate-200 flex items-center space-x-2">
                <Search className="h-4 w-4" />
                <span>Search</span>
              </Label>
              <Input
                id="search"
                placeholder="Search by name or player number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="bg-slate-800 border-slate-600 text-slate-200"
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-slate-200 flex items-center space-x-2">
                <Filter className="h-4 w-4" />
                <span>Chapter</span>
              </Label>
              <Select value={chapterFilter} onValueChange={setChapterFilter}>
                <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                  <SelectValue placeholder="All Chapters" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  <SelectItem value="all">All Chapters</SelectItem>
                  {getUniqueChapters().map(chapter => (
                    <SelectItem key={chapter} value={chapter}>{chapter}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
                   
            <div className="space-y-2">
              <Label className="text-slate-200">Results</Label>
              <div className="flex items-center space-x-2 text-slate-300">
                <Badge variant="outline" className="border-purple-500/50 text-purple-300">
                  {filteredPlayers.length} of {players.length}
                </Badge>
              </div>
            </div>
          </div>

          <Card className="bg-slate-900/50 border-purple-500/20">
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Shield className="h-5 w-5 text-purple-400" />
                <span>All Players</span>
              </CardTitle>
              <CardDescription>
                View and manage all registered players, their roles, and profiles
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border border-slate-700">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700 hover:bg-slate-800/50">
                      <TableHead 
                        className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                        onClick={() => handleSort('first_name')}
                      >
                        <div className="flex items-center space-x-1">
                          <span>Player</span>
                          {getSortIcon('first_name')}
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                        onClick={() => handleSort('email')}
                      >
                        <div className="flex items-center space-x-1">
                          <span>Email</span>
                          {getSortIcon('email')}
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                        onClick={() => handleSort('player_number')}
                      >
                        <div className="flex items-center space-x-1">
                          <span>Player Number</span>
                          {getSortIcon('player_number')}
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                        onClick={() => handleSort('chapter_name')}
                      >
                        <div className="flex items-center space-x-1">
                          <span>Chapter</span>
                          {getSortIcon('chapter_name')}
                        </div>
                      </TableHead>
                      <TableHead 
                        className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                        onClick={() => handleSort('character_count')}
                      >
                        <div className="flex items-center space-x-1">
                          <span>Characters</span>
                          {getSortIcon('character_count')}
                        </div>
                      </TableHead>
                      <TableHead className="text-purple-300">Roles</TableHead>
                      <TableHead className="text-purple-300">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPlayers.map((player) => (
                      <TableRow key={player.id} className="border-slate-700 hover:bg-slate-800/50">
                        <TableCell>
                          <div className="flex items-center space-x-3">
                            <div className="h-8 w-8 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                              <User className="h-4 w-4 text-white" />
                            </div>
                            <div>
                              <button
                                onClick={() => handlePlayerNameClick(player.id)}
                                className="font-medium text-slate-200 hover:text-purple-300 cursor-pointer transition-colors underline-offset-4 hover:underline text-left"
                              >
                                {player.first_name} {player.last_name}
                              </button>
                              <div className="text-sm text-muted-foreground">
                                Joined {new Date(player.created_at).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell className="text-slate-300">
                          {player.email || 'No email'}
                        </TableCell>
                        <TableCell className="font-mono text-slate-300">
                          {player.player_number}
                        </TableCell>
                        <TableCell className="text-slate-300">
                          {player.chapter_name}
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-blue-500/50 text-blue-300 cursor-pointer hover:bg-blue-500/10 transition-colors" onClick={() => handleViewCharacters(player)}>
                            {player.character_count}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {player.roles.length > 0 ? (
                              player.roles.map((roleName, index) => (
                                <Badge 
                                  key={index}
                                  variant={getRoleBadgeVariant(roleName)}
                                  className="text-xs"
                                >
                                  {roleName}
                                </Badge>
                              ))
                            ) : (
                              <Badge variant="outline" className="text-muted-foreground">
                                No roles
                              </Badge>
                            )}
                            {player.is_admin && (
                              <Badge variant="destructive" className="text-xs">
                                Legacy Admin
                              </Badge>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditRoles(player.id)}
                              className="border-purple-500/50 hover:bg-purple-500/10"
                            >
                              <UserCog className="h-4 w-4 mr-1" />
                              Roles
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleEditProfile(player.id)}
                              className="border-blue-500/50 hover:bg-blue-500/10"
                            >
                              <Edit className="h-4 w-4 mr-1" />
                              Profile
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedPlayer(player as any);
                                handleManageCandles(player.id);
                              }}
                              className="border-amber-500/50 hover:bg-amber-500/10 text-amber-300 hover:text-amber-200"
                            >
                              <Coins className="h-4 w-4 mr-1" />
                              Candles
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeletePlayer(player)}
                              className="border-red-500/50 hover:bg-red-500/10 text-red-300 hover:text-red-200"
                            >
                              <Trash2 className="h-4 w-4 mr-1" />
                              Delete
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          {/* Character List Dialog */}
          <Dialog open={characterDialogOpen} onOpenChange={setCharacterDialogOpen}>
            <DialogContent className="bg-slate-900 border-purple-500/20 max-w-3xl">
              <DialogHeader>
                <DialogTitle className="text-purple-300">
                  Characters - {viewingCharactersFor?.name}
                </DialogTitle>
                <DialogDescription>
                  List of characters belonging to this player.
                </DialogDescription>
              </DialogHeader>
              
              {loadingCharacters ? (
                 <div className="flex justify-center p-8">
                   <div className="text-muted-foreground">Loading characters...</div>
                 </div>
              ) : (
                <div className="rounded-md border border-slate-700">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-slate-700 hover:bg-slate-800/50">
                        <TableHead className="text-slate-300">Name</TableHead>
                        <TableHead className="text-slate-300">Heritage</TableHead>
                        <TableHead className="text-slate-300">Culture</TableHead>
                        <TableHead className="text-slate-300">Archetype</TableHead>
                        <TableHead className="text-slate-300">Status</TableHead>
                        <TableHead className="text-right text-slate-300">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedPlayerCharacters.length === 0 ? (
                        <TableRow>
                          <TableCell colSpan={6} className="text-center text-muted-foreground h-24">
                            No characters found
                          </TableCell>
                        </TableRow>
                      ) : (
                        selectedPlayerCharacters.map((char) => (
                          <TableRow key={char.id} className="border-slate-700 hover:bg-slate-800/50">
                            <TableCell className="font-medium text-slate-200">{char.name}</TableCell>
                            <TableCell className="text-slate-300">{char.heritage_name}</TableCell>
                            <TableCell className="text-slate-300">{char.culture_name}</TableCell>
                            <TableCell className="text-slate-300">{char.archetype_name}</TableCell>
                            <TableCell>
                              <Badge variant={char.status === 'Active' ? 'default' : 'secondary'} className="text-xs">
                                {char.status}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-right">
                              <Button 
                                size="sm" 
                                variant="ghost" 
                                onClick={() => navigate(`/admin-character-editor?id=${char.id}`)}
                                className="hover:text-purple-300 hover:bg-purple-500/10"
                              >
                                View / Edit
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))
                      )}
                    </TableBody>
                  </Table>
                </div>
              )}
            </DialogContent>
          </Dialog>

          {/* Role Edit Dialog */}
          <Dialog open={roleDialogOpen} onOpenChange={setRoleDialogOpen}>
            <DialogContent className="bg-slate-900 border-purple-500/20 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-purple-300">
                  Edit Roles - {selectedPlayer?.first_name} {selectedPlayer?.last_name}
                </DialogTitle>
                <DialogDescription>
                  Assign roles and permissions to this player. Roles can be global or scoped to a specific chapter.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid gap-4 max-h-96 overflow-y-auto pr-2">
                  {roles.map((role) => {
                    const isAssigned = assignedRoles.some(r => r.role_id === role.id);
                    const assignment = assignedRoles.find(r => r.role_id === role.id);
                    
                    return (
                    <div key={role.id} className="flex flex-col space-y-3 p-4 rounded-lg border border-slate-700 bg-slate-800/50">
                      <div className="flex items-start space-x-3">
                        <Checkbox
                          id={role.id}
                          checked={isAssigned}
                          onCheckedChange={(checked) => handleRoleToggle(role.id, checked === true)}
                          className="border-purple-500/50 data-[state=checked]:bg-purple-600 mt-1"
                        />
                        <div className="flex-1">
                          <Label htmlFor={role.id} className="text-slate-200 font-medium cursor-pointer">
                            {role.name}
                          </Label>
                          {role.description && (
                            <p className="text-sm text-muted-foreground mt-1">{role.description}</p>
                          )}
                          <div className="flex flex-wrap gap-1 mt-2">
                            {role.permissions.map((permission, index) => (
                              <Badge key={`${role.id}-${permission.id}-${index}`} variant="outline" className="text-xs border-slate-600">
                                {permission.name.replace('manage_', '').replace('_', ' ')}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      
                      {isAssigned && (
                        <div className="pl-7 w-full">
                          <Label className="text-xs text-slate-400 mb-1.5 block">Scope (Optional)</Label>
                          <Select 
                            value={assignment?.chapter_id || "global"} 
                            onValueChange={(val) => handleRoleChapterChange(role.id, val)}
                          >
                            <SelectTrigger className="bg-slate-900/50 border-slate-700 text-slate-200 h-8 text-sm w-full">
                              <SelectValue placeholder="Select Scope" />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-800 border-slate-700">
                              <SelectItem value="global" className="text-slate-300">Global (All Chapters)</SelectItem>
                              {chapters.map(chapter => (
                                <SelectItem key={chapter.id} value={chapter.id} className="text-slate-300">
                                  {chapter.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                    </div>
                  )})}
                </div>
                
                <Separator className="bg-slate-700" />
                
                <div className="space-y-2">
                  <Label htmlFor="role-reason" className="text-slate-200">
                    Reason for Role Change *
                  </Label>
                  <Textarea
                    id="role-reason"
                    placeholder="Explain why you are changing this player's roles..."
                    value={roleChangeReason}
                    onChange={(e) => setRoleChangeReason(e.target.value)}
                    className="bg-slate-800 border-slate-600 text-slate-200"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setRoleDialogOpen(false)}
                  className="border-slate-600"
                >
                  Cancel
                </Button>
                <Button
                  onClick={saveRoleChanges}
                  disabled={!roleChangeReason.trim()}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Save Changes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Profile Edit Dialog */}
          <Dialog open={profileDialogOpen} onOpenChange={setProfileDialogOpen}>
            <DialogContent className="bg-slate-900 border-purple-500/20 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-purple-300">
                  Edit Profile - {selectedPlayer?.first_name} {selectedPlayer?.last_name}
                </DialogTitle>
                <DialogDescription>
                  Edit player profile information including contact details and chapter assignment.
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="first-name" className="text-slate-200">First Name</Label>
                    <Input
                      id="first-name"
                      value={profileChanges.first_name || ''}
                      onChange={(e) => setProfileChanges(prev => ({...prev, first_name: e.target.value}))}
                      className="bg-slate-800 border-slate-600 text-slate-200"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="last-name" className="text-slate-200">Last Name</Label>
                    <Input
                      id="last-name"
                      value={profileChanges.last_name || ''}
                      onChange={(e) => setProfileChanges(prev => ({...prev, last_name: e.target.value}))}
                      className="bg-slate-800 border-slate-600 text-slate-200"
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="phone" className="text-slate-200">Phone Number</Label>
                  <Input
                    id="phone"
                    value={profileChanges.phone_number || ''}
                    onChange={(e) => setProfileChanges(prev => ({...prev, phone_number: e.target.value}))}
                    className="bg-slate-800 border-slate-600 text-slate-200"
                  />
                </div>
                
                <div className="space-y-2">
                  <Label className="text-purple-200">Home Chapter</Label>
                  <Select
                    value={profileChanges.chapter_id || ""}
                    onValueChange={(val) => setProfileChanges({ ...profileChanges, chapter_id: val })}
                  >
                    <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                      <SelectValue placeholder="Select Chapter" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      {chapters.map((chapter) => (
                        <SelectItem key={chapter.id} value={chapter.id} className="text-slate-300">
                          {chapter.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-2">
                  <Label className="text-purple-200 flex items-center gap-2">
                    Referred By
                    {selectedPlayer?.referral_acknowledged && (
                      <Badge variant="secondary" className="bg-green-500/20 text-green-300 text-xs">
                        Verified ✓
                      </Badge>
                    )}
                  </Label>
                  
                  {selectedPlayer?.referral_acknowledged ? (
                    <div className="flex items-center gap-2 p-3 rounded-lg bg-slate-800/50 border border-slate-700">
                      <Shield className="h-4 w-4 text-green-400" />
                      <span className="text-slate-300">
                        {selectedPlayer?.referred_by_player_name || 'Not specified'}
                        {selectedPlayer?.referred_by_player_number && ` (${selectedPlayer.referred_by_player_number})`}
                      </span>
                      <span className="text-xs text-slate-400 ml-auto">Locked - Already acknowledged</span>
                    </div>
                  ) : (
                    <Popover open={referralSelectorOpen} onOpenChange={setReferralSelectorOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          role="combobox"
                          aria-expanded={referralSelectorOpen}
                          className="w-full justify-between bg-slate-800 border-slate-600 text-slate-200 hover:bg-slate-700"
                        >
                          {profileChanges.referred_by_player_id
                            ? (() => {
                                const selected = (playersForReferral || [])
                                  .flatMap(group => group.players)
                                  .find(p => p.id === profileChanges.referred_by_player_id);
                                return selected ? `${selected.name} (${selected.player_number})` : 'Select player...';
                              })()
                            : 'Select player...'}
                          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-full p-0 bg-slate-900 border-purple-500/30" align="start">
                        <Command className="bg-transparent">
                          <CommandInput 
                            placeholder="Search players..."
                            className="bg-slate-800 border-slate-700 text-slate-200"
                            value={referralSearchValue}
                            onValueChange={setReferralSearchValue}
                          />
                          <CommandList>
                            <CommandEmpty className="text-slate-400 py-6 text-center text-sm">No players found.</CommandEmpty>
                            {playersForReferral && playersForReferral.length > 0 && playersForReferral
                              .filter(chapter => chapter?.players && Array.isArray(chapter.players) && chapter.players.length > 0)
                              .map(chapter => (
                              <CommandGroup key={chapter.chapter_id} heading={chapter.chapter_name} className="text-purple-300">
                                {chapter.players
                                  .filter(player => player.id !== selectedPlayer?.id)
                                  .map(player => (
                                  <CommandItem
                                    key={player.id}
                                    value={`${player.name} ${player.player_number}`}
                                    onSelect={() => {
                                      setProfileChanges({ ...profileChanges, referred_by_player_id: player.id });
                                      setReferralSelectorOpen(false);
                                    }}
                                    className="text-slate-300 hover:bg-purple-500/20"
                                  >
                                    {player.name} ({player.player_number})
                                  </CommandItem>
                                ))}
                              </CommandGroup>
                            ))}
                          </CommandList>
                        </Command>
                      </PopoverContent>
                    </Popover>
                  )}
                  
                  {!selectedPlayer?.referral_acknowledged && profileChanges.referred_by_player_id && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setProfileChanges({ ...profileChanges, referred_by_player_id: undefined })}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      Clear referral
                    </Button>
                  )}
                </div>
                
                <Separator className="bg-slate-700" />
                
                <div className="space-y-2">
                  <Label htmlFor="profile-reason" className="text-slate-200">
                    Reason for Profile Changes *
                  </Label>
                  <Textarea
                    id="profile-reason"
                    placeholder="Explain why you are changing this player's profile..."
                    value={profileChangeReason}
                    onChange={(e) => setProfileChangeReason(e.target.value)}
                    className="bg-slate-800 border-slate-600 text-slate-200"
                  />
                </div>
              </div>
              
              <DialogFooter>
                <Button
                  variant="outline"
                  onClick={() => setProfileDialogOpen(false)}
                  className="border-slate-600"
                >
                  Cancel
                </Button>
                <Button
                  onClick={saveProfileChanges}
                  disabled={!profileChangeReason.trim()}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Save Changes
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>

          {/* Delete Confirmation Dialog */}
          <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
            <DialogContent className="bg-slate-900 border-red-500/20 max-w-md">
              <DialogHeader>
                <DialogTitle className="text-red-300 flex items-center space-x-2">
                  <Trash2 className="h-5 w-5" />
                  <span>Delete Player</span>
                </DialogTitle>
                <DialogDescription>
                  Are you sure you want to delete this player? This action cannot be undone.
                </DialogDescription>
              </DialogHeader>
              
              {playerToDelete && (
                <div className="space-y-4">
                  <div className="p-4 rounded-lg border border-red-500/30 bg-red-500/10">
                    <div className="flex items-center space-x-3">
                      <div className="h-10 w-10 rounded-full bg-gradient-to-r from-purple-500 to-blue-500 flex items-center justify-center">
                        <User className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-medium text-slate-200">
                          {playerToDelete.first_name} {playerToDelete.last_name}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {playerToDelete.player_number} • {playerToDelete.chapter_name}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {playerToDelete.character_count} characters
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-sm text-red-300 font-medium">
                    ⚠️ This will permanently delete:
                  </div>
                  <ul className="text-sm text-muted-foreground space-y-1 ml-6">
                    <li>• Player profile and account data</li>
                    <li>• All associated characters ({playerToDelete.character_count})</li>
                    <li>• Role assignments and permissions</li>
                    <li>• Event attendance history</li>
                  </ul>
                </div>
              )}
              
              <DialogFooter className="space-x-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setDeleteDialogOpen(false);
                    setPlayerToDelete(null);
                  }}
                  className="border-slate-600"
                >
                  Cancel
                </Button>
                <Button
                  onClick={confirmDeletePlayer}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Confirm Delete
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        
          {/* Candle Management Dialog */}
          <Dialog open={candleDialogOpen} onOpenChange={setCandleDialogOpen}>
            <DialogContent className="bg-slate-900 border-amber-500/20 max-w-3xl max-h-[80vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-amber-300 flex items-center space-x-2">
                  <Coins className="h-5 w-5" />
                  <span>Manage Candles - {candleHistory?.player_name}</span>
                </DialogTitle>
                <DialogDescription>
                  View candle transaction history and add/remove candles
                </DialogDescription>
              </DialogHeader>
              
              {candleHistory && (
                <div className="space-y-6">
                  {/* Current Balance */}
                  <div className="p-4 rounded-lg border border-amber-500/30 bg-amber-500/10">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">Current Balance</span>
                      <div className="flex items-center space-x-2">
                        <Coins className="h-5 w-5 text-amber-400" />
                        <span className="text-2xl font-bold text-amber-300">
                          {candleHistory.current_balance}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <Separator className="bg-slate-700" />
                  
                  {/* Add Transaction Form */}
                  <div className="space-y-4 p-4 rounded-lg border border-slate-700 bg-slate-800/50">
                    {editingTransaction && (
                      <div className="flex items-center justify-between p-3 rounded-lg bg-blue-500/20 border border-blue-500/30">
                        <div className="flex items-center gap-2 text-blue-300">
                          <Edit className="h-4 w-4" />
                          <span className="text-sm font-medium">Editing Transaction</span>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={handleCancelEdit}
                          className="text-blue-300 hover:text-blue-200 h-7"
                        >
                          Cancel Edit
                        </Button>
                      </div>
                    )}
                    <h3 className="font-medium text-slate-200">{editingTransaction ? 'Edit Transaction' : 'New Transaction'}</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="candle-amount" className="text-slate-200">
                          Amount (+ to add, - to remove)
                        </Label>
                        <Input
                          id="candle-amount"
                          type="number"
                          placeholder="e.g., 10 or -5"
                          value={candleAmount}
                          onChange={(e) => setCandleAmount(e.target.value)}
                          className="bg-slate-800 border-slate-600 text-slate-200"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="transaction-type" className="text-slate-200">
                          Transaction Type
                        </Label>
                        <Select value={transactionType} onValueChange={setTransactionType}>
                          <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            <SelectItem value="general">General</SelectItem>
                            <SelectItem value="print/scroll">Print/Scroll</SelectItem>
                            <SelectItem value="attendance">Attendance</SelectItem>
                            <SelectItem value="candle purchase">Candle Purchase</SelectItem>
                            <SelectItem value="donation">Donation</SelectItem>
                            <SelectItem value="transfer">Transfer</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="character-select" className="text-slate-200">
                          Character (Optional)
                        </Label>
                        <Select 
                          value={selectedCharacterId || 'none'} 
                          onValueChange={(val) => {
                            const charId = val === 'none' ? null : val;
                            setSelectedCharacterId(charId);
                            setSelectedEventId(null);
                            setCharacterEvents([]);
                            if (charId) {
                              loadCharacterEvents(charId);
                            }
                          }}
                        >
                          <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                            <SelectValue placeholder="None" />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            <SelectItem value="none">None</SelectItem>
                            {playerCharacters.map((char) => (
                              <SelectItem key={char.id} value={char.id}>
                                {char.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="event-select" className="text-slate-200">
                          Event (Optional)
                        </Label>
                        <Select 
                          value={selectedEventId || 'none'} 
                          onValueChange={(val) => setSelectedEventId(val === 'none' ? null : val)}
                          disabled={!selectedCharacterId || loadingCharacterData}
                        >
                          <SelectTrigger className="bg-slate-800 border-slate-600 text-slate-200">
                            <SelectValue placeholder={selectedCharacterId ? (loadingCharacterData ? "Loading..." : "None") : "Select character first"} />
                          </SelectTrigger>
                          <SelectContent className="bg-slate-800 border-slate-600">
                            <SelectItem value="none">None</SelectItem>
                            {characterEvents.map((event) => (
                              <SelectItem key={event.id} value={event.id}>
                                {event.name} ({new Date(event.event_date).toLocaleDateString()})
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="candle-reason" className="text-slate-200">
                        Reason *
                      </Label>
                      <Textarea
                        id="candle-reason"
                        placeholder="Explain why candles are being added or removed..."
                        value={candleReason}
                        onChange={(e) => setCandleReason(e.target.value)}
                        className="bg-slate-800 border-slate-600 text-slate-200"
                      />
                    </div>
                    <Button
                      onClick={submitCandleTransaction}
                      disabled={loadingCandles || !candleAmount || !candleReason.trim()}
                      className="bg-amber-600 hover:bg-amber-700 w-full"
                    >
                      {loadingCandles ? 'Processing...' : editingTransaction ? 'Update Transaction' : 'Submit Transaction'}
                    </Button>
                  </div>
                  
                  <Separator className="bg-slate-700" />
                  
                  {/* Transaction History */}
                  <div className="space-y-3">
                    <h3 className="font-medium text-slate-200">Transaction History</h3>
                    {candleHistory.transactions.length > 0 ? (
                      <div className="space-y-2 max-h-96 overflow-y-auto">
                        {candleHistory.transactions.map((transaction: any) => (
                          <div key={transaction.id} className="p-4 rounded-lg border border-slate-700 bg-slate-800/50">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="flex items-center gap-3">
                                  <Badge variant={transaction.amount > 0 ? 'default' : 'destructive'}>
                                    {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                                  </Badge>
                                  <div>
                                    <div className="font-medium text-white">{transaction.reason}</div>
                                    <div className="text-xs text-muted-foreground">
                                      {transaction.granted_by_name} • {new Date(transaction.created_at).toLocaleString()}
                                    </div>
                                    {transaction.transaction_type && transaction.transaction_type !== 'general' && (
                                      <Badge variant="outline" className="text-xs mt-1">
                                        {transaction.transaction_type}
                                      </Badge>
                                    )}
                                    {transaction.character_name && (
                                      <div className="text-xs text-purple-300 mt-1">
                                        Character: {transaction.character_name}
                                      </div>
                                    )}
                                    {transaction.event_name && (
                                      <div className="text-xs text-blue-300 mt-1">
                                        Event: {transaction.event_name}
                                      </div>
                                    )}
                                  </div>
                                </div>
                              </div>
                              {/* ADD THESE BUTTONS */}
                              <div className="flex items-center gap-2 ml-4">
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleEditCandleTransaction(transaction)}
                                  className="h-8 w-8 p-0"
                                >
                                  <Edit className="h-4 w-4" />
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  onClick={() => handleDeleteCandleTransaction(transaction)}
                                  className="h-8 w-8 p-0 text-red-400 hover:text-red-300"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="text-center text-muted-foreground py-8">
                        No transaction history
                      </div>
                    )}
                  </div>
                </div>
              )}
              
              <DialogFooter>
                <Button
                  variant="outline"
                   onClick={() => {
                     setCandleDialogOpen(false);
                     setCandleHistory(null);
                     setCandleAmount('');
                     setCandleReason('');
                     setTransactionType('general');
                     setSelectedCharacterId(null);
                     setSelectedEventId(null);
                     setCharacterEvents([]);
                     setEditingTransaction(null);
                   }}
                  className="border-slate-600"
                >
                  Close
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
          
          {/* Delete Candle Transaction Confirmation Dialog */}
          <Dialog open={deleteTransactionDialogOpen} onOpenChange={setDeleteTransactionDialogOpen}>
            <DialogContent className="bg-slate-900 border-red-500/20 max-w-md">
              <DialogHeader>
                <DialogTitle className="text-red-300 flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5" />
                  Delete Transaction
                </DialogTitle>
                <DialogDescription>
                  Are you sure you want to delete this candle transaction? This action cannot be undone.
                </DialogDescription>
              </DialogHeader>
              
              {transactionToDelete && (
                <div className="space-y-4">
                  <div className="p-4 rounded-lg border border-slate-700 bg-slate-800/50">
                    <div className="flex items-center gap-3">
                      <Badge variant={transactionToDelete.amount > 0 ? 'default' : 'destructive'}>
                        {transactionToDelete.amount > 0 ? '+' : ''}{transactionToDelete.amount}
                      </Badge>
                      <div>
                        <div className="font-medium text-white">{transactionToDelete.reason}</div>
                        <div className="text-xs text-muted-foreground">
                          {transactionToDelete.granted_by_name} • {new Date(transactionToDelete.created_at).toLocaleString()}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}
              
              <DialogFooter className="space-x-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setDeleteTransactionDialogOpen(false);
                    setTransactionToDelete(null);
                  }}
                  className="border-slate-600"
                >
                  Cancel
                </Button>
                <Button
                  onClick={confirmDeleteCandleTransaction}
                  className="bg-red-600 hover:bg-red-700 text-white"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Transaction
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        
      </main>
      
      {/* Background decorative elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
    </div>
  );
};

export default AdminPlayers;
