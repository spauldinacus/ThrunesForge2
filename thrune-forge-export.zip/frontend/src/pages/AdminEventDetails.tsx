import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { apiClient } from 'app';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { ArrowLeft, Calendar, MapPin, Users, UserCheck, UserX, UserPlus, Download, Edit, Plus, FileText } from 'lucide-react';
import type { 
  EventResponse, 
  AttendeeInfo, 
  EventAttendanceResponse, 
  AdminCharacterListItem,
  UpdateAttendanceRequest 
} from 'types';
import { formatDateTimeForDisplay } from 'utils/timezone';

const AdminEventDetails = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const eventId = searchParams.get('eventId');
  const { user } = useUserGuardContext();
  
  const [eventData, setEventData] = useState<EventAttendanceResponse | null>(null);
  const [allCharacters, setAllCharacters] = useState<AdminCharacterListItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState('');
  const [selectedAttendees, setSelectedAttendees] = useState<Set<string>>(new Set());
  const [editingXP, setEditingXP] = useState<{ [key: string]: { ticketXp: number; candleXp: number } }>({});
  const [showAddRSVP, setShowAddRSVP] = useState(false);
  const [selectedCharacterId, setSelectedCharacterId] = useState('');
  const [manualRSVPData, setManualRSVPData] = useState({
    ticket_xp: 0,
    candle_xp: 0,
    notes: '',
    attendance_status: 'rsvp' as 'rsvp' | 'attended' | 'no_show'
  });
  const [viewingNotesAttendee, setViewingNotesAttendee] = useState<AttendeeInfo | null>(null);
  const [noteEditValue, setNoteEditValue] = useState('');
    const [exportProgress, setExportProgress] = useState<{
    show: boolean;
    eventName: string;
    totalCharacters: number;
    progress: number;
    status: string;
  }>({ show: false, eventName: '', totalCharacters: 0, progress: 0, status: '' });

  useEffect(() => {
    if (!eventId) {
      navigate('/manage-events');
      return;
    }
    loadEventData();
  }, [eventId]);

  const loadEventData = async () => {
    if (!eventId) return;
    
    setIsLoading(true);
    try {
      const response = await apiClient.get_event_attendees({ eventId });
      const data = await response.json();
      setEventData(data);
      
      // Load all characters for manual RSVP
      const charactersResponse = await apiClient.list_all_characters();
      const charactersData = await charactersResponse.json();
      setAllCharacters(charactersData.characters);
    } catch (error) {
      console.error('Failed to load event data:', error);
      toast.error('Failed to load event data');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAttendanceUpdate = async (
    rsvpId: string, 
    newStatus: 'rsvp' | 'attended' | 'no_show',
    ticketXp?: number,
    candleXp?: number,
    notes?: string
  ) => {
    setIsUpdating(rsvpId);
    try {
      const updateData = {
        rsvp_id: rsvpId,
        attendance_status: newStatus,
        ...(ticketXp !== undefined && { ticket_xp: ticketXp }),
        ...(candleXp !== undefined && { candle_xp: candleXp }),
        ...(notes !== undefined && { notes })
      };

      await apiClient.update_attendance_status({ rsvpId: rsvpId }, updateData);
      toast.success('Attendance status updated successfully');
      await loadEventData(); // Reload data
    } catch (error: any) {
      console.error('Failed to update attendance:', error);
      toast.error('Failed to update attendance status');
    } finally {
      setIsUpdating('');
    }
  };

  // Bulk selection handlers
  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedAttendees(new Set(attendees.map(a => a.id)));
    } else {
      setSelectedAttendees(new Set());
    }
  };

  const handleSelectAttendee = (attendeeId: string, checked: boolean) => {
    const newSelected = new Set(selectedAttendees);
    if (checked) {
      newSelected.add(attendeeId);
    } else {
      newSelected.delete(attendeeId);
    }
    setSelectedAttendees(newSelected);
  };

  // XP editing handlers
  const handleXPEdit = (attendeeId: string, field: 'ticketXp' | 'candleXp', value: number) => {
    setEditingXP(prev => ({
      ...prev,
      [attendeeId]: {
        ...prev[attendeeId],
        [field]: value
      }
    }));
  };

  const handleXPSave = async (attendeeId: string) => {
    const attendee = attendees.find(a => a.id === attendeeId);
    if (!attendee) return;

    const xpData = editingXP[attendeeId];
    if (!xpData) return;

    await handleAttendanceUpdate(
      attendeeId,
      attendee.attendance_status as 'rsvp' | 'attended' | 'no_show',
      xpData.ticketXp,
      xpData.candleXp
    );
    
    // Clear editing state
    setEditingXP(prev => {
      const newState = { ...prev };
      delete newState[attendeeId];
      return newState;
    });
  };

  // Bulk actions
  const handleBulkStatusUpdate = async (status: 'rsvp' | 'attended' | 'no_show') => {
    if (selectedAttendees.size === 0) {
      toast.error('No attendees selected');
      return;
    }

    try {
      const promises = Array.from(selectedAttendees).map(attendeeId => {
        const attendee = attendees.find(a => a.id === attendeeId);
        if (attendee) {
          return handleAttendanceUpdate(attendeeId, status);
        }
      });
      
      await Promise.all(promises);
      setSelectedAttendees(new Set());
      toast.success(`Updated ${selectedAttendees.size} attendees to ${status}`);
    } catch (error) {
      toast.error('Failed to update some attendees');
    }
  };

  const handleAddManualRSVP = async () => {
    if (!selectedCharacterId || !eventId) return;
    
    try {
      const response = await apiClient.add_manual_rsvp(
        { eventId: eventId },
        {
          character_id: selectedCharacterId,
          ticket_xp: manualRSVPData.ticket_xp,
          candle_xp: manualRSVPData.candle_xp,
          notes: manualRSVPData.notes || null,
          attendance_status: manualRSVPData.attendance_status
        }
      );
      
      // Check if response is OK
      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const errorMessage = errorData?.detail || 'Failed to add manual RSVP';
        
        // Show specific error message for duplicate RSVP
        if (errorMessage.includes('already exists')) {
          const selectedCharacter = allCharacters.find(c => c.id === selectedCharacterId);
          toast.error(`${selectedCharacter?.name || 'This character'} has already been added to this event`);
        } else {
          toast.error(errorMessage);
        }
        return;
      }
      
      toast.success('Manual RSVP added successfully');
      setShowAddRSVP(false);
      setSelectedCharacterId('');
      setManualRSVPData({
        ticket_xp: 0,
        candle_xp: 0,
        notes: '',
        attendance_status: 'rsvp'
      });
      await loadEventData();
    } catch (error) {
      console.error('Failed to add manual RSVP:', error);
      toast.error('Failed to add manual RSVP');
    }
  };

  
  const handleSaveNotes = async () => {
    if (!viewingNotesAttendee) return;
    
    await handleAttendanceUpdate(
      viewingNotesAttendee.id,
      viewingNotesAttendee.attendance_status as 'rsvp' | 'attended' | 'no_show',
      undefined,
      undefined,
      noteEditValue
    );
    setViewingNotesAttendee(null);
  };
  
    const handleExportPDFs = async () => {
    if (!eventData) return;
    
    try {
      // Initialize progress dialog
      setExportProgress({
        show: true,
        eventName: eventData.event.title,
        totalCharacters: 0,
        progress: 0,
        status: 'Loading attendees...'
      });
      
      // Extract character IDs from attendees who have characters
      const characterIds = eventData.attendees
        .filter((attendee) => attendee.character_id)
        .map((attendee) => attendee.character_id);
      
      if (characterIds.length === 0) {
        setExportProgress(prev => ({ ...prev, show: false }));
        toast.error('No characters found for this event\'s attendees');
        return;
      }
      
      // Update with character count
      setExportProgress(prev => ({
        ...prev,
        totalCharacters: characterIds.length,
        progress: 33,
        status: `Generating ${characterIds.length} character sheets...`
      }));
      
      // Get auth token
      const token = await (await import('app/auth')).auth.getAuthToken();
      
      // Use the brain baseUrl
      const url = `${apiClient.baseUrl}/admin/characters/export-pdf`;
      
      const response = await fetch(url, {
        method: 'POST',
        credentials: 'include',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(characterIds)
      });
      
      if (!response.ok) {
        throw new Error(`Bulk export failed: ${response.status}`);
      }
      
      // Update progress
      setExportProgress(prev => ({
        ...prev,
        progress: 66,
        status: 'Processing PDF bundle...'
      }));
      
      // Get binary data as blob
      const blob = await response.blob();
      
      // Final progress update
      setExportProgress(prev => ({
        ...prev,
        progress: 100,
        status: 'Download starting...'
      }));
      
      const url2 = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url2;
      a.download = `${eventData.event.title.replace(/[^a-zA-Z0-9]/g, '_')}_character_sheets_${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url2);
      document.body.removeChild(a);
      
      toast.success(`Exported ${characterIds.length} character sheets for ${eventData.event.title}`);
      
      // Close dialog after a short delay
      setTimeout(() => {
        setExportProgress(prev => ({ ...prev, show: false }));
      }, 1000);
    } catch (error: any) {
      console.error('Failed to export PDFs:', error);
      setExportProgress(prev => ({ ...prev, show: false }));
      toast.error('Failed to export character sheets. Please try again.');
    }
  };

  const formatDate = (dateString: string) => {
    return formatDateTimeForDisplay(dateString, {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'attended': return 'default';
      case 'no_show': return 'destructive';
      default: return 'secondary';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'attended': return <UserCheck className="w-4 h-4" />;
      case 'no_show': return <UserX className="w-4 h-4" />;
      default: return <Users className="w-4 h-4" />;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 p-6 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-400 mx-auto"></div>
          <p className="text-purple-200 mt-4 text-lg">Loading event details...</p>
        </div>
      </div>
    );
  }

  if (!eventData) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 p-6 flex items-center justify-center">
        <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm p-8">
          <div className="text-center">
            <p className="text-purple-200 text-lg mb-4">Event not found</p>
            <Button onClick={() => navigate('/manage-events')} className="bg-gradient-to-r from-purple-600 to-blue-600">
              Back to Events
            </Button>
          </div>
        </Card>
      </div>
    );
  }

  const { event, attendees } = eventData;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate('/manage-events')}
              className="border-purple-400/30 text-purple-200 hover:bg-purple-800/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Events
            </Button>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                {event.title}
              </h1>
              <p className="text-purple-200/80 mt-1">{event.chapter_name}</p>
            </div>
          </div>
          <div className="flex items-center space-x-3">
            <Dialog open={showAddRSVP} onOpenChange={setShowAddRSVP}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700">
                  <UserPlus className="w-4 h-4 mr-2" />
                  Add RSVP
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-purple-500/30">
                <DialogHeader>
                  <DialogTitle className="text-purple-200">Add Manual RSVP</DialogTitle>
                  <DialogDescription className="text-purple-300/70">
                    Manually add a character to this event's RSVP list
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label className="text-purple-200">Character</Label>
                    <Select value={selectedCharacterId} onValueChange={setSelectedCharacterId}>
                      <SelectTrigger className="bg-purple-900/20 border-purple-400/30 text-purple-100">
                        <SelectValue placeholder="Select a character" />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900/90 border-purple-400/30">
                        {allCharacters.map((character) => (
                          <SelectItem key={character.id} value={character.id} className="text-purple-100">
                            {character.name} ({character.heritage_name} {character.archetype_name})
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-purple-200">Ticket XP</Label>
                      <Input
                        type="number"
                        value={manualRSVPData.ticket_xp}
                        onChange={(e) => setManualRSVPData(prev => ({ ...prev, ticket_xp: parseInt(e.target.value) || 0 }))}
                        className="bg-purple-900/20 border-purple-400/30 text-purple-100"
                      />
                    </div>
                    <div>
                      <Label className="text-purple-200">Candle XP</Label>
                      <Input
                        type="number"
                        value={manualRSVPData.candle_xp}
                        onChange={(e) => setManualRSVPData(prev => ({ ...prev, candle_xp: parseInt(e.target.value) || 0 }))}
                        className="bg-purple-900/20 border-purple-400/30 text-purple-100"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <Label className="text-purple-200">Status</Label>
                    <Select value={manualRSVPData.attendance_status} onValueChange={(value: 'rsvp' | 'attended' | 'no_show') => setManualRSVPData(prev => ({ ...prev, attendance_status: value }))}>
                      <SelectTrigger className="bg-purple-900/20 border-purple-400/30 text-purple-100">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-purple-900/90 border-purple-400/30">
                        <SelectItem value="rsvp" className="text-purple-100">RSVP</SelectItem>
                        <SelectItem value="attended" className="text-purple-100">Attended</SelectItem>
                        <SelectItem value="no_show" className="text-purple-100">No Show</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div>
                    <Label className="text-purple-200">Notes</Label>
                    <Textarea
                      value={manualRSVPData.notes}
                      onChange={(e) => setManualRSVPData(prev => ({ ...prev, notes: e.target.value }))}
                      placeholder="Optional notes..."
                      className="bg-purple-900/20 border-purple-400/30 text-purple-100 placeholder-purple-300/50"
                    />
                  </div>
                </div>
                <div className="flex justify-end space-x-3">
                  <Button variant="outline" onClick={() => setShowAddRSVP(false)} className="border-purple-400/30 text-purple-200">
                    Cancel
                  </Button>
                  <Button onClick={handleAddManualRSVP} className="bg-gradient-to-r from-purple-600 to-blue-600">
                    Add RSVP
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            
            <Button 
              variant="outline" 
              className="border-purple-400/30 text-purple-200 hover:bg-purple-800/20"
              onClick={handleExportPDFs}
            >
              <Download className="w-4 h-4 mr-2" />
              Export PDFs
            </Button>
          </div>
        </div>

        {/* Event Details */}
        <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl text-purple-200">Event Details</CardTitle>
              <Badge variant={event.status === 'cancelled' ? 'destructive' : 'secondary'}>
                {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-4">
                <div className="flex items-center text-purple-200/80">
                  <Calendar className="w-5 h-5 mr-3 text-purple-400" />
                  <div>
                    <p className="font-medium">Start Date</p>
                    <p className="text-sm">{formatDate(event.starts_at)}</p>
                  </div>
                </div>
                <div className="flex items-center text-purple-200/80">
                  <Calendar className="w-5 h-5 mr-3 text-purple-400" />
                  <div>
                    <p className="font-medium">End Date</p>
                    <p className="text-sm">{formatDate(event.ends_at)}</p>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                {event.location && (
                  <div className="flex items-center text-purple-200/80">
                    <MapPin className="w-5 h-5 mr-3 text-purple-400" />
                    <div>
                      <p className="font-medium">Location</p>
                      <p className="text-sm">{event.location}</p>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="space-y-4">
                <div className="flex items-center text-purple-200/80">
                  <Users className="w-5 h-5 mr-3 text-purple-400" />
                  <div>
                    <p className="font-medium">Total RSVPs</p>
                    <p className="text-sm">{event.rsvp_count}</p>
                  </div>
                </div>
                <div className="flex items-center text-green-400">
                  <UserCheck className="w-5 h-5 mr-3" />
                  <div>
                    <p className="font-medium">Attended</p>
                    <p className="text-sm">{event.attended_count}</p>
                  </div>
                </div>
              </div>
            </div>
            
            {event.description && (
              <div className="mt-6 pt-6 border-t border-purple-500/20">
                <h3 className="text-lg font-medium text-purple-200 mb-2">Description</h3>
                <p className="text-purple-200/80">{event.description}</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Attendees Table */}
        <Card className="bg-black/40 border-purple-500/30 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-xl text-purple-200">Event Attendees ({attendees.length})</CardTitle>
                <CardDescription className="text-purple-200/70">
                  Manage attendance status and XP distribution for event participants
                </CardDescription>
              </div>
              {selectedAttendees.size > 0 && (
                <div className="flex items-center space-x-2">
                  <span className="text-purple-200 text-sm">{selectedAttendees.size} selected</span>
                  <Button 
                    size="sm" 
                    onClick={() => handleBulkStatusUpdate('attended')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Mark Attended
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleBulkStatusUpdate('no_show')}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Mark No Show
                  </Button>
                  <Button 
                    size="sm" 
                    onClick={() => handleBulkStatusUpdate('rsvp')}
                    variant="outline"
                    className="border-purple-400/30 text-purple-200"
                  >
                    Reset to RSVP
                  </Button>
                </div>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-purple-500/30">
                    <TableHead className="text-purple-200 w-12">
                      <input
                        type="checkbox"
                        checked={attendees.length > 0 && selectedAttendees.size === attendees.length}
                        onChange={(e) => handleSelectAll(e.target.checked)}
                        className="w-4 h-4 rounded border-purple-400/30 bg-purple-900/20"
                      />
                    </TableHead>
                    <TableHead className="text-purple-200">Player</TableHead>
                    <TableHead className="text-purple-200">Character</TableHead>
                    <TableHead className="text-purple-200">Ticket XP</TableHead>
                    <TableHead className="text-purple-200">Candle XP</TableHead>
                    <TableHead className="text-purple-200">Status</TableHead>
                    <TableHead className="text-purple-200">Notes</TableHead>
                    <TableHead className="text-purple-200">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendees.map((attendee) => {
                    const isEditing = editingXP[attendee.id];
                    const currentTicketXp = isEditing?.ticketXp ?? attendee.ticket_xp;
                    const currentCandleXp = isEditing?.candleXp ?? attendee.candle_xp;
                    
                    return (
                      <TableRow key={attendee.id} className="border-purple-500/20">
                        <TableCell>
                          <input
                            type="checkbox"
                            checked={selectedAttendees.has(attendee.id)}
                            onChange={(e) => handleSelectAttendee(attendee.id, e.target.checked)}
                            className="w-4 h-4 rounded border-purple-400/30 bg-purple-900/20"
                          />
                        </TableCell>
                        <TableCell className="text-purple-100">
                          <div>
                            <p className="font-medium">{attendee.player_name}</p>
                            <p className="text-sm text-purple-300/70">#{attendee.player_number}</p>
                          </div>
                        </TableCell>
                        <TableCell className="text-purple-100">
                          {attendee.character_name || 'No character'}
                        </TableCell>
                        <TableCell className="text-purple-100">
                          {isEditing ? (
                            <input
                              type="number"
                              value={currentTicketXp}
                              onChange={(e) => handleXPEdit(attendee.id, 'ticketXp', parseInt(e.target.value) || 0)}
                              className="w-16 px-2 py-1 bg-purple-900/30 border border-purple-400/30 rounded text-center text-purple-100"
                              min="0"
                              max="4"
                            />
                          ) : (
                            <span 
                              onClick={() => setEditingXP(prev => ({ ...prev, [attendee.id]: { ticketXp: attendee.ticket_xp, candleXp: attendee.candle_xp } }))}
                              className="cursor-pointer hover:bg-purple-800/20 px-2 py-1 rounded"
                            >
                              {attendee.ticket_xp}
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-purple-100">
                          {isEditing ? (
                            <input
                              type="number"
                              value={currentCandleXp}
                              onChange={(e) => handleXPEdit(attendee.id, 'candleXp', parseInt(e.target.value) || 0)}
                              className="w-16 px-2 py-1 bg-purple-900/30 border border-purple-400/30 rounded text-center text-purple-100"
                              min="0"
                              max="4"
                            />
                          ) : (
                            <span 
                              onClick={() => setEditingXP(prev => ({ ...prev, [attendee.id]: { ticketXp: attendee.ticket_xp, candleXp: attendee.candle_xp } }))}
                              className="cursor-pointer hover:bg-purple-800/20 px-2 py-1 rounded"
                            >
                              {attendee.candle_xp}
                            </span>
                          )}
                        </TableCell>
                        <TableCell>
                          {attendee.rsvp_status === 'not_attending' ? (
                            <Badge variant="destructive" className="flex items-center w-fit">
                              <UserX className="w-4 h-4" />
                              <span className="ml-1">Not Attending</span>
                            </Badge>
                          ) : (
                            <Badge variant={getStatusBadgeVariant(attendee.attendance_status)} className="flex items-center w-fit">
                              {getStatusIcon(attendee.attendance_status)}
                              <span className="ml-1 capitalize">{attendee.attendance_status.replace('_', ' ')}</span>
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-purple-100 max-w-xs">
                          <div className="flex items-center space-x-2">
                            <p className="truncate flex-1">{attendee.notes || '-'}</p>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setViewingNotesAttendee(attendee);
                                setNoteEditValue(attendee.notes || '');
                              }}
                              className="h-8 w-8 p-0 text-purple-300 hover:text-purple-100"
                            >
                              <FileText className="w-4 h-4" />
                            </Button>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center space-x-2">
                            {isEditing ? (
                              <>
                                <Button 
                                  size="sm" 
                                  onClick={() => handleXPSave(attendee.id)}
                                  className="bg-green-600 hover:bg-green-700 text-xs"
                                >
                                  Save
                                </Button>
                                <Button 
                                  size="sm" 
                                  variant="outline"
                                  onClick={() => setEditingXP(prev => { const newState = {...prev}; delete newState[attendee.id]; return newState; })}
                                  className="border-purple-400/30 text-purple-200 text-xs"
                                >
                                  Cancel
                                </Button>
                              </>
                            ) : (
                              <Select
                                value={attendee.attendance_status}
                                onValueChange={(value: 'rsvp' | 'attended' | 'no_show') => 
                                  handleAttendanceUpdate(attendee.id, value)
                                }
                                disabled={isUpdating === attendee.id}
                              >
                                <SelectTrigger className="w-32 bg-purple-900/20 border-purple-400/30 text-purple-100">
                                  <SelectValue />
                                </SelectTrigger>
                                <SelectContent className="bg-purple-900/90 border-purple-400/30">
                                  <SelectItem value="rsvp" className="text-purple-100">RSVP</SelectItem>
                                  <SelectItem value="attended" className="text-purple-100">Attended</SelectItem>
                                  <SelectItem value="no_show" className="text-purple-100">No Show</SelectItem>
                                </SelectContent>
                              </Select>
                            )}
                            {isUpdating === attendee.id && (
                              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-400"></div>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
              
              {attendees.length === 0 && (
                <div className="text-center py-12">
                  <Users className="w-12 h-12 text-purple-400 mx-auto mb-4" />
                  <p className="text-purple-200 text-lg mb-2">No attendees yet</p>
                  <p className="text-purple-300/70">RSVPs will appear here as players sign up for the event.</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>

              
      {/* Export Progress Dialog */}
      <Dialog open={exportProgress.show} onOpenChange={(open) => !open && setExportProgress(prev => ({ ...prev, show: false }))}>
        <DialogContent className="bg-gradient-to-br from-purple-950/95 to-blue-950/95 border-purple-500/50 backdrop-blur-md">
          <DialogHeader>
            <DialogTitle className="text-2xl bg-gradient-to-r from-purple-300 to-blue-300 bg-clip-text text-transparent">
              Exporting Character Sheets
            </DialogTitle>
            <DialogDescription className="text-purple-200/80">
              Event: {exportProgress.eventName}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            {/* Status Message */}
            <div className="text-center">
              <p className="text-purple-200 text-lg font-medium">
                {exportProgress.status}
              </p>
              {exportProgress.totalCharacters > 0 && (
                <p className="text-purple-300/70 text-sm mt-2">
                  {exportProgress.totalCharacters} character{exportProgress.totalCharacters !== 1 ? 's' : ''}
                </p>
              )}
            </div>
            
            {/* Progress Bar */}
            <div className="space-y-2">
              <div className="w-full bg-purple-900/40 rounded-full h-3 overflow-hidden border border-purple-500/30">
                <div 
                  className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-500 ease-out rounded-full"
                  style={{ width: `${exportProgress.progress}%` }}
                />
              </div>
              <p className="text-center text-purple-300/60 text-sm">
                {exportProgress.progress}%
              </p>
            </div>
            
            {/* Loading Animation */}
            {exportProgress.progress < 100 && (
              <div className="flex justify-center">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Notes View/Edit Dialog */}
      <Dialog open={!!viewingNotesAttendee} onOpenChange={(open) => !open && setViewingNotesAttendee(null)}>
        <DialogContent className="bg-gray-900 border-purple-500/30 text-purple-100">
          <DialogHeader>
            <DialogTitle>Attendee Notes</DialogTitle>
            <DialogDescription>
              View and edit notes for {viewingNotesAttendee?.player_name} ({viewingNotesAttendee?.character_name})
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <Textarea
              value={noteEditValue}
              onChange={(e) => setNoteEditValue(e.target.value)}
              className="bg-purple-900/20 border-purple-400/30 text-purple-100 min-h-[150px]"
              placeholder="No notes..."
            />
          </div>
          <div className="flex justify-end space-x-2">
            <Button 
              variant="outline" 
              onClick={() => setViewingNotesAttendee(null)}
              className="border-purple-400/30 text-purple-200"
            >
              Cancel
            </Button>
            <Button 
              onClick={handleSaveNotes}
              className="bg-gradient-to-r from-purple-600 to-blue-600"
            >
              Save Notes
            </Button>
          </div>
        </DialogContent>
      </Dialog>
        
      </div>
    </div>
  );
};

export default AdminEventDetails;
