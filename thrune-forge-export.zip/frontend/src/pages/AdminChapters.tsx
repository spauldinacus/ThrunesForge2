import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit, Trash2, ArrowLeft, Shield, MapPin, Mail, Globe, Calendar } from 'lucide-react';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { useUserGuardContext } from 'app/auth';
import { usePermissions, PERMISSIONS } from 'utils/usePermissions';
import type { AppApisAdminChapter, ChapterCreate, ChapterUpdate } from 'types';

export default function AdminChapters() {
  // ALL HOOKS MUST BE DECLARED AT THE TOP BEFORE ANY CONDITIONAL LOGIC
  const navigate = useNavigate();
  const { user } = useUserGuardContext();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  
  // State hooks
  const [chapters, setChapters] = useState<AppApisAdminChapter[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingChapter, setEditingChapter] = useState<AppApisAdminChapter | null>(null);
  const [formData, setFormData] = useState<ChapterCreate>({
    name: '',
    description: '',
    chapter_code: '',
    location: '',
    contact_email: '',
    website: ''
  });

  // Effect hooks must also be at the top
  useEffect(() => {
    // Only load chapters if user has permission
    if (!permissionsLoading && hasPermission(PERMISSIONS.MANAGE_CHAPTERS)) {
      loadChapters();
    }
  }, [permissionsLoading]); // Removed hasPermission from dependencies to prevent infinite rerenders

  // Function definitions
  const loadChapters = async () => {
    try {
      setLoading(true);
      const response = await apiClient.list_scoped_chapters();
      const data = await response.json();
      setChapters(data.chapters || []);
    } catch (error) {
      console.error('Failed to load chapters:', error);
      toast.error('Failed to load chapters');
    } finally {
      setLoading(false);
    }
  };

  // NOW we can do conditional rendering after all hooks are declared
  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-purple-400 text-lg">Verifying permissions...</div>
        </div>
      </div>
    );
  }

  // Block access if user doesn't have permission
  if (!hasPermission(PERMISSIONS.MANAGE_CHAPTERS)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <Card className="bg-slate-900 border-red-500/20 max-w-md">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-300 mb-4">You don't have permission to manage chapters.</p>
            <Button 
              onClick={() => navigate('/')}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      chapter_code: '',
      location: '',
      contact_email: '',
      website: ''
    });
    setEditingChapter(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (chapter: AppApisAdminChapter) => {
    setFormData({
      name: chapter.name,
      description: chapter.description || '',
      chapter_code: chapter.chapter_code || '',
      location: chapter.location || '',
      contact_email: chapter.contact_email || '',
      website: chapter.website || ''
    });
    setEditingChapter(chapter);
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate chapter code format
    if (formData.chapter_code && !/^[A-Z]{2}$/.test(formData.chapter_code)) {
      toast.error('Chapter code must be exactly 2 uppercase letters');
      return;
    }

    try {
      if (editingChapter) {
        await apiClient.update_chapter(
          { chapterId: editingChapter.id },
          formData
        );
        toast.success('Chapter updated successfully');
      } else {
        await apiClient.create_chapter(formData);
        toast.success('Chapter created successfully');
      }
      
      setDialogOpen(false);
      resetForm();
      loadChapters();
    } catch (error: any) {
      console.error('Failed to save chapter:', error);
      const errorMessage = error.response?.data?.detail || (editingChapter ? 'Failed to update chapter' : 'Failed to create chapter');
      toast.error(errorMessage);
    }
  };

  const handleDelete = async () => {
    if (!editingChapter) return;
    
    if (!confirm(`Are you sure you want to delete ${editingChapter.name}? This action cannot be undone.`)) {
      return;
    }

    try {
      await apiClient.delete_chapter({ chapterId: editingChapter.id });
      toast.success('Chapter deleted successfully');
      setDialogOpen(false);
      resetForm();
      loadChapters();
    } catch (error: any) {
      console.error('Failed to delete chapter:', error);
      const errorMessage = error.response?.data?.detail || 'Failed to delete chapter';
      toast.error(errorMessage);
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="flex items-center space-x-2">
          <Shield className="w-6 h-6 text-amber-400" />
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400">
            Admin: Chapter Management
          </div>
        </div>

        <Button 
          onClick={openCreateDialog}
          className="bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Chapter
        </Button>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        {loading ? (
          <div className="flex justify-center items-center py-12">
            <div className="text-white text-lg">Loading chapters...</div>
          </div>
        ) : chapters.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-slate-400 text-lg mb-4">No chapters found</div>
            <Button onClick={openCreateDialog} className="bg-gradient-to-r from-green-600 to-emerald-600">
              <Plus className="w-4 h-4 mr-2" />
              Create First Chapter
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {chapters.map((chapter) => (
              <Card 
                key={chapter.id} 
                className="group transition-all duration-300 hover:scale-105 bg-gradient-to-br from-indigo-600/20 to-purple-600/20 backdrop-blur-sm border-indigo-500/30 hover:border-indigo-400/60 shadow-xl hover:shadow-2xl hover:shadow-indigo-500/20"
              >
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <CardTitle className="text-white text-xl group-hover:text-indigo-200 transition-colors">
                        {chapter.name}
                      </CardTitle>
                      {chapter.chapter_code && (
                        <Badge 
                          variant="secondary"
                          className="mt-2 bg-amber-600/20 text-amber-300 border-amber-500/30"
                        >
                          {chapter.chapter_code}
                        </Badge>
                      )}
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditDialog(chapter)}
                      className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {chapter.description && (
                    <p className="text-slate-300 text-sm leading-relaxed">
                      {chapter.description}
                    </p>
                  )}
                  
                  {chapter.location && (
                    <div className="flex items-center text-slate-300 text-sm">
                      <MapPin className="w-4 h-4 mr-2 text-indigo-400" />
                      {chapter.location}
                    </div>
                  )}
                  
                  {chapter.contact_email && (
                    <div className="flex items-center text-slate-300 text-sm">
                      <Mail className="w-4 h-4 mr-2 text-green-400" />
                      {chapter.contact_email}
                    </div>
                  )}
                  
                  {chapter.website && (
                    <div className="flex items-center text-slate-300 text-sm">
                      <Globe className="w-4 h-4 mr-2 text-blue-400" />
                      <a 
                        href={chapter.website.startsWith('http') ? chapter.website : `https://${chapter.website}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="hover:text-blue-300 underline"
                      >
                        {chapter.website}
                      </a>
                    </div>
                  )}
                  
                  <div className="flex items-center text-slate-400 text-xs pt-2">
                    <Calendar className="w-3 h-3 mr-1" />
                    Created: {new Date(chapter.created_at).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </main>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-900/95 border-purple-500/30 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
              {editingChapter ? 'Edit Chapter' : 'Create New Chapter'}
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-slate-300">Chapter Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                required
                className="bg-black/40 border-purple-500/30 text-white"
                placeholder="Enter chapter name"
              />
            </div>
            
            <div>
              <Label htmlFor="chapter_code" className="text-slate-300">Chapter Code *</Label>
              <Input
                id="chapter_code"
                value={formData.chapter_code}
                onChange={(e) => setFormData(prev => ({ ...prev, chapter_code: e.target.value.toUpperCase() }))}
                required
                maxLength={2}
                className="bg-black/40 border-purple-500/30 text-white"
                placeholder="e.g., NY, LA"
              />
              <p className="text-xs text-slate-400 mt-1">Must be exactly 2 uppercase letters</p>
            </div>
            
            <div>
              <Label htmlFor="location" className="text-slate-300">Location</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                className="bg-black/40 border-purple-500/30 text-white"
                placeholder="Enter chapter location"
              />
            </div>
            
            <div>
              <Label htmlFor="contact_email" className="text-slate-300">Contact Email</Label>
              <Input
                id="contact_email"
                type="email"
                value={formData.contact_email}
                onChange={(e) => setFormData(prev => ({ ...prev, contact_email: e.target.value }))}
                className="bg-black/40 border-purple-500/30 text-white"
                placeholder="Enter contact email"
              />
            </div>
            
            <div>
              <Label htmlFor="website" className="text-slate-300">Website</Label>
              <Input
                id="website"
                value={formData.website}
                onChange={(e) => setFormData(prev => ({ ...prev, website: e.target.value }))}
                className="bg-black/40 border-purple-500/30 text-white"
                placeholder="Enter website URL"
              />
            </div>
            
            <div>
              <Label htmlFor="description" className="text-slate-300">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-black/40 border-purple-500/30 text-white resize-none"
                placeholder="Enter chapter description"
                rows={3}
              />
            </div>
            
            <div className="flex flex-col space-y-3 pt-4">
              {editingChapter && (
                <Button
                  type="button"
                  variant="destructive"
                  onClick={handleDelete}
                  className="w-full bg-red-600 hover:bg-red-700 text-white"
                >
                  <Trash2 className="w-4 h-4 mr-2" />
                  Delete Chapter
                </Button>
              )}
              
              <div className="flex space-x-3">
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setDialogOpen(false)}
                  className="flex-1 border-purple-500/30 text-purple-300 hover:bg-purple-600/20"
                >
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  className="flex-1 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700"
                >
                  {editingChapter ? 'Update' : 'Create'}
                </Button>
              </div>
            </div>
            
          </form>
        </DialogContent>
      </Dialog>

      {/* Background decorative elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute top-1/4 right-1/3 w-64 h-64 bg-amber-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/3 left-1/4 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>
    </div>
  );
}
