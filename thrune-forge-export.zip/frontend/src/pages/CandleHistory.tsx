import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Flame, Calendar, Award, Scroll, Trophy } from "lucide-react";

export default function CandleHistory() {
  const navigate = useNavigate();

  const candleEntries = [
    {
      date: "October 10, 2024",
      event: "The Autumn Gathering",
      character: "Seraphina Nightwhisper",
      achievement: "Discovered the Lost Tome of Shadows",
      type: "discovery",
      points: 15
    },
    {
      date: "September 22, 2024",
      event: "Moonlight Tournament",
      character: "Sir Garrett the Bold",
      achievement: "Champion of the Silver Circle",
      type: "victory",
      points: 25
    },
    {
      date: "September 8, 2024",
      event: "The Crimson Conspiracy",
      character: "Lyra Stormweaver",
      achievement: "Saved the Village of Millhaven",
      type: "heroic",
      points: 20
    },
    {
      date: "August 15, 2024",
      event: "Summer Solstice Celebration",
      character: "Thane Ironforge",
      achievement: "Master Craftsman Recognition",
      type: "skill",
      points: 12
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'victory': return Trophy;
      case 'discovery': return Scroll;
      case 'heroic': return Award;
      case 'skill': return Flame;
      default: return Flame;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'victory': return 'from-yellow-600/20 to-amber-600/20 border-yellow-500/30';
      case 'discovery': return 'from-purple-600/20 to-indigo-600/20 border-purple-500/30';
      case 'heroic': return 'from-red-600/20 to-pink-600/20 border-red-500/30';
      case 'skill': return 'from-green-600/20 to-emerald-600/20 border-green-500/30';
      default: return 'from-amber-600/20 to-orange-600/20 border-amber-500/30';
    }
  };

  const totalPoints = candleEntries.reduce((sum, entry) => sum + entry.points, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Candle History
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full bg-gradient-to-br from-amber-500/20 to-orange-500/20">
              <Flame className="w-12 h-12 text-amber-300" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-amber-400 to-orange-400 mb-4">
            Your Adventure Chronicle
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto mb-6">
            Track your LARP achievements, memorable moments, and character progression through the ages.
          </p>
          
          {/* Stats Summary */}
          <div className="flex justify-center space-x-8 mb-8">
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">{candleEntries.length}</div>
              <div className="text-slate-400 text-sm">Adventures</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">{totalPoints}</div>
              <div className="text-slate-400 text-sm">Total Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-400">3</div>
              <div className="text-slate-400 text-sm">Characters</div>
            </div>
          </div>
        </div>

        {/* History Timeline */}
        <div className="max-w-4xl mx-auto space-y-6">
          {candleEntries.map((entry, index) => {
            const Icon = getTypeIcon(entry.type);
            return (
              <Card key={index} className={`group transition-all duration-300 hover:scale-105 bg-gradient-to-br ${getTypeColor(entry.type)} backdrop-blur-sm shadow-xl hover:shadow-2xl hover:shadow-amber-500/20`}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 rounded-full bg-gradient-to-br from-amber-500/30 to-orange-500/30">
                        <Icon className="w-6 h-6 text-amber-300" />
                      </div>
                      <div>
                        <CardTitle className="text-white text-lg group-hover:text-amber-200 transition-colors">
                          {entry.achievement}
                        </CardTitle>
                        <div className="flex items-center mt-1 text-slate-300 text-sm">
                          <Calendar className="w-4 h-4 mr-1 text-amber-400" />
                          {entry.date}
                        </div>
                      </div>
                    </div>
                    <Badge 
                      variant="secondary"
                      className="bg-amber-600/20 text-amber-300 border-amber-500/30"
                    >
                      +{entry.points} pts
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-slate-400">Event: </span>
                      <span className="text-slate-200">{entry.event}</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Character: </span>
                      <span className="text-slate-200">{entry.character}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Add New Entry Button */}
        <div className="text-center mt-12">
          <Button 
            size="lg"
            className="bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white px-8 py-3"
          >
            <Flame className="w-5 h-5 mr-2" />
            Add New Entry
          </Button>
        </div>

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-amber-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-orange-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>
    </div>
  );
}
