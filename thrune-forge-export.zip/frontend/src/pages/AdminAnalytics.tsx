import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { apiClient } from "app";
import { AnalyticsCard } from "components/AnalyticsCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Users, 
  UserCircle, 
  Calendar, 
  TrendingUp, 
  Trophy, 
  MapPin,
  Sword,
  Coins,
  BarChart3,
  Activity,
  Heart,
  ArrowRight,
  ArrowLeft
} from "lucide-react";
import type { AnalyticsOverview } from "types";

export default function AdminAnalytics() {
  const navigate = useNavigate();
  const [overview, setOverview] = useState<AnalyticsOverview | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);
      const response = await apiClient.get_analytics_overview();
      const data = await response.json();
      setOverview(data);
    } catch (err) {
      console.error("Failed to load analytics:", err);
      setError("Failed to load analytics data");
    } finally {
      setLoading(false);
    }
  };

  const dashboards = [
    {
      title: "Character Builds",
      description: "Analyze skill selections, archetype popularity, and build patterns",
      icon: Sword,
      path: "/admin-character-builds",
      color: "from-purple-500 to-pink-500"
    },
    {
      title: "XP Economy",
      description: "Track XP distribution, spending patterns, and progression rates",
      icon: Coins,
      path: "/admin-xp-economy",
      color: "from-amber-500 to-orange-500"
    },
    {
      title: "Event Performance",
      description: "Monitor event attendance, engagement, and trends over time",
      icon: BarChart3,
      path: "/admin-event-performance",
      color: "from-blue-500 to-cyan-500"
    },
    {
      title: "Player Engagement",
      description: "Understand player activity, retention, and participation metrics",
      icon: Activity,
      path: "/admin-player-engagement",
      color: "from-green-500 to-emerald-500"
    },
    {
      title: "Chapter Health",
      description: "View chapter-specific metrics, growth, and comparative analysis",
      icon: Heart,
      path: "/admin-chapter-health",
      color: "from-rose-500 to-red-500"
    }
  ];

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 flex items-center justify-center">
        <div className="text-purple-300 text-lg">Loading analytics...</div>
      </div>
    );
  }

  if (error || !overview) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 flex items-center justify-center">
        <div className="text-red-400 text-lg">{error || "No data available"}</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/")}
            className="mb-4 text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
          
          <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-purple-400 bg-clip-text text-transparent mb-2">
            Analytics Hub
          </h1>
          <p className="text-purple-200/70">Comprehensive insights into your LARP system</p>
          <p className="text-sm text-muted-foreground mt-2">
            Last updated: {new Date(overview.last_updated).toLocaleString()}
          </p>
        </div>

        {/* KPI Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          <AnalyticsCard
            title="Total Corruption"
            value={overview.total_corruption}
            icon={Users}
            subtitle="Across all characters"
          />
          <AnalyticsCard
            title="Total Characters"
            value={overview.total_characters}
            icon={UserCircle}
            subtitle="Active characters"
          />
          <AnalyticsCard
            title="Total Deaths"
            value={overview.total_deaths}
            icon={Calendar}
            subtitle="Across all characters"
          />
          <AnalyticsCard
            title="Avg. Attendance"
            value={overview.attendance_rate}
            icon={TrendingUp}
            subtitle="Last 5 events average"
          />
          <AnalyticsCard
            title="Total XP Distributed"
            value={overview.total_xp_distributed.toLocaleString()}
            icon={Trophy}
            subtitle="All time"
          />
          <AnalyticsCard
            title="Total Events"
            value={overview.total_events}
            icon={MapPin}
            subtitle="All time"
          />
        </div>

        {/* Specialized Dashboards */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-purple-200 mb-6">Specialized Dashboards</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {dashboards.map((dashboard) => {
              const Icon = dashboard.icon;
              return (
                <Card 
                  key={dashboard.path}
                  className="bg-card/40 backdrop-blur-sm border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer group"
                  onClick={() => navigate(dashboard.path)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <CardTitle className="text-xl flex items-center gap-2 text-foreground">
                          <Icon className="h-6 w-6 text-purple-400" />
                          {dashboard.title}
                        </CardTitle>
                        <CardDescription className="mt-2">
                          {dashboard.description}
                        </CardDescription>
                      </div>
                      <ArrowRight className="h-5 w-5 text-purple-400 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className={`h-1 w-full bg-gradient-to-r ${dashboard.color} rounded-full opacity-50`} />
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
