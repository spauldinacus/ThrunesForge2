import { useState, useEffect } from 'react';
import { useUserGuardContext } from 'app/auth';
import { useNavigate } from 'react-router-dom';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Target, BookOpen, Loader2, Users, Calendar, ArrowLeft } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { SharedMilestoneResponse, SharedJournalResponse, ChapterResponse, EventSummary } from 'types';

export default function AdminSharedContent() {
  const navigate = useNavigate();
  const { toast } = useToast();

  // State
  const [sharedMilestones, setSharedMilestones] = useState<SharedMilestoneResponse[]>([]);
  const [sharedJournals, setSharedJournals] = useState<SharedJournalResponse[]>([]);
  const [chapters, setChapters] = useState<ChapterResponse[]>([]);
  const [loading, setLoading] = useState(true);

  // Filters
  const [selectedChapter, setSelectedChapter] = useState<string>('all');
  const [selectedPlayer, setSelectedPlayer] = useState<string>('all');
  const [selectedCharacter, setSelectedCharacter] = useState<string>('all');
  const [selectedEvent, setSelectedEvent] = useState<string>('all');

  useEffect(() => {
    loadChapters();
    loadEvents();
  }, []);

  useEffect(() => {
    loadSharedContent();
  }, [selectedChapter, selectedPlayer, selectedCharacter, selectedEvent]);

  const loadChapters = async () => {
    try {
      const response = await apiClient.list_scoped_chapters();
      const data = await response.json();
      setChapters(data.chapters || []);
    } catch (error) {
      console.error('Failed to load chapters:', error);
      setChapters([]);
    }
  };

  const loadEvents = async () => {
    // Events will be derived from shared journals instead
    // Don't load all events - we'll compute unique events from journals
  };

  const loadSharedContent = async () => {
    setLoading(true);
    try {
      const params: any = {};
      if (selectedPlayer !== 'all') params.player_id = selectedPlayer;
      if (selectedCharacter !== 'all') params.character_id = selectedCharacter;
      if (selectedEvent !== 'all') params.event_id = selectedEvent;

      // Load shared milestones
      const milestonesResponse = await apiClient.get_shared_milestones(params);
      if (milestonesResponse.ok) {
        const milestonesData = await milestonesResponse.json();
        setSharedMilestones(milestonesData);
      }

      // Load shared journals
      const journalsResponse = await apiClient.get_shared_journals(params);
      if (journalsResponse.ok) {
        const journalsData = await journalsResponse.json();
        setSharedJournals(journalsData);
      }
    } catch (error) {
      console.error('Failed to load shared content:', error);
      toast({
        title: 'Error',
        description: 'Failed to load shared content',
        variant: 'destructive',
      });
    } finally {
      setLoading(false);
    }
  };

  // Get unique chapters from the data by name only (no chapter_id available)
  const uniqueChapters = Array.from(
    new Set([...sharedMilestones, ...sharedJournals].map((item) => item.chapter_name))
  ).map((chapterName) => {
    return { id: chapterName, name: chapterName };
  }).filter(chapter => chapter.name); // Remove any empty chapter names
  
  // Get unique players and characters from the data
  const uniquePlayers = Array.from(
    new Set([...sharedMilestones, ...sharedJournals].map((item) => item.player_id))
  ).map((playerId) => {
    const item = [...sharedMilestones, ...sharedJournals].find(
      (i) => i.player_id === playerId
    );
    return { id: playerId, number: item?.player_number || '', name: item?.player_name || '' };
  });

  // Get unique events that have shared journals attached
  const uniqueEvents = Array.from(
    new Set(sharedJournals.filter(j => j.event_id).map(j => j.event_id))
  ).map((eventId) => {
    const journal = sharedJournals.find(j => j.event_id === eventId);
    return {
      id: eventId!,
      title: journal?.event_title || 'Unknown Event',
      starts_at: journal?.created_at || new Date().toISOString() // Use journal created date as fallback
    };
  }).sort((a, b) => {
    // Sort by date descending (latest first)
    const dateA = new Date(a.starts_at).getTime();
    const dateB = new Date(b.starts_at).getTime();
    return dateB - dateA;
  });
  
  const uniqueCharacters = Array.from(
    new Set([...sharedMilestones, ...sharedJournals].map((item) => item.character_id))
  ).map((characterId) => {
    const item = [...sharedMilestones, ...sharedJournals].find(
      (i) => i.character_id === characterId
    );
    return { id: characterId, name: item?.character_name || '' };
  });

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - Shared Player Content
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Shared Player Content
              </h1>
              <p className="text-muted-foreground mt-2">
                View milestones and journal entries that players have chosen to share with staff.
              </p>
            </div>
          </div>

          {/* Filters */}
          <Card className="mb-6 border-purple-500/20 bg-black/40 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-lg text-purple-100">Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-purple-200">Chapter</label>
                  <Select value={selectedChapter} onValueChange={setSelectedChapter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem key="all-chapters" value="all">All Chapters</SelectItem>
                      {uniqueChapters.map((chapter) => (
                        <SelectItem key={`chapter-${chapter.id}`} value={chapter.id}>
                          {chapter.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-purple-200">Player</label>
                  <Select value={selectedPlayer} onValueChange={setSelectedPlayer}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem key="all-players" value="all">All Players</SelectItem>
                      {uniquePlayers.map((player) => (
                        <SelectItem key={`player-${player.id}`} value={player.id}>
                          {player.number} - {player.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-purple-200">Character</label>
                  <Select value={selectedCharacter} onValueChange={setSelectedCharacter}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem key="all-characters" value="all">All Characters</SelectItem>
                      {uniqueCharacters.map((char) => (
                        <SelectItem key={`character-${char.id}`} value={char.id}>
                          {char.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium text-purple-200">Event</label>
                  <Select value={selectedEvent} onValueChange={setSelectedEvent}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem key="all" value="all">All Events</SelectItem>
                      {uniqueEvents.map((event) => {
                        try {
                          const dateStr = format(new Date(event.starts_at), 'MMM d, yyyy');
                          return (
                            <SelectItem key={`event-${event.id}`} value={event.id}>
                              {event.title} ({dateStr})
                            </SelectItem>
                          );
                        } catch (err) {
                          console.error(`Error formatting event "${event.title}":`, err);
                          return null;
                        }
                      })}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Tabs */}
          <Tabs defaultValue="milestones" className="space-y-6">
            <TabsList className="grid w-full max-w-[400px] grid-cols-2">
              <TabsTrigger value="milestones" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Milestones ({sharedMilestones.length})
              </TabsTrigger>
              <TabsTrigger value="journals" className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Journals ({sharedJournals.length})
              </TabsTrigger>
            </TabsList>

            {/* Milestones Tab */}
            <TabsContent value="milestones" className="space-y-4">
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                </div>
              ) : sharedMilestones.length > 0 ? (
                <div className="grid gap-4">
                  {sharedMilestones.map((milestone) => {
                    const progress = milestone.target_progress
                      ? (milestone.current_progress / milestone.target_progress) * 100
                      : 0;
                    const hasTarget = milestone.target_progress !== null;

                    return (
                      <Card key={milestone.id} className="border-border/50 bg-card/50 backdrop-blur-sm">
                        <CardHeader>
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <CardTitle className="text-lg">{milestone.milestone_name}</CardTitle>
                                {milestone.is_custom && (
                                  <Badge variant="secondary">Custom</Badge>
                                )}
                              </div>
                              <CardDescription>{milestone.milestone_description}</CardDescription>
                            </div>
                            <Badge variant="outline">{milestone.category}</Badge>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2">
                            <div className="flex items-center gap-1.5">
                              <Users className="h-4 w-4" />
                              <span>
                                {milestone.player_name} ({milestone.player_number})
                              </span>
                            </div>
                            <span>•</span>
                            <span>{milestone.character_name}</span>
                            <span>•</span>
                            <span>{milestone.chapter_name}</span>
                          </div>
                        </CardHeader>
                        <CardContent className="space-y-4">
                          {hasTarget && (
                            <div className="space-y-2">
                              <div className="flex justify-between text-sm">
                                <span className="text-muted-foreground">Progress</span>
                                <span className="font-medium">
                                  {milestone.current_progress} / {milestone.target_progress}
                                </span>
                              </div>
                              <Progress value={Math.min(progress, 100)} className="h-2" />
                            </div>
                          )}

                          {milestone.notes && (
                            <div className="rounded-lg bg-muted/50 p-3">
                              <p className="text-sm font-medium mb-1">Player Notes:</p>
                              <p className="text-sm text-muted-foreground">{milestone.notes}</p>
                            </div>
                          )}

                          {milestone.completed && (
                            <div className="flex items-center gap-2 text-sm text-green-600 dark:text-green-400">
                              <Calendar className="h-4 w-4" />
                              <span>
                                Completed on {format(new Date(milestone.completed_at!), 'PPP')}
                              </span>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              ) : (
                <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
                  <CardContent className="py-12 text-center">
                    <Target className="h-12 w-12 text-purple-400/50 mx-auto mb-4" />
                    <p className="text-purple-300/70">No shared milestones found.</p>
                    <p className="text-sm text-purple-400/60 mt-2">
                      Players haven't shared any milestones with staff yet.
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Journals Tab */}
            <TabsContent value="journals" className="space-y-4">
              {loading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-purple-400" />
                </div>
              ) : sharedJournals.length > 0 ? (
                <div className="grid gap-4">
                  {sharedJournals.map((journal) => (
                    <Card key={journal.id} className="border-border/50 bg-card/50 backdrop-blur-sm">
                      <CardHeader>
                        <div className="flex items-start justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <BookOpen className="h-5 w-5 text-purple-500 dark:text-purple-400" />
                              <CardTitle className="text-lg">{journal.title}</CardTitle>
                            </div>
                            <CardDescription className="flex items-center gap-2">
                              <Calendar className="h-3.5 w-3.5" />
                              {format(new Date(journal.created_at), 'PPP')}
                            </CardDescription>
                          </div>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground pt-2">
                          <div className="flex items-center gap-1.5">
                            <Users className="h-4 w-4" />
                            <span>
                              {journal.player_name} ({journal.player_number})
                            </span>
                          </div>
                          <span>•</span>
                          <span>{journal.character_name}</span>
                          <span>•</span>
                          <span>{journal.chapter_name}</span>
                        </div>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {journal.event_title && (
                          <div className="rounded-lg bg-purple-500/10 border border-purple-500/20 p-2 px-3">
                            <p className="text-sm text-purple-600 dark:text-purple-400">
                              Event: {journal.event_title}
                            </p>
                          </div>
                        )}

                        <div className="prose prose-sm dark:prose-invert max-w-none">
                          <p className="text-foreground whitespace-pre-wrap">{journal.content}</p>
                        </div>

                        {journal.tags.length > 0 && (
                          <div className="flex flex-wrap gap-2">
                            {journal.tags.map((tag, index) => (
                              <Badge key={`${journal.id}-${tag}-${index}`} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card className="border-purple-500/20 bg-black/40 backdrop-blur-sm">
                  <CardContent className="py-12 text-center">
                    <BookOpen className="h-12 w-12 text-purple-400/50 mx-auto mb-4" />
                    <p className="text-purple-300/70">No shared journal entries found.</p>
                    <p className="text-sm text-purple-400/60 mt-2">
                      Players haven't shared any journal entries with staff yet.
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  );
}
