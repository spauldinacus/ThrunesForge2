import { useEffect, useState } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { apiClient } from "app";
import { CharacterPhoto, PlayerProfile } from "types";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Helper function to convert Google Drive URLs to direct image URLs
const getGoogleDriveImageUrl = (url: string) => {
  if (!url.includes('drive.google.com')) return url;
  
  // Extract the file ID from various Google Drive URL formats
  const match = url.match(/[?&]id=([^&]+)/);
  if (!match) return url;
  
  // Use lh3.googleusercontent.com which works without authentication
  return `https://lh3.googleusercontent.com/d/${match[1]}`;
};

// COMPONENT
export default function CharacterPhotos() {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const characterId = searchParams.get("id");
  
  const [photos, setPhotos] = useState<CharacterPhoto[]>([]);
  const [loading, setLoading] = useState(true);
  const [characterName, setCharacterName] = useState("");
  const [brokenImages, setBrokenImages] = useState<Set<string>>(new Set());
  const [selectedPhoto, setSelectedPhoto] = useState<CharacterPhoto | null>(null);
  const [canUntag, setCanUntag] = useState(false);
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile | null>(null);

  useEffect(() => {
    if (characterId) {
      loadPhotos();
    }
  }, [characterId]);

  // Load permissions and player profile
  useEffect(() => {
    const loadPermissionsAndProfile = async () => {
      try {
        const [permissionsResponse, profileResponse] = await Promise.all([
          apiClient.get_my_permissions(),
          apiClient.get_my_player_profile()
        ]);
        
        const permissionsData = await permissionsResponse.json();
        const profileData = await profileResponse.json();
        
        const hasGalleryPermission = permissionsData.permissions?.includes('manage_photo_galleries') || false;
        setCanUntag(hasGalleryPermission);
        setPlayerProfile(profileData);
      } catch (error) {
        console.error('Failed to load permissions or profile:', error);
      }
    };
    loadPermissionsAndProfile();
  }, []);

  const loadPhotos = async () => {
    if (!characterId) return;
    
    try {
      const response = await apiClient.get_character_photos({ characterId: characterId });
      const data = await response.json();
      setPhotos(data);
    } catch (error) {
      console.error("Failed to load photos:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleImageError = (photoId: string) => {
    setBrokenImages(prev => new Set(prev).add(photoId));
  };
    
  const handleDeleteTag = async (photoId: string) => {
    if (!confirm("Are you sure you want to untag this photo?")) return;
    
    try {
      // Find the tag ID for this photo and character combination
      // We need to get the tag_id from the photo object
      const photo = photos.find(p => p.photo_id === photoId);
      if (!photo) return;
      
      
      // Delete the tag using the tag_id from the photo object
      await apiClient.delete_photo_tag({ tagId: photo.tag_id });
      
      // Remove from local state
      setPhotos(prev => prev.filter(p => p.photo_id !== photoId));
    } catch (error) {
      console.error("Failed to delete tag:", error);
      alert("Failed to untag photo");
    }
  };

  // Check if current user can untag a specific photo
  const canUntagPhoto = (photo: CharacterPhoto): boolean => {
    if (!playerProfile) return false;
    
    // Admin with gallery permission can untag
    if (canUntag) return true;
    
    // Character owner can untag
    if (photo.player_profile_id === playerProfile.id) return true;
    
    return false;
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-950 via-slate-900 to-blue-950 p-8">
      <Card className="bg-slate-900/80 border-purple-500/30">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-3xl text-purple-300">
              Character Photos {characterName && `- ${characterName}`}
            </CardTitle>
            <Button
              onClick={() => navigate("/face-to-name")}
              variant="outline"
              className="border-purple-500/50"
            >
              Back to List
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="text-center text-purple-300">Loading photos...</div>
          ) : photos.length === 0 ? (
            <div className="text-center text-slate-400">No photos found for this character.</div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {photos.map((photo) => (
                <div
                  key={photo.photo_id}
                  className="relative group overflow-hidden rounded-lg border border-purple-500/30 bg-slate-800 cursor-pointer hover:border-purple-400/50 transition-colors"
                  onClick={() => setSelectedPhoto(photo)}
                >
                  {brokenImages.has(photo.photo_id) ? (
                    <div className="w-full h-64 flex items-center justify-center bg-slate-800">
                      <div className="text-center p-4">
                        <p className="text-slate-400 mb-2">Image unavailable</p>
                        <a 
                          href={photo.photo_url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-purple-400 hover:text-purple-300 underline text-sm"
                        >
                          View original
                        </a>
                      </div>
                    </div>
                  ) : (
                    <img
                      src={getGoogleDriveImageUrl(photo.photo_url)}
                      alt="Character photo"
                      className="w-full h-64 object-cover transition-transform group-hover:scale-105"
                      onError={() => handleImageError(photo.photo_id)}
                      loading="lazy"
                    />
                  )}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-purple-200">
                        Tagged: {new Date(photo.tagged_at).toLocaleDateString()}
                      </p>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedPhoto(photo);
                          }}
                          className="h-8 px-2 text-purple-300 hover:text-purple-100"
                        >
                          View
                        </Button>
                        {canUntagPhoto(photo) && (
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteTag(photo.photo_id);
                            }}
                            className="h-8 px-2 text-red-400 hover:text-red-300"
                          >
                            Untag
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Full-size photo dialog */}
      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-[90vw] max-h-[90vh] p-0 overflow-hidden bg-slate-900 border-purple-700/50">
          <DialogHeader className="p-4">
            <DialogTitle className="text-purple-300">
              {characterName && `${characterName} - `}
              Tagged: {selectedPhoto && new Date(selectedPhoto.tagged_at).toLocaleDateString()}
            </DialogTitle>
          </DialogHeader>
          
          {selectedPhoto && (
            <div className="p-4 pt-0 flex items-center justify-center">
              <img
                src={getGoogleDriveImageUrl(selectedPhoto.photo_url)}
                alt="Character photo full size"
                className="max-w-full max-h-[80vh] object-contain rounded"
                onError={(e) => {
                  console.error('Failed to load full-size image:', selectedPhoto.photo_url);
                  e.currentTarget.src = 'https://via.placeholder.com/800x600?text=Image+Not+Available';
                }}
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
