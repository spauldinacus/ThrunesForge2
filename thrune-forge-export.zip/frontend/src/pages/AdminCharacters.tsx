import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import { API_URL } from 'app';
import { auth } from 'app/auth';
import { toast } from 'sonner';
import { XPHistoryModal } from 'components/XPHistoryModal';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Home, Download, Search, Filter, SortAsc, SortDesc, Edit, TrendingUp, Trash2, Clock, MoreVertical, Pencil, Trash, ChevronLeft, ChevronRight, Users } from 'lucide-react';
import { ScrollArea } from "@/components/ui/scroll-area";
import type { CharacterDetail } from "types";
import type { XPTransaction } from 'types';
import { apiClient } from 'app';
import type { AdminCharacterListItem } from 'types';

const AdminCharacters = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  const [characters, setCharacters] = useState<Record<string, any>[]>([]);
  const [filteredCharacters, setFilteredCharacters] = useState<Record<string, any>[]>([]);
  const [selectedCharacters, setSelectedCharacters] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'alive' | 'dead'>('all');
  const [isLoading, setIsLoading] = useState(true);
  const [isXPModalOpen, setIsXPModalOpen] = useState(false);
  const [exportProgress, setExportProgress] = useState({
    show: false,
    totalCharacters: 0,
    progress: 0,
    status: ''
  });
  const [selectedCharacterForXP, setSelectedCharacterForXP] = useState<Record<string, any> | null>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [characterToDelete, setCharacterToDelete] = useState<Record<string, any> | null>(null);
  const [selectedCharacterDetail, setSelectedCharacterDetail] = useState<CharacterDetail | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [detailsLoading, setDetailsLoading] = useState(false);
  
  // Sorting state
  const [sortField, setSortField] = useState<string>('name');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

  // Check permissions on component mount
  React.useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.MANAGE_CHARACTERS)) {
      // Redirect to home if user doesn't have permission
      navigate('/');
      return;
    }
  }, [permissionsLoading, navigate]); // Remove hasPermission from dependencies

  useEffect(() => {
    loadCharacters();
  }, []);

  useEffect(() => {
    filterCharacters();
  }, [characters, searchTerm, statusFilter, sortField, sortDirection]);

  const loadCharacters = async () => {
    setIsLoading(true);
    try {
      const response = await apiClient.list_scoped_characters();
      const data = await response.json();
      setCharacters(data);
    } catch (error) {
      console.error('Failed to load characters:', error);
      toast.error('Failed to load characters');
    } finally {
      setIsLoading(false);
    }
  };

  const filterCharacters = () => {
    let filtered = characters;

    // Apply search filter
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (char) =>
          char.name.toLowerCase().includes(term) ||
          char.player_name.toLowerCase().includes(term) ||
          char.player_number.toLowerCase().includes(term) ||
          char.heritage_name.toLowerCase().includes(term) ||
          char.culture_name.toLowerCase().includes(term) ||
          char.archetype_name.toLowerCase().includes(term)
      );
    }

    // Apply status filter
    if (statusFilter !== 'all') {
      filtered = filtered.filter((char) =>
        statusFilter === 'dead' ? char.retired : !char.retired
      );
    }

    // Sort filtered results
    filtered.sort((a, b) => {
      let aValue = a[sortField];
      let bValue = b[sortField];
      
      // Handle special field types
      if (sortField === 'xp_total ' || sortField === 'xp_available' || sortField === 'events_attended' || sortField === 'corruption' || sortField === 'deaths') {
        aValue = Number(aValue) || 0;
        bValue = Number(bValue) || 0;
      } else if (typeof aValue === 'string' && typeof bValue === 'string') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }
      
      if (sortDirection === 'asc') {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

    setFilteredCharacters(filtered);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (field: string) => {
    if (sortField !== field) return null;
    return sortDirection === 'asc' ? <SortAsc className="h-4 w-4" /> : <SortDesc className="h-4 w-4" />;
  };

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      setSelectedCharacters(new Set(filteredCharacters.map((char) => char.id)));
    } else {
      setSelectedCharacters(new Set());
    }
  };

  const handleSelectCharacter = (characterId: string, checked: boolean) => {
    const newSelected = new Set(selectedCharacters);
    if (checked) {
      newSelected.add(characterId);
    } else {
      newSelected.delete(characterId);
    }
    setSelectedCharacters(newSelected);
  };

const handleBulkPDFExport = async () => {
  if (selectedCharacters.size === 0) {
    toast.error('Please select characters to export');
    return;
  }

  try {
    const characterIds = Array.from(selectedCharacters);
    
    // Initialize progress dialog
    setExportProgress({
      show: true,
      totalCharacters: characterIds.length,
      progress: 33,
      status: `Generating ${characterIds.length} character sheet(s)...`
    });
    
    // Use direct fetch for binary response
    const token = await auth.getAuthToken();
    
    // Use the environment-aware API URL
    const url = `${apiClient.baseUrl}/admin/characters/export-pdf`;
    
    const response = await fetch(url, {
      method: 'POST',
      credentials: 'include',
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(characterIds)
    });
    
    if (!response.ok) {
      throw new Error(`Export failed: ${response.status}`);
    }
    
    // Update progress
    setExportProgress(prev => ({
      ...prev,
      progress: 66,
      status: 'Processing PDF bundle...'
    }));
    
    // Get binary data as blob
    const blob = await response.blob();
    
    // Final progress update
    setExportProgress(prev => ({
      ...prev,
      progress: 100,
      status: 'Download starting...'
    }));
    
    const url2 = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url2;
    a.download = `character_sheets_${new Date().toISOString().split('T')[0]}.pdf`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url2);
    document.body.removeChild(a);
    
    toast.success(`Successfully exported ${characterIds.length} character sheet(s)!`);
    
    // Close dialog after a short delay
    setTimeout(() => {
      setExportProgress(prev => ({ ...prev, show: false }));
    }, 1000);
  } catch (error: any) {
    console.error('Failed to export character sheets:', error);
    setExportProgress(prev => ({ ...prev, show: false }));
    toast.error('Failed to export character sheets. Please try again.');
  }
};

  const loadCharacterDetails = async (characterId: string) => {
    setDetailsLoading(true);
    try {
      const response = await apiClient.get_admin_character({ characterId });
      const data = await response.json() as any;
      
      // Handle potential mismatch between backend (selected_skills) and frontend (skills)
      if (!data.skills && data.selected_skills) {
        data.skills = data.selected_skills;
      }
      
      setSelectedCharacterDetail(data);
      setIsDetailModalOpen(true);
    } catch (error) {
      console.error('Failed to load character details:', error);
      toast.error('Failed to load character details');
    } finally {
      setDetailsLoading(false);
    }
  };
  
  const handleEditCharacter = (characterId: string) => {
    // Validate character ID before navigation
    if (!characterId || typeof characterId !== 'string' || characterId.trim() === '') {
      console.error('Invalid character ID provided:', characterId);
      toast.error('Invalid character ID. Cannot edit character.');
      return;
    }

    // Verify character exists in our current list
    const characterExists = characters.some(char => char.id === characterId);
    if (!characterExists) {
      console.error('Character not found in current list:', characterId);
      toast.error('Character not found. Please refresh the page and try again.');
      return;
    }

    try {
      navigate(`/admin-character-editor?id=${encodeURIComponent(characterId)}`);
    } catch (error) {
      console.error('Navigation error:', error);
      toast.error('Failed to navigate to character editor. Please try again.');
    }
  };

  const handleViewXPHistory = async (character: Record<string, any>) => {
    setSelectedCharacterForXP(character);
    setIsXPModalOpen(true);
  };

  const handleXPTransactionChange = async () => {
    // Refresh character list to update XP totals
    await loadCharacters();
  };

  
  const handleDeleteCharacter = (character: Record<string, any>) => {
    setCharacterToDelete(character);
    setIsDeleteDialogOpen(true);
  };

  const confirmDeleteCharacter = async () => {
    if (!characterToDelete) return;

    try {
      const response = await apiClient.delete_admin_character({ characterId: characterToDelete.id });
      
      if (!response.ok) {
        throw new Error('Failed to delete character');
      }

      toast.success(`Character "${characterToDelete.name}" deleted successfully`);
      
      // Close dialog and reset state
      setIsDeleteDialogOpen(false);
      setCharacterToDelete(null);
      
      // Refresh character list
      await loadCharacters();
    } catch (error) {
      console.error('Failed to delete character:', error);
      toast.error('Failed to delete character');
    }
  };

  const stats = {
    total: characters.length,
    alive: characters.filter((c) => !c.retired).length,
    dead: characters.filter((c) => c.retired).length,
    avgXP: characters.length > 0 ? Math.round(characters.reduce((sum, c) => sum + c.xp_total, 0) / characters.length) : 0,
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
        {/* Page Header Skeleton */}
        <header className="relative z-5 flex justify-between items-center p-5">
          <div className="flex items-center space-x-4">
            <Skeleton className="h-9 w-20" />
          </div>
          
          <div className="flex items-center space-x-4">
            <Skeleton className="h-8 w-72" />
          </div>
          
          <div className="flex items-center space-x-4">
            <Skeleton className="h-9 w-32" />
          </div>
        </header>

        {/* Main Content Skeleton */}
        <main className="container mx-auto px-6 py-2">
          <div className="space-y-6">
            {/* Stats Cards Skeleton */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
              {[...Array(3)].map((_, i) => (
                <Card key={i}>
                  <CardContent className="pt-6">
                    <Skeleton className="h-8 w-16 mb-2" />
                    <Skeleton className="h-4 w-24" />
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Filters Skeleton */}
            <div className="flex flex-col sm:flex-row gap-4">
              <Skeleton className="h-10 flex-1" />
              <Skeleton className="h-10 w-full sm:w-[180px]" />
            </div>

            {/* Table Skeleton */}
            <Card>
              <div className="space-y-4 p-4">
                {[...Array(8)].map((_, i) => (
                  <Skeleton key={i} className="h-16 w-full" />
                ))}
              </div>
            </Card>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Page Header */}
      <header className="relative z-5 flex justify-between items-center p-5">
        <div className="flex items-center space-x-4">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/')}
            className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10"
          >
            <Home className="w-4 h-4 mr-2" />
            Home
          </Button>
        </div>
        
        <div className="flex items-center space-x-4">
          <h1 className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-blue-400 to-amber-400">
            Admin Character Management
          </h1>
        </div>
        
        <div className="flex items-center space-x-4">
          <Button 
            onClick={handleBulkPDFExport}
            disabled={selectedCharacters.size === 0}
            className="bg-purple-600 hover:bg-purple-700 flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            Export PDFs ({selectedCharacters.size})
          </Button>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-2">
        <div className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{characters.length}</div>
                <p className="text-xs text-muted-foreground">Total Characters</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-green-600">{characters.filter(c => !c.retired).length}</div>
                <p className="text-xs text-muted-foreground">Active</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold text-red-600">{characters.filter(c => c.retired).length}</div>
                <p className="text-xs text-muted-foreground">Retired</p>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search characters, players, or heritage..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={(value: 'all' | 'alive' | 'dead') => setStatusFilter(value)}>
              <SelectTrigger className="w-full sm:w-[180px]">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Characters</SelectItem>
                <SelectItem value="alive">Active Only</SelectItem>
                <SelectItem value="dead">Retired Only</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Characters Table */}
          <Card>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="w-12">
                    <Checkbox
                      checked={selectedCharacters.size === filteredCharacters.length && filteredCharacters.length > 0}
                      onCheckedChange={handleSelectAll}
                    />
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('name')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Character</span>
                      {getSortIcon('name')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('player_name')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Player</span>
                      {getSortIcon('player_name')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('heritage_name')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Heritage/Culture</span>
                      {getSortIcon('heritage_name')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('archetype_name')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Archetype</span>
                      {getSortIcon('archetype_name')}
                    </div>
                  </TableHead>
                  <TableHead>Stats</TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('xp_total')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>XP</span>
                      {getSortIcon('xp_total')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('events_attended')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Events</span>
                      {getSortIcon('events_attended')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('retired')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Status</span>
                      {getSortIcon('retired')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('deaths')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Deaths</span>
                      {getSortIcon('deaths')}
                    </div>
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => handleSort('corruption')}
                  >
                    <div className="flex items-center space-x-1">
                      <span>Corruption</span>
                      {getSortIcon('corruption')}
                    </div>
                  </TableHead>
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredCharacters.map((character, index) => (
                  <TableRow key={character.id || `char-${index}`}>
                    <TableCell>
                      <Checkbox
                        checked={selectedCharacters.has(character.id)}
                        onCheckedChange={(checked) => handleSelectCharacter(character.id, checked as boolean)}
                      />
                    </TableCell>
                    <TableCell>
                      <div 
                        className="font-medium cursor-pointer text-purple-300 hover:text-purple-100 hover:underline"
                        onClick={() => loadCharacterDetails(character.id)}
                      >
                        {character.name}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {character.skill_count || 0} skills
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="font-medium">{character.player_name}</div>
                      <div className="text-sm text-muted-foreground">
                        {character.player_number}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{character.heritage_name}</div>
                        <div className="text-muted-foreground">{character.culture_name}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>{character.archetype_name}</div>
                        {character.secondary_archetype_name && (
                          <div className="text-muted-foreground">
                            + {character.secondary_archetype_name}
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div>Body: {character.body}</div>
                        <div>Stamina: {character.stamina}</div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <div className="font-semibold text-amber-400">
                          {character.xp_available} XP available
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {character.xp_total} XP earned total
                        </div>
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="outline">{character.events_attended}</Badge>
                    </TableCell>
                    <TableCell>
                      {character.retired ? (
                        <Badge variant="destructive">Retired</Badge>
                      ) : (
                        <Badge variant="default">Active</Badge>
                      )}
                    </TableCell>
                    <TableCell>
                      <Badge 
                        variant={character.deaths > 0 ? "destructive" : "outline"}
                        className={character.deaths > 0 ? "bg-red-900/30 text-red-300 border-red-600/50" : "bg-gray-900/30 text-gray-300 border-gray-600/50"}
                      >
                        {character.deaths || 0}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      <div className="text-sm">
                        <Badge 
                          variant={character.corruption >= 5 ? "destructive" : character.corruption >= 3 ? "secondary" : "outline"}
                          className={character.corruption >= 5 ? "bg-red-900/30 text-red-300 border-red-600/50" : 
                                   character.corruption >= 3 ? "bg-orange-900/30 text-orange-300 border-orange-600/50" : 
                                   "bg-gray-900/30 text-gray-300 border-gray-600/50"}
                        >
                          {character.corruption}/10
                        </Badge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditCharacter(character.id)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleViewXPHistory(character)}
                        >
                          <TrendingUp className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteCharacter(character)}
                          className="border-red-500/50 text-red-400 hover:bg-red-500/10"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Card>

          {filteredCharacters.length === 0 && (
            <div className="text-center py-8">
              <p className="text-muted-foreground">No characters found matching your criteria.</p>
            </div>
          )}
        </div>

        {/* Character Detail Modal */}
        <Dialog open={isDetailModalOpen} onOpenChange={setIsDetailModalOpen}>
          <DialogContent className="max-w-4xl max-h-[80vh] bg-slate-900 border-purple-500/30">
            <DialogHeader>
              <DialogTitle className="text-purple-100">
                {selectedCharacterDetail?.name || 'Character Details'}
              </DialogTitle>
            </DialogHeader>
            
            {detailsLoading ? (
              <div className="space-y-4">
                <Skeleton className="h-6 w-full" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-32 w-full" />
              </div>
            ) : selectedCharacterDetail ? (
              <ScrollArea className="max-h-[60vh]">
                <div className="space-y-6 pr-4">
                  {/* Character Info */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <h3 className="text-lg font-semibold text-purple-100 mb-2">Character Info</h3>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-purple-300">Heritage:</span> <span className="text-purple-100">{selectedCharacterDetail.heritage_name}</span></p>
                        <p><span className="text-purple-300">Culture:</span> <span className="text-purple-100">{selectedCharacterDetail.culture_name}</span></p>
                        <p><span className="text-purple-300">Archetype:</span> <span className="text-purple-100">{selectedCharacterDetail.archetype_name}</span></p>
                        {selectedCharacterDetail.secondary_archetype_name && (
                          <p><span className="text-purple-300">Secondary Archetype:</span> <span className="text-purple-100">{selectedCharacterDetail.secondary_archetype_name}</span></p>
                        )}
                        {selectedCharacterDetail.tertiary_archetype_name && (
                          <p><span className="text-purple-300">Tertiary Archetype:</span> <span className="text-purple-100">{selectedCharacterDetail.tertiary_archetype_name}</span></p>
                        )}
                        <p><span className="text-purple-300">Status:</span> <span className={selectedCharacterDetail.retired ? 'text-red-400' : 'text-green-400'}>{selectedCharacterDetail.retired ? 'Retired' : 'Active'}</span></p>
                        <p><span className="text-purple-300">Deaths:</span> <span className="text-purple-100">{selectedCharacterDetail.deaths || 0}</span></p>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-lg font-semibold text-purple-100 mb-2">Stats & XP</h3>
                      <div className="space-y-2 text-sm">
                        <p><span className="text-red-400">Body:</span> <span className="text-purple-100">{selectedCharacterDetail.body}</span></p>
                        <p><span className="text-blue-400">Stamina:</span> <span className="text-purple-100">{selectedCharacterDetail.stamina}</span></p>
                        <p><span className="text-yellow-400">XP Available:</span> <span className="text-purple-100">{selectedCharacterDetail.xp_available}</span></p>
                        <p><span className="text-purple-300">Total XP:</span> <span className="text-purple-100">{selectedCharacterDetail.xp_total}</span></p>
                        <p><span className="text-purple-300">Events:</span> <span className="text-purple-100">{selectedCharacterDetail.events_attended}</span></p>
                        <p><span className="text-orange-400">Corruption:</span> <span className="text-purple-100">{selectedCharacterDetail.corruption || 0}/10</span></p>
                      </div>
                    </div>
                  </div>
                                                
                  {/* Heritage Benefits & Flaws */}
                  <div>
                    <h3 className="text-lg font-semibold text-purple-100 mb-2">Heritage: {selectedCharacterDetail.heritage_name}</h3>
                    <div className="space-y-2 text-sm">
                      <div className="p-3 bg-green-900/20 rounded border border-green-500/30">
                        <div className="text-green-400 font-medium mb-1">
                          {selectedCharacterDetail.heritage.benefit_name || 'Benefit'}
                        </div>
                        <p className="text-purple-100">{selectedCharacterDetail.heritage.benefit}</p>
                      </div>
                      <div className="p-3 bg-red-900/20 rounded border border-red-500/30">
                        <div className="text-red-400 font-medium mb-1">
                          {selectedCharacterDetail.heritage.weakness_name || 'Weakness'}
                        </div>
                        <p className="text-purple-100">{selectedCharacterDetail.heritage.weakness}</p>
                      </div>
                    </div>
                  </div>
                  
                  {/* Culture Benefits */}
                  <div>
                    <h3 className="text-lg font-semibold text-purple-100 mb-2">Culture: {selectedCharacterDetail.culture_name}</h3>
                    <div className="p-3 bg-blue-900/20 rounded border border-blue-500/30">
                      <div className="text-blue-400 font-medium mb-1">
                        {selectedCharacterDetail.culture.benefit_name || 'Cultural Benefit'}
                      </div>
                      <p className="text-purple-100">{selectedCharacterDetail.culture.benefit}</p>
                    </div>
                  </div>

                  {/* Skills */}
                  <div>
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-lg font-semibold text-purple-100">Skills ({selectedCharacterDetail.skills.length})</h3>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {selectedCharacterDetail.skills.map((skill, index) => (
                        <div key={skill.id || `skill-${index}`} className="flex items-center justify-between p-2 bg-slate-800/50 rounded border border-purple-500/20">
                          <div>
                            <span className="text-purple-100 font-medium">{skill.name}</span>
                            {skill.is_primary && <Badge variant="default" className="ml-2 text-xs">Primary</Badge>}
                            {skill.is_secondary && !skill.is_primary && <Badge variant="secondary" className="ml-2 text-xs">Secondary</Badge>}
                          </div>
                          <span className="text-yellow-400 text-sm">{skill.xp_cost} XP</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* Notes */}
                  <div>
                    <h3 className="text-lg font-semibold text-purple-100 mb-3">Notes</h3>
                    <div className="mb-3">
                      <h4 className="text-purple-300 font-medium mb-1">Player Notes:</h4>
                      <p className="text-purple-100 text-sm bg-slate-800/30 p-3 rounded border border-purple-500/20 whitespace-pre-wrap">
                        {selectedCharacterDetail.player_notes || <span className="text-purple-400 italic">No player notes recorded</span>}
                      </p>
                    </div>
                    <div>
                      <h4 className="text-purple-300 font-medium mb-1">Addictions/Diseases:</h4>
                      <p className="text-purple-100 text-sm bg-slate-800/30 p-3 rounded border border-purple-500/20 whitespace-pre-wrap">
                        {selectedCharacterDetail.addictions_diseases || <span className="text-purple-400 italic">No addictions or diseases recorded</span>}
                      </p>
                    </div>
                  </div>
                  
                  {/* XP History Button */}
                  <div className="flex justify-center">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        handleViewXPHistory(selectedCharacterDetail);
                        // Optional: close this modal if you want only one open at a time
                        // setIsDetailModalOpen(false);
                      }}
                      className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
                    >
                      <Clock className="w-4 h-4 mr-2" />
                      View XP History
                    </Button>
                  </div>
                </div>
              </ScrollArea>
            ) : null}
          </DialogContent>
        </Dialog>
        
        {/* XP History Modal */}
        {selectedCharacterForXP && (
          <XPHistoryModal
            open={isXPModalOpen}
            onOpenChange={setIsXPModalOpen}
            characterId={selectedCharacterForXP.id}
            characterName={selectedCharacterForXP.name}
            onTransactionChange={handleXPTransactionChange}
          />
        )}

        {/* Export Progress Dialog */}
        <Dialog open={exportProgress.show} onOpenChange={(open) => !open && setExportProgress(prev => ({ ...prev, show: false }))}>
          <DialogContent className="bg-slate-900 border-purple-500/30">
            <DialogHeader>
              <DialogTitle className="text-purple-100">Exporting Character Sheets</DialogTitle>
              <DialogDescription className="text-purple-300">
                Generating PDF for {exportProgress.totalCharacters} character(s)...
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="w-full bg-gray-700 rounded-full h-2.5">
                <div 
                  className="bg-gradient-to-r from-purple-600 to-blue-600 h-2.5 rounded-full transition-all duration-300"
                  style={{ width: `${exportProgress.progress}%` }}
                ></div>
              </div>
              <p className="text-sm text-purple-200 text-center">{exportProgress.status}</p>
            </div>
          </DialogContent>
        </Dialog>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
          <AlertDialogContent className="bg-slate-900 border-purple-500/30">
            <AlertDialogHeader>
              <AlertDialogTitle className="text-purple-100">Are you absolutely sure?</AlertDialogTitle>
              <AlertDialogDescription className="text-purple-300">
                This will permanently delete the character <span className="font-bold text-red-400">"{characterToDelete?.name}"</span> and all associated data including XP transactions and event RSVPs. This action cannot be undone.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel className="border-purple-500/50 text-purple-400 hover:bg-purple-500/10">
                Cancel
              </AlertDialogCancel>
              <AlertDialogAction 
                onClick={confirmDeleteCharacter}
                className="bg-red-600 hover:bg-red-700 text-white"
              >
                Delete Character
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </main>
    </div>
  );
};

export default AdminCharacters;
