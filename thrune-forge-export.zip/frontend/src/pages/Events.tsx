import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Calendar, Clock, MapPin, X, Filter, Users, Edit2, ExternalLink, CheckCircle2, XCircle, User, Star } from "lucide-react";
import { toast } from "sonner";
import { useUserGuardContext } from "app/auth";
import { apiClient } from "app";
import RSVPModal from "components/RSVPModal";
import { CharacterSelectionDialog } from "components/CharacterSelectionDialog";
import { usePermissions } from "utils/usePermissions";
import { formatDateForDisplay, formatTimeForDisplay } from 'utils/timezone';
import type { PublicEventResponse, PublicChapterResponse } from 'types';

type EventStatus = "scheduled" | "completed" | "cancelled" ;
type RSVPStatus = "attending" | "not_attending" | "waitlisted" | "tentative" | "no_rsvp";

export default function Events() {
  const navigate = useNavigate();
  const { user } = useUserGuardContext();
  const { permissions, hasPermission } = usePermissions();
  
  // State
  const [events, setEvents] = useState<EventSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  // RSVP Modal
  const [rsvpModalOpen, setRSVPModalOpen] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState<EventSummary | null>(null);
  const [selectedRSVPForUpdate, setSelectedRSVPForUpdate] = useState<RSVPStatus | null>(null);
  const [rsvpMode, setRSVPMode] = useState<'create' | 'update'>('create');
  
  // Character Selection Dialog for multi-character updates
  const [characterSelectionOpen, setCharacterSelectionOpen] = useState(false);
  const [pendingEvent, setPendingEvent] = useState<EventSummary | null>(null);
  
  // Filters
  const [statusFilter, setStatusFilter] = useState<EventStatus | "all">("scheduled");
  const [chapterFilter, setChapterFilter] = useState<string | "all">("all");
  const [fromDate, setFromDate] = useState<string>("");
  const [toDate, setToDate] = useState<string>("");

  // Check if user has admin permissions
  const isAdmin = hasPermission('view_admin_panel') || hasPermission('manage_players');

  // Load events
  const loadEvents = async () => {
    setLoading(true);
    try {
      const response = await apiClient.list_events({});
      const data = await response.json();
      setEvents(data.events || []);
    } catch (error) {
      console.error('Failed to load events:', error);
      setError('Failed to load events. Please try again.');
      toast.error('Failed to load events');
    } finally {
      setLoading(false);
    }
  };

  // Open RSVP modal with character selection for multi-character updates
  const handleUpdateRSVP = (event: EventSummary) => {
    const existingRSVPs = event.my_rsvps || [];
    // Filter out attended characters - they cannot be edited
    const editableRSVPs = existingRSVPs.filter(rsvp => 
      (rsvp as any).attendance_status !== 'attended'
    );
    
    if (editableRSVPs.length > 1) {
      // Multiple editable characters - show character selection dialog first
      setPendingEvent({...event, my_rsvps: editableRSVPs});
      setCharacterSelectionOpen(true);
    } else if (editableRSVPs.length === 1) {
      // Single editable character - proceed directly to update
      setSelectedEvent(event);
      setSelectedRSVPForUpdate(editableRSVPs[0]);
      setRSVPMode('update');
      setRSVPModalOpen(true);
    } else {
      // No editable RSVPs - create new
      setSelectedEvent(event);
      setSelectedRSVPForUpdate(null);
      setRSVPMode('create');
      setRSVPModalOpen(true);
    }
  };

  // Open RSVP modal for adding another character
  const handleAddAnotherCharacter = (event: EventSummary) => {
    setSelectedEvent(event);
    setSelectedRSVPForUpdate(null);
    setRSVPMode('create');
    setRSVPModalOpen(true);
  };

  // Handle character selection for multi-character updates
  const handleCharacterSelected = (rsvp: RSVPStatus) => {
    if (pendingEvent) {
      setSelectedEvent(pendingEvent);
      setSelectedRSVPForUpdate(rsvp);
      setRSVPMode('update');
      setCharacterSelectionOpen(false);
      setPendingEvent(null);
      setRSVPModalOpen(true);
    }
  };

  // Handle RSVP success
  const handleRSVPSuccess = async () => {
    await loadEvents(); // Refresh events to show updated RSVPs
    setSelectedRSVPForUpdate(null);
    setRSVPMode('create');
  };

  // Reset filters
  const resetFilters = () => {
    setStatusFilter("scheduled");
    setChapterFilter("all");
    setFromDate("");
    setToDate("");
  };

  // Load events on mount and filter changes
  useEffect(() => {
    loadEvents();
  }, [statusFilter, chapterFilter, fromDate, toDate]);

  const getRSVPBadgeColor = (status: string) => {
    switch (status) {
      case 'going': return 'bg-green-600/20 text-green-300 border-green-500/30';
      case 'maybe': return 'bg-amber-600/20 text-amber-300 border-amber-500/30';
      case 'not_attending': return 'bg-red-600/20 text-red-300 border-red-500/30';
      default: return '';
    }
  };

  const getAttendanceBadgeColor = (attendanceStatus: string) => {
    switch (attendanceStatus) {
      case 'attended': return 'bg-blue-600/20 text-blue-300 border-blue-500/30';
      case 'no_show': return 'bg-red-600/20 text-red-300 border-red-500/30';
      case 'rsvp': return 'bg-gray-600/20 text-gray-300 border-gray-500/30';
      default: return 'bg-gray-600/20 text-gray-300 border-gray-500/30';
    }
  };

  const getStatusBadgeColor = (status: EventStatus) => {
    switch (status) {
      case 'scheduled': return 'bg-green-600/20 text-green-300 border-green-500/30';
      case 'completed': return 'bg-blue-600/20 text-blue-300 border-blue-500/30';
      case 'cancelled': return 'bg-red-600/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-600/20 text-gray-300 border-gray-500/30';
    }
  };

  // Calculate total XP for an event's RSVPs
  const getTotalXP = (rsvps: any[]) => {
    return rsvps.reduce((total, rsvp) => total + (rsvp.ticket_xp || 0) + (rsvp.candle_xp || 0), 0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Navigation Header */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Events
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="p-4 rounded-full bg-gradient-to-br from-blue-500/20 to-indigo-500/20">
              <Calendar className="w-12 h-12 text-blue-300" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-indigo-400 mb-4">
            Events
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
            Browse and RSVP for LARP events. Join fellow adventurers in epic quests and memorable experiences.
          </p>
        </div>

        {/* Filters */}
        <div className="mb-8">
          <Card className="bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-sm border-purple-500/30">
            <CardHeader>
              <div className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-purple-300" />
                <CardTitle className="text-white">Filters</CardTitle>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <Label htmlFor="status-filter" className="text-slate-300">Status</Label>
                  <Select value={statusFilter} onValueChange={(value: EventStatus | "all") => setStatusFilter(value)}>
                    <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                      <SelectValue placeholder="All statuses" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="all" className="text-white">All Events</SelectItem>
                      <SelectItem value="scheduled" className="text-white">Scheduled</SelectItem>
                      <SelectItem value="completed" className="text-white">Completed</SelectItem>
                      <SelectItem value="cancelled" className="text-white">Cancelled</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="chapter-filter" className="text-slate-300">Chapter</Label>
                  <Select value={chapterFilter} onValueChange={(value: string) => setChapterFilter(value)}>
                    <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                      <SelectValue placeholder="All chapters" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-slate-600">
                      <SelectItem value="all" className="text-white">All Chapters</SelectItem>
                      {Array.from(new Map(events.map(event => [event.chapter.id, event.chapter])).values())
                        .filter(chapter => chapter.id && chapter.id.trim() !== '')
                        .map((chapter) => (
                          <SelectItem key={chapter.id} value={chapter.id} className="text-white">
                            {chapter.name}
                          </SelectItem>
                        ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="from-date" className="text-slate-300">From Date</Label>
                  <Input
                    id="from-date"
                    type="date"
                    value={fromDate}
                    onChange={(e) => setFromDate(e.target.value)}
                    className="bg-slate-800/50 border-slate-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="to-date" className="text-slate-300">To Date</Label>
                  <Input
                    id="to-date"
                    type="date"
                    value={toDate}
                    onChange={(e) => setToDate(e.target.value)}
                    className="bg-slate-800/50 border-slate-600 text-white"
                  />
                </div>
              </div>
              <div className="flex justify-end mt-4">
                <Button
                  variant="outline"
                  onClick={resetFilters}
                  className="border-slate-600 text-slate-300 hover:bg-slate-700"
                >
                  <X className="w-4 h-4 mr-2" />
                  Reset
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-sm border-blue-500/30">
                <CardHeader>
                  <Skeleton className="h-6 w-3/4 bg-slate-700" />
                  <Skeleton className="h-4 w-1/4 bg-slate-700" />
                </CardHeader>
                <CardContent className="space-y-3">
                  <Skeleton className="h-4 w-full bg-slate-700" />
                  <Skeleton className="h-4 w-full bg-slate-700" />
                  <Skeleton className="h-4 w-2/3 bg-slate-700" />
                  <Skeleton className="h-10 w-full bg-slate-700" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="text-center py-12">
            <div className="text-red-400 text-lg mb-4">{error}</div>
            <Button onClick={loadEvents} className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
              Try Again
            </Button>
          </div>
        )}

        {/* Empty State */}
        {!loading && !error && events.length === 0 && (
          <div className="text-center py-12">
            <div className="text-slate-400 text-lg mb-4">No events found</div>
            <p className="text-slate-500 mb-6">Try adjusting your filters or check back later for new events.</p>
            <Button onClick={resetFilters} variant="outline" className="border-slate-600 text-slate-300 hover:bg-slate-700">
              Clear Filters
            </Button>
          </div>
        )}

        {/* Events Grid */}
        {!loading && !error && events.length > 0 && (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {events.map((event) => (
              <Card key={event.id} className="group transition-all duration-300 hover:scale-105 bg-gradient-to-br from-blue-600/20 to-indigo-600/20 backdrop-blur-sm border-blue-500/30 hover:border-blue-400/60 shadow-xl hover:shadow-2xl hover:shadow-blue-500/20">
                <CardHeader>
                  <div className="flex justify-between items-start mb-2">
                    <CardTitle className="text-white text-lg group-hover:text-blue-200 transition-colors">
                      {event.title}
                    </CardTitle>
                    <Badge className={getStatusBadgeColor(event.status)}>
                      {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="text-sm text-slate-400">
                    {event.chapter.name}
                  </div>
                  
                  {/* Enhanced RSVP Display */}
                  {event.my_rsvps && event.my_rsvps.length > 0 && (
                    <div className="space-y-2 mt-3">
                      {event.my_rsvps.map((rsvp, index) => {
                        const isAttended = (rsvp as any).attendance_status === 'attended';
                        const attendanceStatus = (rsvp as any).attendance_status || 'rsvp';
                        
                        return (
                          <div key={index} className="flex items-center justify-between p-2 rounded-lg bg-slate-800/30 border border-slate-600/30">
                            <div className="flex items-center gap-2">
                              <div className="flex flex-col gap-1">
                                <Badge className={getRSVPBadgeColor(rsvp.status)} size="sm">
                                  {rsvp.status.replace('_', ' ').toUpperCase()}
                                </Badge>
                                {attendanceStatus !== 'rsvp' && (
                                  <Badge className={getAttendanceBadgeColor(attendanceStatus)} size="sm">
                                    {attendanceStatus.toUpperCase()}
                                  </Badge>
                                )}
                              </div>
                              {rsvp.character_name && (
                                <div className="flex items-center gap-1 text-xs text-slate-300">
                                  <User className="w-3 h-3" />
                                  {rsvp.character_name}
                                  {isAttended && <span className="text-blue-300 ml-1">(Attended)</span>}
                                </div>
                              )}
                            </div>
                            {(rsvp.ticket_xp > 0 || rsvp.candle_xp > 0) && (
                              <div className="flex items-center gap-1 text-xs text-amber-300">
                                <Star className="w-3 h-3" />
                                {(rsvp.ticket_xp || 0) + (rsvp.candle_xp || 0)} XP
                              </div>
                            )}
                          </div>
                        );
                      })}
                      {event.my_rsvps.length > 1 && (
                        <div className="text-xs text-slate-400 text-center">
                          {event.my_rsvps.length} characters registered
                        </div>
                      )}
                    </div>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center text-blue-400 mb-1">
                    <Calendar className="w-4 h-4 mr-2" />
                    <span className="text-sm">
                      {formatDateForDisplay(event.starts_at)}
                    </span>
                  </div>
                  <div className="flex items-center text-blue-400 mb-1">
                    <Clock className="w-4 h-4 mr-2" />
                    <span className="text-sm">
                      {formatTimeForDisplay(event.starts_at)} - {formatTimeForDisplay(event.ends_at)}
                    </span>
                  </div>
                  {event.location && (
                    <div className="flex items-center text-slate-300 text-sm">
                      <MapPin className="w-4 h-4 mr-2 text-blue-400" />
                      {event.location}
                    </div>
                  )}
                  <div className="flex items-center text-slate-300 text-sm">
                    <Users className="w-4 h-4 mr-2 text-blue-400" />
                    {event.rsvp_count} RSVPs
                  </div>
                  {/* Player's characters RSVPed */}
                  {event.my_rsvps && event.my_rsvps.length > 0 && (
                    <div className="text-xs text-slate-400 ml-6">
                      Your characters: {event.my_rsvps
                        .filter(rsvp => rsvp.character_name && rsvp.status !== 'not_attending')
                        .map(rsvp => rsvp.character_name)
                        .join(', ') || 'General RSVP'}
                    </div>
                  )}
                  {event.description && (
                    <p className="text-slate-400 text-sm line-clamp-2">
                      {event.description}
                    </p>
                  )}
                  
                  {/* RSVP Actions */}
                  {event.status === 'scheduled' && (
                    <div className="space-y-2 pt-2">
                      {(() => {
                        // Check if any characters are marked as attended (cannot be edited)
                        const attendedCharacters = (event.my_rsvps || []).filter(rsvp => 
                          (rsvp as any).attendance_status === 'attended'
                        );
                        const editableRsvps = (event.my_rsvps || []).filter(rsvp => 
                          (rsvp as any).attendance_status !== 'attended'
                        );
                        const hasAttendedCharacters = attendedCharacters.length > 0;
                        
                        return (
                          <>
                            <Button
                              onClick={() => handleUpdateRSVP(event)}
                              disabled={editableRsvps.length === 0 && hasAttendedCharacters}
                              className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                              {event.my_rsvps && event.my_rsvps.length > 0 ? 
                                (editableRsvps.length === 0 ? 'RSVPs Finalized' : 'Update RSVP') : 
                                'RSVP to Event'
                              }
                            </Button>
                            
                            {/* Show option to add another character if already RSVPed and not all attended */}
                            {event.my_rsvps && event.my_rsvps.length > 0 && (
                              <Button
                                variant="outline"
                                onClick={() => handleAddAnotherCharacter(event)}
                                className="w-full border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                              >
                                Add Another Character
                              </Button>
                            )}
                            
                            {/* Show info message if some characters are attended */}
                            {hasAttendedCharacters && (
                              <div className="text-xs text-blue-300 text-center p-2 bg-blue-600/10 rounded border border-blue-500/30">
                                <span className="font-medium">{attendedCharacters.length}</span> character(s) marked as attended by admin. 
                                These RSVPs cannot be modified.
                              </div>
                            )}
                          </>
                        );
                      })()}
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/3 left-1/4 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/4 right-1/3 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>
      
      {/* Character Selection Dialog */}
      <Dialog open={characterSelectionOpen} onOpenChange={setCharacterSelectionOpen}>
        <DialogContent className="max-w-md bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-sm border-purple-500/30">
          <DialogHeader>
            <DialogTitle className="text-white text-xl">
              Select Character to Update
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-slate-300 text-sm">
              You have multiple characters registered for this event. Which character's RSVP would you like to update?
            </p>
            <div className="space-y-2">
              {pendingEvent?.my_rsvps?.map((rsvp, index) => (
                <Button
                  key={index}
                  variant="outline"
                  onClick={() => handleCharacterSelected(rsvp)}
                  className="w-full justify-start border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                >
                  <div className="flex items-center gap-3">
                    <User className="w-4 h-4" />
                    <div className="text-left">
                      <div className="font-medium">
                        {rsvp.character_name || 'General RSVP'}
                      </div>
                      <div className="text-xs text-slate-400">
                        Status: {rsvp.status.replace('_', ' ').toUpperCase()}
                        {(rsvp.ticket_xp > 0 || rsvp.candle_xp > 0) && (
                          <span className="ml-2">
                            | {(rsvp.ticket_xp || 0) + (rsvp.candle_xp || 0)} XP
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </Button>
              ))}
            </div>
            <div className="flex justify-end">
              <Button
                variant="outline"
                onClick={() => setCharacterSelectionOpen(false)}
                className="border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Enhanced RSVP Modal */}
      {selectedEvent && (
        <RSVPModal
          open={rsvpModalOpen}
          onOpenChange={setRSVPModalOpen}
          event={selectedEvent}
          onRSVPSuccess={handleRSVPSuccess}
          rsvpMode={rsvpMode}
          selectedRSVPForUpdate={selectedRSVPForUpdate}
        />
      )}
    </div>
  );
}
