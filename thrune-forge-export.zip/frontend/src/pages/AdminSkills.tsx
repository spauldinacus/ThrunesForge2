

import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Zap } from "lucide-react";
import { usePermissions } from 'utils/usePermissions';
import { PERMISSIONS } from 'utils/permissions';
import SkillsAdmin from 'components/SkillsAdmin';

export default function AdminSkills() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();

  // Check permissions on component mount
  React.useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.MANAGE_SKILLS)) {
      // Redirect to home if user doesn't have permission
      navigate('/');
      return;
    }
  }, [permissionsLoading, navigate]); // Remove hasPermission from dependencies

  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-purple-300">Loading...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="p-2 rounded-full bg-gradient-to-br from-blue-500/20 to-purple-500/20">
            <Zap className="w-6 h-6 text-blue-300" />
          </div>
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-400">
            Skills Administration
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <SkillsAdmin />
        
        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-purple-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>
    </div>
  );
}
