import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePermissions } from 'utils/usePermissions';
import { Role, RoleCreate, RoleUpdate, Permission } from 'types';
import { PERMISSIONS } from 'utils/permissions';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Pencil, Plus, Trash2, Users, Shield, Key, Edit, Edit2, ArrowLeft } from 'lucide-react';

interface RoleWithAssignments extends Role {
  user_count?: number;
}

interface CreateRoleFormData {
  name: string;
  description: string;
  permission_ids: string[];
}

export default function AdminRoles() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();

  const [roles, setRoles] = useState<Role[]>([]);
  const [permissions, setPermissions] = useState<Permission[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<Role | null>(null);
  const [createForm, setCreateForm] = useState<CreateRoleFormData>({
    name: '',
    description: '',
    permission_ids: []
  });

  // Load roles and permissions data
  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      const [rolesResponse, permissionsResponse] = await Promise.all([
        apiClient.list_all_roles(),
        apiClient.list_permissions()
      ]);
      
      if (!rolesResponse.ok || !permissionsResponse.ok) {
        throw new Error('Failed to load data');
      }
      
      const rolesData = await rolesResponse.json();
      const permissionsData = await permissionsResponse.json();
      
      // Deduplicate roles by ID and deduplicate permissions within each role
      const uniqueRoles = rolesData.filter((role: Role, index: number, self: Role[]) => 
        index === self.findIndex((r: Role) => r.id === role.id)
      ).map((role: Role) => ({
        ...role,
        permissions: role.permissions.filter((permission, index, self) => 
          index === self.findIndex((p) => p.id === permission.id)
        )
      }));
      
      setRoles(uniqueRoles);
      setPermissions(permissionsData);
    } catch (error: any) {
      console.error('Failed to load data:', error);
      setError('Failed to load roles and permissions');
    } finally {
      setLoading(false);
    }
  };

  // Check permissions and load data
  useEffect(() => {
    if (!permissionsLoading) {
      if (!hasPermission(PERMISSIONS.MANAGE_ROLES)) {
        navigate('/');
        return;
      }
      loadData();
    }
  }, [permissionsLoading, navigate]); // Remove hasPermission from dependencies

  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-purple-300">Loading...</div>
      </div>
    );
  }

  // Show access denied if user doesn't have permission
  if (!hasPermission(PERMISSIONS.MANAGE_ROLES)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-red-400">Access denied. You don't have permission to manage roles.</div>
      </div>
    );
  }

  const handleCreateRole = async () => {
    if (!createForm.name.trim()) {
      toast.error('Role name is required');
      return;
    }

    const createData: RoleCreate = {
      name: createForm.name,
      description: createForm.description || null,
      permission_ids: createForm.permission_ids
    };

    try {
      const response = await apiClient.create_role(createData);
      if (response.ok) {
        const createdRole = await response.json();
        setRoles([...roles, createdRole]);
        setCreateForm({ name: '', description: '', permission_ids: [] });
        setIsCreateOpen(false);
        toast.success('Role created successfully!');
      } else {
        // Parse the error response to get the specific error message
        let errorMessage = 'Failed to create role';
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            errorMessage = errorData.detail;
          }
        } catch {
          // If we can't parse JSON, use the status text or default message
          errorMessage = response.statusText || 'Failed to create role';
        }
        toast.error(errorMessage);
      }
    } catch (error) {
      console.error('Failed to create role:', error);
      toast.error('Failed to create role. Please try again.');
    }
  };

  const handleUpdateRole = async () => {
    if (!selectedRole || !selectedRole.id) return;

    const updateData: RoleUpdate = {
      name: selectedRole.name,
      description: selectedRole.description || null,
      permission_ids: selectedRole.permissions.map(p => p.id)
    };

    try {
      const response = await apiClient.update_role({ roleId: selectedRole.id }, updateData);
      if (response.ok) {
        const updatedRole = await response.json();
        setRoles(roles.map(r => r.id === updatedRole.id ? updatedRole : r));
        setSelectedRole(null);
        setIsEditOpen(false);
        toast.success('Role updated successfully!');
      } else {
        // Parse the error response to get the specific error message
        let errorMessage = 'Failed to update role';
        try {
          const errorData = await response.json();
          if (errorData.detail) {
            errorMessage = errorData.detail;
          }
        } catch {
          // If we can't parse JSON, use the status text or default message
          errorMessage = response.statusText || 'Failed to update role';
        }
        toast.error(errorMessage);
      }
    } catch (error) {
      console.error('Failed to update role:', error);
      toast.error('Failed to update role. Please try again.');
    }
  };

  const handleDeleteRole = async (role: Role) => {
    if (!confirm(`Are you sure you want to delete the role "${role.name}"?`)) {
      return;
    }

    try {
      const response = await apiClient.delete_role({ roleId: role.id });
      
      if (response.ok) {
        toast.success('Role deleted successfully');
        await loadData();
      } else {
        const errorData = await response.text();
        toast.error(`Failed to delete role: ${errorData}`);
      }
    } catch (error: any) {
      console.error('Failed to delete role:', error);
      toast.error('Failed to delete role');
    }
  };

  // Handle permission toggle for create form
  const handleCreatePermissionToggle = (permissionId: string, checked: boolean) => {
    setCreateForm(prev => ({
      ...prev,
      permission_ids: checked 
        ? [...prev.permission_ids, permissionId]
        : prev.permission_ids.filter(id => id !== permissionId)
    }));
  };

  // Handle permission toggle for edit form
  const handleEditPermissionToggle = (permissionId: string, checked: boolean) => {
    if (!selectedRole) return;
    
    setSelectedRole(prev => {
      if (!prev) return prev;
      
      const currentPermissionIds = prev.permissions.map(p => p.id);
      const newPermissionIds = checked 
        ? [...currentPermissionIds, permissionId]
        : currentPermissionIds.filter(id => id !== permissionId);
      
      const newPermissions = permissions.filter(p => newPermissionIds.includes(p.id));
      
      return {
        ...prev,
        permissions: newPermissions
      };
    });
  };

  if (loading) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="h-8 w-8 text-purple-400" />
          <h1 className="text-3xl font-bold text-purple-100">Role Management</h1>
        </div>
        <div className="text-center py-8">
          <div className="text-purple-400">Loading roles and permissions...</div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center gap-3 mb-6">
          <Shield className="h-8 w-8 text-purple-400" />
          <h1 className="text-3xl font-bold text-purple-100">Role Management</h1>
        </div>
        <Alert>
          <AlertDescription className="text-red-400">
            {error}
          </AlertDescription>
        </Alert>
        <Button onClick={loadData} className="bg-purple-600 hover:bg-purple-700">
          Retry
        </Button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - Role Management
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Role & Permission Management
              </h1>
              <p className="text-muted-foreground mt-2">
                Manage system roles and permissions for your LARP community
              </p>
            </div>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Shield className="h-8 w-8 text-purple-400" />
                <span className="text-2xl font-bold text-purple-400">{roles.length}</span>
                <span className="text-muted-foreground">Roles</span>
              </div>
              <Button 
                onClick={() => setIsCreateOpen(true)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Role
              </Button>
            </div>
          </div>

          {/* Roles Grid */}
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {roles.map((role) => (
              <Card key={role.id} className="bg-slate-900 border-purple-500/20">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-purple-100 flex items-center gap-2">
                      <Key className="h-5 w-5 text-purple-400" />
                      {role.name}
                      {role.is_system_role && (
                        <Badge variant="secondary" className="bg-blue-600/20 text-blue-400 border-blue-400/30">
                          System
                        </Badge>
                      )}
                    </CardTitle>
                    <div className="flex gap-1">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setSelectedRole(role);
                          setIsEditOpen(true);
                        }}
                        disabled={role.is_system_role}
                        className={role.is_system_role ? "opacity-50 cursor-not-allowed" : ""}
                        title={role.is_system_role ? "Cannot edit system roles" : "Edit role"}
                      >
                        <Edit2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteRole(role)}
                        disabled={role.is_system_role}
                        className={`text-red-400 hover:text-red-300 ${role.is_system_role ? "opacity-50 cursor-not-allowed" : ""}`}
                        title={role.is_system_role ? "Cannot delete system roles" : "Delete role"}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {role.description && (
                    <p className="text-purple-300 text-sm mb-4">
                      {role.description}
                    </p>
                  )}
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-purple-400" />
                      <span className="text-purple-200 text-sm">
                        {role.user_count || 0} user(s) assigned
                      </span>
                    </div>
                    
                    <div>
                      <p className="text-purple-300 text-sm font-medium mb-2">
                        Permissions ({role.permissions.length}):
                      </p>
                      <div className="flex flex-wrap gap-1">
                        {role.permissions.length > 0 ? (
                          role.permissions.map((permission) => (
                            <Badge 
                              key={`${role.id}-${permission.id}`} 
                              variant="outline" 
                              className="text-xs border-purple-500/30 text-purple-300"
                            >
                              {permission.name}
                            </Badge>
                          ))
                        ) : (
                          <span className="text-purple-400 text-sm italic">No permissions</span>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {roles.length === 0 && (
            <Card className="bg-slate-900 border-purple-500/20">
              <CardContent className="text-center py-8">
                <Shield className="h-12 w-12 text-purple-400 mx-auto mb-4" />
                <p className="text-purple-300 text-lg mb-2">No roles found</p>
                <p className="text-purple-400 mb-4">Create your first role to get started.</p>
                <Button 
                  onClick={() => setIsCreateOpen(true)}
                  className="bg-purple-600 hover:bg-purple-700 text-white"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Create Role
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Create Role Dialog */}
          <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
            <DialogContent className="bg-slate-900 border-purple-500/20 text-purple-100 max-w-2xl max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle className="text-purple-100">Create New Role</DialogTitle>
              </DialogHeader>
              {isCreateOpen && (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Role Name
                    </label>
                    <Input
                      value={createForm.name}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter role name"
                      className="bg-slate-800 border-purple-500/20 text-purple-100"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Description
                    </label>
                    <Textarea
                      value={createForm.description}
                      onChange={(e) => setCreateForm(prev => ({ ...prev, description: e.target.value }))}
                      placeholder="Enter role description"
                      className="bg-slate-800 border-purple-500/20 text-purple-100"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-3 block">
                      Permissions
                    </label>
                    <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                      {permissions.map((permission, index) => {
                        const isChecked = createForm.permission_ids.includes(permission.id);
                        return (
                          <div key={`create-${permission.id}-${index}`} className="flex items-center space-x-2">
                            <Checkbox
                              id={`create-checkbox-${permission.id}`}
                              checked={isChecked}
                              onCheckedChange={(checked) => 
                                handleCreatePermissionToggle(permission.id, checked as boolean)
                              }
                            />
                            <label 
                              htmlFor={`create-checkbox-${permission.id}`} 
                              className="text-sm text-purple-200 cursor-pointer"
                            >
                              {permission.name}
                            </label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-3 pt-4">
                    <Button 
                      variant="outline" 
                      onClick={() => setIsCreateOpen(false)}
                      className="border-purple-500/20 text-purple-300 hover:bg-slate-800"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleCreateRole}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      Create Role
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>

          {/* Edit Role Dialog */}
          <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
            <DialogContent className="bg-slate-900 border-purple-500/20 text-purple-100 max-w-2xl">
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2">
                  <Edit className="h-5 w-5" />
                  Edit Role: {selectedRole?.name}
                </DialogTitle>
              </DialogHeader>
              
              {selectedRole && (
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Role Name *
                    </label>
                    <Input
                      value={selectedRole.name}
                      onChange={(e) => setSelectedRole(prev => 
                        prev ? { ...prev, name: e.target.value } : prev
                      )}
                      placeholder="Enter role name"
                      className="bg-slate-800 border-purple-500/20 text-purple-100"
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-2 block">
                      Description
                    </label>
                    <Textarea
                      value={selectedRole.description || ''}
                      onChange={(e) => setSelectedRole(prev => 
                        prev ? { ...prev, description: e.target.value } : prev
                      )}
                      placeholder="Enter role description"
                      className="bg-slate-800 border-purple-500/20 text-purple-100"
                      rows={3}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-purple-300 mb-3 block">
                      Permissions
                    </label>
                    <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                      {permissions.map((permission) => {
                        const isChecked = selectedRole.permissions.some(p => p.id === permission.id);
                        return (
                          <div key={`edit-permission-${permission.id}`} className="flex items-center space-x-2">
                            <Checkbox
                              id={`edit-${permission.id}`}
                              checked={isChecked}
                              onCheckedChange={(checked) => 
                                handleEditPermissionToggle(permission.id, checked as boolean)
                              }
                            />
                            <label 
                              htmlFor={`edit-${permission.id}`} 
                              className="text-sm text-purple-200 cursor-pointer"
                            >
                              {permission.name}
                            </label>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                  
                  <div className="flex justify-end gap-3 pt-4">
                    <Button 
                      variant="outline" 
                      onClick={() => {
                        setIsEditOpen(false);
                        setSelectedRole(null);
                      }}
                      className="border-purple-500/20 text-purple-300 hover:bg-slate-800"
                    >
                      Cancel
                    </Button>
                    <Button 
                      onClick={handleUpdateRole}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      Update Role
                    </Button>
                  </div>
                </div>
              )}
            </DialogContent>
          </Dialog>
        </div>
      </main>
    </div>
  );
}
