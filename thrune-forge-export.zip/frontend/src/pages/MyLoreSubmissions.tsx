import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Loader2, Scroll, Filter, ArrowLeft } from 'lucide-react';
import { apiClient } from 'app';
import { toast } from 'sonner';
import LoreSubmissionCard from 'components/LoreSubmissionCard';
import { LoreSubmissionResponse, CharacterListItem } from 'types';

export default function MyLoreSubmissions() {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [submissions, setSubmissions] = useState<LoreSubmissionResponse[]>([]);
  const [filteredSubmissions, setFilteredSubmissions] = useState<LoreSubmissionResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [characters, setCharacters] = useState<CharacterListItem[]>([]);
  const [filterCharacter, setFilterCharacter] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [submissions, filterCharacter]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [submissionsRes, charactersRes] = await Promise.all([
        apiClient.get_my_lore_submissions(),
        apiClient.list_my_characters(),
      ]);

      const submissionsData = await submissionsRes.json();
      const charactersData = await charactersRes.json();

      setSubmissions(submissionsData);
      setCharacters(charactersData);
    } catch (error) {
      console.error('Error loading lore submissions:', error);
      toast.error('Failed to load lore submissions');
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    if (filterCharacter === 'all') {
      setFilteredSubmissions(submissions);
    } else {
      setFilteredSubmissions(submissions.filter((sub) => sub.character_id === filterCharacter));
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-purple-400" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-blue-900 p-6">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header with navigation */}
        <header className="relative z-10 flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <Button 
              variant="ghost" 
              onClick={() => navigate('/')}
              className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Home
            </Button>
          </div>
          
          <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
            My Lore Research
          </div>
        </header>

        {/* Filter Section */}
        {characters.length > 1 && (
          <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-700/30 rounded-lg p-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-purple-200">
                <Filter className="w-5 h-5" />
                <span className="font-semibold">Filter by Character:</span>
              </div>
              <Select value={filterCharacter} onValueChange={setFilterCharacter}>
                <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100 w-64">
                  <SelectValue placeholder="All My Characters" />
                </SelectTrigger>
                <SelectContent className="bg-purple-900 border-purple-700">
                  <SelectItem key="all" value="all" className="text-purple-100">
                    All My Characters
                  </SelectItem>
                  {characters.map((character) => (
                    <SelectItem key={character.id} value={character.id} className="text-purple-100">
                      {character.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        )}

        {/* Results Count */}
        {submissions.length > 0 && (
          <div className="text-purple-300 text-center">
            Showing {filteredSubmissions.length} of {submissions.length} submission(s)
          </div>
        )}

        {/* Submissions Grid */}
        {filteredSubmissions.length === 0 ? (
          <div className="bg-gradient-to-br from-purple-900/30 to-blue-900/30 border border-purple-700/30 rounded-lg p-12 text-center">
            <Scroll className="w-16 h-16 text-purple-500/50 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-purple-300 mb-2">
              No Lore Submissions Yet
            </h3>
            <p className="text-purple-400">
              {submissions.length === 0
                ? "Your lore research submissions will appear here once they've been logged by the game administrators."
                : 'No submissions found for the selected character.'}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {filteredSubmissions.map((submission) => (
              <LoreSubmissionCard key={submission.id} submission={submission} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
