import React, { useState, useEffect, useRef } from 'react';
import { convertGoogleDriveUrl } from 'utils/googleDriveHelper';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { ArrowLeft, Tag, X, Users } from 'lucide-react';

interface PhotoTag {
  id: string;
  character_id: string;
  character_name: string;
  player_name: string;
  tagged_by_name: string;
  x_position: number;
  y_position: number;
  created_at: string;
}

interface Character {
  id: string;
  name?: string;
  character_name?: string;
  player_name?: string;
  heritage_name: string;
  culture_name: string;
}

interface PhotoWithTags {
  photo_id: string;
  photo_url: string;
  thumbnail_url?: string;
  description?: string;
  gallery_name: string;
  event_date?: string | null;
  tags: PhotoTag[];
}

const GalleryPhotos = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const galleryId = searchParams.get('id');
  
  const [photos, setPhotos] = useState<PhotoWithTags[]>([]);
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoWithTags | null>(null);
  const [isTagging, setIsTagging] = useState(false);
  const [myCharacters, setMyCharacters] = useState<Character[]>([]);
  const [allCharacters, setAllCharacters] = useState<Character[]>([]);
  const [selectedCharacterId, setSelectedCharacterId] = useState<string>('');
  const [clickPosition, setClickPosition] = useState<{ x: number; y: number } | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [galleryName, setGalleryName] = useState<string>('');
  const imageRef = useRef<HTMLDivElement>(null);

  
  // Helper to convert Google Drive URLs to publicly accessible lh3 format
  const getGoogleDriveImageUrl = (url: string) => {
    if (!url.includes('drive.google.com')) return url;
    
    // Extract the file ID from various Google Drive URL formats
    const match = url.match(/[?&]id=([^&]+)/);
    if (!match) return url;
    
    // Use lh3.googleusercontent.com/d/ which works without authentication
    return `https://lh3.googleusercontent.com/d/${match[1]}`;
  };
  
  // Load permissions
  useEffect(() => {
    const loadPermissions = async () => {
      try {
        const response = await apiClient.get_my_permissions();
        const data = await response.json();
        setIsAdmin(data.permissions?.includes('manage_photo_galleries') || false);
      } catch (error) {
        console.error('Failed to load permissions:', error);
      }
    };
    loadPermissions();
  }, []);

  // Load photos from specific gallery
  useEffect(() => {
    const loadPhotos = async () => {
      if (!galleryId) return;
      
      setLoading(true);
      try {
        const response = await apiClient.list_public_gallery_photos({ galleryId: galleryId! });
        const photosData = await response.json();
        
        // Tags now come directly from the backend response!
        const photosWithTags: PhotoWithTags[] = photosData.map((photo: any) => ({
          photo_id: photo.photo_id,
          photo_url: photo.photo_url,
          thumbnail_url: photo.thumbnail_url,
          description: photo.description,
          gallery_name: photo.gallery_name,
          event_date: photo.event_date,
          tags: photo.tags || [],  // Tags included in response - no N+1 queries!
        }));
        
        if (photosWithTags.length > 0) {
          setGalleryName(photosWithTags[0].gallery_name);
        }
        
        setPhotos(photosWithTags);
      } catch (error) {
        console.error('Failed to load photos:', error);
        toast.error('Failed to load gallery photos');
      } finally {
        setLoading(false);
      }
    };

    loadPhotos();
  }, [galleryId, navigate]);

  // Load characters when tagging mode is activated
  const loadCharacters = async () => {
    try {
      // Load my characters
      const myCharsResponse = await apiClient.get_my_characters_for_tagging();
      const myCharsData = await myCharsResponse.json();
      setMyCharacters(myCharsData);

      // Load all characters if admin
      if (isAdmin) {
        const allCharsResponse = await apiClient.get_all_characters_for_tagging();
        const allCharsData = await allCharsResponse.json();
        setAllCharacters(allCharsData);
      }
    } catch (error) {
      console.error('Failed to load characters:', error);
      toast.error('Failed to load characters for tagging');
    }
  };

  const handlePhotoClick = (photo: PhotoWithTags) => {
    setSelectedPhoto(photo);
    setIsTagging(false);
    setClickPosition(null);
    setSelectedCharacterId('');
  };

  const startTagging = () => {
    setIsTagging(true);
    loadCharacters();
  };

  const handleImageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!isTagging || !imageRef.current) return;

    const rect = imageRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    setClickPosition({ x, y });
  };

  const handleCreateTag = async () => {
    if (!selectedPhoto || !selectedCharacterId || !clickPosition) {
      toast.error('Please select a character and click on the image');
      return;
    }

    try {
      // Validate inputs
      console.log('Creating tag with:', {
        character_id: selectedCharacterId,
        x_position: clickPosition.x,
        y_position: clickPosition.y
      });
      const response = await apiClient.create_photo_tag({
        photo_url: selectedPhoto.photo_url,
        photo_id: selectedPhoto.photo_id,
        character_id: selectedCharacterId,
        x_position: Number(clickPosition.x.toFixed(2)),  // Ensure it's a proper number
        y_position: Number(clickPosition.y.toFixed(2)),  // Ensure it's a proper number
      });

      // Check if the response was successful
      if (!response.ok) {
        // Try to get the error detail from the response
        let errorMessage = 'Failed to create tag';
        try {
          const errorData = await response.json();
          errorMessage = errorData.detail || errorMessage;
        } catch {
          // If JSON parsing fails, use default message
          errorMessage = 'Failed to create tag';
        }
        
        toast.error(errorMessage);
        
        // Reset tagging state
        setIsTagging(false);
        setClickPosition(null);
        setSelectedCharacterId('');
        return;
      }

      const newTag = await response.json();

      // Update local state
      setPhotos(photos.map(p =>
        p.photo_id === selectedPhoto.photo_id
          ? { ...p, tags: [...p.tags, newTag] }
          : p
      ));

      setSelectedPhoto({
        ...selectedPhoto,
        tags: [...selectedPhoto.tags, newTag],
      });

      // Reset tagging state
      setIsTagging(false);
      setClickPosition(null);
      setSelectedCharacterId('');

      toast.success(`Tagged ${newTag.character_name}!`);
    } catch (error: any) {
      console.error('Failed to create tag:', error);
      const errorMessage = error?.message || 'Failed to create tag';
      toast.error(errorMessage);
    }
  };

  const handleDeleteTag = async (tagId: string) => {
    if (!selectedPhoto) return;

    try {
      await apiClient.delete_photo_tag({ tagId });

      // Update local state
      const updatedTags = selectedPhoto.tags.filter(t => t.id !== tagId);
      
      setPhotos(photos.map(p =>
        p.photo_id === selectedPhoto.photo_id
          ? { ...p, tags: updatedTags }
          : p
      ));

      setSelectedPhoto({
        ...selectedPhoto,
        tags: updatedTags,
      });

      toast.success('Tag removed');
    } catch (error) {
      console.error('Failed to delete tag:', error);
      toast.error('Failed to remove tag');
    }
  };

  const charactersToShow = isAdmin ? allCharacters : myCharacters;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950">
      {/* Header */}
      <header className="relative z-10 flex justify-between items-center p-6 border-b border-purple-800/30">
        <Button 
          variant="ghost" 
          onClick={() => navigate('/photo-gallery')}
          className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Galleries
        </Button>
        
        <h1 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          {galleryName || 'Gallery Photos'}
        </h1>

        <div className="w-32" /> {/* Spacer */}
      </header>

      {/* Photo Grid */}
      <div className="container mx-auto p-6">
        {loading ? (
          <div className="text-center text-purple-300">Loading photos...</div>
        ) : photos.length === 0 ? (
          <div className="text-center text-purple-300">No photos in this gallery yet.</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {photos.map((photo) => (
              <Card 
                key={photo.photo_id}
                className="cursor-pointer hover:ring-2 hover:ring-purple-500 transition-all bg-slate-900/50 border-purple-700/30"
                onClick={() => handlePhotoClick(photo)}
              >
                <CardContent className="p-4">
                  <div className="relative">
                    <img 
                      src={getGoogleDriveImageUrl(photo.photo_url)} 
                      alt={photo.description || 'LARP Photo'}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    {photo.tags.length > 0 && (
                      <Badge className="absolute top-2 right-2 bg-purple-600">
                        <Users className="w-3 h-3 mr-1" />
                        {photo.tags.length}
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Photo Detail Dialog */}
      <Dialog open={!!selectedPhoto} onOpenChange={() => setSelectedPhoto(null)}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-slate-900 border-purple-700/50">
          <DialogHeader>
            <DialogTitle className="text-purple-300">
              {selectedPhoto?.description || 'Photo Details'}
            </DialogTitle>
            <DialogDescription className="text-purple-400">
              {isTagging ? 'Click on the image to place a tag' : 'View and manage character tags'}
            </DialogDescription>
          </DialogHeader>

          {selectedPhoto && (
            <div className="space-y-4">
              {/* Image with tags */}
              <div 
                ref={imageRef}
                className="relative border border-purple-700/30 rounded-lg overflow-hidden cursor-crosshair"
                onClick={handleImageClick}
              >
                <img 
                  src={getGoogleDriveImageUrl(selectedPhoto.photo_url)}
                  alt="Full size"
                  className="w-full h-auto max-h-[60vh] object-contain"
                  onError={(e) => {
                    console.error('Failed to load image:', selectedPhoto.photo_url);
                    e.currentTarget.src = 'https://via.placeholder.com/800x600?text=Image+Not+Available';
                  }}
                />
                
                {/* Render existing tags */}
                {selectedPhoto.tags.map((tag) => (
                  <div
                    key={tag.id}
                    className="absolute w-8 h-8 -ml-4 -mt-4 bg-purple-600/80 border-2 border-white rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-all opacity-0 hover:opacity-100 group"
                    style={{
                      left: `${tag.x_position}%`,
                      top: `${tag.y_position}%`,
                    }}
                    title={`${tag.character_name} (${tag.player_name})`}
                  >
                    <Tag className="w-4 h-4 text-white" />
                  </div>
                ))}

                {/* Preview new tag position */}
                {clickPosition && (
                  <div
                    className="absolute w-8 h-8 -ml-4 -mt-4 bg-amber-500 border-2 border-white rounded-full flex items-center justify-center shadow-lg animate-pulse"
                    style={{
                      left: `${clickPosition.x}%`,
                      top: `${clickPosition.y}%`,
                    }}
                  >
                    <Tag className="w-4 h-4 text-white" />
                  </div>
                )}
              </div>

              {/* Tagging Controls */}
              {isTagging ? (
                <div className="space-y-3">
                  <Select value={selectedCharacterId} onValueChange={setSelectedCharacterId}>
                    <SelectTrigger className="bg-slate-800 border-purple-700/50 text-purple-200">
                      <SelectValue placeholder={isAdmin ? "Select any character..." : "Select your character..."} />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-800 border-purple-700/50">
                      {charactersToShow.map((char) => (
                        <SelectItem key={char.id} value={char.id} className="text-purple-200">
                          {char.character_name || char.name}
                          {char.player_name && ` (${char.player_name})`}
                          {' - '}
                          {char.heritage_name} {char.culture_name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>

                  <div className="flex gap-2">
                    <Button 
                      onClick={handleCreateTag}
                      disabled={!selectedCharacterId || !clickPosition}
                      className="flex-1 bg-purple-600 hover:bg-purple-700"
                    >
                      Confirm Tag
                    </Button>
                    <Button 
                      variant="outline"
                      onClick={() => {
                        setIsTagging(false);
                        setClickPosition(null);
                        setSelectedCharacterId('');
                      }}
                      className="border-purple-700/50 text-purple-300"
                    >
                      Cancel
                    </Button>
                  </div>

                  {!clickPosition && (
                    <Alert className="bg-purple-900/20 border-purple-700/50">
                      <AlertDescription className="text-purple-300">
                        Select a character, then click on the image where you want to place the tag
                      </AlertDescription>
                    </Alert>
                  )}
                </div>
              ) : (
                <Button 
                  onClick={startTagging}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  <Tag className="w-4 h-4 mr-2" />
                  Tag a Character
                </Button>
              )}

              {/* Tagged Characters List */}
              {selectedPhoto.tags.length > 0 && (
                <div className="space-y-2">
                  <h3 className="text-sm font-semibold text-purple-300">Tagged Characters:</h3>
                  <div className="space-y-2">
                    {selectedPhoto.tags.map((tag) => (
                      <div 
                        key={tag.id}
                        className="flex items-center justify-between p-3 bg-slate-800/50 border border-purple-700/30 rounded-lg"
                      >
                        <div>
                          <p className="font-medium text-purple-200">{tag.character_name}</p>
                          <p className="text-sm text-purple-400">
                            Player: {tag.player_name} • Tagged by: {tag.tagged_by_name}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDeleteTag(tag.id)}
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default GalleryPhotos;
