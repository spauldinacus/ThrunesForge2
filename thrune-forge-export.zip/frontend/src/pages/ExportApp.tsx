import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, FileArchive, Database, Code, CheckCircle, AlertCircle } from "lucide-react";
import { apiClient } from "app";
import { toast } from "sonner";

export default function ExportApp() {
  const [status, setStatus] = useState<{
    total_files: number;
    total_migrations: number;
    total_size_bytes: number;
    ready: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    loadStatus();
  }, []);

  const loadStatus = async () => {
    setLoading(true);
    try {
      const response = await apiClient.get_export_status();
      const data = await response.json();
      setStatus(data);
    } catch (error) {
      console.error("Failed to load export status:", error);
      toast.error("Failed to load export status");
    } finally {
      setLoading(false);
    }
  };

  const downloadPackage = async () => {
    setDownloading(true);
    try {
      const response = await apiClient.download_complete_package();
      
      // Convert response to blob
      const blob = await response.blob();
      
      // Create download link
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'thrune-forge-export.zip';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast.success("Export package downloaded successfully!");
    } catch (error) {
      console.error("Failed to download package:", error);
      toast.error("Failed to download export package");
    } finally {
      setDownloading(false);
    }
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Export Application</h1>
        <p className="text-muted-foreground">
          Download a complete package of your application code and database migrations
        </p>
      </div>

      <div className="grid gap-6">
        {/* Status Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileArchive className="h-5 w-5" />
              Export Status
            </CardTitle>
            <CardDescription>
              Overview of what will be included in the export
            </CardDescription>
          </CardHeader>
          <CardContent>
            {loading ? (
              <div className="text-center py-8 text-muted-foreground">
                Loading export status...
              </div>
            ) : status ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="flex flex-col items-center p-4 bg-muted rounded-lg">
                    <Code className="h-8 w-8 mb-2 text-primary" />
                    <div className="text-2xl font-bold">{status.total_files}</div>
                    <div className="text-sm text-muted-foreground">Code Files</div>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-muted rounded-lg">
                    <Database className="h-8 w-8 mb-2 text-primary" />
                    <div className="text-2xl font-bold">{status.total_migrations}</div>
                    <div className="text-sm text-muted-foreground">Migrations</div>
                  </div>
                  
                  <div className="flex flex-col items-center p-4 bg-muted rounded-lg">
                    <FileArchive className="h-8 w-8 mb-2 text-primary" />
                    <div className="text-2xl font-bold">{formatBytes(status.total_size_bytes)}</div>
                    <div className="text-sm text-muted-foreground">Total Size</div>
                  </div>
                </div>

                {status.ready ? (
                  <div className="flex items-center gap-2 text-green-600 dark:text-green-500 bg-green-50 dark:bg-green-950/30 p-3 rounded-lg">
                    <CheckCircle className="h-5 w-5" />
                    <span className="font-medium">Ready to export</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-orange-600 dark:text-orange-500 bg-orange-50 dark:bg-orange-950/30 p-3 rounded-lg">
                    <AlertCircle className="h-5 w-5" />
                    <span className="font-medium">Export preparation in progress</span>
                  </div>
                )}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                Failed to load export status
              </div>
            )}
          </CardContent>
        </Card>

        {/* Export Info Card */}
        <Card>
          <CardHeader>
            <CardTitle>What's Included</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-start gap-3">
              <Code className="h-5 w-5 mt-0.5 text-primary" />
              <div>
                <div className="font-medium">Complete Source Code</div>
                <div className="text-sm text-muted-foreground">
                  All frontend (React/TypeScript) and backend (FastAPI/Python) files
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <Database className="h-5 w-5 mt-0.5 text-primary" />
              <div>
                <div className="font-medium">Database Migrations</div>
                <div className="text-sm text-muted-foreground">
                  All {status?.total_migrations || 0} migration files in execution order
                </div>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <FileArchive className="h-5 w-5 mt-0.5 text-primary" />
              <div>
                <div className="font-medium">Configuration Files</div>
                <div className="text-sm text-muted-foreground">
                  package.json, tsconfig, vite config, pyproject.toml
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Download Button */}
        <Card>
          <CardContent className="pt-6">
            <Button
              onClick={downloadPackage}
              disabled={!status?.ready || downloading}
              size="lg"
              className="w-full"
            >
              <Download className="mr-2 h-5 w-5" />
              {downloading ? "Preparing Download..." : "Download Complete Package"}
            </Button>
            <p className="text-sm text-muted-foreground text-center mt-3">
              Downloads as: <code className="bg-muted px-2 py-1 rounded">thrune-forge-export.zip</code>
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}