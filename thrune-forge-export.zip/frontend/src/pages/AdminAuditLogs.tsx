import { useState, useEffect } from "react";
import { format } from "date-fns";
import { useNavigate } from "react-router-dom";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { useMemo } from 'react';
import { apiClient } from 'app';
import { usePermissions, PERMISSIONS } from "utils/usePermissions";
import { Loader2, RefreshCw, History, ArrowLeft, Shield } from "lucide-react";

// Define locally until generated in types
interface AuditLogEntry {
  id: string;
  performed_by_user_id: string;
  action_type: string;
  action: string;
  entity_id: string | null;
  entity_name: string | null;
  entity_type: string | null;
  details: any;
  created_at: string;
  performed_by_name: string | null;
}

const AdminAuditLogs = () => {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(false);
  const [backfilling, setBackfilling] = useState(false);
  const [filters, setFilters] = useState({
    limit: 50,
    offset: 0,
    action_type: "",
    action: "",
    entity_type: "",
    user_id: "",
    start_date: undefined as string | undefined,
    end_date: undefined as string | undefined,
    sort_by: "created_at",
    sort_direction: "desc"
  });
  
  const canViewLogs = hasPermission(PERMISSIONS.VIEW_AUDIT_LOGS) || hasPermission(PERMISSIONS.VIEW_ADMIN_PANEL);

  const fetchLogs = async () => {
    setLoading(true);
    try {
      // Use undefined for empty strings so they are omitted from the query or handled correctly
      const response = await apiClient.get_audit_logs({
        limit: filters.limit,
        offset: filters.offset,
        action_type: filters.action_type || undefined,
        action: filters.action || undefined,
        entity_type: filters.entity_type || undefined,
        user_id: filters.user_id || undefined,
        start_date: filters.start_date ? new Date(filters.start_date).toISOString() : undefined,
        end_date: filters.end_date ? new Date(filters.end_date + 'T23:59:59').toISOString() : undefined, // Fix end of day
        sort_by: filters.sort_by,
        sort_direction: filters.sort_direction,
      });
      const data = await response.json();
      setLogs(data);
    } catch (error) {
      console.error("Failed to fetch audit logs:", error);
      toast.error("Failed to fetch audit logs");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (canViewLogs && !permissionsLoading) {
      fetchLogs();
    }
  }, [canViewLogs, permissionsLoading, filters.limit, filters.offset, filters.sort_by, filters.sort_direction]); // Refresh when pagination or sorting changes

  const handleSearch = () => {
    setFilters((prev) => ({ ...prev, offset: 0 })); // Reset to first page on search
    fetchLogs();
  };

  const handleBackfill = async () => {
    if (!confirm("This will scan all XP transactions and create audit log entries. Continue?")) return;
    
    setBackfilling(true);
    try {
      const response = await apiClient.backfill_audit_logs();
      const result = await response.json();
      toast.success(result.message || "Backfill started");
      fetchLogs();
    } catch (error) {
      console.error("Backfill failed:", error);
      toast.error("Backfill failed");
    } finally {
      setBackfilling(false);
    }
  };

  const renderDetails = (details: any) => {
    if (!details) return <span className="text-muted-foreground">-</span>;
    
    let parsedDetails = details;
    if (typeof details === 'string') {
      try {
        parsedDetails = JSON.parse(details);
      } catch {
        return <span className="text-sm">{details}</span>;
      }
    }

    if (typeof parsedDetails === 'object' && parsedDetails !== null) {
      return (
        <div className="text-xs space-y-1">
          {Object.entries(parsedDetails).map(([key, value]) => (
            <div key={key} className="flex gap-2">
              <span className="font-semibold text-muted-foreground min-w-[80px] capitalize">
                {key.replace(/_/g, ' ')}:
              </span>
              <span className="text-foreground break-all">
                {typeof value === 'object' ? JSON.stringify(value) : String(value)}
              </span>
            </div>
          ))}
        </div>
      );
    }

    return <span>{String(parsedDetails)}</span>;
  };

  if (permissionsLoading) {
    return (
      <div className="flex justify-center items-center h-screen bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!canViewLogs) {
    return (
      <div className="flex justify-center items-center h-screen bg-background text-foreground">
        Access Denied
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>
        
        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - Audit Logs
        </div>
      </header>

      <main className="container mx-auto px-6 py-12 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
              Audit Logs
            </h1>
            <p className="text-muted-foreground mt-2">
              View and filter system audit logs
            </p>
          </div>
          <div className="flex gap-2">
              <Button variant="outline" onClick={fetchLogs} disabled={loading} className="border-purple-500/50 hover:bg-purple-500/10 text-purple-300">
                  <RefreshCw className={`mr-2 h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
                  Refresh
              </Button>
              <Button variant="secondary" onClick={handleBackfill} disabled={backfilling}>
                  <History className="mr-2 h-4 w-4" />
                  {backfilling ? "Backfilling..." : "Backfill History"}
              </Button>
          </div>
        </div>

      <Card className="bg-slate-900/50 border-purple-500/20">
        <CardHeader>
          <CardTitle className="text-slate-200">Filters</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 w-full">
            <Input
              placeholder="Action Type (e.g. xp_change)"
              value={filters.action_type}
              onChange={(e) => setFilters({ ...filters, action_type: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="bg-slate-800 border-slate-600 text-slate-200"
            />
            <Input
              placeholder="Specific Action (e.g. grant)"
              value={filters.action}
              onChange={(e) => setFilters({ ...filters, action: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="bg-slate-800 border-slate-600 text-slate-200"
            />
            <Input
              placeholder="Entity Type (e.g. character)"
              value={filters.entity_type}
              onChange={(e) => setFilters({ ...filters, entity_type: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="bg-slate-800 border-slate-600 text-slate-200"
            />
            <Input
              placeholder="User ID"
              value={filters.user_id}
              onChange={(e) => setFilters({ ...filters, user_id: e.target.value })}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              className="bg-slate-800 border-slate-600 text-slate-200"
            />
          </div>
          
          <div className="flex flex-col md:flex-row gap-4 items-end">
             <div className="flex-1 w-full md:w-auto">
               <span className="text-sm text-slate-400 mb-1 block">Start Date</span>
               <Input
                  type="date"
                  value={filters.start_date || ''}
                  onChange={(e) => setFilters({ ...filters, start_date: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-slate-200"
               />
             </div>
             <div className="flex-1 w-full md:w-auto">
               <span className="text-sm text-slate-400 mb-1 block">End Date</span>
               <Input
                  type="date"
                  value={filters.end_date || ''}
                  onChange={(e) => setFilters({ ...filters, end_date: e.target.value })}
                  className="bg-slate-800 border-slate-600 text-slate-200"
               />
             </div>
             <Button onClick={handleSearch} className="w-full md:w-auto bg-purple-600 hover:bg-purple-700 text-white">Search</Button>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-900/50 border-purple-500/20">
        <CardContent className="p-0">
          <div className="rounded-md border border-slate-700">
            <Table>
              <TableHeader>
                <TableRow className="border-slate-700 hover:bg-slate-800/50">
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => setFilters(prev => ({ 
                      ...prev, 
                      sort_by: 'created_at', 
                      sort_direction: prev.sort_by === 'created_at' && prev.sort_direction === 'desc' ? 'asc' : 'desc' 
                    }))}
                  >
                    Timestamp {filters.sort_by === 'created_at' && (filters.sort_direction === 'desc' ? '↓' : '↑')}
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => setFilters(prev => ({ 
                        ...prev, 
                        sort_by: 'performed_by_name', 
                        sort_direction: prev.sort_by === 'performed_by_name' && prev.sort_direction === 'desc' ? 'asc' : 'desc' 
                      }))}
                  >
                    Admin {filters.sort_by === 'performed_by_name' && (filters.sort_direction === 'desc' ? '↓' : '↑')}
                  </TableHead>
                  <TableHead 
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => setFilters(prev => ({ 
                      ...prev, 
                      sort_by: 'action_type', 
                      sort_direction: prev.sort_by === 'action_type' && prev.sort_direction === 'desc' ? 'asc' : 'desc' 
                    }))}
                  >
                    Type {filters.sort_by === 'action_type' && (filters.sort_direction === 'desc' ? '↓' : '↑')}
                  </TableHead>
                  <TableHead
                     className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => setFilters(prev => ({ 
                      ...prev, 
                      sort_by: 'action', 
                      sort_direction: prev.sort_by === 'action' && prev.sort_direction === 'desc' ? 'asc' : 'desc' 
                    }))}
                  >
                    Action {filters.sort_by === 'action' && (filters.sort_direction === 'desc' ? '↓' : '↑')}
                  </TableHead>
                  <TableHead
                    className="text-purple-300 cursor-pointer hover:text-purple-200 select-none"
                    onClick={() => setFilters(prev => ({ 
                      ...prev, 
                      sort_by: 'entity_name', 
                      sort_direction: prev.sort_by === 'entity_name' && prev.sort_direction === 'desc' ? 'asc' : 'desc' 
                    }))}
                  >
                    Entity {filters.sort_by === 'entity_name' && (filters.sort_direction === 'desc' ? '↓' : '↑')}
                  </TableHead>
                  <TableHead className="w-[300px] text-purple-300">Details</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading && logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center">
                      <Loader2 className="h-6 w-6 animate-spin mx-auto text-purple-400" />
                    </TableCell>
                  </TableRow>
                ) : logs.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="h-24 text-center text-slate-400">
                      No logs found.
                    </TableCell>
                  </TableRow>
                ) : (
                  logs.map((log) => (
                    <TableRow key={log.id} className="border-slate-700 hover:bg-slate-800/50">
                      <TableCell className="whitespace-nowrap text-slate-300">
                        {format(new Date(log.created_at), "MMM d, yyyy HH:mm")}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                            <span className="font-medium text-slate-200">{log.performed_by_name || "Unknown"}</span>
                            <span className="text-xs text-slate-400 truncate max-w-[100px]" title={log.performed_by_user_id}>
                                {log.performed_by_user_id}
                            </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <span className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 border-transparent bg-slate-700 text-slate-200">
                            {log.action_type}
                        </span>
                      </TableCell>
                      <TableCell className="text-slate-300">{log.action}</TableCell>
                      <TableCell>
                         <div className="flex flex-col">
                            <span className="font-medium text-slate-200">{log.entity_name || log.entity_type || "-"}</span>
                            <span className="text-xs text-slate-400 truncate max-w-[100px]" title={log.entity_id || ""}>
                                {log.entity_id || "-"}
                            </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="bg-slate-950/50 p-2 rounded-md overflow-auto max-h-[150px] border border-slate-800">
                          {renderDetails(log.details)}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
          <div className="flex items-center justify-end space-x-2 p-4">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters((prev) => ({ ...prev, offset: Math.max(0, prev.offset - prev.limit) }))}
              disabled={filters.offset === 0 || loading}
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setFilters((prev) => ({ ...prev, offset: prev.offset + prev.limit }))}
              disabled={logs.length < filters.limit || loading}
              className="border-slate-700 text-slate-300 hover:bg-slate-800"
            >
              Next
            </Button>
          </div>
        </CardContent>
      </Card>
      </main>
    </div>
  );
};

export default AdminAuditLogs;
