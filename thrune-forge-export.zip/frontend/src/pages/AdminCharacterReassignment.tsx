import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { apiClient } from 'app';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ArrowLeft, Shield, Search, ArrowUpDown, UserCog } from 'lucide-react';
import { usePermissions, PERMISSIONS } from 'utils/usePermissions';
import { CharacterReassignmentModal } from 'components/CharacterReassignmentModal';
import { toast } from 'sonner';

interface CharacterSummary {
  id: string;
  name: string;
  heritage_name: string;
  culture_name: string;
  archetype_name: string;
  player_id: string | null;
  player_name: string | null;
}

type SortField = 'name' | 'heritage_name' | 'culture_name' | 'archetype_name' | 'player_name';
type SortDirection = 'asc' | 'desc';

export default function AdminCharacterReassignment() {
  const navigate = useNavigate();
  const { hasPermission, loading: permissionsLoading } = usePermissions();
  const [characters, setCharacters] = useState<CharacterSummary[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortField, setSortField] = useState<SortField>('name');
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [modalOpen, setModalOpen] = useState(false);
  const [selectedCharacter, setSelectedCharacter] = useState<{
    id: string;
    name: string;
    playerName: string | null;
  } | null>(null);

  // Check permissions on component mount
  useEffect(() => {
    if (!permissionsLoading && !hasPermission(PERMISSIONS.CHARACTER_REASSIGNMENT)) {
      navigate('/');
      return;
    }
  }, [permissionsLoading, navigate]);

  const fetchCharacters = async () => {
    try {
      setLoading(true);
      const response = await apiClient.list_all_characters_for_reassignment();
      const data = await response.json();
      setCharacters(data);
    } catch (error) {
      console.error('Failed to fetch characters:', error);
      toast.error('Failed to load characters');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!permissionsLoading && hasPermission(PERMISSIONS.CHARACTER_REASSIGNMENT)) {
      fetchCharacters();
    }
  }, [permissionsLoading]);  // ← CHANGED: Remove hasPermission, add permissionsLoading check

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const handleAssignClick = (character: CharacterSummary) => {
    setSelectedCharacter({
      id: character.id,
      name: character.name,
      playerName: character.player_name,
    });
    setModalOpen(true);
  };

  // Filter and sort characters
  const filteredAndSortedCharacters = characters
    .filter((char) => {
      const search = searchTerm.toLowerCase();
      return (
        char.name.toLowerCase().includes(search) ||
        char.player_name?.toLowerCase().includes(search) ||
        char.heritage_name.toLowerCase().includes(search) ||
        char.culture_name.toLowerCase().includes(search) ||
        char.archetype_name.toLowerCase().includes(search)
      );
    })
    .sort((a, b) => {
      const aValue = a[sortField] || '';
      const bValue = b[sortField] || '';
      const multiplier = sortDirection === 'asc' ? 1 : -1;
      return aValue.toString().localeCompare(bValue.toString()) * multiplier;
    });

  // Show loading while checking permissions
  if (permissionsLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <div className="text-purple-400 text-lg">Verifying permissions...</div>
        </div>
      </div>
    );
  }

  // Block access if user doesn't have permission
  if (!hasPermission(PERMISSIONS.CHARACTER_REASSIGNMENT)) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900 flex items-center justify-center">
        <Card className="bg-slate-900 border-red-500/20 max-w-md">
          <CardHeader>
            <CardTitle className="text-red-400 flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Access Denied
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-red-300 mb-4">
              You don't have permission to reassign characters.
            </p>
            <Button
              onClick={() => navigate('/')}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              Return Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900/20 to-slate-900">
      {/* Header with navigation */}
      <header className="relative z-10 flex justify-between items-center p-6">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Button>
        </div>

        <div className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
          Admin - Character Reassignment
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-12">
        <Card className="bg-slate-900/80 border-purple-500/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-xl text-purple-300 flex items-center gap-2">
              <UserCog className="h-5 w-5" />
              Character Assignments
            </CardTitle>
            <p className="text-slate-400 text-sm mt-2">
              Reassign characters from one player to another. All changes are tracked in history.
            </p>
          </CardHeader>
          <CardContent>
            {/* Search */}
            <div className="mb-6">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  type="text"
                  placeholder="Search by character name, player name, heritage, culture, or archetype..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-slate-800 border-purple-500/20 text-slate-100 placeholder:text-slate-500"
                />
              </div>
            </div>

            {/* Table */}
            {loading ? (
              <div className="text-center py-12 text-slate-400">
                Loading characters...
              </div>
            ) : (
              <div className="rounded-md border border-purple-500/20 overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow className="bg-slate-800/50 hover:bg-slate-800/50">
                      <TableHead
                        className="text-purple-300 cursor-pointer hover:text-purple-200"
                        onClick={() => handleSort('name')}
                      >
                        <div className="flex items-center gap-1">
                          Character Name
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead
                        className="text-purple-300 cursor-pointer hover:text-purple-200"
                        onClick={() => handleSort('heritage_name')}
                      >
                        <div className="flex items-center gap-1">
                          Heritage
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead
                        className="text-purple-300 cursor-pointer hover:text-purple-200"
                        onClick={() => handleSort('culture_name')}
                      >
                        <div className="flex items-center gap-1">
                          Culture
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead
                        className="text-purple-300 cursor-pointer hover:text-purple-200"
                        onClick={() => handleSort('archetype_name')}
                      >
                        <div className="flex items-center gap-1">
                          Archetype
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead
                        className="text-purple-300 cursor-pointer hover:text-purple-200"
                        onClick={() => handleSort('player_name')}
                      >
                        <div className="flex items-center gap-1">
                          Player
                          <ArrowUpDown className="h-3 w-3" />
                        </div>
                      </TableHead>
                      <TableHead className="text-purple-300 text-right">
                        Actions
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredAndSortedCharacters.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={6}
                          className="text-center py-8 text-slate-400"
                        >
                          No characters found
                        </TableCell>
                      </TableRow>
                    ) : (
                      filteredAndSortedCharacters.map((character) => (
                        <TableRow
                          key={character.id}
                          className="border-purple-500/10 hover:bg-purple-600/5"
                        >
                          <TableCell className="font-medium text-slate-200">
                            {character.name}
                          </TableCell>
                          <TableCell className="text-slate-300">
                            {character.heritage_name}
                          </TableCell>
                          <TableCell className="text-slate-300">
                            {character.culture_name}
                          </TableCell>
                          <TableCell className="text-slate-300">
                            {character.archetype_name}
                          </TableCell>
                          <TableCell className="text-slate-300">
                            {character.player_name || (
                              <span className="text-slate-500 italic">Unassigned</span>
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            <Button
                              size="sm"
                              onClick={() => handleAssignClick(character)}
                              className="bg-purple-600 hover:bg-purple-700 text-white"
                            >
                              Assign To
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
            )}

            {/* Results count */}
            {!loading && (
              <div className="mt-4 text-sm text-slate-400">
                Showing {filteredAndSortedCharacters.length} of {characters.length} characters
              </div>
            )}
          </CardContent>
        </Card>

        {/* Background decorative elements */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <div className="absolute top-1/4 right-1/4 w-64 h-64 bg-purple-600/10 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-1/3 left-1/3 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        </div>
      </main>

      {/* Reassignment Modal */}
      <CharacterReassignmentModal
        open={modalOpen}
        onOpenChange={setModalOpen}
        character={selectedCharacter}
        onSuccess={fetchCharacters}
      />
    </div>
  );
}
