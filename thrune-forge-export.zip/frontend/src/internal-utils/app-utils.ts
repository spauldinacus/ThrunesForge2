export const isLocalDevMode = import.meta.env.VITE_LOCAL === "true";
