import { useEffect } from 'react';
import { Toaster } from "@/components/ui/sonner"
import { errorCapture, initializeDeploymentErrorHandlers } from 'utils/errorCapture';
import { BugReportButton } from 'components/BugReportButton';

export function AppProvider({ children }: { children: React.ReactNode }) {
  // Initialize error capture and deployment error handlers on mount
  useEffect(() => {
    errorCapture.initialize();
    initializeDeploymentErrorHandlers();
  }, []);

  return (
    <>
      {children}
      <Toaster />
      <BugReportButton />
    </>
  )
}
