import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Alert,
  AlertDescription,
} from '@/components/ui/alert';
import { Loader2, AlertCircle } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { ChapterResponse, PlayerProfile, AdminCharacterListItem } from 'types';

interface CharacterReassignmentModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  character: {
    id: string;
    name: string;
    playerName: string | null;
  } | null;
  onSuccess: () => void;
}

interface Chapter {
  id: string;
  name: string;
}

interface Player {
  id: string;
  name: string;
  player_number: string;
}

export const CharacterReassignmentModal: React.FC<CharacterReassignmentModalProps> = ({
  open,
  onOpenChange,
  character,
  onSuccess,
}) => {
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [players, setPlayers] = useState<Player[]>([]);
  const [selectedChapterId, setSelectedChapterId] = useState<string>('');
  const [selectedPlayerId, setSelectedPlayerId] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [loadingPlayers, setLoadingPlayers] = useState(false);
  const [showConfirmation, setShowConfirmation] = useState(false);

  // Fetch chapters on mount
  useEffect(() => {
    const fetchChapters = async () => {
      try {
        const response = await apiClient.list_scoped_chapters();
        const data = await response.json();
        setChapters(data.chapters || []);
        
        // Default to Wanderer's Hope if it exists
        const wanderersHope = data.chapters?.find((c: Chapter) => c.name === "Wanderer's Hope");
        if (wanderersHope) {
          setSelectedChapterId(wanderersHope.id);
        }
      } catch (error) {
        console.error('Failed to fetch chapters:', error);
        toast.error('Failed to load chapters');
      }
    };
    
    if (open) {
      fetchChapters();
    }
  }, [open]);

  // Fetch players when chapter changes
  useEffect(() => {
    const fetchPlayers = async () => {
      if (!selectedChapterId) return;
      
      try {
        setLoadingPlayers(true);
        const response = await apiClient.get_players_by_chapter({ chapterId: selectedChapterId });
        const data = await response.json();
        setPlayers(data.players || []);
      } catch (error) {
        console.error('Failed to fetch players:', error);
        toast.error('Failed to load players');
      } finally {
        setLoadingPlayers(false);
      }
    };
    
    fetchPlayers();
  }, [selectedChapterId]);

  const handleReassign = async () => {
    if (!character || !selectedPlayerId) return;

    try {
      setLoading(true);
      await apiClient.reassign_character(
        { characterId: character.id },
        { new_player_profile_id: selectedPlayerId }
      );
      
      toast.success('Character reassigned successfully');
      onSuccess();
      handleClose();
    } catch (error) {
      console.error('Error reassigning character:', error);
      toast.error('An error occurred while reassigning the character');
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedChapterId('');
    setSelectedPlayerId('');
    setNotes('');
    setShowConfirmation(false);
    onOpenChange(false);
  };

  const selectedPlayer = players.find(p => p.id === selectedPlayerId);

  if (!character) return null;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="bg-slate-900 border-purple-500/20 text-slate-100 sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
            {showConfirmation ? 'Confirm Reassignment' : 'Reassign Character'}
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            {showConfirmation 
              ? 'Please confirm this character reassignment'
              : `Reassign ${character.name} to a different player`}
          </DialogDescription>
        </DialogHeader>

        {!showConfirmation ? (
          <div className="space-y-4">
            <div>
              <Label className="text-slate-300">Current Player</Label>
              <div className="mt-1 p-2 bg-slate-800 rounded-md text-slate-300">
                {character.playerName || 'Unassigned'}
              </div>
            </div>

            <div>
              <Label htmlFor="chapter" className="text-slate-300">Chapter</Label>
              <Select value={selectedChapterId} onValueChange={setSelectedChapterId}>
                <SelectTrigger className="bg-slate-800 border-purple-500/20 text-slate-100">
                  <SelectValue placeholder="Select a chapter" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-purple-500/20">
                  {chapters.map((chapter) => (
                    <SelectItem 
                      key={chapter.id} 
                      value={chapter.id}
                      className="text-slate-100 focus:bg-purple-600/20"
                    >
                      {chapter.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="player" className="text-slate-300">New Player</Label>
              {loadingPlayers ? (
                <div className="flex items-center justify-center p-4 bg-slate-800 rounded-md">
                  <Loader2 className="h-4 w-4 animate-spin text-purple-400" />
                  <span className="ml-2 text-slate-400">Loading players...</span>
                </div>
              ) : (
                <Select value={selectedPlayerId} onValueChange={setSelectedPlayerId}>
                  <SelectTrigger className="bg-slate-800 border-purple-500/20 text-slate-100">
                    <SelectValue placeholder="Select a player" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-purple-500/20">
                    {players.map((player) => (
                      <SelectItem 
                        key={player.id} 
                        value={player.id}
                        className="text-slate-100 focus:bg-purple-600/20"
                      >
                        {player.name} ({player.player_number})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>

            <div>
              <Label htmlFor="notes" className="text-slate-300">Notes/Reason (Optional)</Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Enter reason for reassignment..."
                className="bg-slate-800 border-purple-500/20 text-slate-100 placeholder:text-slate-500"
                rows={3}
              />
            </div>
          </div>
        ) : (
          <Alert className="bg-amber-900/20 border-amber-500/30">
            <AlertCircle className="h-4 w-4 text-amber-400" />
            <AlertDescription className="text-amber-200">
              Are you sure you want to reassign <strong>{character.name}</strong> from{' '}
              <strong>{character.playerName || 'no player'}</strong> to{' '}
              <strong>{selectedPlayer?.name}</strong>?
              {notes && (
                <div className="mt-2 text-sm">
                  <strong>Reason:</strong> {notes}
                </div>
              )}
            </AlertDescription>
          </Alert>
        )}

        <DialogFooter>
          {!showConfirmation ? (
            <>
              <Button
                variant="outline"
                onClick={handleClose}
                className="border-purple-500/20 text-slate-300 hover:bg-purple-600/10"
              >
                Cancel
              </Button>
              <Button
                onClick={() => setShowConfirmation(true)}
                disabled={!selectedPlayerId}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                Continue
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="outline"
                onClick={() => setShowConfirmation(false)}
                disabled={loading}
                className="border-purple-500/20 text-slate-300 hover:bg-purple-600/10"
              >
                Back
              </Button>
              <Button
                onClick={handleReassign}
                disabled={loading}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                {loading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Reassigning...
                  </>
                ) : (
                  'Confirm Reassignment'
                )}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
