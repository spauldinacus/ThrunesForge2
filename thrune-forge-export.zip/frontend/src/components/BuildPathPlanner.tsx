import { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Trash2, AlertTriangle, CheckCircle2, Lightbulb } from 'lucide-react';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { cn } from '@/lib/utils';
import { useTheme } from '@/hooks/use-theme';

// Define types locally until generated
interface SkillAssignment {
  skill_id: string;
  skill_name: string;
  best_archetype_id: string;
  best_archetype_name: string;
  cost: number;
  penalty_cost: number;
}

interface ArchetypeCombination {
  archetype_id: string;
  archetype_name: string;
  secondary_archetype_id?: string | null;
  secondary_archetype_name?: string | null;
  tertiary_archetype_id?: string | null;
  tertiary_archetype_name?: string | null;
  xp_cost: number;
  xp_savings: number;
  skill_assignments?: SkillAssignment[] | null;
}

type TimelineStep = 
  | { type: 'start'; cumulativeXp?: number }
  | { type: 'unlock_archetype'; archetypeId: string; archetypeName: string; cost: number; cumulativeXp?: number }
  | { type: 'skill'; skillId: string; assignment: SkillAssignment; cost?: number; inefficient?: boolean; cumulativeXp?: number };

interface BuildPathPlannerProps {
  combination: ArchetypeCombination;
  selectedSkills: { skill_id: string; quantity: number }[];
  archetypes: { id: string; name: string }[];
}

export const BuildPathPlanner = ({ combination, selectedSkills, archetypes }: BuildPathPlannerProps) => {
  const { theme } = useTheme();
  const [timeline, setTimeline] = useState<TimelineStep[]>([{ type: 'start' }]);
  const [primaryArchetypeId, setPrimaryArchetypeId] = useState(combination.archetype_id);

  // Reset primary if combination changes
  useMemo(() => {
    setPrimaryArchetypeId(combination.archetype_id);
  }, [combination.archetype_id]);

  // Group skills by best archetype
  const groupedSkills = useMemo(() => {
    const groups: Record<string, SkillAssignment[]> = {};
    if (!combination.skill_assignments) return {};

    combination.skill_assignments.forEach(assignment => {
      const archName = assignment.best_archetype_name;
      if (!groups[archName]) groups[archName] = [];
      groups[archName].push(assignment);
    });
    return groups;
  }, [combination]);

  // Calculate current timeline state
  const timelineState = useMemo(() => {
    let totalXp = 0;
    let wastedXp = 0;
    const activeArchetypes = new Set<string>([primaryArchetypeId]);
    const addedSkillIds = new Set<string>();

    const steps = timeline.map(step => {
      if (step.type === 'start') return { ...step, cumulativeXp: 0 };
      
      if (step.type === 'unlock_archetype') {
        activeArchetypes.add(step.archetypeId);
        totalXp += step.cost;
        return { ...step, cumulativeXp: totalXp };
      }

      if (step.type === 'skill') {
        addedSkillIds.add(step.skillId);
        // Check cost based on CURRENT active archetypes
        const bestArch = step.assignment.best_archetype_id;
        let cost = step.assignment.penalty_cost;
        let inefficient = true;

        if (activeArchetypes.has(bestArch)) {
            cost = step.assignment.cost;
            inefficient = false;
        } else {
             // Basic penalty check is sufficient for now based on backend logic
             // Backend provides penalty_cost as "worst case" or "unoptimized case"
        }

        if (inefficient) {
            wastedXp += (cost - step.assignment.cost);
        }
        totalXp += cost || 0;
        return { ...step, cost, inefficient, cumulativeXp: totalXp };
      }
      return step;
    });

    return { totalXp, wastedXp, activeArchetypes, addedSkillIds, steps };
  }, [timeline, combination, primaryArchetypeId]);

  // Suggest a better primary archetype based on added skills
  const suggestion = useMemo(() => {
    const skillCounts: Record<string, number> = {};
    
    // Count skills in timeline
    timeline.forEach(step => {
        if (step.type === 'skill') {
            const bestId = step.assignment.best_archetype_id;
            skillCounts[bestId] = (skillCounts[bestId] || 0) + 1;
        }
    });

    // Find archetype with most skills
    let maxCount = 0;
    let bestId = primaryArchetypeId;

    Object.entries(skillCounts).forEach(([id, count]) => {
        if (count > maxCount) {
            maxCount = count;
            bestId = id;
        }
    });

    if (bestId !== primaryArchetypeId) {
        const arch = archetypes.find(a => a.id === bestId);
        if (arch) return arch;
    }
    return null;
  }, [timeline, primaryArchetypeId, archetypes]);

  const addSkill = (assignment: SkillAssignment) => {
    setTimeline(prev => [...prev, { 
      type: 'skill', 
      skillId: assignment.skill_id, 
      assignment, 
      cost: 0, // Calculated in memo
      inefficient: false 
    }]);
  };

  const addUnlock = (id: string, name: string) => {
    setTimeline(prev => [...prev, { 
      type: 'unlock_archetype', 
      archetypeId: id, 
      archetypeName: name, 
      cost: 50 
    }]);
  };

  const removeStep = (index: number) => {
    setTimeline(prev => prev.filter((_, i) => i !== index));
  };

  const availableArchetypesToUnlock = useMemo(() => {
      const candidates = [];
      if (combination.secondary_archetype_id && !timelineState.activeArchetypes.has(combination.secondary_archetype_id)) {
          candidates.push({ id: combination.secondary_archetype_id, name: combination.secondary_archetype_name || "Secondary" });
      }
      if (combination.tertiary_archetype_id && !timelineState.activeArchetypes.has(combination.tertiary_archetype_id)) {
          candidates.push({ id: combination.tertiary_archetype_id, name: combination.tertiary_archetype_name || "Tertiary" });
      }
      return candidates;
  }, [combination, timelineState.activeArchetypes]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
      {/* Left Column: Skill Pool */}
      <div className="lg:col-span-1 space-y-4 overflow-y-auto pr-2 custom-scrollbar min-h-0">
        <h3 className="font-medieval text-xl mb-4 text-primary">Skill Pool</h3>
        {Object.entries(groupedSkills).map(([archName, skills]) => (
          <Card key={archName} className="bg-card/50 border-white/10">
            <CardHeader className="py-3">
              <CardTitle className="text-sm font-bold text-primary">{archName}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 p-3">
              {skills.map(skill => {
                const isAdded = timelineState.addedSkillIds.has(skill.skill_id);
                if (isAdded) return null;

                return (
                  <div 
                    key={skill.skill_id}
                    onClick={() => addSkill(skill)}
                    className="flex items-center justify-between p-2 rounded bg-background/50 hover:bg-primary/20 cursor-pointer transition-colors border border-white/5"
                  >
                    <span className="text-sm font-medium">{skill.skill_name}</span>
                    <Badge variant="outline" className="text-xs border-primary/20">{skill.cost} XP</Badge>
                  </div>
                );
              })}
              {skills.every(s => timelineState.addedSkillIds.has(s.skill_id)) && (
                <div className="text-xs text-muted-foreground italic text-center py-2">All skills added</div>
              )}
            </CardContent>
          </Card>
        ))}
        
        {/* Unlock Buttons */}
        {availableArchetypesToUnlock.length > 0 && (
            <div className="pt-4 border-t border-white/10">
                <h4 className="text-sm font-bold mb-2 text-muted-foreground">Available Unlocks</h4>
                <div className="space-y-2">
                    {availableArchetypesToUnlock.map(arch => (
                        <Button 
                            key={arch.id} 
                            variant="outline" 
                            className="w-full justify-between border-dashed border-primary/50 hover:bg-primary/10 text-primary"
                            onClick={() => addUnlock(arch.id, arch.name)}
                        >
                            <span>Unlock {arch.name}</span>
                            <span className="text-xs font-mono">50 XP</span>
                        </Button>
                    ))}
                </div>
            </div>
        )}
      </div>

      {/* Right Column: Timeline */}
      <div className="lg:col-span-2 flex flex-col h-full min-h-0 overflow-hidden bg-background/30 rounded-lg border border-white/5 p-4">
        {/* Stats Header */}
        <div className="flex items-center justify-between mb-4 bg-card/80 p-4 rounded-lg border border-white/10 shadow-sm">
            <div className="flex items-center gap-8">
                <div>
                    <div className="text-xs text-muted-foreground uppercase tracking-wider mb-1">Total Cost</div>
                    <div className="text-2xl font-medieval text-primary">{timelineState.totalXp} XP</div>
                </div>
                {timelineState.wastedXp > 0 && (
                    <div>
                        <div className="text-xs text-red-400 uppercase tracking-wider mb-1">Inefficiency</div>
                        <div className="text-xl font-bold text-red-500 flex items-center gap-1">
                            +{timelineState.wastedXp} XP
                            <AlertTriangle className="w-4 h-4" />
                        </div>
                    </div>
                )}
            </div>
            <Button variant="ghost" onClick={() => setTimeline([{ type: 'start' }])} size="sm" className="text-muted-foreground hover:text-white hover:bg-white/5">
                Reset Plan
            </Button>
        </div>

        {/* Timeline Items */}
        <div className="flex-1 overflow-y-auto space-y-3 pr-2 custom-scrollbar">
            {timelineState.steps.map((step, index) => {
                if (step.type === 'start') {
                    return (
                        <div key="start" className="space-y-2">
                            <div className="flex items-center gap-4 p-3 rounded-lg bg-primary/10 border border-primary/20">
                                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center font-bold text-primary border border-primary/50 text-sm">
                                    1
                                </div>
                                <div className="flex-1">
                                    <div className="font-bold text-primary mb-1">Start Journey</div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-xs text-primary/80">Primary Archetype:</span>
                                        <Select value={primaryArchetypeId} onValueChange={setPrimaryArchetypeId}>
                                            <SelectTrigger className="h-7 w-[200px] bg-background/50 border-primary/30 text-xs">
                                                <SelectValue />
                                            </SelectTrigger>
                                            <SelectContent>
                                                {archetypes.map(a => (
                                                    <SelectItem key={a.id} value={a.id}>{a.name}</SelectItem>
                                                ))}
                                            </SelectContent>
                                        </Select>
                                    </div>
                                </div>
                                <div className="font-mono text-sm text-primary/60">0 XP</div>
                            </div>

                            {suggestion && (
                                <Alert className="bg-amber-900/20 border-amber-600/50 py-2">
                                    <Lightbulb className="h-4 w-4 text-amber-500" />
                                    <AlertDescription className="text-xs flex items-center justify-between ml-2 w-full">
                                        <span className="text-amber-200">
                                            Consider starting with <strong>{suggestion.name}</strong> for better efficiency.
                                        </span>
                                        <Button 
                                            variant="ghost" 
                                            size="sm" 
                                            className="h-6 text-amber-400 hover:text-amber-300 hover:bg-amber-900/40"
                                            onClick={() => setPrimaryArchetypeId(suggestion.id)}
                                        >
                                            Switch
                                        </Button>
                                    </AlertDescription>
                                </Alert>
                            )}
                        </div>
                    );
                }

                return (
                    <div key={index} className="flex items-center gap-2 group relative pl-4">
                        {/* Connecting Line (visual only) */}
                        <div className="absolute left-[27px] -top-4 h-6 w-0.5 bg-white/10" />

                        <div className={cn(
                            "flex-1 flex items-center justify-between p-3 rounded-lg border transition-all",
                            step.type === 'unlock_archetype' 
                                ? "bg-purple-500/10 border-purple-500/30" 
                                : step.inefficient 
                                    ? "bg-red-500/10 border-red-500/30" 
                                    : "bg-card border-white/10"
                        )}>
                            <div className="flex items-center gap-4">
                                <div className={cn(
                                    "w-8 h-8 rounded-full flex items-center justify-center font-bold text-xs border shrink-0",
                                    step.type === 'unlock_archetype' 
                                        ? "bg-purple-900/50 border-purple-500 text-purple-200" 
                                        : step.inefficient
                                            ? "bg-red-900/20 border-red-500/50 text-red-200"
                                            : "bg-background border-white/20 text-muted-foreground"
                                )}>
                                    {index + 1}
                                </div>
                                
                                <div>
                                    {step.type === 'unlock_archetype' ? (
                                        <>
                                            <div className="font-bold text-purple-400">Unlock {step.archetypeName}</div>
                                            <div className="text-xs text-purple-300/60">Expands skill options</div>
                                        </>
                                    ) : (
                                        <>
                                            <div className="font-bold">{step.assignment.skill_name}</div>
                                            <div className="text-xs text-muted-foreground flex items-center gap-1">
                                                Best with: <span className="text-primary">{step.assignment.best_archetype_name}</span>
                                            </div>
                                        </>
                                    )}
                                </div>
                            </div>

                            <div className="flex items-center gap-4">
                                <div className="text-right">
                                    <div className={cn("font-mono font-bold", step.inefficient ? "text-red-400" : "text-white")}>
                                        {step.cost} XP
                                    </div>
                                    {step.inefficient && (
                                        <div className="text-[10px] text-red-400 flex items-center justify-end gap-1">
                                            <span>+{step.cost! - step.assignment.cost} wasted</span>
                                        </div>
                                    )}
                                </div>
                                <Button 
                                    variant="ghost" 
                                    size="icon" 
                                    className="opacity-0 group-hover:opacity-100 transition-opacity text-muted-foreground hover:text-red-400 hover:bg-red-500/10 h-8 w-8"
                                    onClick={() => removeStep(index)}
                                >
                                    <Trash2 className="w-4 h-4" />
                                </Button>
                            </div>
                        </div>
                    </div>
                );
            })}
            
            {/* End State */}
             {Object.keys(groupedSkills).length > 0 && Object.keys(groupedSkills).every(arch => 
                groupedSkills[arch].every(s => timelineState.addedSkillIds.has(s.skill_id))
            ) && (
                <div className="flex items-center gap-4 p-3 rounded-lg bg-green-500/10 border border-green-500/30 mt-4 ml-4">
                     <div className="w-8 h-8 rounded-full bg-green-600/20 border border-green-500/50 flex items-center justify-center shrink-0">
                        <CheckCircle2 className="w-5 h-5 text-green-500" />
                     </div>
                     <div>
                        <div className="font-bold text-green-400">Build Complete!</div>
                        <div className="text-xs text-green-300/60">All target skills acquired.</div>
                     </div>
                </div>
            )}
        </div>
      </div>
    </div>
  );
};
