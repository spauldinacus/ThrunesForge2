import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiClient } from 'app';
import { Event } from 'types';

interface JournalEntryFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: JournalEntryFormData) => void;
  initialData?: Partial<JournalEntryFormData>;
  isEdit?: boolean;
}

export interface JournalEntryFormData {
  title: string;
  content: string;
  tags: string[];
  eventId?: string;
  sharedWithStaff: boolean;
}

export function JournalEntryForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  isEdit = false,
}: JournalEntryFormProps) {
  const [formData, setFormData] = useState<JournalEntryFormData>({
    title: initialData?.title || '',
    content: initialData?.content || '',
    tags: initialData?.tags || [],
    eventId: initialData?.eventId,
    sharedWithStaff: initialData?.sharedWithStaff || false,
  });
  const [tagInput, setTagInput] = useState('');
  const [events, setEvents] = useState<Event[]>([]);
  const [loadingEvents, setLoadingEvents] = useState(false);

  // Load events for linking
  useEffect(() => {
    if (open) {
      loadEvents();
    }
  }, [open]);

  const loadEvents = async () => {
    setLoadingEvents(true);
    try {
      const response = await apiClient.list_events({});
      if (response.ok) {
        const data = await response.json();
        setEvents(Array.isArray(data.events) ? data.events : []);
      }
    } catch (error) {
      console.error('Failed to load events:', error);
    } finally {
      setLoadingEvents(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const addTag = () => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, tagInput.trim()],
      });
      setTagInput('');
    }
  };

  const removeTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter((t) => t !== tag),
    });
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addTag();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Edit' : 'Create'} Journal Entry</DialogTitle>
          <DialogDescription>
            Record your character's experiences, thoughts, and development.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="title">Title *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="e.g., Reflections on the Battle of Thornridge"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="content">Content *</Label>
            <Textarea
              id="content"
              value={formData.content}
              onChange={(e) => setFormData({ ...formData, content: e.target.value })}
              placeholder="Write your journal entry here...\n\nWhat happened? How does your character feel? What did they learn?"
              rows={10}
              required
              className="font-serif"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="event">Link to Event (optional)</Label>
            <Select
              value={formData.eventId || 'none'}
              onValueChange={(value) =>
                setFormData({ ...formData, eventId: value === 'none' ? undefined : value })
              }
              disabled={loadingEvents}
            >
              <SelectTrigger id="event">
                <SelectValue placeholder={loadingEvents ? 'Loading events...' : 'Select an event'} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">No event</SelectItem>
                {events.map((event) => (
                  <SelectItem key={event.id} value={event.id}>
                    {event.title} - {new Date(event.starts_at).toLocaleDateString()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="tags">Tags</Label>
            <div className="flex gap-2">
              <Input
                id="tags"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Add tags (press Enter)"
              />
              <Button type="button" variant="outline" onClick={addTag}>
                Add
              </Button>
            </div>
            {formData.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {formData.tags.map((tag, index) => (
                  <div
                    key={index}
                    className="inline-flex items-center gap-1 bg-secondary text-secondary-foreground px-2 py-1 rounded-md text-sm"
                  >
                    <span>{tag}</span>
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="hover:text-destructive"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border/50 p-4">
            <div className="space-y-0.5">
              <Label htmlFor="share">Share with Staff</Label>
              <p className="text-sm text-muted-foreground">
                Allow staff to read this journal entry
              </p>
            </div>
            <Switch
              id="share"
              checked={formData.sharedWithStaff}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, sharedWithStaff: checked })
              }
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{isEdit ? 'Update' : 'Create'} Entry</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
