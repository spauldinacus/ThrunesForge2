import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, Circle, Lock, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface MilestoneCardProps {
  name: string;
  description: string;
  category: string;
  milestoneType?: string;
  currentProgress: number;
  targetProgress?: number | null;
  completed: boolean;
  notes?: string | null;
  sharedWithStaff: boolean;
  isCustom?: boolean;
  awardedBy?: string | null;
  onEdit?: () => void;
  onDelete?: () => void;
  onToggleShare?: () => void;
  onAddNotes?: () => void;
  onMarkComplete?: () => void;
}

export function MilestoneCard({
  name,
  description,
  category,
  milestoneType,
  currentProgress,
  targetProgress,
  completed,
  notes,
  sharedWithStaff,
  isCustom = false,
  awardedBy,
  onEdit,
  onDelete,
  onToggleShare,
  onAddNotes,
  onMarkComplete,
}: MilestoneCardProps) {
  const progress = targetProgress ? (currentProgress / targetProgress) * 100 : 0;
  const hasTarget = targetProgress !== null && targetProgress !== undefined;

  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {completed ? (
                <CheckCircle2 className="h-5 w-5 text-green-500" />
              ) : (
                <Circle className="h-5 w-5 text-muted-foreground" />
              )}
              <CardTitle className="text-lg">{name}</CardTitle>
            </div>
            <CardDescription>{description}</CardDescription>
          </div>
          <div className="flex flex-col gap-2">
            <Badge variant="outline" className="w-fit">
              {category}
            </Badge>
            {isCustom && (
              <Badge variant="secondary" className="w-fit">
                Custom
              </Badge>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Progress Bar */}
        {hasTarget && (
          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Progress</span>
              <span className="font-medium">
                {currentProgress} / {targetProgress}
              </span>
            </div>
            <Progress value={Math.min(progress, 100)} className="h-2" />
          </div>
        )}

        {/* Notes */}
        {notes && (
          <div className="rounded-lg bg-muted/50 p-3">
            <p className="text-sm text-muted-foreground">{notes}</p>
          </div>
        )}

        {/* Status Indicators */}
        <div className="flex flex-col gap-2">
          {awardedBy && (
            <div className="flex items-center gap-1.5 text-sm text-amber-500">
              <CheckCircle2 className="h-4 w-4" />
              <span>Awarded by {awardedBy}</span>
            </div>
          )}
          <div className="flex items-center gap-3 text-sm">
            {sharedWithStaff ? (
              <div className="flex items-center gap-1.5 text-blue-500 dark:text-blue-400">
                <Users className="h-4 w-4" />
                <span>Shared with staff</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-muted-foreground">
                <Lock className="h-4 w-4" />
                <span>Private</span>
              </div>
            )}
          </div>
        </div>

        {/* Action Buttons */}
        {(onEdit || onDelete || onToggleShare || onAddNotes) && (
          <div className="flex flex-wrap gap-2 pt-2">
            {onAddNotes && (
              <Button variant="outline" size="sm" onClick={onAddNotes}>
                {notes ? 'Edit Notes' : 'Add Notes'}
              </Button>
            )}
            {milestoneType === 'other' && !isCustom && onMarkComplete && (
              <Button
                variant={completed ? "outline" : "default"}
                size="sm"
                onClick={onMarkComplete}
                className={completed ? "border-green-600 text-green-300" : "bg-purple-600 hover:bg-purple-700"}
              >
                {completed ? 'Unmark Complete' : 'Mark Complete'}
              </Button>
            )}
            {onToggleShare && (
              <Button variant="outline" size="sm" onClick={onToggleShare}>
                {sharedWithStaff ? 'Make Private' : 'Share with Staff'}
              </Button>
            )}
            {onEdit && (
              <Button variant="outline" size="sm" onClick={onEdit}>
                Edit
              </Button>
            )}
            {onDelete && (
              <Button variant="destructive" size="sm" onClick={onDelete}>
                Delete
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
