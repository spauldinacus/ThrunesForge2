import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type {
  LoreSubmissionCreate,
  LoreSubmissionUpdate,
  LoreSubmissionResponse,
  AdminEventResponse,
  // CharacterListItem not needed - using Record<string, any>[]
  ChapterResponse,
} from 'types';

interface Props {
  onSuccess: () => void;
  onCancel: () => void;
  existingSubmission?: LoreSubmissionResponse;
}

export default function LoreSubmissionForm({ onSuccess, onCancel, existingSubmission }: Props) {
  const [loading, setLoading] = useState(false);
  const [events, setEvents] = useState<AdminEventResponse[]>([]);
  const [chapters, setChapters] = useState<ChapterResponse[]>([]);
  const [characters, setCharacters] = useState<Record<string, any>[]>([]);
  const [loadingData, setLoadingData] = useState(true);

  // Form fields
  const [eventId, setEventId] = useState(existingSubmission?.event_id || '');
  const [chapterId, setChapterId] = useState(existingSubmission?.chapter_id || '');
  const [characterId, setCharacterId] = useState(existingSubmission?.character_id || '');
  const [availableLores, setAvailableLores] = useState<string[]>([]);
  const [selectedLores, setSelectedLores] = useState<string[]>(
    existingSubmission?.lores_used ? existingSubmission.lores_used.split(', ') : []
  );
  const [outcome, setOutcome] = useState(existingSubmission?.outcome || '');
  const [itemsUsed, setItemsUsed] = useState(existingSubmission?.items_used || '');
  const [link, setLink] = useState(existingSubmission?.link || '');

  // Search/filter states
  const [eventSearch, setEventSearch] = useState('');
  const [chapterSearch, setChapterSearch] = useState('');
  const [characterSearch, setCharacterSearch] = useState('');

  useEffect(() => {
    loadFormData();
  }, []);

  const loadFormData = async () => {
    try {
      setLoadingData(true);
      const [eventsRes, chaptersRes, charactersRes] = await Promise.all([
        apiClient.list_scoped_events(),
        apiClient.list_scoped_chapters(),
        apiClient.list_scoped_characters(),
      ]);

      const eventsData = await eventsRes.json();
      const chaptersData = await chaptersRes.json();
      const charactersData = await charactersRes.json();

      setEvents(eventsData.events || []);
      setChapters(chaptersData.chapters || []);
      setCharacters(charactersData || []);
          } catch (error) {
      console.error('Failed to load form data:', error);
      toast.error('Failed to load form data');
    } finally {
      setLoadingData(false);
    }
  };

  // Handler for character selection - auto-select chapter, last event, and load lores
  const handleCharacterChange = async (selectedCharacterId: string) => {
    setCharacterId(selectedCharacterId);
    
    const selectedCharacter = characters.find(c => c.id === selectedCharacterId);
    if (selectedCharacter) {
      // Auto-select chapter
      if (selectedCharacter.chapter_id) {
        setChapterId(selectedCharacter.chapter_id);
      }
      
      // Auto-select last attended event
      if (selectedCharacter.last_attended_event_id) {
        setEventId(selectedCharacter.last_attended_event_id);
      }
      
      // Fetch character's full details to get skills with names
      try {
        const charResponse = await apiClient.get_admin_character({ characterId: selectedCharacterId });
        const charData = await charResponse.json();
        
        // Filter skills to only those containing "lore" in the name (case-insensitive)
        const loreSkills = (charData.selected_skills || [])
          .filter((skill: any) => skill.name.toLowerCase().includes('lore'))
          .map((skill: any) => skill.name);
        
        // Remove duplicates
        const uniqueLores = [...new Set(loreSkills)];
        setAvailableLores(uniqueLores);
        
        // Auto-select all available lores
        setSelectedLores(uniqueLores);
      } catch (error) {
        console.error('Failed to load character skills:', error);
        toast.error('Failed to load character lore skills');
        setAvailableLores([]);
      }
    }
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation
    if (!eventId || !chapterId || !characterId || !outcome) {
      toast.error('Please fill in all required fields');
      return;
    }
    
    setLoading(true);
    try {
      // Convert selected lores array to comma-separated string
      const loresUsedString = selectedLores.join(', ');
      
      if (existingSubmission) {
        // Update existing submission
        const updateData: LoreSubmissionUpdate = {
          event_id: eventId,
          chapter_id: chapterId,
          character_id: characterId,
          lores_used: loresUsedString,
          outcome: outcome,
          items_used: itemsUsed || null,
          link: link || null,
        };
        await apiClient.update_lore_submission(
          { submissionId: existingSubmission.id },  // Line 122 - camelCase!
          updateData
        );
        toast.success('Lore submission updated successfully');
      } else {
        // Create new submission
        const createData: LoreSubmissionCreate = {
          event_id: eventId,
          chapter_id: chapterId,
          character_id: characterId,
          lores_used: loresUsedString,
          outcome: outcome,
          items_used: itemsUsed || null,
          link: link || null,
        };
        await apiClient.create_lore_submission(createData);
        toast.success('Lore submission created successfully');
      }
      onSuccess();
    } catch (error) {
      console.error('Error saving lore submission:', error);
      toast.error('Failed to save lore submission');
    } finally {
      setLoading(false);
    }
  };

  const filteredEvents = (events || []).filter((event) =>
    event.title.toLowerCase().includes(eventSearch.toLowerCase())
  );

  const filteredChapters = (chapters || []).filter((chapter) =>
    chapter.name.toLowerCase().includes(chapterSearch.toLowerCase())
  );

  const filteredCharacters = (characters || [])
    .filter((character) =>
      character.name.toLowerCase().includes(characterSearch.toLowerCase())
    )
    .sort((a, b) => a.name.localeCompare(b.name));

  if (loadingData) {
    return (
      <div className="flex items-center justify-center p-8">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
            {/* Character Selection */}
      <div className="space-y-2">
        <Label htmlFor="character" className="text-purple-200">
          Character <span className="text-red-400">*</span>
        </Label>
        <Select value={characterId} onValueChange={handleCharacterChange}>
          <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
            <SelectValue placeholder="Select a character" />
          </SelectTrigger>
          <SelectContent className="bg-purple-900 border-purple-700">
            <div className="p-2">
              <Input
                placeholder="Search characters..."
                value={characterSearch}
                onChange={(e) => setCharacterSearch(e.target.value)}
                className="bg-purple-800/50 border-purple-600 text-purple-100"
              />
            </div>
            {filteredCharacters.map((character) => (
              <SelectItem key={character.id} value={character.id} className="text-purple-100">
                {character.name} ({character.player_name})
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      
      {/* Event Selection */}
      <div className="space-y-2">
        <Label htmlFor="event" className="text-purple-200">
          Event <span className="text-red-400">*</span>
        </Label>
        <Select value={eventId} onValueChange={setEventId}>
          <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
            <SelectValue placeholder="Select an event" />
          </SelectTrigger>
          <SelectContent className="bg-purple-900 border-purple-700">
            <div className="p-2">
              <Input
                placeholder="Search events..."
                value={eventSearch}
                onChange={(e) => setEventSearch(e.target.value)}
                className="bg-purple-800/50 border-purple-600 text-purple-100"
              />
            </div>
            {filteredEvents.map((event) => (
              <SelectItem key={event.id} value={event.id} className="text-purple-100">
                {event.title}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Chapter Selection */}
      <div className="space-y-2">
        <Label htmlFor="chapter" className="text-purple-200">
          Chapter <span className="text-red-400">*</span>
        </Label>
        <Select value={chapterId} onValueChange={setChapterId}>
          <SelectTrigger className="bg-purple-900/20 border-purple-700/50 text-purple-100">
            <SelectValue placeholder="Select a chapter" />
          </SelectTrigger>
          <SelectContent className="bg-purple-900 border-purple-700">
            <div className="p-2">
              <Input
                placeholder="Search chapters..."
                value={chapterSearch}
                onChange={(e) => setChapterSearch(e.target.value)}
                className="bg-purple-800/50 border-purple-600 text-purple-100"
              />
            </div>
            {filteredChapters.map((chapter) => (
              <SelectItem key={chapter.id} value={chapter.id} className="text-purple-100">
                {chapter.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Lores Used - Multi-select */}
      <div className="space-y-2">
        <Label className="text-purple-200">
          Lores Used
        </Label>
        {availableLores.length > 0 ? (
          <div className="bg-purple-900/20 border border-purple-700/50 rounded-md p-4 space-y-3 max-h-48 overflow-y-auto">
            {availableLores.map((lore) => (
              <div key={lore} className="flex items-center space-x-2">
                <Checkbox
                  id={`lore-${lore}`}
                  checked={selectedLores.includes(lore)}
                  onCheckedChange={(checked) => {
                    if (checked) {
                      setSelectedLores([...selectedLores, lore]);
                    } else {
                      setSelectedLores(selectedLores.filter(l => l !== lore));
                    }
                  }}
                  className="border-purple-500 data-[state=checked]:bg-purple-600"
                />
                <label
                  htmlFor={`lore-${lore}`}
                  className="text-sm text-purple-100 cursor-pointer flex-1"
                >
                  {lore}
                </label>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-purple-900/20 border border-purple-700/50 rounded-md p-4 text-center text-purple-400">
            {characterId ? 'This character has no lore skills' : 'Select a character to see available lores'}
          </div>
        )}
        {selectedLores.length > 0 && (
          <div className="text-sm text-purple-300">
            Selected: {selectedLores.join(', ')}
          </div>
        )}
      </div>

            {/* Items Used */}
      <div className="space-y-2">
        <Label htmlFor="itemsUsed" className="text-purple-200">
          Items Used
        </Label>
        <Input
          id="itemsUsed"
          value={itemsUsed}
          onChange={(e) => setItemsUsed(e.target.value)}
          placeholder="e.g., Ancient Scroll, Magic Crystal"
          className="bg-purple-900/20 border-purple-700/50 text-purple-100"
        />
      </div>
      
      {/* Outcome */}
      <div className="space-y-2">
        <Label htmlFor="outcome" className="text-purple-200">
          Outcome <span className="text-red-400">*</span>
        </Label>
        <Textarea
          id="outcome"
          value={outcome}
          onChange={(e) => setOutcome(e.target.value)}
          placeholder="Describe the findings or results of the lore research..."
          className="bg-purple-900/20 border-purple-700/50 text-purple-100 min-h-[120px]"
          required
        />
      </div>

      {/* Reference Link */}
      <div className="space-y-2">
        <Label htmlFor="link" className="text-purple-200">
          Reference Link (Optional)
        </Label>
        <Input
          id="link"
          type="url"
          value={link}
          onChange={(e) => setLink(e.target.value)}
          placeholder="https://..."
          className="bg-purple-900/20 border-purple-700/50 text-purple-100"
        />
      </div>

      {/* Actions */}
      <div className="flex gap-3 pt-4">
        <Button
          type="submit"
          disabled={loading}
          className="flex-1 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
        >
          {loading ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Saving...
            </>
          ) : existingSubmission ? (
            'Update Submission'
          ) : (
            'Create Submission'
          )}
        </Button>
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={loading}
          className="border-purple-700/50 text-purple-200 hover:bg-purple-900/20"
        >
          Cancel
        </Button>
      </div>
    </form>
  );
}
