import React from 'react';
import { useUser } from '@stackframe/react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator
} from '@/components/ui/dropdown-menu';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { User, Settings, LogOut } from 'lucide-react';
import { stackClientApp } from 'app/auth';

interface Props {
  className?: string;
}

export const UserButton: React.FC<Props> = ({ className }) => {
  const user = useUser();
  const navigate = useNavigate();

  if (!user) {
    return null;
  }

  const displayName = user.displayName || user.primaryEmail || 'User';
  const initials = displayName
    .split(' ')
    .map(name => name.charAt(0))
    .join('')
    .toUpperCase()
    .slice(0, 2);

  const handleSignOut = async () => {
    try {
      await stackClientApp.signOut();
      navigate('/');
    } catch (error) {
      console.error('Sign out error:', error);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button 
          variant="ghost" 
          className={`h-10 w-10 rounded-full p-0 hover:bg-purple-600/20 ${className}`}
        >
          <Avatar className="h-9 w-9 border-2 border-purple-400/30">
            <AvatarFallback className="bg-gradient-to-br from-purple-600/30 to-blue-600/30 text-purple-200 font-medium">
              {initials}
            </AvatarFallback>
          </Avatar>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent 
        className="w-56 bg-gray-900/95 border-purple-500/30 backdrop-blur-sm" 
        align="end"
      >
        <div className="px-3 py-2">
          <p className="text-sm font-medium text-purple-200">{displayName}</p>
          {user.primaryEmail && (
            <p className="text-xs text-purple-300/70">{user.primaryEmail}</p>
          )}
        </div>
        <DropdownMenuSeparator className="bg-purple-500/30" />
        <DropdownMenuItem 
          onClick={() => navigate('/player-profile')}
          className="text-purple-200 hover:bg-purple-600/20 focus:bg-purple-600/20 cursor-pointer"
        >
          <User className="mr-2 h-4 w-4" />
          Player Profile
        </DropdownMenuItem>
        <DropdownMenuItem 
          onClick={() => navigate('/auth/account-settings')}
          className="text-purple-200 hover:bg-purple-600/20 focus:bg-purple-600/20 cursor-pointer"
        >
          <Settings className="mr-2 h-4 w-4" />
          Account Settings
        </DropdownMenuItem>
        <DropdownMenuSeparator className="bg-purple-500/30" />
        <DropdownMenuItem 
          onClick={handleSignOut}
          className="text-red-400 hover:bg-red-600/20 focus:bg-red-600/20 cursor-pointer"
        >
          <LogOut className="mr-2 h-4 w-4" />
          Sign Out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default UserButton;
