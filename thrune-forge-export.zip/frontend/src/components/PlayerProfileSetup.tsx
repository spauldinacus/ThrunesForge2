import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useUserGuardContext } from 'app/auth';
import { apiClient } from 'app';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Loader2, UserPlus, Sparkles } from 'lucide-react';
import type { CreatePlayerProfileRequest, PlayerProfile, Chapter } from 'types';
import { clearPermissionsCache } from 'utils/usePermissions';
import { useProfileStatusStore } from 'utils/profileStatusStore';
import { errorCapture } from 'utils/errorCapture';


export const PlayerProfileSetup = () => {
  const { user } = useUserGuardContext();
  const navigate = useNavigate();
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<CreatePlayerProfileRequest>({
    first_name: '',
    last_name: '',
    phone_number: '',
    emergency_contact_name: '',
    emergency_contact_phone: '',
    chapter_id: '' as any
  });

  // Get profile status store actions
  const { updateProfileStatus } = useProfileStatusStore();

  // Load chapters on mount
  useEffect(() => {
    const loadChapters = async () => {
      try {
        const response = await apiClient.list_public_chapters();
        const chaptersData = await response.json();
        setChapters(chaptersData.chapters || []);
      } catch (error) {
        console.error('Failed to load chapters:', error);
        toast.error('Failed to load chapters');
      }
    };
    loadChapters();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const response = await apiClient.create_player_profile(formData);
      const profile: PlayerProfile = await response.json();
      
      // Immediately update profile status store to sync UI state
      updateProfileStatus(true); // hasProfile = true
      
      // Clear permissions cache to force re-fetch on home page
      clearPermissionsCache();
            
      toast.success(`Welcome to Thrune's Forge! Your player number is ${profile.player_number}`);
      navigate('/');
    } catch (error: any) {
      console.error('Profile creation failed:', error);
      
      if (error.status === 400) {
        const errorData = await error.json();
        toast.error(errorData.detail || 'Please check your information and try again');
      } else {
        toast.error('Failed to create profile. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const isFormValid = formData.first_name && formData.last_name && formData.chapter_id;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center p-6">
      <Card className="w-full max-w-2xl bg-black/60 backdrop-blur-xl border-purple-500/30 shadow-2xl shadow-purple-500/10">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <div className="p-4 rounded-full bg-gradient-to-br from-purple-500/20 to-amber-500/20">
              <UserPlus className="w-12 h-12 text-purple-300" />
            </div>
          </div>
          <CardTitle className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400">
            Complete Your Player Profile
          </CardTitle>
          <p className="text-purple-200/80">
            Welcome to Thrune's Forge! Please complete your player profile to get started.
          </p>
        </CardHeader>

        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-purple-300 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Basic Information
              </h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="first_name" className="text-purple-200">
                    First Name *
                  </Label>
                  <Input
                    id="first_name"
                    value={formData.first_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, first_name: e.target.value }))}
                    className="bg-black/40 border-purple-500/30 text-white placeholder-purple-300/50"
                    placeholder="Enter your first name"
                    required
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="last_name" className="text-purple-200">
                    Last Name *
                  </Label>
                  <Input
                    id="last_name"
                    value={formData.last_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, last_name: e.target.value }))}
                    className="bg-black/40 border-purple-500/30 text-white placeholder-purple-300/50"
                    placeholder="Enter your last name"
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone_number" className="text-purple-200">
                  Phone Number
                </Label>
                <Input
                  id="phone_number"
                  type="tel"
                  value={formData.phone_number}
                  onChange={(e) => setFormData(prev => ({ ...prev, phone_number: e.target.value }))}
                  className="bg-black/40 border-purple-500/30 text-white placeholder-purple-300/50"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            {/* Emergency Contact */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-purple-300 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Emergency Contact
              </h3>
              
              <div className="space-y-2">
                <Label htmlFor="emergency_contact_name" className="text-purple-200">
                  Emergency Contact Name
                </Label>
                <Input
                  id="emergency_contact_name"
                  value={formData.emergency_contact_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_name: e.target.value }))}
                  className="bg-black/40 border-purple-500/30 text-white placeholder-purple-300/50"
                  placeholder="Full name of emergency contact"
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="emergency_contact_phone" className="text-purple-200">
                  Emergency Contact Phone
                </Label>
                <Input
                  id="emergency_contact_phone"
                  type="tel"
                  value={formData.emergency_contact_phone}
                  onChange={(e) => setFormData(prev => ({ ...prev, emergency_contact_phone: e.target.value }))}
                  className="bg-black/40 border-purple-500/30 text-white placeholder-purple-300/50"
                  placeholder="(555) 123-4567"
                />
              </div>
            </div>

            {/* Chapter Selection */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-purple-300 flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Chapter Selection
              </h3>
              
              <div className="space-y-2">
                <Label htmlFor="chapter_id" className="text-purple-200">
                  Choose Your Chapter *
                </Label>
                <Select
                  value={formData.chapter_id.toString()}
                  onValueChange={(value) => setFormData(prev => ({ ...prev, chapter_id: value as any }))}
                >
                  <SelectTrigger className="bg-black/40 border-purple-500/30 text-white">
                    <SelectValue placeholder="Select a chapter" />
                  </SelectTrigger>
                  <SelectContent className="bg-black/90 border-purple-500/30">
                    {(chapters || [])
                      .filter(chapter => chapter.id && chapter.id.trim() !== '')
                      .map((chapter) => (
                        <SelectItem 
                          key={chapter.id} 
                          value={chapter.id}
                          className="text-white hover:bg-purple-500/20"
                        >
                          {chapter.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            {/* Submit Button */}
            <div className="pt-6">
              <Button
                type="submit"
                disabled={!isFormValid || loading}
                className="w-full bg-gradient-to-r from-purple-600 to-amber-600 hover:from-purple-700 hover:to-amber-700 text-white font-semibold py-3 px-6 rounded-lg shadow-lg shadow-purple-500/25 hover:shadow-purple-500/40 transition-all duration-200"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-5 h-5 mr-2 animate-spin" />
                    Creating Profile...
                  </>
                ) : (
                  'Complete Registration'
                )}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default PlayerProfileSetup;
