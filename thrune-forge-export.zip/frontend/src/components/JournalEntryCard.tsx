import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Calendar, Lock, Users, BookOpen } from 'lucide-react';
import { format } from 'date-fns';

interface JournalEntryCardProps {
  title: string;
  content: string;
  tags?: string[];
  eventTitle?: string | null;
  sharedWithStaff: boolean;
  createdAt: string;
  onEdit?: () => void;
  onDelete?: () => void;
  onToggleShare?: () => void;
}

export function JournalEntryCard({
  title,
  content,
  tags = [],
  eventTitle,
  sharedWithStaff,
  createdAt,
  onEdit,
  onDelete,
  onToggleShare,
}: JournalEntryCardProps) {
  return (
    <Card className="border-border/50 bg-card/50 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <BookOpen className="h-5 w-5 text-purple-500 dark:text-purple-400" />
              <CardTitle className="text-lg">{title}</CardTitle>
            </div>
            <CardDescription className="flex items-center gap-2">
              <Calendar className="h-3.5 w-3.5" />
              {format(new Date(createdAt), 'PPP')}
            </CardDescription>
          </div>
          <div className="flex items-center gap-2">
            {sharedWithStaff ? (
              <div className="flex items-center gap-1.5 text-blue-500 dark:text-blue-400 text-sm">
                <Users className="h-4 w-4" />
                <span>Shared</span>
              </div>
            ) : (
              <div className="flex items-center gap-1.5 text-muted-foreground text-sm">
                <Lock className="h-4 w-4" />
                <span>Private</span>
              </div>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Event Link */}
        {eventTitle && (
          <div className="rounded-lg bg-purple-500/10 border border-purple-500/20 p-2 px-3">
            <p className="text-sm text-purple-600 dark:text-purple-400">
              Event: {eventTitle}
            </p>
          </div>
        )}

        {/* Content */}
        <div className="prose prose-sm dark:prose-invert max-w-none">
          <p className="text-foreground whitespace-pre-wrap">{content}</p>
        </div>

        {/* Tags */}
        {tags.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {tags.map((tag, index) => (
              <Badge key={index} variant="secondary" className="text-xs">
                {tag}
              </Badge>
            ))}
          </div>
        )}

        {/* Action Buttons */}
        {(onEdit || onDelete || onToggleShare) && (
          <div className="flex flex-wrap gap-2 pt-2">
            {onToggleShare && (
              <Button variant="outline" size="sm" onClick={onToggleShare}>
                {sharedWithStaff ? 'Make Private' : 'Share with Staff'}
              </Button>
            )}
            {onEdit && (
              <Button variant="outline" size="sm" onClick={onEdit}>
                Edit
              </Button>
            )}
            {onDelete && (
              <Button variant="destructive" size="sm" onClick={onDelete}>
                Delete
              </Button>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
