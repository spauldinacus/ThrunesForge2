
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Plus, Minus } from 'lucide-react';
import { CharacterData } from 'utils/characterTypes';
import { calculateBodyStaminaXPCost } from 'utils/xpCalculations';

interface StatManagerProps {
  characterData: CharacterData;
  onStatChange: (stat: 'body' | 'stamina', increment: boolean) => void;
  xpAvailable: number;
}

export const StatManager: React.FC<StatManagerProps> = ({
  characterData,
  onStatChange,
  xpAvailable
}) => {
  // Add null safety for characterData
  if (!characterData) {
    return (
      <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-700/50">
        <CardHeader>
          <CardTitle className="text-purple-100">Physical Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-purple-400 text-center py-4">
            Character data not available
          </div>
        </CardContent>
      </Card>
    );
  }

  const getNextCost = (stat: 'body' | 'stamina', increment: boolean) => {
    const currentValue = characterData[stat] || 10; // Default to 10 if undefined
    if (increment) {
      return calculateBodyStaminaXPCost(currentValue, currentValue + 1);
    }
    return calculateBodyStaminaXPCost(currentValue - 1, currentValue);
  };

  const canIncrease = (stat: 'body' | 'stamina') => {
    const currentValue = characterData[stat] || 10;
    const cost = getNextCost(stat, true);
    return currentValue < 100 && (xpAvailable || 0) >= cost;
  };

  const canDecrease = (stat: 'body' | 'stamina') => {
    const currentValue = characterData[stat] || 10;
    return currentValue > 10;
  };

  return (
    <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-700/50">
      <CardHeader>
        <CardTitle className="text-purple-100 flex items-center gap-2">
          Physical Stats
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Body */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-purple-300 font-medium">Body:</span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatChange('body', false)}
                disabled={!canDecrease('body')}
                className="h-8 w-8 p-0"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center font-bold text-purple-100">
                {characterData.body}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatChange('body', true)}
                disabled={!canIncrease('body')}
                className="h-8 w-8 p-0"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="text-xs text-purple-400 text-right">
            Next: {getNextCost('body', true)} XP
          </div>
        </div>

        {/* Stamina */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-purple-300 font-medium">Stamina:</span>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatChange('stamina', false)}
                disabled={!canDecrease('stamina')}
                className="h-8 w-8 p-0"
              >
                <Minus className="h-4 w-4" />
              </Button>
              <span className="w-12 text-center font-bold text-purple-100">
                {characterData.stamina}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => onStatChange('stamina', true)}
                disabled={!canIncrease('stamina')}
                className="h-8 w-8 p-0"
              >
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <div className="text-xs text-purple-400 text-right">
            Next: {getNextCost('stamina', true)} XP
          </div>
        </div>
      </CardContent>
    </Card>
  );
};
