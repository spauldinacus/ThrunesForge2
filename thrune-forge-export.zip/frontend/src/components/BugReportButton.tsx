import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Bug } from 'lucide-react';
import { BugReportModal } from 'components/BugReportModal';

export function BugReportButton() {
  const [showModal, setShowModal] = useState(false);

  return (
    <>
      <Button
        onClick={() => setShowModal(true)}
        className="fixed bottom-6 left-6 z-50 rounded-full w-14 h-14 bg-purple-600 hover:bg-purple-700 shadow-lg border-2 border-purple-400/30"
        title="Report a Bug"
      >
        <Bug className="w-6 h-6 text-white" />
      </Button>

      <BugReportModal 
        open={showModal} 
        onClose={() => setShowModal(false)} 
      />
    </>
  );
}