

import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Plus, Minus, ArrowUpDown, Lock } from 'lucide-react';
import { ScrollArea } from '@/components/ui/scroll-area';
import { SkillWithState, SkillSortMode } from 'utils/characterTypes';

interface SkillSelectorProps {
  skills: SkillWithState[];
  selectedSkills: Record<string, number>;
  sortMode: SkillSortMode;
  onSortModeChange: (mode: SkillSortMode) => void;
  onAddSkill: (skill: SkillWithState) => void;
  onRemoveSkill: (skill: SkillWithState) => void;
  xpAvailable: number;
  xpCalculating: boolean;
  isLoading?: boolean; // Add loading prop
}

export const SkillSelector: React.FC<SkillSelectorProps> = ({
  skills,
  selectedSkills,
  sortMode,
  onSortModeChange,
  onAddSkill,
  onRemoveSkill,
  xpAvailable,
  xpCalculating,
  isLoading = false // Default to false
}) => {
  const [open, setOpen] = React.useState(false);

  const getSkillBadgeColor = (skill: SkillWithState) => {
    if (!skill) return 'bg-purple-600 hover:bg-purple-700';
    if (skill.is_primary) return 'bg-green-600 hover:bg-green-700';
    if (skill.is_secondary) return 'bg-blue-600 hover:bg-blue-700';
    return 'bg-purple-600 hover:bg-purple-700';
  };

  const getSkillTypeLabel = (skill: SkillWithState) => {
    if (!skill) return 'General (20 XP)';
    if (skill.is_primary) return 'Primary (5 XP)';
    if (skill.is_secondary) return 'Secondary (10 XP)';
    return 'General (20 XP)';
  };

  // Add safety check for skills array
  const safeSkills = skills || [];

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className="w-full border-purple-600 text-purple-300 hover:bg-purple-900/50"
        >
          <Plus className="mr-2 h-4 w-4" />
          Add Skills
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[80vh] bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 border-purple-500">
        <DialogHeader>
          <DialogTitle className="text-purple-100 flex items-center justify-between">
            <span>Select Skills</span>
            <div className="flex items-center gap-2">
              {xpCalculating && (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-400"></div>
              )}
              <span className={`text-sm font-medium ${
                xpAvailable < 0 ? 'text-red-400' : 'text-green-400'
              }`}>
                {xpAvailable} XP Available
              </span>
            </div>
          </DialogTitle>
          <div className="flex items-center gap-2 mt-2">
            <Button
              variant={sortMode === 'category' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onSortModeChange('category')}
              className="text-xs"
            >
              Category
            </Button>
            <Button
              variant={sortMode === 'alphabetical' ? 'default' : 'outline'}
              size="sm"
              onClick={() => onSortModeChange('alphabetical')}
              className="text-xs"
            >
              <ArrowUpDown className="h-3 w-3 mr-1" />
              A-Z
            </Button>
          </div>
        </DialogHeader>
        
        <ScrollArea className="h-96">
          <div className="space-y-2 p-2">
            {isLoading ? (
              <div className="text-center text-purple-400 py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400 mx-auto mb-2"></div>
                Loading skills...
              </div>
            ) : safeSkills.length === 0 ? (
              <div className="text-center text-purple-400 py-8">
                No skills available
              </div>
            ) : (
              safeSkills.map((skill) => {
                if (!skill || !skill.id) return null;
                
                const currentPurchases = selectedSkills[skill.id] || 0;
                const maxPurchases = skill.max_purchases || 1;
                const canAdd = currentPurchases < maxPurchases && !skill.is_locked && 
                  (skill.xp_cost || 0) <= xpAvailable;
                const canRemove = currentPurchases > 0;
                
                return (
                  <div
                    key={skill.id}
                    className={`p-3 rounded-lg border transition-all ${
                      skill.is_locked
                        ? 'bg-gray-800/50 border-gray-700 opacity-50'
                        : 'bg-purple-900/30 border-purple-700/50 hover:border-purple-600'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-purple-100">{skill.name}</h4>
                          {skill.is_locked && <Lock className="h-4 w-4 text-gray-400" />}
                          <Badge 
                            className={`text-xs ${getSkillBadgeColor(skill)}`}
                          >
                            {getSkillTypeLabel(skill)}
                          </Badge>
                          {currentPurchases > 0 && (
                            <Badge variant="secondary" className="text-xs">
                              {currentPurchases}/{skill.max_purchases}
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm text-purple-300 mb-2">
                          {skill.description}
                        </p>
                        
                        {skill.is_locked && skill.missing_prerequisites && skill.missing_prerequisites.length > 0 && (
                          <p className="text-xs text-red-400">
                            Missing: {skill.missing_prerequisites.join(', ')}
                          </p>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-2 ml-4">
                        {currentPurchases > 0 && (
                          <Button
                            variant="outline"
                            size="sm"
                            onClick={() => onRemoveSkill(skill)}
                            className="h-8 w-8 p-0"
                          >
                            <Minus className="h-4 w-4" />
                          </Button>
                        )}
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onAddSkill(skill)}
                          disabled={!canAdd}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
