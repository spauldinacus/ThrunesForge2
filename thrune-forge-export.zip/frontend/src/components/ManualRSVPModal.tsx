

import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { toast } from 'sonner';
import { apiClient } from 'app';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  eventId: string;
  eventName?: string;
  characterId: string;
  characterName: string;
  onSuccess?: () => void;
}

export function ManualRSVPModal({
  open,
  onOpenChange,
  eventId,
  eventName,
  characterId,
  characterName,
  onSuccess,
}: Props) {
  const [loading, setLoading] = useState(false);
  const [manualRSVPData, setManualRSVPData] = useState({
    ticket_xp: 0,
    candle_xp: 0,
    notes: '',
    attendance_status: 'attended' as 'rsvp' | 'attended' | 'no_show', // Default to attended since this is usually triggered when trying to add rewards
  });

  // Reset form when opened
  useEffect(() => {
    if (open) {
      setManualRSVPData({
        ticket_xp: 0,
        candle_xp: 0,
        notes: '',
        attendance_status: 'attended',
      });
    }
  }, [open]);

  const handleAddManualRSVP = async () => {
    if (!characterId || !eventId) return;

    setLoading(true);
    try {
      const response = await apiClient.add_manual_rsvp(
        { eventId: eventId },
        {
          character_id: characterId,
          ticket_xp: manualRSVPData.ticket_xp,
          candle_xp: manualRSVPData.candle_xp,
          notes: manualRSVPData.notes || null,
          attendance_status: manualRSVPData.attendance_status,
        }
      );

      // Check if response is OK
      if (!response.ok) {
        const errorData = await response.json().catch(() => null);
        const errorMessage = errorData?.detail || 'Failed to add manual RSVP';
        toast.error(errorMessage);
        return;
      }

      toast.success('Manual RSVP added successfully');
      onSuccess?.();
      onOpenChange(false);
    } catch (error) {
      console.error('Failed to add manual RSVP:', error);
      toast.error('Failed to add manual RSVP');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gray-900 border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-purple-200">Add Manual RSVP</DialogTitle>
          <DialogDescription className="text-purple-300/70">
            Manually add <strong>{characterName}</strong> to {eventName ? <strong>{eventName}</strong> : 'this event'}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label className="text-purple-200">Ticket XP (0-2)</Label>
              <Input
                type="number"
                min={0}
                max={2}
                value={manualRSVPData.ticket_xp}
                onChange={(e) =>
                  setManualRSVPData((prev) => ({
                    ...prev,
                    ticket_xp: parseInt(e.target.value) || 0,
                  }))
                }
                className="bg-purple-900/20 border-purple-400/30 text-purple-100"
              />
            </div>
            <div>
              <Label className="text-purple-200">Candle XP (0-2)</Label>
              <Input
                type="number"
                min={0}
                max={2}
                value={manualRSVPData.candle_xp}
                onChange={(e) =>
                  setManualRSVPData((prev) => ({
                    ...prev,
                    candle_xp: parseInt(e.target.value) || 0,
                  }))
                }
                className="bg-purple-900/20 border-purple-400/30 text-purple-100"
              />
            </div>
          </div>

          <div>
            <Label className="text-purple-200">Status</Label>
            <Select
              value={manualRSVPData.attendance_status}
              onValueChange={(value: 'rsvp' | 'attended' | 'no_show') =>
                setManualRSVPData((prev) => ({ ...prev, attendance_status: value }))
              }
            >
              <SelectTrigger className="bg-purple-900/20 border-purple-400/30 text-purple-100">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-purple-900/90 border-purple-400/30">
                <SelectItem value="rsvp" className="text-purple-100">
                  RSVP
                </SelectItem>
                <SelectItem value="attended" className="text-purple-100">
                  Attended
                </SelectItem>
                <SelectItem value="no_show" className="text-purple-100">
                  No Show
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <Label className="text-purple-200">Notes</Label>
            <Textarea
              value={manualRSVPData.notes}
              onChange={(e) =>
                setManualRSVPData((prev) => ({ ...prev, notes: e.target.value }))
              }
              placeholder="Optional notes..."
              className="bg-purple-900/20 border-purple-400/30 text-purple-100 placeholder-purple-300/50"
            />
          </div>
        </div>
        <DialogFooter className="flex justify-end space-x-3">
          <Button
            variant="outline"
            onClick={() => onOpenChange(false)}
            className="border-purple-400/30 text-purple-200"
          >
            Cancel
          </Button>
          <Button
            onClick={handleAddManualRSVP}
            disabled={loading}
            className="bg-gradient-to-r from-purple-600 to-blue-600"
          >
            {loading ? 'Adding...' : 'Add RSVP'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
