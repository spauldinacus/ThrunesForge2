import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Zap } from 'lucide-react';
import { apiClient } from 'app';
import { ArchetypeResponse, ArchetypeCreate, ArchetypeUpdate, SkillResponse } from 'types';

interface Props {}

const ArchetypeManagement: React.FC<Props> = () => {
  const [archetypes, setArchetypes] = useState<ArchetypeResponse[]>([]);
  const [skills, setSkills] = useState<SkillResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingArchetype, setEditingArchetype] = useState<ArchetypeResponse | null>(null);
  
  const [formData, setFormData] = useState<ArchetypeCreate>({
    name: '',
    description: '',
    primary_skill_ids: [],
    secondary_skill_ids: [],
    candle_cost: 0
  });

  const fetchArchetypes = async () => {
    try {
      setLoading(true);
      const response = await apiClient.list_archetypes();
      const data = await response.json();
      setArchetypes(data);
    } catch (error) {
      console.error('Error fetching archetypes:', error);
      toast.error('Failed to load archetypes');
    } finally {
      setLoading(false);
    }
  };

  const fetchSkills = async () => {
    try {
      const response = await apiClient.list_skills({ show_hidden: true });
      const data = await response.json();
      setSkills(data.skills || []);
    } catch (error) {
      console.error('Error fetching skills:', error);
      toast.error('Failed to load skills');
    }
  };

  const fetchData = async () => {
    await Promise.all([
      fetchArchetypes(),
      fetchSkills()
    ]);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      primary_skill_ids: [],
      secondary_skill_ids: [],
      candle_cost: 0
    });
    setEditingArchetype(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (archetype: ArchetypeResponse) => {
    setFormData({
      name: archetype.name,
      description: archetype.description,
      primary_skill_ids: Array.isArray(archetype.primary_skills) ? archetype.primary_skills.map(s => s.id) : [],
      secondary_skill_ids: Array.isArray(archetype.secondary_skills) ? archetype.secondary_skills.map(s => s.id) : [],
      candle_cost: archetype.candle_cost || 0
    });
    setEditingArchetype(archetype);
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingArchetype) {
        await apiClient.update_archetype({ archetypeId: editingArchetype.id }, formData);
        toast.success('Archetype updated successfully');
      } else {
        await apiClient.create_archetype(formData);
        toast.success('Archetype created successfully');
      }
      
      setDialogOpen(false);
      fetchArchetypes();
    } catch (error) {
      console.error('Error saving archetype:', error);
      toast.error('Failed to save archetype');
    }
  };

  const handleDelete = async (archetype: ArchetypeResponse) => {
    if (!confirm(`Are you sure you want to delete "${archetype.name}"?`)) {
      return;
    }
    
    try {
      await apiClient.delete_archetype({ archetypeId: archetype.id });
      toast.success('Archetype deleted successfully');
      fetchArchetypes();
    } catch (error) {
      console.error('Error deleting archetype:', error);
      toast.error('Failed to delete archetype');
    }
  };

  const handleSkillSelection = (skillId: string, skillType: 'primary' | 'secondary', checked: boolean) => {
    setFormData(prev => {
      const currentIds = skillType === 'primary' ? prev.primary_skill_ids : prev.secondary_skill_ids;
      const otherIds = skillType === 'primary' ? prev.secondary_skill_ids : prev.primary_skill_ids;
      
      let newIds: string[];
      if (checked) {
        // Add skill if not already present
        newIds = currentIds.includes(skillId) ? currentIds : [...currentIds, skillId];
        // Remove from other list if present
        const newOtherIds = otherIds.filter(id => id !== skillId);
        
        if (skillType === 'primary') {
          return { ...prev, primary_skill_ids: newIds, secondary_skill_ids: newOtherIds };
        } else {
          return { ...prev, secondary_skill_ids: newIds, primary_skill_ids: newOtherIds };
        }
      } else {
        // Remove skill
        newIds = currentIds.filter(id => id !== skillId);
        if (skillType === 'primary') {
          return { ...prev, primary_skill_ids: newIds };
        } else {
          return { ...prev, secondary_skill_ids: newIds };
        }
      }
    });
  };

  if (loading && archetypes.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-purple-300">Loading archetypes...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-purple-100">Archetype Management</h1>
          <p className="text-purple-300 mt-1">Manage character archetypes and their associated skills</p>
        </div>
        <Button onClick={openCreateDialog} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Archetype
        </Button>
      </div>

      {/* Archetypes List */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {(archetypes || []).map((archetype) => (
          <Card key={archetype.id} className="bg-slate-800/50 border-purple-800/30 backdrop-blur-sm hover:bg-slate-800/70 transition-colors">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-purple-100">{archetype.name}</CardTitle>
                  {archetype.candle_cost > 0 && (
                    <Badge variant="outline" className="mt-1 text-amber-400 border-amber-400/30">
                      {archetype.candle_cost} Candles
                    </Badge>
                  )}
                  <CardDescription className="text-slate-300 mt-2">
                    {archetype.description}
                  </CardDescription>
                </div>
                <div className="flex space-x-2 ml-4">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => openEditDialog(archetype)}
                    className="h-8 w-8 text-purple-300 hover:text-purple-200 hover:bg-purple-600/20"
                  >
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleDelete(archetype)}
                    className="h-8 w-8 text-red-300 hover:text-red-200 hover:bg-red-600/20"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Primary Skills */}
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Target className="w-4 h-4 text-amber-400" />
                    <span className="text-sm font-medium text-amber-300">Primary Skills</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(archetype.primary_skills || []).length > 0 ? (
                      (archetype.primary_skills || []).map((skill) => (
                        <Badge key={skill.id} variant="secondary" className="bg-amber-600/20 text-amber-300 border-amber-600/30">
                          {skill.name}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-slate-500 text-sm">No primary skills</span>
                    )}
                  </div>
                </div>

                {/* Secondary Skills */}
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Users className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-medium text-blue-300">Secondary Skills</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {(archetype.secondary_skills || []).length > 0 ? (
                      (archetype.secondary_skills || []).map((skill) => (
                        <Badge key={skill.id} variant="secondary" className="bg-blue-600/20 text-blue-300 border-blue-600/30">
                          {skill.name}
                        </Badge>
                      ))
                    ) : (
                      <span className="text-slate-500 text-sm">No secondary skills</span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create/Edit Dialog */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-800 border-purple-800/30 max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-100">
              {editingArchetype ? 'Edit Archetype' : 'Create New Archetype'}
            </DialogTitle>
            <DialogDescription className="text-slate-300">
              {editingArchetype ? 'Update archetype details and skill associations.' : 'Add a new archetype with associated skills.'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-purple-200">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="bg-slate-700 border-slate-600 text-purple-100"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="candle_cost" className="text-purple-200">Candle Cost</Label>
                <Input
                  id="candle_cost"
                  type="number"
                  min="0"
                  value={formData.candle_cost || 0}
                  onChange={(e) => setFormData(prev => ({ ...prev, candle_cost: parseInt(e.target.value) || 0 }))}
                  className="bg-slate-700 border-slate-600 text-purple-100"
                  placeholder="0"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description" className="text-purple-200">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-slate-700 border-slate-600 text-purple-100 min-h-[100px]"
                required
              />
            </div>

            {/* Skills Selection */}
            <div className="grid grid-cols-2 gap-6">
              {/* Primary Skills */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Target className="w-4 h-4 text-amber-400" />
                  <Label className="text-amber-300 font-medium">Primary Skills</Label>
                </div>
                <div className="border border-slate-600 rounded-lg p-3 max-h-60 overflow-y-auto bg-slate-750">
                  {(skills || []).map((skill) => (
                    <div key={skill.id} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`primary-${skill.id}`}
                        checked={formData.primary_skill_ids.includes(skill.id)}
                        onCheckedChange={(checked) => handleSkillSelection(skill.id, 'primary', checked as boolean)}
                        className="border-amber-600 data-[state=checked]:bg-amber-600"
                      />
                      <label htmlFor={`primary-${skill.id}`} className="text-sm text-slate-300 cursor-pointer flex-1">
                        {skill.name}
                      </label>
                    </div>
                  ))}
                  {skills.length === 0 && (
                    <p className="text-slate-500 text-sm">No skills available</p>
                  )}
                </div>
              </div>

              {/* Secondary Skills */}
              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Users className="w-4 h-4 text-blue-400" />
                  <Label className="text-blue-300 font-medium">Secondary Skills</Label>
                </div>
                <div className="border border-slate-600 rounded-lg p-3 max-h-60 overflow-y-auto bg-slate-750">
                  {(skills || []).map((skill) => (
                    <div key={skill.id} className="flex items-center space-x-2 py-1">
                      <Checkbox
                        id={`secondary-${skill.id}`}
                        checked={formData.secondary_skill_ids.includes(skill.id)}
                        onCheckedChange={(checked) => handleSkillSelection(skill.id, 'secondary', checked as boolean)}
                        className="border-blue-600 data-[state=checked]:bg-blue-600"
                      />
                      <label htmlFor={`secondary-${skill.id}`} className="text-sm text-slate-300 cursor-pointer flex-1">
                        {skill.name}
                      </label>
                    </div>
                  ))}
                  {skills.length === 0 && (
                    <p className="text-slate-500 text-sm">No skills available</p>
                  )}
                </div>
              </div>
            </div>
            
            <div className="flex justify-end space-x-3 pt-4">
              <Button type="button" variant="outline" onClick={() => setDialogOpen(false)} className="border-slate-600 text-slate-300">
                Cancel
              </Button>
              <Button type="submit" className="bg-purple-600 hover:bg-purple-700">
                {editingArchetype ? 'Update' : 'Create'} Archetype
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ArchetypeManagement;
