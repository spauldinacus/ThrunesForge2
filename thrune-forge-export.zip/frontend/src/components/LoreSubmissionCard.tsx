import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Calendar, ExternalLink, Scroll, MapPin } from 'lucide-react';
import { LoreSubmissionResponse } from 'types';

interface Props {
  submission: LoreSubmissionResponse;
}

export default function LoreSubmissionCard({ submission }: Props) {
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  };

  return (
    <Card className="hover:shadow-lg transition-shadow duration-200 bg-gradient-to-br from-purple-900/20 to-blue-900/20 border-purple-700/30">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-xl text-purple-200 flex items-center gap-2">
              <Scroll className="w-5 h-5 text-amber-400" />
              {submission.character_name}
            </CardTitle>
            <CardDescription className="flex items-center gap-4 mt-2 text-purple-300">
              <span className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                {formatDate(submission.created_at)}
              </span>
            </CardDescription>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Event and Chapter */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="bg-blue-900/30 text-blue-200 border-blue-700/50">
            <MapPin className="w-3 h-3 mr-1" />
            {submission.chapter_name}
          </Badge>
          <Badge variant="outline" className="bg-purple-900/30 text-purple-200 border-purple-700/50">
            {submission.event_name}
          </Badge>
        </div>

        {/* Lores Used */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-amber-400 flex items-center gap-2">
            <Scroll className="w-4 h-4" />
            Lores Used
          </h4>
          <p className="text-sm text-purple-100 bg-black/20 p-3 rounded-md border border-purple-700/30">
            {submission.lores_used}
          </p>
        </div>

        {/* Items Used */}
        {submission.items_used && (
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-amber-400">Items Used</h4>
            <p className="text-sm text-purple-100 bg-black/20 p-3 rounded-md border border-purple-700/30">
              {submission.items_used}
            </p>
          </div>
        )}
        
        {/* Outcome */}
        <div className="space-y-2">
          <h4 className="text-sm font-semibold text-amber-400">Outcome</h4>
          <p className="text-sm text-purple-100 bg-black/20 p-3 rounded-md border border-purple-700/30 whitespace-pre-wrap">
            {submission.outcome}
          </p>
        </div>

        {/* Reference Link */}
        {submission.link && (
          <div className="pt-2">
            <a
              href={submission.link}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 transition-colors underline"
            >
              <ExternalLink className="w-4 h-4" />
              Reference Link
            </a>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
