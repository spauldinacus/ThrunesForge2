import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Users } from 'lucide-react';
import { apiClient } from 'app';
import { CultureResponse, CultureCreate, CultureUpdate, HeritageResponse } from 'types';

interface Props {}

const CultureManagement: React.FC<Props> = () => {
  const [cultures, setCultures] = useState<CultureResponse[]>([]);
  const [heritages, setHeritages] = useState<HeritageResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingCulture, setEditingCulture] = useState<CultureResponse | null>(null);
  const [selectedHeritageFilter, setSelectedHeritageFilter] = useState("all");
  
  const [formData, setFormData] = useState<CultureCreate>({
    name: '',
    heritage_id: '',
    description: '',
    costuming_requirements: '',
    benefit: '',
    benefit_name: '',
    candle_cost: 0
  });

  const fetchHeritages = async () => {
    try {
      const response = await apiClient.list_heritages();
      if (response.ok) {
        const data = await response.json();
        setHeritages(data?.heritages || []);
      }
    } catch (error) {
      console.error('Error fetching heritages:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCultures = async (heritage_id?: string) => {
    try {
      const params = heritage_id ? { heritage_id } : {};
      const response = await apiClient.list_cultures(params);
      if (response.ok) {
        const data = await response.json();
        const culturesList = data || [];
        setCultures(culturesList.sort((a, b) => a.name.localeCompare(b.name)));
      } else {
        console.error('Failed to fetch cultures');
      }
    } catch (error) {
      console.error('Error fetching cultures:', error);
    }
  };

  const fetchData = async () => {
    await Promise.all([
      fetchHeritages(),
      fetchCultures(selectedHeritageFilter === "all" ? undefined : selectedHeritageFilter)
    ]);
  };

  useEffect(() => {
    // Initial load - fetch heritages and all cultures
    const initialLoad = async () => {
      await Promise.all([
        fetchHeritages(),
        fetchCultures() // No filter on initial load
      ]);
    };
    
    initialLoad();
  }, []);

  useEffect(() => {
    fetchCultures(selectedHeritageFilter === "all" ? undefined : selectedHeritageFilter);
  }, [selectedHeritageFilter]);

  const resetForm = () => {
    setFormData({
      name: '',
      heritage_id: '',
      description: '',
      costuming_requirements: '',
      benefit: '',
      benefit_name: '',
      candle_cost: 0
    });
    setEditingCulture(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (culture: CultureResponse) => {
    setFormData({
      name: culture.name,
      heritage_id: culture.heritage_id,
      description: culture.description,
      costuming_requirements: culture.costuming_requirements || '',
      benefit: culture.benefit,
      benefit_name: culture.benefit_name || '',
      candle_cost: culture.candle_cost || 0
    });
    setEditingCulture(culture);
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingCulture) {
        const response = await apiClient.update_culture({ cultureId: editingCulture.id }, formData);
        if (response.ok) {
          toast.success('Culture updated successfully');
        } else {
          throw new Error('Failed to update culture');
        }
      } else {
        const response = await apiClient.create_culture(formData);
        if (response.ok) {
          toast.success('Culture created successfully');
        } else {
          throw new Error('Failed to create culture');
        }
      }
      
      setDialogOpen(false);
      resetForm();
      fetchCultures(selectedHeritageFilter === "all" ? undefined : selectedHeritageFilter);
    } catch (error) {
      console.error('Error saving culture:', error);
      toast.error(editingCulture ? 'Failed to update culture' : 'Failed to create culture');
    }
  };

  const handleDelete = async (culture: CultureResponse) => {
    if (!confirm(`Are you sure you want to delete "${culture.name}"?`)) {
      return;
    }
    
    try {
      const response = await apiClient.delete_culture({ cultureId: culture.id });
      if (response.ok) {
        toast.success('Culture deleted successfully');
        fetchCultures(selectedHeritageFilter === "all" ? undefined : selectedHeritageFilter);
      } else {
        throw new Error('Failed to delete culture');
      }
    } catch (error) {
      console.error('Error deleting culture:', error);
      toast.error('Failed to delete culture');
    }
  };

  const clearFilter = () => {
    setSelectedHeritageFilter('all');
  };

  // Get all heritages for filter dropdown
  const allHeritages = heritages || [];
  
  // Get filtered cultures
  const selectedHeritage = heritages && heritages.length > 0 ? heritages.find(h => h.id === selectedHeritageFilter) : null;

  if (loading && cultures.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-purple-300">Loading cultures...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-purple-100">Culture Management</h1>
          <p className="text-purple-300 mt-1">Manage cultural variations within heritage lineages</p>
        </div>
        <Button onClick={openCreateDialog} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Culture
        </Button>
      </div>

      {/* Heritage Filter */}
      <Card className="bg-slate-800/50 border-purple-800/30 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-purple-100 text-lg flex items-center">
            <Filter className="w-5 h-5 mr-2" />
            Filter by Heritage
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4">
            <Select value={selectedHeritageFilter} onValueChange={setSelectedHeritageFilter}>
              <SelectTrigger className="w-64 bg-slate-700 border-purple-800/30 text-purple-100">
                <SelectValue placeholder="All heritages" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-purple-800/30">
                <SelectItem value="all" className="text-purple-100">All heritages</SelectItem>
                {(allHeritages || [])
                  .filter(heritage => heritage.id && heritage.id.trim() !== '')
                  .map((heritage) => (
                    <SelectItem key={heritage.id} value={heritage.id} className="text-purple-100">
                      {heritage.name}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            {selectedHeritageFilter && selectedHeritageFilter !== "all" && (
              <Button
                variant="outline"
                size="sm"
                onClick={clearFilter}
                className="border-purple-800/30 text-purple-300 hover:text-purple-100"
              >
                <X className="w-4 h-4 mr-1" />
                Clear
              </Button>
            )}
          </div>
          {selectedHeritage && (
            <div className="mt-3 p-3 bg-slate-700/50 rounded border border-purple-800/30">
              <div className="text-sm text-purple-300">Showing cultures for:</div>
              <div className="text-purple-100 font-medium">{selectedHeritage.name}</div>
              <div className="text-sm text-purple-300 mt-1">{selectedHeritage.description}</div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Culture Cards */}
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {(cultures || []).map((culture) => (
          <Card key={culture.id} className="bg-slate-800/50 border-purple-800/30 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-purple-100">{culture.name}</CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditDialog(culture)}
                    className="text-purple-300 hover:text-purple-100"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(culture)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <CardDescription className="text-purple-300">
                {culture.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <div className="text-sm text-purple-300 mb-1">Heritage:</div>
                <Badge variant="secondary" className="text-xs">
                  {culture.heritage_name}
                </Badge>
              </div>
              
              <div>
                <div className="text-sm text-purple-300 mb-1">{culture.benefit_name ? culture.benefit_name : 'Benefit'}:</div>
                <div className="text-sm text-purple-100 whitespace-pre-wrap">{culture.benefit}</div>
              </div>

              {culture.candle_cost > 0 && (
                <div>
                  <div className="text-sm text-purple-300 mb-1">Candle Cost:</div>
                  <Badge variant="outline" className="text-amber-400 border-amber-400/30">
                    {culture.candle_cost} Candles
                  </Badge>
                </div>
              )}
              
              {culture.costuming_requirements && (
                <div>
                  <div className="text-sm text-purple-300 mb-1">Costuming:</div>
                  <div className="text-sm text-purple-100 whitespace-pre-wrap">{culture.costuming_requirements}</div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {cultures.length === 0 && !loading && (
        <Card className="bg-slate-800/50 border-purple-800/30 backdrop-blur-sm">
          <CardContent className="text-center py-12">
            <div className="text-purple-300 text-lg mb-2">
              {selectedHeritageFilter && selectedHeritageFilter !== "all" ? 'No cultures found for this heritage' : 'No cultures found'}
            </div>
            <div className="text-purple-400 text-sm mb-4">
              {selectedHeritageFilter && selectedHeritageFilter !== "all" ? 'Try selecting a different heritage or create a new culture.' : 'Get started by creating your first culture.'}
            </div>
            <Button onClick={openCreateDialog} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Create Culture
            </Button>
          </CardContent>
        </Card>
      )}

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-800 border-purple-800/30 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-100">
              {editingCulture ? 'Edit Culture' : 'Create Culture'}
            </DialogTitle>
            <DialogDescription className="text-purple-300">
              {editingCulture ? 'Update culture details and traits' : 'Add a new cultural variation within a heritage lineage'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name" className="text-purple-300">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="bg-slate-700 border-purple-800/30 text-purple-100"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="heritage" className="text-purple-300">Heritage *</Label>
                <Select 
                  value={formData.heritage_id || ''} 
                  onValueChange={(value) => setFormData(prev => ({ ...prev, heritage_id: value }))}
                  required
                >
                  <SelectTrigger className="bg-slate-700 border-purple-800/30 text-purple-100">
                    <SelectValue placeholder="Select a heritage" />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-800 border-purple-800/30">
                    {(heritages || [])
                      .filter(heritage => heritage.id && heritage.id.trim() !== '')
                      .map((heritage) => (
                        <SelectItem key={heritage.id} value={heritage.id} className="text-purple-100">
                          {heritage.name}
                        </SelectItem>
                      ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label htmlFor="candle_cost" className="text-purple-300">Candle Cost</Label>
              <Input
                id="candle_cost"
                type="number"
                min="0"
                value={formData.candle_cost || 0}
                onChange={(e) => setFormData(prev => ({ ...prev, candle_cost: parseInt(e.target.value) || 0 }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                placeholder="0"
              />
              <p className="text-xs text-purple-400 mt-1">Cost in Candles to unlock this culture</p>
            </div>
            
            <div>
              <Label htmlFor="description" className="text-purple-300">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={3}
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="benefit" className="text-purple-300">Benefit</Label>
              <Textarea
                id="benefit"
                value={formData.benefit}
                onChange={(e) => setFormData({ ...formData, benefit: e.target.value })}
                placeholder="Describe the mechanical benefit of this culture..."
                className="bg-slate-700/50 border-purple-800/30 text-purple-100"
                rows={3}
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="benefit_name" className="text-purple-300">Benefit Name</Label>
              <Input
                id="benefit_name"
                value={formData.benefit_name}
                onChange={(e) => setFormData({ ...formData, benefit_name: e.target.value })}
                placeholder="Name of the benefit (optional)"
                className="bg-slate-700/50 border-purple-800/30 text-purple-100"
              />
            </div>
            
            <div>
              <Label htmlFor="costuming_requirements" className="text-purple-300">Costuming Requirements (Optional)</Label>
              <Textarea
                id="costuming_requirements"
                value={formData.costuming_requirements}
                onChange={(e) => setFormData(prev => ({ ...prev, costuming_requirements: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={2}
                placeholder="Describe any specific cultural costuming requirements"
              />
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="border-purple-800/30 text-purple-300 hover:text-purple-100"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-purple-600 hover:bg-purple-700"
              >
                {editingCulture ? 'Update Culture' : 'Create Culture'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default CultureManagement;
