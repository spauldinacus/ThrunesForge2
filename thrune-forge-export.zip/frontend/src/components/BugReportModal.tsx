import { useState, useEffect } from 'react';
import { useUser } from '@stackframe/react';
import { useLocation } from 'react-router-dom';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { errorCapture } from 'utils/errorCapture';
import { Loader2 } from 'lucide-react';

interface Props {
  open: boolean;
  onClose: () => void;
}

export function BugReportModal({ open, onClose }: Props) {
  const user = useUser();
  const location = useLocation();
  const [submitting, setSubmitting] = useState(false);
  const [playerName, setPlayerName] = useState('');
  const [email, setEmail] = useState('');
  const [description, setDescription] = useState('');

  // Auto-fill user data when modal opens
  useEffect(() => {
    if (open && user) {
      setEmail(user.primaryEmail || '');
      // Try to get player name from user's display name
      setPlayerName(user.displayName || '');
    }
  }, [open, user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!description.trim()) {
      toast.error('Please describe the issue');
      return;
    }

    setSubmitting(true);

    try {
      const errors = errorCapture.getErrors();
      const currentPage = window.location.pathname;
      
      const response = await apiClient.submit_bug_report({
        email: email || 'no-email@provided.com',
        description: description.trim(),
        page_url: currentPage,
        player_name: playerName || 'Anonymous',
        console_errors: errors.length > 0 ? errors : null,
      });

      if (response.ok) {
        toast.success('Bug report submitted! Thank you for your feedback.');
        setDescription('');
        onClose();
      } else {
        throw new Error('Failed to submit');
      }
    } catch (error) {
      console.error('Failed to submit bug report:', error);
      toast.error('Failed to submit bug report. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="sm:max-w-[600px] bg-slate-900 border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-2xl text-purple-200">Report a Bug</DialogTitle>
          <DialogDescription className="text-slate-400">
            Help us improve by reporting issues you encounter. We'll receive your description along with technical details.
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div>
            <Label htmlFor="playerName" className="text-purple-200">Your Name (Optional)</Label>
            <Input
              id="playerName"
              value={playerName}
              onChange={(e) => setPlayerName(e.target.value)}
              placeholder="Enter your name"
              className="bg-slate-800 border-purple-500/30 text-white"
            />
          </div>

          <div>
            <Label htmlFor="email" className="text-purple-200">Email (Optional)</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="your.email@example.com"
              className="bg-slate-800 border-purple-500/30 text-white"
            />
          </div>

          <div>
            <Label htmlFor="description" className="text-purple-200">
              What happened? <span className="text-red-400">*</span>
            </Label>
            <Textarea
              id="description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Describe what you were doing and what went wrong..."
              rows={6}
              required
              className="bg-slate-800 border-purple-500/30 text-white resize-none"
            />
            <p className="text-xs text-slate-500 mt-1">
              Technical details (console errors, page info) will be included automatically.
            </p>
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              disabled={submitting}
              className="border-purple-500/30 text-purple-200 hover:bg-purple-600/20"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={submitting}
              className="bg-purple-600 hover:bg-purple-700 text-white"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                'Submit Report'
              )}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}