import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Users } from 'lucide-react';
import { apiClient } from 'app';
import { HeritageResponse, HeritageCreate, HeritageUpdate, SkillResponse } from 'types';

const initialFormData = {
  name: '',
  description: '',
  costuming_requirements: '',
  base_body: 4,
  base_stamina: 4,
  benefit: '',
  benefit_name: '',
  weakness: '',
  weakness_name: '',
  secondary_skill_ids: [],
  candle_cost: 0
};

const HeritageManagement = () => {
  const [heritages, setHeritages] = useState<HeritageResponse[]>([]);
  const [skills, setSkills] = useState<SkillResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingHeritage, setEditingHeritage] = useState<HeritageResponse | null>(null);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [formData, setFormData] = useState(initialFormData);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [heritagesRes, skillsRes] = await Promise.all([
        apiClient.list_heritages(),
        apiClient.list_skills()
      ]);
      
      const heritagesData = await heritagesRes.json();
      const skillsData = await skillsRes.json();
      
      // Handle API response format - skills API returns {skills: [], total: n}
      // and heritages API returns {heritages: [], total: n}
      const heritagesList = Array.isArray(heritagesData) ? heritagesData : heritagesData.heritages || [];
      setHeritages(heritagesList.sort((a, b) => a.name.localeCompare(b.name)));
      setSkills(Array.isArray(skillsData) ? skillsData : skillsData.skills || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast.error('Failed to load data');
      // Set empty arrays as fallback
      setHeritages([]);
      setSkills([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      costuming_requirements: '',
      base_body: 4,
      base_stamina: 4,
      benefit: '',
      benefit_name: '',
      weakness: '',
      weakness_name: '',
      secondary_skill_ids: [],
      candle_cost: 0
    });
    setSelectedSkills([]);
    setEditingHeritage(null);
  };

  const openCreateDialog = () => {
    resetForm();
    setDialogOpen(true);
  };

  const openEditDialog = (heritage: HeritageResponse) => {
    setFormData({
      name: heritage.name,
      description: heritage.description,
      costuming_requirements: heritage.costuming_requirements,
      base_body: heritage.base_body,
      base_stamina: heritage.base_stamina,
      benefit: heritage.benefit,
      benefit_name: heritage.benefit_name || '',
      weakness: heritage.weakness,
      weakness_name: heritage.weakness_name || '',
      secondary_skill_ids: (heritage.secondary_skills || []).map(skill => skill.id),
      candle_cost: heritage.candle_cost || 0
    });
    setSelectedSkills((heritage.secondary_skills || []).map(skill => skill.id));
    setEditingHeritage(heritage);
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const submitData = { ...formData, secondary_skill_ids: selectedSkills };
      
      if (editingHeritage) {
        const response = await apiClient.update_heritage({ heritageId: editingHeritage.id }, submitData);
        if (response.ok) {
          toast.success('Heritage updated successfully');
        } else {
          throw new Error('Failed to update heritage');
        }
      } else {
        const response = await apiClient.create_heritage(submitData);
        if (response.ok) {
          toast.success('Heritage created successfully');
        } else {
          throw new Error('Failed to create heritage');
        }
      }
      
      setDialogOpen(false);
      resetForm();
      fetchData();
    } catch (error) { 
      console.error('Error saving heritage:', error);
      toast.error(editingHeritage ? 'Failed to update heritage' : 'Failed to create heritage');
    }
  };

  const handleDelete = async (heritage: HeritageResponse) => {
    if (!confirm(`Are you sure you want to delete "${heritage.name}"?`)) {
      return;
    }
    
    try {
      const response = await apiClient.delete_heritage({ heritageId: heritage.id });
      if (response.ok) {
        toast.success('Heritage deleted successfully');
        fetchData();
      } else {
        throw new Error('Failed to delete heritage');
      }
    } catch (error) {
      console.error('Error deleting heritage:', error);
      toast.error('Failed to delete heritage');
    }
  };

  const toggleSkillSelection = (skillId: string) => {
    setSelectedSkills(prev => {
      if (prev.includes(skillId)) {
        return prev.filter(id => id !== skillId);
      } else {
        return [...prev, skillId];
      }
    });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-purple-300">Loading heritages...</div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-purple-100">Heritage Management</h1>
          <p className="text-purple-300 mt-1">Manage character heritage types and their abilities</p>
        </div>
        <Button onClick={openCreateDialog} className="bg-purple-600 hover:bg-purple-700">
          <Plus className="w-4 h-4 mr-2" />
          Add Heritage
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {(heritages || []).map((heritage) => (
          <Card key={heritage.id} className="bg-slate-800/50 border-purple-800/30 backdrop-blur-sm">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-purple-100">{heritage.name}</CardTitle>
                <div className="flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => openEditDialog(heritage)}
                    className="text-purple-300 hover:text-purple-100"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(heritage)}
                    className="text-red-400 hover:text-red-300"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              <CardDescription className="text-purple-300">
                {heritage.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-purple-300">Body:</span>
                  <span className="ml-2 text-purple-100">{heritage.base_body}</span>
                </div>
                <div>
                  <span className="text-purple-300">Stamina:</span>
                  <span className="ml-2 text-purple-100">{heritage.base_stamina}</span>
                </div>
              </div>
              
              <div>
                <div className="text-sm text-purple-300 mb-1">
                  {heritage.benefit_name || 'Benefit'}:
                </div>
                <div className="text-sm text-purple-100 whitespace-pre-wrap">{heritage.benefit}</div>
              </div>
              
              <div>
                <div className="text-sm text-purple-300 mb-1">
                  {heritage.weakness_name || 'Weakness'}:
                </div>
                <div className="text-sm text-purple-100 whitespace-pre-wrap">{heritage.weakness}</div>
              </div>

              {heritage.candle_cost > 0 && (
                <div>
                  <div className="text-sm text-purple-300 mb-1">Candle Cost:</div>
                  <Badge variant="outline" className="text-amber-400 border-amber-400/30">
                    {heritage.candle_cost} Candles
                  </Badge>
                </div>
              )}
              
              {heritage.costuming_requirements && (
                <div>
                  <div className="text-sm text-purple-300 mb-1">Costuming:</div>
                  <div className="text-sm text-purple-100 whitespace-pre-wrap">{heritage.costuming_requirements}</div>
                </div>
              )}
              
              {(heritage.secondary_skills || []).length > 0 && (
                <div>
                  <div className="text-sm text-purple-300 mb-2">Secondary Skills:</div>
                  <div className="flex flex-wrap gap-1">
                    {(heritage.secondary_skills || []).map((skill) => (
                      <Badge key={skill.id} variant="secondary" className="text-xs">
                        {skill.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="bg-slate-800 border-purple-800/30 max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-100">
              {editingHeritage ? 'Edit Heritage' : 'Create Heritage'}
            </DialogTitle>
            <DialogDescription className="text-purple-300">
              {editingHeritage ? 'Update heritage details and abilities' : 'Add a new heritage type with stats and abilities'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name" className="text-purple-300">Name</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  className="bg-slate-700 border-purple-800/30 text-purple-100"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <Label htmlFor="base_body" className="text-purple-300">Base Body</Label>
                  <Input
                    id="base_body"
                    type="number"
                    value={formData.base_body}
                    onChange={(e) => setFormData(prev => ({ ...prev, base_body: parseInt(e.target.value) }))}
                    className="bg-slate-700 border-purple-800/30 text-purple-100"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="base_stamina" className="text-purple-300">Base Stamina</Label>
                  <Input
                    id="base_stamina"
                    type="number"
                    value={formData.base_stamina}
                    onChange={(e) => setFormData(prev => ({ ...prev, base_stamina: parseInt(e.target.value) }))}
                    className="bg-slate-700 border-purple-800/30 text-purple-100"
                    required
                  />
                </div>
              </div>
            </div>

            <div>
              <Label htmlFor="candle_cost" className="text-purple-300">Candle Cost</Label>
              <Input
                id="candle_cost"
                type="number"
                min="0"
                value={formData.candle_cost || 0}
                onChange={(e) => setFormData(prev => ({ ...prev, candle_cost: parseInt(e.target.value) || 0 }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                placeholder="0"
              />
              <p className="text-xs text-purple-400 mt-1">Cost in Candles to unlock this heritage</p>
            </div>
            
            <div>
              <Label htmlFor="description" className="text-purple-300">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={3}
                required
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="benefit_name" className="text-purple-300">Benefit Name</Label>
                <Input
                  id="benefit_name"
                  value={formData.benefit_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, benefit_name: e.target.value }))}
                  className="bg-slate-700 border-purple-800/30 text-purple-100"
                  placeholder="e.g., Enhanced Constitution"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="weakness_name" className="text-purple-300">Weakness Name</Label>
                <Input
                  id="weakness_name"
                  value={formData.weakness_name}
                  onChange={(e) => setFormData(prev => ({ ...prev, weakness_name: e.target.value }))}
                  className="bg-slate-700 border-purple-800/30 text-purple-100"
                  placeholder="e.g., Light Sensitivity"
                  required
                />
              </div>
            </div>
            
            <div>
              <Label htmlFor="benefit" className="text-purple-300">Benefit Description</Label>
              <Textarea
                id="benefit"
                value={formData.benefit}
                onChange={(e) => setFormData(prev => ({ ...prev, benefit: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={2}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="weakness" className="text-purple-300">Weakness Description</Label>
              <Textarea
                id="weakness"
                value={formData.weakness}
                onChange={(e) => setFormData(prev => ({ ...prev, weakness: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={2}
                required
              />
            </div>
            
            <div>
              <Label htmlFor="costuming_requirements" className="text-purple-300">Costuming Requirements (Optional)</Label>
              <Textarea
                id="costuming_requirements"
                value={formData.costuming_requirements}
                onChange={(e) => setFormData(prev => ({ ...prev, costuming_requirements: e.target.value }))}
                className="bg-slate-700 border-purple-800/30 text-purple-100"
                rows={2}
                placeholder="Describe any specific costuming requirements"
              />
            </div>
            
            <div>
              <Label className="text-purple-300 mb-3 block">Secondary Skills</Label>
              <div className="max-h-40 overflow-y-auto space-y-2 border rounded p-3 bg-slate-700/50 border-purple-800/30">
                {(skills || []).length === 0 ? (
                  <div className="text-purple-300 text-sm">No skills available</div>
                ) : (
                  (skills || []).map((skill) => (
                    <div key={skill.id} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={`skill-${skill.id}`}
                        checked={selectedSkills.includes(skill.id)}
                        onChange={() => toggleSkillSelection(skill.id)}
                        className="rounded border-purple-800/30"
                      />
                      <label htmlFor={`skill-${skill.id}`} className="text-purple-100 text-sm cursor-pointer flex-1">
                        {skill.name}
                      </label>
                    </div>
                  ))
                )}
              </div>
              <div className="text-xs text-purple-400 mt-1">
                Selected: {selectedSkills.length} skills
              </div>
            </div>
            
            <div className="flex justify-end space-x-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setDialogOpen(false)}
                className="border-purple-800/30 text-purple-300 hover:text-purple-100"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="bg-purple-600 hover:bg-purple-700"
              >
                {editingHeritage ? 'Update Heritage' : 'Create Heritage'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default HeritageManagement;
