import { ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowLeft } from "lucide-react";

export interface AnalyticsLayoutProps {
  children: ReactNode;
  title: string;
  breadcrumbs?: { label: string; path?: string }[];
}

export function AnalyticsLayout({ children, title, breadcrumbs }: AnalyticsLayoutProps) {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-purple-950 to-slate-900 text-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header with breadcrumbs */}
        <div className="mb-8">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate("/admin-analytics")}
            className="mb-4 text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Analytics Hub
          </Button>
          
          {breadcrumbs && breadcrumbs.length > 0 && (
            <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-2">
              {breadcrumbs.map((crumb, index) => (
                <div key={index} className="flex items-center">
                  {index > 0 && <span className="mx-2">/</span>}
                  {crumb.path ? (
                    <button
                      onClick={() => navigate(crumb.path!)}
                      className="hover:text-purple-300 transition-colors"
                    >
                      {crumb.label}
                    </button>
                  ) : (
                    <span className="text-foreground">{crumb.label}</span>
                  )}
                </div>
              ))}
            </nav>
          )}
          
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-purple-400 bg-clip-text text-transparent">
            {title}
          </h1>
        </div>

        {/* Content */}
        {children}
      </div>
    </div>
  );
}
