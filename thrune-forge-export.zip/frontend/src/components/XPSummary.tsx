import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { SkillWithState } from 'utils/characterTypes';

interface XPSummaryProps {
  xpSpent: number;
  xpAvailable: number;
  xpCalculating: boolean;
  selectedSkills: SkillWithState[];
  maxXP?: number;
  totalEarnedXP?: number;
  totalXP?: number;
  testMode?: boolean; // Add test mode flag
}

export const XPSummary: React.FC<XPSummaryProps> = ({
  xpSpent,
  xpAvailable,
  xpCalculating,
  selectedSkills,
  maxXP = 25,
  totalEarnedXP,
  totalXP,
  testMode = false
}) => {
  return (
    <Card className="bg-gradient-to-br from-purple-900/40 to-blue-900/40 border-purple-700/50">
      <CardHeader>
        <CardTitle className="text-purple-100">Experience Points</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-purple-900/30 rounded-lg p-4 border border-purple-700/50">
          {totalXP !== undefined && (
            <div className="flex justify-between items-center mb-2">
              <span className="text-purple-300 font-medium">Total XP:</span>
              <span className="text-purple-100 font-bold text-lg">{totalXP}</span>
            </div>
          )}
          {totalEarnedXP !== undefined && (
            <div className="flex justify-between items-center mb-2">
              <span className="text-purple-300 font-medium">Total Earned XP:</span>
              <span className="text-purple-100 font-bold text-lg">{totalEarnedXP}</span>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span className="text-purple-300 font-medium">XP Spent:</span>
            <div className="flex items-center gap-2">
              {xpCalculating && (
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-400"></div>
              )}
              <span className="text-purple-100 font-bold text-lg">{xpSpent}</span>
            </div>
          </div>
          
          {!testMode && (
            <div className="flex justify-between items-center">
              <span className="text-purple-300 font-medium">XP Available:</span>
              <div className="flex items-center gap-2">
                {xpCalculating && (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-purple-400"></div>
                )}
                <span className={`font-bold text-lg ${
                  xpAvailable < 0 ? 'text-red-400' : 'text-green-400'
                }`}>
                  {xpAvailable}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Selected Skills Summary */}
        {selectedSkills.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-purple-300 font-medium text-sm">Selected Skills ({selectedSkills.length}):</h4>
            <div className="space-y-1 max-h-40 overflow-y-auto">
              {selectedSkills.map((skill) => {
                const purchaseCount = skill.purchase_count || 1;
                return (
                  <div key={skill.id} className="flex justify-between items-center text-sm bg-slate-800/30 rounded p-2">
                    <div className="flex flex-col">
                      <span className="text-purple-200 font-medium">{skill.name}</span>
                      {purchaseCount > 1 && (
                        <span className="text-purple-400 text-xs">x{purchaseCount}</span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${
                          skill.is_primary ? 'bg-green-600/20 text-green-300' :
                          skill.is_secondary ? 'bg-blue-600/20 text-blue-300' :
                          'bg-purple-600/20 text-purple-300'
                        }`}
                      >
                        {skill.xp_cost ?? 0} XP
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {!testMode && xpAvailable < 0 && (
          <div className="bg-red-900/20 border border-red-500/30 rounded-lg p-3">
            <p className="text-red-400 text-sm flex items-center">
              <span className="mr-2">⚠️</span>
              Character exceeds XP budget by {Math.abs(xpAvailable)} XP
            </p>
          </div>
        )}

        {testMode && (
          <div className="bg-blue-900/20 border border-blue-500/30 rounded-lg p-3">
            <p className="text-blue-300 text-sm flex items-center">
              <span className="mr-2">🧪</span>
              Test Mode: No XP limits
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
