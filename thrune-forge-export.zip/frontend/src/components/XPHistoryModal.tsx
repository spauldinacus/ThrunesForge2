


import React, { useState, useEffect, useMemo } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import type { XPTransaction } from 'types';
import { ManualRSVPModal } from './ManualRSVPModal';

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  characterId: string;
  characterName: string;
  onTransactionChange?: () => void; // Add callback for parent to refresh
}

interface NewTransaction {
  amount: number;
  transaction_type: string;
  reason: string;
}

const TRANSACTION_TYPES = [
  { value: 'initial', label: 'Initial XP' },
  { value: 'event_reward', label: 'Event Reward' },
  { value: 'admin_adjustment', label: 'Admin Adjustment' },
  { value: 'skill_purchase', label: 'Skill Purchase' },
  { value: 'skill_refund', label: 'Skill Refund' },
  { value: 'body_purchase', label: 'Body Purchase' },
  { value: 'stamina_purchase', label: 'Stamina Purchase' },
];

export function XPHistoryModal({ open, onOpenChange, characterId, characterName, onTransactionChange }: Props) {
  const [transactions, setTransactions] = useState<XPTransaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newTransaction, setNewTransaction] = useState<NewTransaction>({
    amount: 0,
    transaction_type: '',
    reason: '',
  });

    // State for event selection
  const [events, setEvents] = useState<any[]>([]);
  const [selectedEventId, setSelectedEventId] = useState<string | null>(null);
  const [loadingEvents, setLoadingEvents] = useState(false);
  const [showManualRSVP, setShowManualRSVP] = useState(false);
  
  const loadTransactions = async () => {
    if (!characterId) return;
    
    setLoading(true);
    try {
      const response = await apiClient.get_admin_character_xp_history({ characterId });
      const data = await response.json();
      setTransactions(data.transactions || []);
    } catch (error) {
      console.error('Error loading XP history:', error);
      toast.error('Failed to load XP history');
    } finally {
      setLoading(false);
    }
  };

    const fetchEvents = async () => {
    try {
      setLoadingEvents(true);
      const response = await apiClient.list_scoped_events();
      const data = await response.json();
      if (data.events) {
        // Sort events by date descending
        const sortedEvents = data.events.sort((a: any, b: any) => 
          new Date(b.starts_at).getTime() - new Date(a.starts_at).getTime()
        );
        setEvents(sortedEvents);
      }
    } catch (error) {
      console.error('Failed to fetch events:', error);
      toast.error('Failed to load events list');
    } finally {
      setLoadingEvents(false);
    }
  };

  useEffect(() => {
    if (open) {
      fetchEvents();
    }
  }, [open]);
  
  const handleAddTransaction = async (forceTransaction = false) => {
    if (!newTransaction.amount || !newTransaction.transaction_type || !newTransaction.reason.trim()) {
      toast.error('Please fill in all fields');
      return;
    }

    // Validate event attendance if type is event_reward
    let finalReason = newTransaction.reason;
    
    if (newTransaction.transaction_type === 'event_reward') {
      if (!selectedEventId) {
        toast.error('Please select an event for event reward');
        return;
      }

      try {
        setLoading(true); 
        const response = await apiClient.get_event_attendees({ eventId: selectedEventId });
        const data = await response.json();
        
        const attendee = data.attendees.find((a: any) => a.character_id === characterId);
        
        if (!attendee || attendee.attendance_status !== 'attended') {
          setLoading(false);
          if (confirm('Character is not marked as "Attended" for this event.\n\nWould you like to manually mark them as attended now?')) {
            setShowManualRSVP(true);
          }
          return;
        }

        // Prepend event name to reason
        const selectedEvent = events.find(e => e.id === selectedEventId);
        if (selectedEvent) {
          finalReason = `[${selectedEvent.title}] ${newTransaction.reason}`;
        }

      } catch (error) {
        console.error('Failed to verify attendance:', error);
        toast.error('Failed to verify event attendance');
        setLoading(false);
        return;
      }
    }

    try {
      const response = await apiClient.add_admin_xp_transaction(
        { characterId, force: forceTransaction },
        {
          amount: newTransaction.amount,
          transaction_type: newTransaction.transaction_type,
          reason: finalReason,
        }
      );
      
      // Check if response is OK before parsing
      if (!response.ok) {
        const errorText = await response.text();
        console.error('API Error:', errorText);
        toast.error('Failed to add XP transaction');
        return;
      }
      
      const data = await response.json();
      
      // Check if transaction would cause negative XP
      if (data.would_cause_negative_xp && !forceTransaction) {
        const proceed = confirm(
          `Warning: This transaction would result in negative XP!\n\n` +
          `Current Available: ${data.current_available} XP\n` +
          `Transaction Amount: ${data.transaction_amount} XP\n` +
          `Resulting Available: ${data.projected_available} XP\n\n` +
          `Do you want to proceed anyway?`
        );
        
        if (proceed) {
          // Retry with force=true
          await handleAddTransaction(true);
        }
        return;
      }
      
      toast.success('XP transaction added successfully');
      setNewTransaction({ amount: 0, transaction_type: '', reason: '' });
      setShowAddForm(false);
      await loadTransactions();
      onTransactionChange?.(); // Notify parent to refresh
    } catch (error) {
      console.error('Error adding transaction:', error);
      toast.error('Failed to add XP transaction');
    }
  };

  const handleDeleteTransaction = async (transactionId: string, forceDelete = false) => {
    if (!forceDelete && !confirm('Are you sure you want to delete this XP transaction? This action cannot be undone.')) {
      return;
    }

    try {
      const response = await apiClient.delete_admin_xp_transaction({ 
        transactionId,
        force: forceDelete 
      });
      
      const data = await response.json();
      
      // Check if deletion would cause negative XP
      if (data.would_cause_negative_xp && !forceDelete) {
        const proceed = confirm(
          `Warning: Deleting this transaction would result in negative XP!\n\n` +
          `Current Available: ${data.current_available} XP\n` +
          `Transaction Amount: ${data.transaction_amount} XP\n` +
          `Resulting Available: ${data.projected_available} XP\n\n` +
          `Do you want to proceed anyway?`
        );
        
        if (proceed) {
          // Retry with force=true
          await handleDeleteTransaction(transactionId, true);
        }
        return;
      }
      
      if (response.ok) {
        toast.success('XP transaction deleted successfully');
        await loadTransactions();
        onTransactionChange?.(); // Notify parent to refresh
      } else {
        toast.error('Failed to delete XP transaction');
      }
    } catch (error) {
      console.error('Error deleting transaction:', error);
      toast.error('Failed to delete XP transaction');
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString();
  };

  const getTransactionTypeColor = (type: string) => {
    switch (type) {
      case 'initial':
        return 'bg-blue-100 text-blue-800';
      case 'event_reward':
        return 'bg-green-100 text-green-800';
      case 'admin_adjustment':
        return 'bg-yellow-100 text-yellow-800';
      case 'skill_purchase':
      case 'body_purchase':
      case 'stamina_purchase':
        return 'bg-red-100 text-red-800';
      case 'skill_refund':
        return 'bg-purple-100 text-purple-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Use useMemo to ensure calculations update when transactions change
  const xpTotals = useMemo(() => {
    // Only count actual XP grants as earned (not refunds)
    const earned = transactions.filter(t => 
      t.amount > 0 && 
      !t.transaction_type.includes('refund') &&
      (
        t.transaction_type === 'initial' ||
        t.transaction_type === 'event_reward' ||
        (t.transaction_type === 'admin_adjustment' && 
         !t.reason.toLowerCase().includes('refund'))
      )
    ).reduce((sum, t) => sum + t.amount, 0);
    
    // Calculate total purchases (negative amounts)
    const totalPurchases = transactions.filter(t => 
      t.amount < 0
    ).reduce((sum, t) => sum + Math.abs(t.amount), 0);
    
    // Calculate total refunds (positive amounts that are refund types OR admin adjustments with refund in reason)
    const totalRefunds = transactions.filter(t => 
      t.amount > 0 && 
      (t.transaction_type.includes('refund') ||
       (t.transaction_type === 'admin_adjustment' && t.reason.toLowerCase().includes('refund')))
    ).reduce((sum, t) => sum + t.amount, 0);
    
    // Spent = purchases minus refunds
    const spent = Math.max(0, totalPurchases - totalRefunds);
    const available = Math.max(0, earned - spent);
    
    return { earned, spent, available };
  }, [transactions]);

  useEffect(() => {
    if (open && characterId) {
      loadTransactions();
    }
  }, [open, characterId]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-purple-400">
            XP History - {characterName}
          </DialogTitle>
        </DialogHeader>

        {/* XP Summary */}
        <div className="grid grid-cols-3 gap-4 mb-6">
          <Card className="bg-gradient-to-br from-green-900/20 to-green-800/10 border-green-700/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-green-400">Total Earned</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-300">{xpTotals.earned}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-red-900/20 to-red-800/10 border-red-700/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-red-400">Total Spent</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-red-300">{xpTotals.spent}</div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-900/20 to-blue-800/10 border-blue-700/30">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm text-blue-400">Available</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-300">{xpTotals.available}</div>
            </CardContent>
          </Card>
        </div>

        {/* Add Transaction Form */}
        {showAddForm ? (
          <Card className="mb-6 bg-gray-900/50 border-gray-700">
            <CardHeader>
              <CardTitle className="text-lg text-purple-400">Add New Transaction</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="amount" className="text-gray-300">Amount</Label>
                  <Input
                    id="amount"
                    type="number"
                    placeholder="Enter XP amount (positive for earned, negative for spent)"
                    value={newTransaction.amount || ''}
                    onChange={(e) => setNewTransaction(prev => ({ ...prev, amount: parseInt(e.target.value) || 0 }))}
                    className="bg-gray-800 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label htmlFor="type" className="text-gray-300">Transaction Type</Label>
                  <Select 
                    value={newTransaction.transaction_type} 
                    onValueChange={(value) => {
                      setNewTransaction(prev => ({ ...prev, transaction_type: value }));
                      if (value !== 'event_reward') setSelectedEventId(null);
                    }}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      {TRANSACTION_TYPES.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {newTransaction.transaction_type === 'event_reward' && (
                <div className="mt-2">
                  <Label className="text-gray-300">Select Event</Label>
                  <Select
                    value={selectedEventId || ''}
                    onValueChange={setSelectedEventId}
                    disabled={loadingEvents}
                  >
                    <SelectTrigger className="bg-gray-800 border-gray-600 text-white mt-1">
                      <SelectValue placeholder={loadingEvents ? "Loading events..." : "Select an event"} />
                    </SelectTrigger>
                    <SelectContent>
                      {events.map((event) => (
                        <SelectItem key={event.id} value={event.id}>
                          {event.title} ({new Date(event.starts_at).toLocaleDateString()})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              )}
              <div>
                <Label htmlFor="reason" className="text-gray-300">Reason</Label>
                <Textarea
                  id="reason"
                  placeholder="Enter reason for this transaction"
                  value={newTransaction.reason}
                  onChange={(e) => setNewTransaction(prev => ({ ...prev, reason: e.target.value }))}
                  className="bg-gray-800 border-gray-600 text-white"
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={() => handleAddTransaction()} className="bg-purple-600 hover:bg-purple-700">
                  Add Transaction
                </Button>
                <Button onClick={() => setShowAddForm(false)} variant="outline" className="border-gray-600 text-gray-300">
                  Cancel
                </Button>
              </div>
            </CardContent>
          </Card>
        ) : (
          <div className="mb-6">
            <Button onClick={() => setShowAddForm(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Add XP Transaction
            </Button>
          </div>
        )}

        {/* Transactions Table */}
        <div className="rounded-lg border border-gray-700 bg-gray-900/50">
          <Table>
            <TableHeader>
              <TableRow className="border-gray-700 hover:bg-gray-800/50">
                <TableHead className="text-purple-400">Date</TableHead>
                <TableHead className="text-purple-400">Type</TableHead>
                <TableHead className="text-purple-400">Amount</TableHead>
                <TableHead className="text-purple-400">Reason</TableHead>
                <TableHead className="text-purple-400">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-gray-400 py-8">
                    Loading XP history...
                  </TableCell>
                </TableRow>
              ) : transactions.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="text-center text-gray-400 py-8">
                    No XP transactions found
                  </TableCell>
                </TableRow>
              ) : (
                transactions.map((transaction) => (
                  <TableRow key={transaction.id} className="border-gray-700 hover:bg-gray-800/30">
                    <TableCell className="text-gray-300">
                      {formatDate(transaction.created_at)}
                    </TableCell>
                    <TableCell>
                      <Badge className={getTransactionTypeColor(transaction.transaction_type)}>
                        {TRANSACTION_TYPES.find(t => t.value === transaction.transaction_type)?.label || transaction.transaction_type}
                      </Badge>
                    </TableCell>
                    <TableCell className={`font-medium ${
                      transaction.amount > 0 ? 'text-green-400' : 'text-red-400'
                    }`}>
                      {transaction.amount > 0 ? '+' : ''}{transaction.amount}
                    </TableCell>
                    <TableCell className="text-gray-300 max-w-md truncate">
                      {transaction.reason}
                    </TableCell>
                    <TableCell>
                      {transaction.transaction_type !== 'initial' && (
                        <Button
                          onClick={() => handleDeleteTransaction(transaction.id)}
                          variant="ghost"
                          size="sm"
                          className="text-red-400 hover:text-red-300 hover:bg-red-900/20"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </DialogContent>
      
      <ManualRSVPModal
        open={showManualRSVP}
        onOpenChange={setShowManualRSVP}
        eventId={selectedEventId || ''}
        eventName={events.find(e => e.id === selectedEventId)?.title}
        characterId={characterId}
        characterName={characterName}
        onSuccess={async () => {
          await loadTransactions();
          onTransactionChange?.();
        }}
      />
    </Dialog>
  );
}
