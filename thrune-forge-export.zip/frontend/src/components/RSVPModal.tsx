import React, { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Coins, Star, User, Users } from "lucide-react";
import { toast } from "sonner";
import { apiClient } from "app";
import type { Character, CreateRSVPRequest, EventSummary, PlayerProfile } from "types";

export interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  event: EventSummary;
  onRSVPSuccess: () => void;
  rsvpMode?: 'create' | 'update';
  selectedRSVPForUpdate?: RSVPStatus | null;
}

type RSVPStatus = "going" | "maybe" | "not_attending";

export default function RSVPModal({ 
  open, 
  onOpenChange, 
  event, 
  onRSVPSuccess, 
  rsvpMode = 'create', 
  selectedRSVPForUpdate = null 
}: Props) {
  const [loading, setLoading] = useState(false);
  const [characters, setCharacters] = useState<Character[]>([]);
  const [playerProfile, setPlayerProfile] = useState<PlayerProfile | null>(null);
  const [loadingData, setLoadingData] = useState(true);
  
  // RSVP form state
  const [status, setStatus] = useState<RSVPStatus>("going");
  const [selectedCharacter, setSelectedCharacter] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [ticketXP, setTicketXP] = useState(0);
  const [candleXP, setCandleXP] = useState(0);
  
  // Get characters that are already RSVPed for this event
  const rsvpedCharacterIds = event.my_rsvps?.map(rsvp => rsvp.character_id).filter(Boolean) || [];
  
  // Filter characters based on RSVP mode
  const availableCharacters = characters.filter(character => {
    if (character.retired) return false;
    
    if (rsvpMode === 'create') {
      // For creating new RSVP ("Add another character"), exclude characters already RSVPed
      return !rsvpedCharacterIds.includes(character.id);
    } else {
      // For updating RSVP, only include characters that already have RSVPs
      return rsvpedCharacterIds.includes(character.id);
    }
  });
  
  // Load player data when modal opens
  useEffect(() => {
    if (open) {
      loadPlayerData();
      
      // Form initialization based on RSVP mode
      if (rsvpMode === 'create') {
        // For "Add another character" - always start fresh
        setStatus("going");
        setSelectedCharacter(null);
        setNotes("");
        setTicketXP(0);
        setCandleXP(0);
      } else if (rsvpMode === 'update' && selectedRSVPForUpdate) {
        // For "Update RSVP" - pre-fill with existing data
        setStatus(selectedRSVPForUpdate.status);
        setSelectedCharacter(selectedRSVPForUpdate.character_id || null);
        setNotes(selectedRSVPForUpdate.notes || "");
        setTicketXP(selectedRSVPForUpdate.ticket_xp || 0);
        setCandleXP(selectedRSVPForUpdate.candle_xp || 0);
      } else {
        // Fallback - reset form
        setStatus("going");
        setSelectedCharacter(null);
        setNotes("");
        setTicketXP(0);
        setCandleXP(0);
      }
    } else {
      // Reset form when modal closes
      setStatus("going");
      setSelectedCharacter(null);
      setNotes("");
      setTicketXP(0);
      setCandleXP(0);
    }
  }, [open, rsvpMode, selectedRSVPForUpdate]);
  
  const loadPlayerData = async () => {
    try {
      setLoadingData(true);
      
      // Load characters and player profile in parallel
      const [charactersResponse, profileResponse] = await Promise.all([
        apiClient.list_my_characters(),
        apiClient.get_my_player_profile()
      ]);
      
      const charactersData = await charactersResponse.json();
      const profileData = await profileResponse.json();
      
      setCharacters(charactersData || []);
      setPlayerProfile(profileData);
    } catch (err) {
      console.error('Failed to load player data:', err);
      toast.error('Failed to load player data');
    } finally {
      setLoadingData(false);
    }
  };
  
  const handleSubmit = async () => {
    try {
      setLoading(true);
      
      const rsvpData: CreateRSVPRequest = {
        status,
        character_id: selectedCharacter || undefined,
        notes: notes.trim() || undefined,
        ticket_xp: ticketXP,
        candle_xp: candleXP
      };
      
      const response = await apiClient.create_or_update_rsvp({ eventId: event.id }, rsvpData);
      await response.json();
      
      toast.success('RSVP updated successfully!');
      onRSVPSuccess();
      onOpenChange(false);
    } catch (err) {
      console.error('Failed to update RSVP:', err);
      toast.error('Failed to update RSVP');
    } finally {
      setLoading(false);
    }
  };
  
  // Calculate existing candle XP and cost difference
  const existingCandleXP = selectedCharacter 
    ? event.my_rsvps?.find(rsvp => rsvp.character_id === selectedCharacter)?.candle_xp || 0
    : 0;
  const candleCostDifference = (candleXP - existingCandleXP) * 10;
  const isRefund = candleCostDifference < 0;
  const costAmount = Math.abs(candleCostDifference);
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md bg-gradient-to-br from-purple-600/20 to-indigo-600/20 backdrop-blur-sm border-purple-500/30">
        <DialogHeader>
          <DialogTitle className="text-white text-xl">
            RSVP for {event.title}
          </DialogTitle>
        </DialogHeader>
        
        {loadingData ? (
          <div className="space-y-4">
            <div className="animate-pulse space-y-3">
              <div className="h-4 bg-slate-700 rounded w-3/4"></div>
              <div className="h-10 bg-slate-700 rounded"></div>
              <div className="h-4 bg-slate-700 rounded w-1/2"></div>
              <div className="h-20 bg-slate-700 rounded"></div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* RSVP Status */}
            <div className="space-y-2">
              <Label className="text-slate-300">Response</Label>
              <div className="grid grid-cols-3 gap-2">
                <Button
                  variant={status === 'going' ? 'default' : 'outline'}
                  onClick={() => setStatus('going')}
                  className={`text-xs ${
                    status === 'going'
                      ? 'bg-green-600 hover:bg-green-700'
                      : 'border-green-500/50 text-green-300 hover:bg-green-600/20'
                  }`}
                >
                  Going
                </Button>
                <Button
                  variant={status === 'maybe' ? 'default' : 'outline'}
                  onClick={() => setStatus('maybe')}
                  className={`text-xs ${
                    status === 'maybe'
                      ? 'bg-amber-600 hover:bg-amber-700'
                      : 'border-amber-500/50 text-amber-300 hover:bg-amber-600/20'
                  }`}
                >
                  Maybe
                </Button>
                <Button
                  variant={status === 'not_attending' ? 'default' : 'outline'}
                  onClick={() => setStatus('not_attending')}
                  className={`text-xs ${
                    status === 'not_attending'
                      ? 'bg-red-600 hover:bg-red-700'
                      : 'border-red-500/50 text-red-300 hover:bg-red-600/20'
                  }`}
                >
                  Not Attending
                </Button>                
              </div>
            </div>
            
            {/* Character Selection */}
            <div className="space-y-2">
              <Label className="text-slate-300 flex items-center gap-2">
                <User className="w-4 h-4" />
                Character *
              </Label>
              <Select value={selectedCharacter || ""} onValueChange={(value) => setSelectedCharacter(value || null)}>
                <SelectTrigger className="bg-slate-800/50 border-slate-600 text-white">
                  <SelectValue placeholder="Select a character" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-600">
                  {availableCharacters.map((character) => (
                    <SelectItem key={character.id} value={character.id} className="text-white">
                      {character.name} ({character.heritage_name})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            
            {/* XP Purchasing */}
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Star className="w-4 h-4 text-amber-400" />
                <Label className="text-slate-300">Experience Points</Label>
              </div>
              
              {/* Ticket XP */}
              <div className="space-y-2">
                <Label className="text-slate-400 text-sm">XP with Event Ticket (0-2)</Label>
                <div className="grid grid-cols-3 gap-2">
                  {[0, 1, 2].map((xp) => (
                    <Button
                      key={xp}
                      variant={ticketXP === xp ? 'default' : 'outline'}
                      onClick={() => setTicketXP(xp)}
                      className={`text-xs ${
                        ticketXP === xp
                          ? 'bg-blue-600 hover:bg-blue-700'
                          : 'border-blue-500/50 text-blue-300 hover:bg-blue-600/20'
                      }`}
                    >
                      {xp} XP
                    </Button>
                  ))}
                </div>
              </div>
              
              {/* Candle XP */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-slate-400 text-sm flex items-center gap-1">
                    <Coins className="w-3 h-3" />
                    XP with Candles (0-2)
                  </Label>
                  {playerProfile && (
                    <Badge variant="outline" className="border-amber-500/50 text-amber-300">
                      {playerProfile.candles_available} candles
                    </Badge>
                  )}
                </div>
                <div className="grid grid-cols-3 gap-2">
                  {[0, 1, 2].map((xp) => {
                    const costDifference = (xp - existingCandleXP) * 10;
                    const willGoNegative = playerProfile && costDifference > 0 && playerProfile.candles_available < costDifference;
                    
                    return (
                      <Button
                        key={xp}
                        variant={candleXP === xp ? 'default' : 'outline'}
                        onClick={() => setCandleXP(xp)}
                        className={`text-xs ${
                          candleXP === xp
                            ? 'bg-amber-600 hover:bg-amber-700'
                            : willGoNegative
                            ? 'border-red-500/50 text-red-300 hover:bg-red-600/20'
                            : 'border-amber-500/50 text-amber-300 hover:bg-amber-600/20'
                        }`}
                      >
                        {xp} XP
                        {costDifference !== 0 && (
                          <span className="text-xs ml-1">
                            ({costDifference > 0 ? '+' : ''}{costDifference}c)
                          </span>
                        )}
                      </Button>
                    );
                  })}
                </div>
                {candleCostDifference !== 0 && (
                  <p className={`text-xs ${
                    playerProfile && candleCostDifference > 0 && playerProfile.candles_available < candleCostDifference
                      ? 'text-red-400'
                      : isRefund
                      ? 'text-green-400'
                      : 'text-slate-400'
                  }`}>
                    {isRefund ? 'Refund' : 'Additional cost'}: {costAmount} candles
                    {playerProfile && candleCostDifference > 0 && playerProfile.candles_available < candleCostDifference && (
                      <span className="ml-2">
                        (Will result in negative balance: {playerProfile.candles_available - candleCostDifference})
                      </span>
                    )}
                  </p>
                )}
              </div>
            </div>
            
            {/* Notes */}
            <div className="space-y-2">
              <Label className="text-slate-300">Notes (Optional)</Label>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Any additional notes or comments..."
                className="bg-slate-800/50 border-slate-600 text-white placeholder:text-slate-400"
                rows={3}
              />
            </div>
            
            <Separator className="bg-slate-600" />
            
            {/* Actions */}
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={() => onOpenChange(false)}
                className="flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={loading || !selectedCharacter}
                className="flex-1 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700"
              >
                {loading ? 'Updating...' : 'Update RSVP'}
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
