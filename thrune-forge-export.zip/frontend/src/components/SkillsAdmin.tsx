


import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { Plus, Edit2, Trash2, Zap } from 'lucide-react';
import { toast } from 'sonner';
import { apiClient } from 'app';
import { SkillResponse, SkillCreate, SkillUpdate } from 'types';

interface FormData {
  name: string;
  description: string;
  hidden: boolean;
  admin_only: boolean;
  prerequisiteSkillIds: string[];
  prerequisite_count: number;
  max_purchases: number;
}

const SkillsAdmin = () => {
  const [skills, setSkills] = useState<SkillResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [editingSkill, setEditingSkill] = useState<SkillResponse | null>(null);
  const [formData, setFormData] = useState<FormData>({
    name: '',
    description: '',
    hidden: false,
    admin_only: false,
    prerequisiteSkillIds: [],
    prerequisite_count: 1,
    max_purchases: 1
  });
  const [formLoading, setFormLoading] = useState(false);
  // Admin should always see all skills - remove showHidden toggle
  // const [showHidden, setShowHidden] = useState(false);

  // Load skills
  const loadSkills = async () => {
    try {
      setLoading(true);
      // Admin always sees all skills including hidden ones
      const response = await apiClient.list_skills({ show_hidden: true });
      const data = await response.json();
      const skillsList = data.skills || [];
      setSkills(skillsList.sort((a, b) => a.name.localeCompare(b.name)));
    } catch (error) {
      toast.error('Failed to load skills');
      console.error('Error loading skills:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadSkills();
  }, []); // Remove showHidden dependency

  // Reset form data
  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      hidden: false,
      admin_only: false,
      prerequisiteSkillIds: [],
      prerequisite_count: 1,
      max_purchases: 1
    });
    setEditingSkill(null);
  };

  // Open create dialog
  const openCreateDialog = () => {
    resetForm();
    setIsCreateDialogOpen(true);
  };

  // Open edit dialog
  const openEditDialog = async (skill: SkillResponse) => {
    try {
      // Get full skill details including prerequisites
      const response = await apiClient.get_skill({ skillId: skill.id });
      const fullSkill = await response.json();
      
      setFormData({
        name: fullSkill.name,
        description: fullSkill.description,
        hidden: fullSkill.hidden,
        admin_only: fullSkill.admin_only || false,
        prerequisiteSkillIds: fullSkill.prerequisites.map((p: SkillResponse) => p.id),
        prerequisite_count: fullSkill.prerequisite_count || 1,
        max_purchases: fullSkill.max_purchases || 1
      });
      setEditingSkill(fullSkill);
      setIsCreateDialogOpen(true);
    } catch (error: any) {
      console.error('Error loading skill:', error);
      toast.error('Failed to load skill details');
    }
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim() || !formData.description.trim()) {
      toast.error('Name and description are required');
      return;
    }

    // Validate prerequisite count
    if (formData.prerequisiteSkillIds.length > 0 && formData.prerequisite_count > formData.prerequisiteSkillIds.length) {
      toast.error(`Prerequisite count cannot exceed ${formData.prerequisiteSkillIds.length} selected prerequisites`);
      return;
    }

    setFormLoading(true);
    try {
      if (editingSkill) {
        // Update existing skill
        const updateData = {
          name: formData.name,
          description: formData.description,
          hidden: formData.hidden,
          admin_only: formData.admin_only,
          prerequisite_skill_ids: formData.prerequisiteSkillIds,
          prerequisite_count: formData.prerequisite_count,
          max_purchases: formData.max_purchases
        };
        await apiClient.update_skill({ skillId: editingSkill.id }, updateData);
        toast.success('Skill updated successfully');
      } else {
        // Create new skill
        const createData = {
          name: formData.name,
          description: formData.description,
          hidden: formData.hidden,
          admin_only: formData.admin_only,
          prerequisite_skill_ids: formData.prerequisiteSkillIds,
          prerequisite_count: formData.prerequisite_count,
          max_purchases: formData.max_purchases
        };
        await apiClient.create_skill(createData);
        toast.success('Skill created successfully');
      }
      
      setIsCreateDialogOpen(false);
      resetForm();
      loadSkills();
    } catch (error: any) {
      // Handle different error response structures
      let errorMessage = `Failed to ${editingSkill ? 'update' : 'create'} skill`;
      
      if (error?.error?.detail) {
        // apiClient stores error in error.detail
        errorMessage = error.error.detail;
      } else if (typeof error?.error === 'string') {
        // Sometimes error is directly a string
        errorMessage = error.error;
      } else if (error?.message) {
        // Fallback to error.message
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      console.error('Error saving skill:', error);
    } finally {
      setFormLoading(false);
    }
  };

  // Handle delete
  const handleDelete = async (skill: SkillResponse) => {
    try {
      await apiClient.delete_skill({ skillId: skill.id });
      toast.success('Skill deleted successfully');
      loadSkills();
    } catch (error: any) {
      // Handle different error response structures
      let errorMessage = 'Failed to delete skill';
      
      if (error?.error?.detail) {
        // apiClient stores error in error.detail
        errorMessage = error.error.detail;
      } else if (typeof error?.error === 'string') {
        // Sometimes error is directly a string
        errorMessage = error.error;
      } else if (error?.message) {
        // Fallback to error.message
        errorMessage = error.message;
      }
      
      toast.error(errorMessage);
      console.error('Error deleting skill:', error);
    }
  };

  // Toggle prerequisite selection
  const togglePrerequisite = (skillId: string) => {
    setFormData(prev => ({
      ...prev,
      prerequisiteSkillIds: prev.prerequisiteSkillIds.includes(skillId)
        ? prev.prerequisiteSkillIds.filter(id => id !== skillId)
        : [...prev.prerequisiteSkillIds, skillId]
    }));
  };

  // Get available skills for prerequisites (exclude current skill if editing)
  const getAvailablePrerequisites = () => {
    return skills.filter(skill => 
      skill.id !== editingSkill?.id
      // Note: Don't filter hidden skills here - admins can set them as prerequisites
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-purple-100">Skills Management</h2>
          <p className="text-purple-300">Manage LARP skills and their prerequisite chains</p>
        </div>
        <div className="flex gap-2">
          <Button 
            onClick={openCreateDialog}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Skill
          </Button>
        </div>
      </div>

      {/* Skills Grid */}
      {loading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="bg-gray-800/40 border-gray-700 animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-gray-700 rounded"></div>
                <div className="h-3 bg-gray-700 rounded w-2/3"></div>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="h-3 bg-gray-700 rounded"></div>
                <div className="h-3 bg-gray-700 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {skills.map((skill) => (
            <Card key={skill.id} className="bg-gray-800/40 border-gray-700 hover:bg-gray-800/60 transition-colors">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <CardTitle className="text-lg text-purple-100 flex items-center gap-2">
                    {skill.name}
                    {skill.hidden && (
                      <Badge variant="secondary" className="bg-yellow-600/20 text-yellow-300 border-yellow-600/30">
                        <Zap className="w-3 h-3 mr-1" />
                        Hidden
                      </Badge>
                    )}
                  </CardTitle>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => openEditDialog(skill)}
                      className="h-8 w-8 p-0 hover:bg-purple-600/20"
                    >
                      <Edit2 className="w-4 h-4 text-purple-300" />
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-8 w-8 p-0 hover:bg-red-600/20"
                        >
                          <Trash2 className="w-4 h-4 text-red-400" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent className="bg-gray-900 border-gray-700">
                        <AlertDialogHeader>
                          <AlertDialogTitle className="text-purple-100">Delete Skill</AlertDialogTitle>
                          <AlertDialogDescription className="text-gray-300">
                            Are you sure you want to delete "{skill.name}"? This action cannot be undone.
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel className="bg-gray-700 hover:bg-gray-600 text-gray-200 border-gray-600">
                            Cancel
                          </AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(skill)}
                            className="bg-red-600 hover:bg-red-700"
                          >
                            Delete
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
                <CardDescription className="text-gray-400">
                  {skill.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {skill.prerequisites.length > 0 && (
                    <Badge variant="outline" className="border-blue-500/30 text-blue-300">
                      {skill.prerequisites.length} prerequisite{skill.prerequisites.length !== 1 ? 's' : ''} required
                    </Badge>
                  )}
                  {skill.max_purchases > 1 && (
                    <Badge variant="outline" className="border-green-500/30 text-green-300">
                      Max {skill.max_purchases} purchases
                    </Badge>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {skills.length === 0 && !loading && (
        <Card className="bg-gray-800/40 border-gray-700">
          <CardContent className="flex flex-col items-center justify-center py-8">
            <Zap className="w-12 h-12 text-gray-500 mb-4" />
            <h3 className="text-lg font-semibold text-gray-300 mb-2">No Skills Found</h3>
            <p className="text-gray-500 text-center mb-4">
              {showHidden ? 'No skills have been created yet.' : 'No visible skills found. Try showing hidden skills.'}
            </p>
            <Button 
              onClick={openCreateDialog}
              className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create First Skill
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Create/Edit Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-gray-900 border-gray-700 max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-purple-100">
              {editingSkill ? 'Edit Skill' : 'Create New Skill'}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              {editingSkill ? 'Update skill details and prerequisites.' : 'Add a new skill to the LARP system.'}
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-purple-100">Name *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Skill name"
                  className="bg-gray-800 border-gray-600 text-gray-100"
                  required
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="hidden"
                    checked={formData.hidden}
                    onCheckedChange={(checked) => setFormData(prev => ({ ...prev, hidden: !!checked }))}
                    className="border-gray-600"
                  />
                  <Label htmlFor="hidden" className="text-purple-100 flex items-center gap-2">
                    <Zap className="w-4 h-4" />
                    Hidden Skill
                  </Label>
                </div>
                <p className="text-sm text-gray-400">Hidden skills need an admin to add them, not available in character create.</p>
              </div>
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="description" className="text-purple-100">Description *</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe what this skill does..."
                className="bg-gray-800 border-gray-600 text-gray-100 min-h-[100px]"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label className="text-purple-100">Prerequisites</Label>
              <div className="max-h-48 overflow-y-auto bg-gray-800 border border-gray-600 rounded-md p-3">
                {getAvailablePrerequisites().length === 0 ? (
                  <p className="text-gray-400 text-sm text-center py-4">
                    No skills available as prerequisites
                  </p>
                ) : (
                  <div className="space-y-2">
                    {getAvailablePrerequisites().map((skill) => (
                      <div key={skill.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`prereq-${skill.id}`}
                          checked={formData.prerequisiteSkillIds.includes(skill.id)}
                          onCheckedChange={() => togglePrerequisite(skill.id)}
                          className="border-gray-600"
                        />
                        <Label htmlFor={`prereq-${skill.id}`} className="text-gray-200 text-sm flex-1">
                          {skill.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>
              <div className="flex justify-between items-center text-sm text-gray-400">
                <span>
                  Selected: {formData.prerequisiteSkillIds.length} prerequisite{formData.prerequisiteSkillIds.length !== 1 ? 's' : ''}
                </span>
                {formData.prerequisiteSkillIds.length > 0 && (
                  <span className="text-purple-300">
                    Requires {formData.prerequisite_count} of {formData.prerequisiteSkillIds.length}
                  </span>
                )}
              </div>
            </div>
            
            {/* Prerequisite Count Field */}
            {formData.prerequisiteSkillIds.length > 1 && (
              <div className="space-y-2">
                <Label htmlFor="prerequisite_count" className="text-purple-100">
                  Prerequisite Count Required *
                </Label>
                <select
                  id="prerequisite_count"
                  value={formData.prerequisite_count}
                  onChange={(e) => setFormData(prev => ({ ...prev, prerequisite_count: parseInt(e.target.value) }))}
                  className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-gray-100 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  required
                >
                  {Array.from({ length: formData.prerequisiteSkillIds.length }, (_, i) => i + 1).map(num => (
                    <option key={num} value={num}>
                      {num} of {formData.prerequisiteSkillIds.length} prerequisites required
                    </option>
                  ))}
                </select>
                <p className="text-sm text-gray-400">
                  Player must have {formData.prerequisite_count} of the selected prerequisites to unlock this skill
                </p>
              </div>
            )}
            
            {/* Max Purchases Field */}
            <div className="space-y-2">
              <Label htmlFor="max_purchases" className="text-purple-100">
                Maximum Purchases *
              </Label>
              <select
                id="max_purchases"
                value={formData.max_purchases}
                onChange={(e) => setFormData(prev => ({ ...prev, max_purchases: parseInt(e.target.value) }))}
                className="w-full px-3 py-2 bg-gray-800 border border-gray-600 rounded-md text-gray-100 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                required
              >
                {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
                  <option key={num} value={num}>
                    {num} {num === 1 ? 'purchase' : 'purchases'} allowed
                  </option>
                ))}
              </select>
              <p className="text-sm text-gray-400">
                {formData.max_purchases === 1 
                  ? "This skill can only be purchased once"
                  : `Players can purchase this skill up to ${formData.max_purchases} times`}
              </p>
            </div>
            
            <div className="flex justify-end gap-2 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsCreateDialogOpen(false)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={formLoading}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                {formLoading ? 'Saving...' : editingSkill ? 'Update Skill' : 'Create Skill'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default SkillsAdmin;
