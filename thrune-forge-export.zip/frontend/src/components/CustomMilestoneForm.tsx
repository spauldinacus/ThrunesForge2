import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface CustomMilestoneFormProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSubmit: (data: CustomMilestoneFormData) => void;
  initialData?: Partial<CustomMilestoneFormData>;
  isEdit?: boolean;
}

export interface CustomMilestoneFormData {
  name: string;
  description: string;
  category: string;
  targetProgress?: number;
  currentProgress?: number;
  notes?: string;
  sharedWithStaff: boolean;
}

const MILESTONE_CATEGORIES = [
  { value: 'roleplay', label: 'Roleplay' },
  { value: 'story', label: 'Story' },
  { value: 'social', label: 'Social' },
  { value: 'combat', label: 'Combat' },
  { value: 'mechanical', label: 'Mechanical' },
  { value: 'character_development', label: 'Character Development' },
  { value: 'general', label: 'General' },
];

export function CustomMilestoneForm({
  open,
  onOpenChange,
  onSubmit,
  initialData,
  isEdit = false,
}: CustomMilestoneFormProps) {
  const [formData, setFormData] = useState<CustomMilestoneFormData>({
    name: initialData?.name || '',
    description: initialData?.description || '',
    category: initialData?.category || 'general',
    targetProgress: initialData?.targetProgress,
    currentProgress: initialData?.currentProgress || 0,
    notes: initialData?.notes || '',
    sharedWithStaff: initialData?.sharedWithStaff || false,
  });

  // Update form data when initialData changes (for edit mode)
  useEffect(() => {
    if (initialData) {
      setFormData({
        name: initialData.name || '',
        description: initialData.description || '',
        category: initialData.category || 'general',
        targetProgress: initialData.targetProgress,
        currentProgress: initialData.currentProgress || 0,
        notes: initialData.notes || '',
        sharedWithStaff: initialData.sharedWithStaff || false,
      });
    }
  }, [initialData, open]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? 'Edit' : 'Create'} Custom Milestone</DialogTitle>
          <DialogDescription>
            Track your personal character goals and roleplay achievements.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Milestone Name *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Make 5 new allies"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Describe what this milestone means for your character..."
              rows={3}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value })}
              >
                <SelectTrigger id="category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {MILESTONE_CATEGORIES.map((cat) => (
                    <SelectItem key={cat.value} value={cat.value}>
                      {cat.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="targetProgress">Target Progress (optional)</Label>
              <Input
                id="targetProgress"
                type="number"
                min="1"
                value={formData.targetProgress || ''}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    targetProgress: e.target.value ? parseInt(e.target.value) : undefined,
                  })
                }
                placeholder="e.g., 5"
              />
            </div>
          </div>

          {isEdit && formData.targetProgress && (
            <div className="space-y-2">
              <Label htmlFor="currentProgress">Current Progress</Label>
              <Input
                id="currentProgress"
                type="number"
                min="0"
                max={formData.targetProgress}
                value={formData.currentProgress || 0}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    currentProgress: parseInt(e.target.value) || 0,
                  })
                }
              />
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Add any additional context or reflections..."
              rows={2}
            />
          </div>

          <div className="flex items-center justify-between rounded-lg border border-border/50 p-4">
            <div className="space-y-0.5">
              <Label htmlFor="share">Share with Staff</Label>
              <p className="text-sm text-muted-foreground">
                Allow staff to view this milestone
              </p>
            </div>
            <Switch
              id="share"
              checked={formData.sharedWithStaff}
              onCheckedChange={(checked) =>
                setFormData({ ...formData, sharedWithStaff: checked })
              }
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit">{isEdit ? 'Update' : 'Create'} Milestone</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
